
#ifndef Client_socketIp_Host_h
#define Client_socketIp_Host_h

#define IP_ADDRESS "192.168.1.101"
#define IP_HOST 6666
#define MAX_RECV_SIZE 1024

#endif
