#ifndef __HttpTest__TestCpp__
#define __HttpTest__TestCpp__

#include <iostream>

#include "cocos2d.h"
using namespace cocos2d;
class testOC:public CCLayer{
public:
    
    virtual bool init();
    void initOc();
    void firefly();
    CREATE_FUNC(testOC);
};
#endif /* defined(__HttpTest__TestCpp__) */
