
#ifndef client1_commond_h
#define client1_commond_h

#define CURRENTLAYER 185

#endif
