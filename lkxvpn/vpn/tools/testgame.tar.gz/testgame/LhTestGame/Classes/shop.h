//
//  shop.h
//  LhTestGame
//
//  Created by lh on 13-10-25.
//
//

#ifndef __LhTestGame__shop__
#define __LhTestGame__shop__

#include <iostream>
#include "cocos2d.h"
using namespace cocos2d;
#endif /* defined(__LhTestGame__shop__) */
