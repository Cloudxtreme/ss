#coding:utf8
'''
Created on 2013-10-25

@author: lan (www.9miao.com)
'''

def loadModule():
    import gateservice
    from gaterootapp import *
    from localservice import *