#coding:utf8
'''
Created on 2013-10-25

@author: lan (www.9miao.com)
'''
from firefly.dbentrust.dbpool import dbpool
from MySQLdb.cursors import DictCursor

ALL_SKILL_TEMPLATE = {}
ALL_SKILL_INFO = {}
SKILL_GROUP = {}
ALL_BUFF_INFO = {}
PROFESSION_SKILLGROUP = {}

#buff和buff直接的效果配置
BUFF_BUFF = {}
#buff对技能加成配置表
BUFF_SKILL = {}

def getBuffOffsetInfo():
    '''获取所有buff之间效果的信息配置
    '''
    global BUFF_BUFF
    sql = "SELECT * FROM tb_buff_buff"
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result=cursor.fetchall()
    cursor.close()
    conn.close()
    for offset in result:
        if not BUFF_BUFF.has_key(offset['buffId']):
            BUFF_BUFF[offset['buffId']] = {}
        BUFF_BUFF[offset['buffId']][offset['tbuffId']] = offset
    
def getBuffAddition():
    '''获取buff对技能的加成
    '''
    global BUFF_SKILL
    sql = "SELECT * FROM tb_buff_skill"
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result=cursor.fetchall()
    cursor.close()
    conn.close()
    for addition in result:
        if not BUFF_SKILL.has_key(addition['buffId']):
            BUFF_SKILL[addition['buffId']] = {}
        BUFF_SKILL[addition['buffId']][addition['skillId']] = addition['addition']

def getSkillEffectByID(skillEffectID):
    '''获取技能效果ID'''
    sql = "SELECT * FROM tb_skill_effect where effectId=%d"%skillEffectID
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result=cursor.fetchone()
    cursor.close()
    conn.close()
    return result

def getALLSkillTemplate():
    """
    """
    global ALL_SKILL_TEMPLATE
    sql="select * from `tb_skill_template`"
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result=cursor.fetchall()
    cursor.close()
    conn.close()
    for _skill in result:
        ALL_SKILL_TEMPLATE[_skill['id']] = _skill

def getAllSkill():
    '''初始化技能信息
    #职业技能组
    #技能池
    #技能组
    '''
    global  ALL_SKILL_INFO,SKILL_GROUP,PROFESSION_SKILLGROUP
    sql = "SELECT * FROM tb_skill_info"
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    for skill in result:
        effectInfo = getSkillEffectByID(skill['effect'])
        skill['effect'] = effectInfo
        ALL_SKILL_INFO[skill['skillId']] = skill
        if not SKILL_GROUP.has_key(skill['skillGroup']):
            SKILL_GROUP[skill['skillGroup']] = {}
        SKILL_GROUP[skill['skillGroup']][skill['level']] = skill
    #初始化职业技能组ID
    for groupID in SKILL_GROUP:
        skillInfo = SKILL_GROUP[groupID].get(1)
        profession = skillInfo.get('profession',0)
        if not PROFESSION_SKILLGROUP.has_key(profession):
            PROFESSION_SKILLGROUP[profession] = []
        PROFESSION_SKILLGROUP[profession].append(groupID)
        
def getBuffEffect(buffEffectID):
    '''获取buff效果'''
    sql = "SELECT * FROM tb_buff_effect where buffEffectID = %d"%buffEffectID
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result=cursor.fetchone()
    cursor.close()
    conn.close()
    return result
        
def getAllBuffInfo():
    '''获取所有技能的信息'''
    global ALL_BUFF_INFO
    sql = "SELECT * FROM tb_buff_info"
    conn = dbpool.connection()
    cursor = conn.cursor(cursorclass=DictCursor)
    cursor.execute(sql)
    result=cursor.fetchall()
    cursor.close()
    conn.close()
    for buff in result:
        ALL_BUFF_INFO[buff['buffId']] = buff
        effectInfo = getBuffEffect(buff['buffEffectID'])
        ALL_BUFF_INFO[buff['buffId']]['buffEffects'] = effectInfo

