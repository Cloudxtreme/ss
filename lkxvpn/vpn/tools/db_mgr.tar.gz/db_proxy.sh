#!/bin/sh

proc=`ps -ef | grep -v grep| grep mysql-proxy | grep 4040 | wc -l`

if [ $proc -eq 0 ]
then
        echo "run 4040"
        mysql-proxy --proxy-backend-addresses=61.142.208.101 --proxy-address=:4040 --proxy-lua-script=/opt/db_mgr/file/script/efly-mysql-proxy.lua &
fi

#4041

#4042

#...
