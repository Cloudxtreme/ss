<?php

	echo md5("112.90.54.46:8504/patch2.ls.sntaro.com/check/0101003/liangshan_3.1.8.351_to_3.1.8.353.exe");


?>
