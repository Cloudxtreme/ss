#!/bin/sh

log_file="/opt/cdn_db_mgr/log/proxy/4040/2013-04-16.log"

if [ -f ${log_file} ]; then
	echo "exits"
fi
