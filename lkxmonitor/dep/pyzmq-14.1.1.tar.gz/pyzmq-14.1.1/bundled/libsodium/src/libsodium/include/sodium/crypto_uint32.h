#ifndef crypto_uint32_H
#define crypto_uint32_H

#include <stdint.h>

typedef uint32_t crypto_uint32;

#endif
