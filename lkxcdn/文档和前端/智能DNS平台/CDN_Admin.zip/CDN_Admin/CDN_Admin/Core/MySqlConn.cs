﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace CDN_Admin.Core
{
    public class MySqlConn
    {
        private static string _MYSQL_SERVER = String.Empty;
      //  private static string _MYSQL_SERVER1 = String.Empty;
        /// <summary>
        /// dtl_server数据库连接串
        /// </summary>
        public static string MYSQL_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_SERVER))
                {
                    if (ConfigurationManager.ConnectionStrings["MySql_Server"] == null)
                    {
                        throw new Exception("the config node 'MySql_Server' is required in web.config");
                    }

                    lock (_MYSQL_SERVER)
                    {
                        _MYSQL_SERVER = ConfigurationManager.ConnectionStrings["MySql_Server"].ConnectionString;
                    }
                }
                return _MYSQL_SERVER;
            }
        }

        //public static string MYSQL_SERVER1
        //{
        //    get
        //    {
        //        if (String.IsNullOrEmpty(_MYSQL_SERVER1))
        //        {
        //            if (ConfigurationManager.ConnectionStrings["MySql_Server1"] == null)
        //            {
        //                throw new Exception("the config node 'MySql_Server1' is required in web.config");
        //            }

        //            lock (_MYSQL_SERVER1)
        //            {
        //                _MYSQL_SERVER1 = ConfigurationManager.ConnectionStrings["MySql_Server1"].ConnectionString;
        //            }
        //        }
        //        return _MYSQL_SERVER1;
        //    }
        //}

    }
}