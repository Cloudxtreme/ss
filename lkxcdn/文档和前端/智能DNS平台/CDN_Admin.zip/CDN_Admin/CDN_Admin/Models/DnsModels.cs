﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CDN_Admin.Models
{
    public class DnsModels
    {
        [Required(ErrorMessage = "id是必选项！")]
        [Display(Name = "ID")]
        public int id { get; set; }

        [Required(ErrorMessage = "域名是必选项！")]
        [Display(Name = "域名")]
        public string name { get; set; }

        [Required(ErrorMessage = "ttl是必选项！")]
        [Display(Name = "ttl")]
        public int ttl { get; set; }

        [Required(ErrorMessage = "rdtype是必选项！")]
        [Display(Name = "rdtype")]
        public string rdtype { get; set; }

        [Required(ErrorMessage = "rdata是必选项！")]
        [Display(Name = "rdata")]
        public string rdata { get; set; }

        [Required(ErrorMessage = "tablename是必选项！")]
        [Display(Name = "tablename")]
        public string tablename { get; set; }

        [Required(ErrorMessage = "type是必选项！")]
        [Display(Name = "type")]
        public string type { get; set; }

        [Required(ErrorMessage = "status是必选项！")]
        [Display(Name = "status")]
        public string status { get; set; }

        [Required(ErrorMessage = "desc是必选项！")]
        [Display(Name = "desc")]
        public string desc { get; set; }

        [Required(ErrorMessage = "lasttime是必选项！")]
        [Display(Name = "lasttime")]
        public DateTime lasttime { get; set; }

        public string ShowOrNot { get; set; }
    }
}