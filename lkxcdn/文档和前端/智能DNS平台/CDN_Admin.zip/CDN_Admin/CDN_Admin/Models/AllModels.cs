﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Admin.Models
{
    public class AllModels
    {
        public int id { get; set; }

        public int dnsid { get; set; }

        public string ttl { get; set; }

        public string rdtype { get; set; }

        public string rdata { get; set; }

        public string tablename { get; set; }

        public string type { get; set; }

        public string status { get; set; }

        public string lasttime { get; set; }

        public string name { get; set; }

      //  public string status { get; set; }

        public string desc { get; set; }

        public string zone { get; set; }

        public string local { get; set; }

        public string nettype { get; set; }
    }
}