﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Admin.Models
{
    public class ShowModels
    {
        public int id { get; set; }

        public int ttl { get; set; }

        public string ip { get; set; }

        public string nettype { get; set; }

        public string lasttime { get; set; }

        public string local { get; set; }

        public string desc { get; set; }

        public bool IsSet { get; set; }
    }
}