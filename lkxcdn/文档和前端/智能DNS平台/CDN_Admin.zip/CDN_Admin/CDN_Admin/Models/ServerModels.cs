﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Admin.Models
{
    public class ServerModels
    {
        public int id { get; set; }

        public string ip { get; set; }

        public string nettype { get; set; }

        public string zone { get; set; }

        public string local { get; set; }

        public string desc { get; set; }

    }
}