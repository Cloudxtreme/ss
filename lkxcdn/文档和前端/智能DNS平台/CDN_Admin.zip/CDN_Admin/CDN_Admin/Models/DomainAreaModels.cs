﻿using System.ComponentModel.DataAnnotations;

namespace CDN_Admin.Models
{
    public class DomainAreaModels
    {
        [Required(ErrorMessage = "id是必选项！")]
        public int id { get; set; }

        [Required(ErrorMessage = "域名是必选项！")]
        public string domain { get; set; }

        public string area { get; set; }

        public string city { get; set; }

        public string nettype { get; set; }

        public string tablename { get; set; }
    }
}