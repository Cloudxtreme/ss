﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Text;
using System.Data;

using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using CDN_Admin.Models;
using System.Collections;
using CDN_Admin.Core;

namespace CDN_Admin.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            HttpContext.Session["user"] = null;
            Cookie Cookie = new Cookie();
            ViewData["name"] = "";
            ViewData["pwd"] = "";
            string name = Cookie.getCookie("dns_name");//取值
            string pwd = Cookie.getCookie("dns_pwd");
            if (!string.IsNullOrEmpty(name))
            {
                ViewData["name"] = name;
            }
            if (!string.IsNullOrEmpty(pwd))
            {
                ViewData["pwd"] = pwd;
            }
            return View();
        }

        public ActionResult AreaSet(string domain_id="", string domain="",string city="",string nettype="",string key="")
        {
            if (HttpContext.Session["user"] != null)
            {
                DomainAreaModels model = new DomainAreaModels();  
                model.id = int.Parse(domain_id.Trim());
                model.domain = domain.Trim();
                Dictionary<string, List<DomainAreaModels>> Area = GetArea(); //获取全部区域城市
                List<ServerModels> serverList = GetServerList();  //获取全部服务器列表

                //获取指定域名已经覆盖的服务器列表
                if (serverList.Count > 0 && city.Length > 0)
                {
                    List<DnsModels> data = GetListDns(domain_id.Trim());
                    //Dictionary<string, List<ShowModels>> showDic = new Dictionary<string, List<ShowModels>>();
                    List<ShowModels> showDic = new List<ShowModels>();
                    showDic = GetAreaSet(serverList, data, city, nettype);

                    ViewData["showData"] = showDic;

                    ViewData["city_nettype"] = city + "_" + nettype;
                }
                ViewData["key"] = key;
                ViewData["area"] = Area;
                return View(model);
            }
            else
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        public ActionResult AreaIP(string domain_id = "", string domain = "")
        {
            if (HttpContext.Session["user"] != null)
            {
                DomainAreaModels model = new DomainAreaModels();
                model.id = int.Parse(domain_id.Trim());
                model.domain = domain.Trim();

                List<ServerModels> serverList = GetServerList();  //获取全部服务器列表

                //获取指定域名已经覆盖的服务器列表
                if (serverList.Count > 0)
                {
                    List<DnsModels> data = GetListDns(domain_id.Trim());
                 
                    List<ShowModels> showDic = new List<ShowModels>();
                    showDic = GetAreaIp(serverList, data);

                    ViewData["showData"] = showDic;
                }
                ViewData["domain"] = domain.Trim();
                return View(model);
            }
            else
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        public ActionResult Search(string Ip = "",int intSort=0)
        {
            if (HttpContext.Session["user"] != null)
            {
                List<AllModels> model = new List<AllModels>();

                model = GetModelByIp(Ip,intSort);  //获取全部服务器列表

                ViewData["ip"] = Ip;
                ViewData["sort"] = intSort;
                ViewData["showData"] = model;

                return View(model);
            }
            else
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        //public ActionResult ShowData(string city, string nettype)
        //{
        //    if (HttpContext.Session["user"] != null)
        //    {
        //        DomainAreaModels model = new DomainAreaModels();
        //        //model.id = int.Parse(domain_id.Trim());
        //        model.id = 31;
        //        //model.domain = domain.Trim();
        //        model.domain = "cdn.0505u.com.cache.rightgo.net";
        //        Dictionary<string, List<DomainAreaModels>> Area = GetArea(); //获取全部区域城市
        //        List<ServerModels> serverList = GetServerList();  //获取全部服务器列表
        //        List<DnsModels> data = GetListDns("31"); //获取指定域名已经覆盖的服务器列表
        //        if (serverList.Count > 0)
        //        {
        //            //Dictionary<string, List<ShowModels>> showDic = new Dictionary<string, List<ShowModels>>();
        //            List<ShowModels> showDic = new List<ShowModels>();
        //            showDic = GetAreaSet(serverList, data, city, nettype);
        //            //foreach (string area in Area.Keys) //循环8个区域
        //            //{
        //            //    foreach (DomainAreaModels citySet in Area[area])  //循环每个省份（城市）
        //            //    {
        //            //        List<ShowModels> ShowList = GetAreaSet(serverList, data, citySet.city, citySet.nettype);
        //            //        showDic.Add(ShowList[citySet]);
        //            //    }
        //            //}
        //            ViewData["showData"] = showDic;
        //        }
        //       // ViewData["area"] = Area;
        //        return View();
        //        //return "true";
        //    }
        //    else
        //    {
        //        return RedirectToAction("LogTimeOut", "Home");
        //       // return "error";
        //    }
        //}

        public ActionResult About()
        {
            return View();
        }
        public ActionResult LogTimeOut()
        {
            return View();
        }
        public ActionResult dns_Mgr(int page=1)
        {
            try
            {
                if (GetUserInfo())
                {
                    ViewData["citys"] = GetCity(); //获取全部区域城市
                    ViewData["page"] = page;
                    ViewData["totalNum"] = GetDomainNum();
                    ViewData["domainList"] = GetDomainListByPage(page);

                    string user = HttpContext.Session["user"].ToString();
                    ViewData["user"] = user;
                    return View();
                }
                else
                {
                    return RedirectToAction("GetInfoErr", "Home");
                }
            }
            catch
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        public ActionResult GetInfoErr()
        {
            ViewData["err"] = "报错信息";
            return View();
        }

        //Ajax post method
        [HttpPost, ActionName("StopServer")]
        public string StopServer(string DnsId)
        {
            try
            {
                MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
               // MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                if (mycn != null)
                {
                    try
                    {
                        StringBuilder strSql = new StringBuilder();
                        mycn.Open();
                        strSql.Append("update `dns_list` set `status`='false' where `id`='" + DnsId.Trim() + "'");
                        MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                        int result = cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        //if (1 == result)
                        {
                            strSql.Clear();
                            strSql.Append("delete from ip_list where `dnsid` = '" + DnsId.Trim() + "'");
                            MySqlCommand dele_cmd = new MySqlCommand(strSql.ToString(), mycn);
                            int rs = dele_cmd.ExecuteNonQuery();
                            dele_cmd.Dispose();
                        }
                        mycn.Close();
                        return "设置成功！";
                    }
                    catch
                    {
                        if (mycn != null) mycn.Close();
                    }
                }
            }
            catch { }
            return "设置失败！";
        }

        [HttpPost, ActionName("FastAllDele")]
        public string FastAllDele(string DnsId, string Ip)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
          //  MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            try
            {
                mycn.Open();
                if (DnsId == "") //全部dns
                {
                    string query = "delete from `ip_list` where `rdata`='" + Ip + "'";
                    MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                    insetCmd.ExecuteNonQuery();
                    insetCmd.Dispose();
                    return "删除成功！";
                }
                else
                {
                    string query = "delete from `ip_list` where `dnsid` = '" + DnsId.Trim() + "' and `rdata`='" + Ip + "'";
                    MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                    insetCmd.ExecuteNonQuery();
                    insetCmd.Dispose();
                    return "删除成功！";
                }
            }
            catch (Exception e)
            {
                mycn.Close();
                return e.Message;
            }
        }

        [HttpPost, ActionName("FastDele")]
        public string FastDele(string DnsId, string Ip, string Netype, string City)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
         //   MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            try
            {
                //string table = GetTableByCity(City.Trim() + "_" + Netype.Trim());

                List<string> tableList = new List<string>();
                tableList = GetTableListByCityNettype(City.Trim(), Netype.Trim());

                mycn.Open();

                for (int i=0;i<tableList.Count;i++)
                {
                    if (DnsId == "") //全部dns
                    {
                        //string strSql = "SELECT * FROM `dns_list` where `status`='true' order by `id`";
                        //DataSet Ds = MySqlHelper.ExecuteDataset(mycn, strSql);
                        //if (Ds.Tables[0].Rows.Count > 0)
                        {
                            //foreach (DataRow dr in Ds.Tables[0].Rows)
                            {
                                string query = string.Empty;
                                if (Ip.Trim().Length > 0)
                                {
                                    query = "delete from `ip_list` where `rdata`='" + Ip + "' and `tablename`='" + tableList[i].ToString() + "'"; //`dnsid` = '" + dr["id"].ToString() + "'
                                }
                                else
                                {
                                    query = "delete from `ip_list` where `tablename`='" + tableList[i].ToString() + "'";
                                }
                                MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                                insetCmd.ExecuteNonQuery();
                                insetCmd.Dispose();
                            }
                           // return "删除成功！";
                        }
                    }
                    else
                    {
                        string query = string.Empty;
                        if (Ip.Trim().Length > 0)
                        {

                            query = "delete from `ip_list` where `dnsid` = '" + DnsId.Trim() + "' and `rdata`='" + Ip + "' and `tablename`='" + tableList[i].ToString() + "'";
                        }
                        else
                        {
                            query = "delete from `ip_list` where `dnsid` = '" + DnsId.Trim() + "' and `tablename`='" + tableList[i].ToString() + "'";
                        }
                        MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                        insetCmd.ExecuteNonQuery();
                        insetCmd.Dispose();
                       // return "删除成功！";
                    }

                }
                return "删除成功！";
            }
            catch (Exception e)
            {
                mycn.Close();
                return e.Message;
            }
        }

        [HttpPost, ActionName("FastSet")]
        public string FastSet(string DnsId, string Ip, string Netype, string City)
        {
           MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
           //  MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            try
            {
                mycn.Open();
                string table1 = string.Empty;
                List<string> nameList = new List<string>();
                if (City != "全部")
                {
                    table1 = GetTableByCity(City.Trim() + "_" + Netype.Trim());
                    nameList.Add(table1);
                }
                else
                {
                    nameList = GetTableListByNettype(Netype.Trim());
                }
                for (int i=0;i<nameList.Count; i++)
                {
                    if (DnsId == "") //全部dns
                    {
                        string strSql = "SELECT * FROM `dns_list` where `status` !='false' order by `id`";
                        DataSet Ds = MySqlHelper.ExecuteDataset(mycn, strSql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dr in Ds.Tables[0].Rows)
                            {
                                string sql = "select * from `ip_list` where `dnsid` = '" + dr["id"].ToString() + "' and `rdata`='" + Ip + "' and `tablename`='" + nameList[i].ToString() + "'";
                                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, sql.ToString());
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    continue;
                                }
                                else
                                {
                                    string query = "INSERT INTO `ip_list` (`dnsid`, `ttl`, `rdtype`, `rdata`, `tablename`, `type`, `status`, `lasttime`) VALUES ('" +
                                    dr["id"].ToString() + "', 300, 'A', '" + Ip.Trim() + "', '" + nameList[i].ToString() + "', '', 'true', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                                    MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                                    insetCmd.ExecuteNonQuery();
                                    insetCmd.Dispose();
                                }
                            }
                           // return "设置成功！";
                        }
                    }
                    else
                    {
                        //string sql = "select * from `ip_list` where `dnsid` = '" + DnsId.Trim() + "' and `rdata`='" + Ip + "' and `tablename`='" + nameList[i].ToString() + "'";
                        //DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, sql.ToString());
                        //if (ds.Tables[0].Rows.Count > 0)
                        //{
                        //    return "已经存在该记录！";
                        //}
                        //else
                        //{
                            string query = "INSERT INTO `ip_list` (`dnsid`, `ttl`, `rdtype`, `rdata`, `tablename`, `type`, `status`, `lasttime`) VALUES (" +
                                int.Parse(DnsId.Trim()) + ", 300, 'A', '" + Ip.Trim() + "', '" + nameList[i].ToString() + "', '', 'true', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                            MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                            insetCmd.ExecuteNonQuery();
                            insetCmd.Dispose();
                            //return "设置成功！";
                       // }
                    }
                }

            }
            catch (Exception e)
            {
                mycn.Close();
                return e.Message;
            }
            return "设置成功！";
        }

        //public string FastSet(string DnsId, string Ip, string Netype, string City)
        //{
        //    // MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
        //    MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
        //    try
        //    {
        //        if (City != "全部")
        //        {
        //            string table = GetTableByCity(City.Trim() + "_" + Netype.Trim());
        //            mycn.Open();
        //            if (DnsId == "") //全部dns
        //            {
        //                string strSql = "SELECT * FROM `dns_list` where `status`='true' order by `id`";
        //                DataSet Ds = MySqlHelper.ExecuteDataset(mycn, strSql);
        //                if (Ds.Tables[0].Rows.Count > 0)
        //                {
        //                    foreach (DataRow dr in Ds.Tables[0].Rows)
        //                    {
        //                        string sql = "select * from `ip_list` where `dnsid` = '" + dr["id"].ToString() + "' and `rdata`='" + Ip + "' and `tablename`='" + table + "'";
        //                        DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, sql.ToString());
        //                        if (ds.Tables[0].Rows.Count > 0)
        //                        {
        //                            continue;
        //                        }
        //                        else
        //                        {
        //                            string query = "INSERT INTO `ip_list` (`dnsid`, `ttl`, `rdtype`, `rdata`, `tablename`, `type`, `status`, `lasttime`) VALUES ('" +
        //                            dr["id"].ToString() + "', 300, 'A', '" + Ip.Trim() + "', '" + table + "', '', 'true', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
        //                            MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
        //                            insetCmd.ExecuteNonQuery();
        //                            insetCmd.Dispose();
        //                        }
        //                    }
        //                    return "设置成功！";
        //                }
        //            }
        //            else
        //            {
        //                string sql = "select * from `ip_list` where `dnsid` = '" + DnsId.Trim() + "' and `rdata`='" + Ip + "' and `tablename`='" + table + "'";
        //                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, sql.ToString());
        //                if (ds.Tables[0].Rows.Count > 0)
        //                {
        //                    return "已经存在该记录！";
        //                }
        //                else
        //                {
        //                    string query = "INSERT INTO `ip_list` (`dnsid`, `ttl`, `rdtype`, `rdata`, `tablename`, `type`, `status`, `lasttime`) VALUES (" +
        //                        int.Parse(DnsId.Trim()) + ", 300, 'A', '" + Ip.Trim() + "', '" + table + "', '', 'true', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
        //                    MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
        //                    insetCmd.ExecuteNonQuery();
        //                    insetCmd.Dispose();
        //                    return "设置成功！";
        //                }
        //            }
        //        }
        //        else
        //        {
        //            if (Netype == "电信")
        //            {
        //                string sql = " update ip_list set `rdata` = '" + Ip + "' where `dnsid` = '" + DnsId.Trim() + "' and `tablename `like 'ct_%'";
        //                mycn.Open();
        //                MySqlCommand updateCmd = new MySqlCommand(sql.ToString(), mycn);
        //                updateCmd.ExecuteNonQuery();
        //                updateCmd.Dispose();
        //                return "设置成功！";
        //            }
        //            else if (Netype == "移动")
        //            {
        //                string sql = " update ip_list set `rdata` = '" + Ip + "' where `dnsid` = '" + DnsId.Trim() + "' and `tablename` like 'mobile_%'";
        //                mycn.Open();
        //                MySqlCommand updateCmd = new MySqlCommand(sql.ToString(), mycn);
        //                updateCmd.ExecuteNonQuery();
        //                updateCmd.Dispose();
        //                return "设置成功！";
        //            }

        //            else
        //            {
        //                string sql = "update ip_list set `rdata` = '" + Ip + "' where `dnsid` = '" + DnsId.Trim() + "' and tablename like 'cnc_%'";
        //                mycn.Open();
        //                MySqlCommand updateCmd = new MySqlCommand(sql.ToString(), mycn);
        //                updateCmd.ExecuteNonQuery();
        //                updateCmd.Dispose();
        //                return "设置成功！";
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        mycn.Close();
        //        return e.Message;
        //    }
        //    return "";
        //}

        [HttpPost, ActionName("Replace")]
        public string Replace(string DnsId, string Ip, string sIp)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
            //   MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            try
            {
                string strSql = "update `ip_list` set `rdata` = '" + sIp + "' where `rdata` = '" + Ip + "'";
                if (DnsId != "")
                {
                    strSql += " and `dnsid` = '" + DnsId + "';";
                }
                else
                {
                    strSql += ";";
                }
                mycn.Open();
                MySqlCommand updateCmd = new MySqlCommand(strSql.ToString(), mycn);
                updateCmd.ExecuteNonQuery();
                updateCmd.Dispose();
            }
            catch (Exception e)
            {
                mycn.Close();
                return e.Message;
            }
            return "设置成功！";
        }

        [HttpPost, ActionName("MobanSet")]
        public string MobanSet(string setId, string mobanId)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
         //   MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            try
            {
                try
                {
                    string dele = "delete from `ip_list` where `dnsid` = '" + setId.Trim() + "';";
                    mycn.Open();
                    MySqlCommand cmd = new MySqlCommand(dele.ToString(), mycn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
                catch { }
                string sql = "select * from ip_list where `dnsid` = '" + mobanId.Trim() + "'";
                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, sql.ToString());
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        string query = "INSERT INTO `ip_list` (`dnsid`, `ttl`, `rdtype`, `rdata`, `tablename`, `type`, `status`, `lasttime`) VALUES (" + int.Parse(setId.Trim()) + ", 300, 'A', '" + dr["rdata"] + "', '" + dr["tablename"] + "', '', 'true', '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                        //mycn.Open();
                        MySqlCommand insetCmd = new MySqlCommand(query.ToString(), mycn);
                        insetCmd.ExecuteNonQuery();
                        insetCmd.Dispose();
                    }
                    return "设置成功！";
                }
                return "模版的值为空！";
            }
            catch(Exception e)
            {
                mycn.Close();
                return e.Message;
            }
            //return "设置失败！";
        }

        public string UpdStatus(string setId)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
            //   MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            try
            {
                string upd = "update `dns_list` set `status`='true'  where `id` = '" + setId.Trim() + "';";
                mycn.Open();
                MySqlCommand cmd = new MySqlCommand(upd.ToString(), mycn);
                int result = cmd.ExecuteNonQuery();
                cmd.Dispose();

                return "ok";
            }
            catch (Exception e)
            {
                mycn.Close();
                return e.Message;
            }
        }
        

        [HttpPost, ActionName("AddNodeObj")]
        public string AddNodeObj(string domain, string ip, string area, string ttl)
        {
            try
            {
                string tbName = GetTableByCity(area.Trim());
                if (DoAddIpObj(domain.Trim(), ip.Trim(), tbName, int.Parse(ttl.Trim())))
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("SELECT `id` FROM `ip_list` where `tablename`='" + tbName + "' and `rdata`='" + ip.Trim() + "'");

                   // MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                  //  DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, strSql.ToString());
                   
                    DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), strSql.ToString());
                    if (ds.Tables[0] != null)
                    {
                        return ds.Tables[0].Rows[0][0].ToString();
                    }
                }
                return "添加失败！";
            }
            catch
            {
                return "添加报错！";
            }
        }

        [HttpPost, ActionName("EditNodeObj")]
        public string EditNodeObj(int id, int ttl)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
              //  MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                string strSql = "update `ip_list` set `ttl`=" + ttl + " where `id`=" + id;
                con.Open();
                MySqlCommand cmd = new MySqlCommand(strSql.ToString(), con);
                int result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                if (1 == result)
                    return "保存成功！";
            }
            catch
            {
                return "保存报错，请联系管理员！";
            }
            return "保存失败！";
        }

        [HttpPost, ActionName("DeleNodeObj")]
        public string DeleNodeObj(int id)
        {
            try
            {
                MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
              //  MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                StringBuilder strSql = new StringBuilder();
                mycn.Open();
                strSql.Append("delete from `ip_list` where `id`=" + id);
                MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                int result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                mycn.Close();
                if (1 <= result)
                    return "删除成功！";
            }
            catch { return "删除报错！"; }
            return "删除失败！";
        }

        //修改一个DNS对象
        [HttpPost, ActionName("EditDnsObj")]
        public string EditDnsObj(string id, string dns, string desc, string statu)
        {
            //string table = GetTableByArea(slc.Trim());
            if (DoEditDns(id.Trim(), dns.Trim(), desc.Trim(), statu))
            {
                return "保存成功！";
            }
            return "保存失败！";
        }

        //添加DNS新记录
        [HttpPost, ActionName("AddNew")]
        public string AddNew(string dns, string desc, string statu)
        {
            string dnsToLower = dns.ToLower();
            MySqlConnection con = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
         //   MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            //string table = GetTableByArea(slc.Trim());
            try
            {
                StringBuilder strSql = new StringBuilder();
                con.Open();
                strSql.Append("select `id` from `dns_list` where `name`='" + dnsToLower.Trim() + "'");
                DataSet ds = MySqlHelper.ExecuteDataset(con,strSql.ToString());
                if (ds.Tables[0].Rows.Count <= 0)
                {
                    strSql.Clear();
                    strSql.Append("insert into `dns_list`(`name`,`status`,`desc`)Values('" + dnsToLower.Trim() + "','" + statu.Trim() + "','" + desc.Trim() + "')");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), con);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    con.Close();
                    if (1 == result)
                        return "添加成功！";
                }
                else
                {
                    con.Close();
                    return "已经存在该域名！";
                }
            }
            catch
            {
                if (con != null) con.Close();
                return "添加报错，请联系管理员！";
            }
            return "添加失败！";
        }

        //删除Dns对象
        [HttpPost, ActionName("DeleDnsObj")]
        public string DeleDnsObj(string id)
        {
            try
            {
                if (DoDeleDns(id.Trim()))
                {
                    return "删除成功！";
                }
                return "删除失败！";
            }
            catch
            {
                return "删除报错，请联系管理员！";
            }
        }

        //通过域名查找该域名所有的绑定
        [HttpPost, ActionName("GetListByDns")]
        public string GetListByDns(string dns)
        {
            try
            {
                string sql = "select * from `server_list` where `type`='node' ORDER BY `nettype`";
                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(CDN_Admin.Core.MySqlConn.MYSQL_SERVER, sql);
                Hashtable campare = new Hashtable();
                campare.Add("东北电信", "db_ct_");
                campare.Add("东北网通", "db_cnc_");

                campare.Add("华北电信", "hb_ct_");
                campare.Add("华北网通", "hb_cnc_");

                campare.Add("华东电信", "hd_ct_");
                campare.Add("华东网通", "hd_cnc_");

                campare.Add("华南电信", "hn_ct_");
                campare.Add("华南网通", "hn_cnc_");

                campare.Add("华中电信", "hz_ct_");
                campare.Add("华中网通", "hz_cnc_");

                campare.Add("西北电信", "xb_ct_");
                campare.Add("西北网通", "xb_cnc_");

                campare.Add("西南电信", "xn_ct_");
                campare.Add("西南网通", "xn_cnc_");

                campare.Add("其它电信", "qt_ct_");
                campare.Add("其它网通", "qt_cnc_");
                StringBuilder DataStr = new StringBuilder();
                List<DnsModels> model = GetListDns(dns.Trim());
                if (model.Count > 0)
                {
                    IEnumerable<IGrouping<string, DnsModels>> query = model.GroupBy(obj => obj.tablename, obj => obj);
                    //根据tablename进行分组，得到一个该域名和区域所拥有的ip
                    foreach (IGrouping<string, DnsModels> info in query)
                    {
                        List<DnsModels> dif_area = info.ToList<DnsModels>();//分组后的集合，即(域名+区域)所有的ip
                        campare.Remove(GetAreaByTable(dif_area[0].tablename));
                        DataStr.Append(GetJson(dif_area));
                        DataStr.Append("|");
                    }
                    if (campare.Count > 0)
                    {
                        foreach (DictionaryEntry de in campare)
                        {
                            DataStr.Append(GetChildJson(ds.Tables[0], de.Key.ToString(), de.Value.ToString()));
                        }
                    }
                    string result = DataStr.ToString().Substring(0, DataStr.ToString().Length - 1);
                    return result;
                }
                else
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DictionaryEntry de in campare)
                        {
                            DataStr.Append(GetChildJson(ds.Tables[0], de.Key.ToString(), de.Value.ToString()));
                        }
                        return DataStr.ToString().Substring(0, DataStr.ToString().Length - 1);
                    }
                    return "";
                }
            }
            catch
            { 
                return "查询数据出错！";
            }
        }

        //用户登录验证
        public string CheckLogin(string user, string pwd, string cookie, string code)
        {
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(user) | r.IsMatch(pwd))
                {
                    //SQL注入
                    return "请不要注入，后果自负！";
                }
                else
                {
                    Cookie Cookie = new Cookie();
                    if (cookie.Trim() == "记住")
                    {
                        Cookie.setCookie("dns_name", user, 1);
                        Cookie.setCookie("dns_pwd", pwd, 1);
                    }
                    else
                    {
                        Cookie.delCookie("dns_name");
                        Cookie.delCookie("dns_pwd");
                    }

                    if (code != Session["ValidateCode"].ToString())
                    {
                        return "验证码输入错误！";
                    }

                    StringBuilder strSql = new StringBuilder();
                     strSql.Append("SELECT Count(`user`),`user` FROM `admin` where `user`='" + user.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower() + "' and status='true'");

                //   strSql.Append("SELECT Count(`user`),`user` FROM `admin` where `user`='" + user.Trim() + "' and status='true'");

                    MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (sdr.Read())
                    {
                        if (int.Parse(sdr["Count(`user`)"].ToString()) == 1)
                        {
                            HttpContext.Session["user"] = sdr["user"];    //用户名
                            return "true";
                        }
                    }
                }
                return "用户名或密码错误！";
            }
            catch(Exception e)
            {
                return e.Message; 
            }
        }

        //private Method
        //获取新闻列表
        private List<DnsModels> GetDomainListByPage(int page)
        {
            try
            {
                string strSql = string.Empty;
                strSql = "SELECT * FROM `dns_list` order by `id` LIMIT 20 OFFSET " + (page - 1) * 20; // where `status`='true'

               // MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
             //   DataSet Ds = MySqlHelper.ExecuteDataset(mycn, strSql);
                
                DataSet Ds = MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(),strSql);
                
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<DnsModels> obj = new List<DnsModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        DnsModels model = new DnsModels();
                        model.id = int.Parse(dr["id"].ToString());
                        model.name = dr["name"].ToString();
                        model.status = dr["status"].ToString();
                        model.desc = dr["desc"].ToString();
                        obj.Add(model);
                    }
                    return obj;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //获取域名个数
        private int GetDomainNum()
        {
            try
            {
                string strSql = string.Empty;
                strSql = "SELECT Count(*) FROM `dns_list`"; // where `status`='true'

                //MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
               // DataSet Ds = MySqlHelper.ExecuteDataset(mycn, strSql);
                
                DataSet Ds = MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), strSql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return 0;
        }

        private List<ShowModels> GetAreaSet(List<ServerModels> serverList, List<DnsModels> data, string city, string nettype)
        {
            try
            {
                
                List<ShowModels> ShowList = new List<ShowModels>();
                if (serverList.Count > 0)
                {
                    string sql = "select * from `zone_table`";

                   // MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                   // DataSet ds = MySqlHelper.ExecuteDataset(mycn, sql);
                    
                    DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), sql);
                   
                    Hashtable campare = new Hashtable();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        if (dr["tablename"].ToString().StartsWith("ct_"))
                        {
                            campare.Add(dr["tablename"].ToString(), dr["local"].ToString() + "_电信");
                        }
                        if (dr["tablename"].ToString().StartsWith("cnc_"))
                        {
                            campare.Add(dr["tablename"].ToString(), dr["local"].ToString() + "_网通");
                        }
                        if (dr["tablename"].ToString().StartsWith("mobile_"))
                        {
                            campare.Add(dr["tablename"].ToString(), dr["local"].ToString() + "_移动");
                        }
                    }
                    foreach (ServerModels server in serverList)
                    {
                        ShowModels show = new ShowModels();
                        show.id = 0;
                        show.ip = server.ip;
                        show.nettype = server.nettype;
                        show.ttl = 300;
                        show.local = server.local;
                        show.desc = server.desc;
                        show.lasttime = "";
                        show.IsSet = false;
                        if (data.Count > 0)
                        {
                            foreach (DnsModels obj in data)
                            {
                                string info = campare[obj.tablename].ToString();
                                string[] arr = info.Split('_');
                                if (arr[0] == city && arr[1] == nettype && obj.rdata == server.ip) //相同省份（城市）、网络、ip地址
                                {
                                    show.id = obj.id;
                                    show.IsSet = true;
                                    show.ttl = obj.ttl;
                                    show.lasttime = obj.lasttime.ToString("yyyy-MM-dd HH:mm:ss");
                                }
                            }
                        }
                        ShowList.Add(show);
                    }
                    return ShowList;
                }
            }
            catch
            { }
            return null;
        }

        private List<ShowModels> GetAreaIp(List<ServerModels> serverList, List<DnsModels> data)
        {
            try
            {
                List<ShowModels> ShowList = new List<ShowModels>();
                if (serverList.Count > 0)
                {
                    string sql = "select * from `zone_table`";

                    // MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                    // DataSet ds = MySqlHelper.ExecuteDataset(mycn, sql);

                    DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), sql);

                    Hashtable campare = new Hashtable();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        if (dr["tablename"].ToString().StartsWith("ct_"))
                        {
                            campare.Add(dr["tablename"].ToString(), dr["local"].ToString() + "_电信");
                        }
                        if (dr["tablename"].ToString().StartsWith("cnc_"))
                        {
                            campare.Add(dr["tablename"].ToString(), dr["local"].ToString() + "_网通");
                        }
                        if (dr["tablename"].ToString().StartsWith("mobile_"))
                        {
                            campare.Add(dr["tablename"].ToString(), dr["local"].ToString() + "_移动");
                        }
                    }
                    foreach (ServerModels server in serverList)
                    {
                        ShowModels show = new ShowModels();
                        show.id = 0;
                        show.ip = server.ip;
                        show.nettype = server.nettype;
                        show.ttl = 300;
                        show.local = server.local;
                        show.desc = server.desc;
                        show.lasttime = "";
                        show.IsSet = false;
                        if (data.Count > 0)
                        {
                            foreach (DnsModels obj in data)
                            {
                                string info = campare[obj.tablename].ToString();
                                string[] arr = info.Split('_');
                                if (obj.rdata == server.ip) //相同省份（城市）、网络、ip地址
                                {
                                    show.id = obj.id;
                                    show.IsSet = true;
                                    show.ttl = obj.ttl;
                                    show.lasttime = obj.lasttime.ToString("yyyy-MM-dd HH:mm:ss");
                                }
                            }
                            if (show.IsSet == true)
                            {
                                ShowList.Add(show);
                            }

                        }
                        
                    }
                    return ShowList;
                }
            }
            catch
            { }
            return null;
        }

   
        private string[] GetCity()
        {
            try
            {
                string con = HttpContext.Session["dbinfo"].ToString();
               // MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                string sql = "select distinct `local` from `zone_table` ORDER BY `zone`,`local`";
                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);
                if (ds.Tables[0] != null)
                {
                    string[] ret = new string[ds.Tables[0].Rows.Count];
                    for (int i=0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        ret[i] = ds.Tables[0].Rows[i][0].ToString();
                    }
                    return ret;
                }
            }
            catch
            { }
            return null;
        }

        private Dictionary<string, List<DomainAreaModels>> GetArea()
        {
            try
            {
                string con = HttpContext.Session["dbinfo"].ToString();
              //  MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                string sql = "select * from `zone_table` ORDER BY `zone`,`local`";
                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);
                if (ds.Tables[0] != null)
                {
                    string temp_area = "";
                    Dictionary<string, List<DomainAreaModels>> dic = new Dictionary<string, List<DomainAreaModels>>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        if (dr["zone"].ToString() != temp_area) //新区域
                        {
                            DomainAreaModels domain = new DomainAreaModels();
                            domain.city = dr["local"].ToString();
                            domain.nettype = dr["nettype"].ToString();
                            domain.tablename = dr["tablename"].ToString();

                            List<DomainAreaModels> item = new List<DomainAreaModels>();
                            item.Add(domain);

                            dic.Add(dr["zone"].ToString(), item);
                        }
                        else
                        { 
                            DomainAreaModels domain = new DomainAreaModels();
                            domain.city = dr["local"].ToString();
                            domain.nettype = dr["nettype"].ToString();
                            domain.tablename = dr["tablename"].ToString();

                            dic[dr["zone"].ToString()].Add(domain);
                        }
                        temp_area = dr["zone"].ToString();
                    }
                    return dic;
                }
            }
            catch { }
            return null;
        }

        private List<ServerModels> GetServerList()
        {
            string sql = "select * from `server_list` where `type`='node' ORDER BY  `nettype`,`local`";
            DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
            
            //MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk");
           // DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);
            
            
            
            if (ds.Tables[0].Rows.Count > 0)
            {
                List<ServerModels> data = new List<ServerModels>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ServerModels item = new ServerModels();
                    item.id = int.Parse(dr["id"].ToString());
                    item.ip = dr["ip"].ToString();
                    item.zone = dr["zone"].ToString();
                    item.nettype = dr["nettype"].ToString();
                    item.local = dr["local"].ToString();
                    item.desc = dr["desc"].ToString();
                    data.Add(item);
                }
                return data;
            }
            return null;
        }

        private List<ServerModels> GetServerListbyIp(string ip)
        {
            string sql = "select * from `server_list` where `type`='node' and `ip`='" + ip + "'  ORDER BY  `nettype`,`local`";
            DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);

            //MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk");
            // DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);



            if (ds.Tables[0].Rows.Count > 0)
            {
                List<ServerModels> data = new List<ServerModels>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ServerModels item = new ServerModels();
                    item.id = int.Parse(dr["id"].ToString());
                    item.ip = dr["ip"].ToString();
                    item.zone = dr["zone"].ToString();
                    item.nettype = dr["nettype"].ToString();
                    item.local = dr["local"].ToString();
                    item.desc = dr["desc"].ToString();
                    data.Add(item);
                }
                return data;
            }
            return null;
        }

        private List<AllModels> GetModelByIp(string ip,int intSort)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());

            string sql = "select * from((SELECT * FROM `ip_list` where `rdata`='" + ip.Trim() + "' Order by `rdata` desc) A left join (Select * from zone_table) B on A.tablename=B.tablename)";
            DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, sql);

            string strSql = "select * from dns_list";
            DataSet ds_dns = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(mycn, strSql);
            //MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk");
            // DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);

            if (ds.Tables[0].Rows.Count > 0)
            {
                List<AllModels> data = new List<AllModels>();
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    AllModels item = new AllModels();
                    item.id = int.Parse(dr["id"].ToString());
                    //item.desc = dr["desc"].ToString();
                    item.dnsid = int.Parse(dr["dnsid"].ToString());
                    item.lasttime = dr["lasttime"].ToString();
                    item.local = dr["local"].ToString();
                    // item.name = dr["name"].ToString();
                    item.nettype = dr["nettype"].ToString();
                    item.rdata = dr["rdata"].ToString();
                    item.rdtype = dr["rdtype"].ToString();
                    //  item.status = dr["status"].ToString();
                    item.tablename = dr["tablename"].ToString();
                    item.ttl = dr["ttl"].ToString();
                    item.type = dr["type"].ToString();
                    item.zone = dr["zone"].ToString();
                    foreach (DataRow dnsDr in ds_dns.Tables[0].Rows)
                    {
                        if (dnsDr["id"].ToString() == dr["dnsid"].ToString())
                        {
                            item.status = dnsDr["status"].ToString();
                            item.name = dnsDr["name"].ToString();
                            item.desc = dnsDr["desc"].ToString();
                        }
                    }
                    data.Add(item);
                }
                //排序
                switch (intSort)
                {
                    case 0: data.Sort(SortNamUp);
                        break;
                    case 1: data.Sort(SortNamDown);
                        break;
                    case 2: data.Sort(SortLocalUp);
                        break;
                    case 3: data.Sort(SortLocalDown);
                        break;
                }

                return data;
            }
            return null;
        }

        //定义排序函数
        private static int SortNamUp(AllModels model1, AllModels model2)
        {
            return model1.name.CompareTo(model2.name);
        }
        private static int SortNamDown(AllModels model1, AllModels model2)
        {
            return model2.name.CompareTo(model1.name);
        }
        private static int SortLocalUp(AllModels model1, AllModels model2)
        {
            return model2.local.CompareTo(model1.local);
        }
        private static int SortLocalDown(AllModels model1, AllModels model2)
        {
            return model1.local.CompareTo(model2.local);
        }

        private string GetTableByCity(string citynettype)
        {
            try
            {
                string[] arr = citynettype.Split('_');
                string city = arr[0];
                string nettype = arr[1];
                string sql = "select * from `zone_table`";
               DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), sql);

             //    MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
              //  DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    if (dr["local"].ToString() == city && dr["nettype"].ToString() == nettype)
                    {
                        return dr["tablename"].ToString();
                    }
                }
            }
            catch { }
            return "";
        }
        
        private List<string> GetTableListByNettype(string nettype)
        {
            List<string> nameList = new List<string>();
            string sql = "select * from `zone_table` where  `nettype` = '"+nettype+"'";
            try
            {
               DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), sql);

             //    MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            //    DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    if (dr["nettype"].ToString() == nettype)
                    {
                        nameList.Add(dr["tablename"].ToString());
                    }
                }
                return nameList;
            }
            catch { }
            return  nameList;
        }

        private List<string> GetTableListByCityNettype(string city,string nettype)
        {
            List<string> nameList = new List<string>();
            string sql = string.Empty;
            if (city == "全部")
            {
                sql = "select * from `zone_table` where  `nettype` = '" + nettype + "'";
            }
            else
            {
                sql = "select * from `zone_table` where `local`='" + city + "' and `nettype` = '" + nettype + "'";
            }
            try
            {
                 DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(HttpContext.Session["dbinfo"].ToString(), sql);

              //  MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
             //   DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    if (dr["nettype"].ToString() == nettype)
                    {
                        nameList.Add(dr["tablename"].ToString());
                    }
                }
                return nameList;
            }
            catch { }
            return nameList;
        }


        private bool DoAddIpObj(string dnsID, string ip, string tbName, int ttl)
        {
            MySqlConnection con = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());

         //   MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");

            try
            {
                int result = 0;
                con.Open();
                StringBuilder strSql = new StringBuilder();
                strSql.Append("insert into `ip_list`(`dnsid`,`ttl`,`rdtype`,`rdata`,`tablename`,`lasttime`,`status`)Values(" + int.Parse(dnsID) + "," + ttl + ",'A','" + ip.Trim() + "','" + tbName + "','" + DateTime.Now.ToString() + "','true')");
                MySqlCommand cmd = new MySqlCommand(strSql.ToString(), con);
                result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Close();
                if (1 == result)
                    return true;
            }
            catch
            {
                if (con != null) con.Close();
            }
            return false;
        }

        //获取json格式数据
        private string GetChildJson(DataTable tb, string area, string sd)
        {
            int a = 1;
            string json = area + "&";
            foreach (DataRow dr in tb.Rows)
            {
                json += sd + a + ",0,300," + dr["ip"].ToString().Trim() + "," + dr["nettype"].ToString().Trim() + "," + dr["desc"].ToString().Trim() + ",false*";
                a++;
            }
            return json.Substring(0, json.Length - 1) + "|";
        }

        //获取json格式数据
        private string GetJson(List<DnsModels> t)
        {
            try
            {
                string json = GetAreaByTable(t[0].tablename) + "&";
                string sql = "select * from `server_list` where `type`='node' ORDER BY `nettype`";
                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(CDN_Admin.Core.MySqlConn.MYSQL_SERVER, sql);
                if (ds.Tables[0].Rows.Count>0)
                {
                    string[] s = t[0].tablename.Split('_');
                    int m = 1;
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        DnsModels find_obj = t.Find(delegate(DnsModels Obj)
                        {
                            return Obj.rdata == dr["ip"].ToString().Trim();
                        });
                        if (find_obj != null)
                        {
                            json += find_obj.id + "," + find_obj.lasttime + "," + find_obj.ttl + "," + find_obj.rdata + "," + dr["nettype"].ToString().Trim() + "," + dr["desc"].ToString().Trim() + ",true*";
                        }
                        else
                        {
                            json += s[3] + "_" + s[4] + "_" + m + ",0,300," + dr["ip"].ToString().Trim() + "," + dr["nettype"].ToString().Trim() + "," + dr["desc"].ToString().Trim() + ",false*";
                        }
                        m++;
                    }
                }
                return json.Substring(0,json.Length-1);
            }
            catch
            {
                return "";
            }
        }

        //查找dns相同的对象列表
        private List<DnsModels> GetListDns(string dns)
        {
            try
            {
                 string con = HttpContext.Session["dbinfo"].ToString();

              //  MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
             //   DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);

              // MySqlConnection conn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                //string con = conn.ToString();

               // if (!string.IsNullOrEmpty(conn))
                if(con.ToString().Length>0)
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("SELECT * FROM `ip_list` where `dnsid`='" + dns.Trim() + "' Order by `rdata` desc");
                    DataSet dns_ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, strSql.ToString());
                    if (dns_ds.Tables[0] != null)
                    {
                        List<DnsModels> Data = new List<DnsModels>();
                        foreach (DataRow dr in dns_ds.Tables[0].Rows)
                        {
                            DnsModels model = new DnsModels();
                            model.id = int.Parse(dr["id"].ToString());
                            //model.name = dr["dnsid"].ToString();
                            model.rdata = dr["rdata"].ToString();
                            model.rdtype = dr["rdtype"].ToString();
                            model.tablename = dr["tablename"].ToString();
                            model.type = dr["type"].ToString();
                            model.ttl = int.Parse(dr["ttl"].ToString());
                            model.status = dr["status"].ToString();
                            model.lasttime = DateTime.Parse(dr["lasttime"].ToString());
                            model.ShowOrNot = "true";
                            Data.Add(model);
                        }
                        return Data;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //查找dns相同的对象列表
        private List<DnsModels> GetListByIp(string ip)
        {
            try
            {
                string con = HttpContext.Session["dbinfo"].ToString();

                //  MySqlConnection con = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                //   DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, sql);

                // MySqlConnection conn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
                //string con = conn.ToString();

                // if (!string.IsNullOrEmpty(conn))
                if (con.ToString().Length > 0)
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("SELECT * FROM `ip_list` where `rdata`='" + ip.Trim() + "' Order by `rdata` desc");
                    DataSet dns_ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(con, strSql.ToString());
                    if (dns_ds.Tables[0] != null)
                    {
                        List<DnsModels> Data = new List<DnsModels>();
                        foreach (DataRow dr in dns_ds.Tables[0].Rows)
                        {
                            DnsModels model = new DnsModels();
                            model.id = int.Parse(dr["id"].ToString());
                            model.name = dr["dnsid"].ToString();
                            model.rdata = dr["rdata"].ToString();
                            model.rdtype = dr["rdtype"].ToString();
                            model.tablename = dr["tablename"].ToString();
                            model.type = dr["type"].ToString();
                            model.ttl = int.Parse(dr["ttl"].ToString());
                            model.status = dr["status"].ToString();
                            model.lasttime = DateTime.Parse(dr["lasttime"].ToString());
                            model.ShowOrNot = "true";
                            Data.Add(model);
                        }
                        return Data;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //删除一个dns对象
        private bool DoDeleDns(string id)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
          //  MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");

            if (mycn != null)
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    mycn.Open();
                    strSql.Append("delete from `dns_list` where `id`=" + int.Parse(id) + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    //删除该域名下对应的ip地址
                    strSql.Clear();
                    strSql.Append("delete from `ip_list` where `dnsid`=" + int.Parse(id) + "");
                    MySqlCommand ipcmd = new MySqlCommand(strSql.ToString(), mycn);
                    int ipresult = ipcmd.ExecuteNonQuery();
                    ipcmd.Dispose();
                    mycn.Close();
                    if (1 == result && ipresult >= 1)
                        return true;
                }
                catch
                {
                    if (mycn != null) mycn.Close();
                }
            }
            return false;
        }

        //修改一个dns对象
        private bool DoEditDns(string id, string dns, string desc, string statu)
        {
            MySqlConnection mycn = new MySqlConnection(HttpContext.Session["dbinfo"].ToString());
         //   MySqlConnection mycn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
   

            if (mycn != null)
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    mycn.Open();
                    strSql.Append("update `dns_list` set `name`='" + dns.Trim() + "',`desc`='" + desc.Trim() + "',`status`='" + statu.Trim() + "' where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    mycn.Close();
                    if (1 == result)
                        return true;
                }
                catch
                {
                    if (mycn != null) mycn.Close();
                }
            }
            return false;
        }

        private string GetIdByName(string dns)
        {
            try
            {
               string con = HttpContext.Session["dbinfo"].ToString();
                // MySqlConnection conn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
               // string con = conn.ToString(); 

                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT id FROM `dns_list` where `name`='" + dns.Trim() + "'"); // and `rdata`='" + ip.Trim() + "' and `tablename`='" + tablename.Trim() + "'
                MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(con, strSql.ToString());
                if (sdr.Read())
                {
                    if (int.Parse(sdr["id"].ToString()) > 0)
                    {
                        return sdr["id"].ToString();
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }
        private string GetNameByID(string dns_Id)
        {
            try
            {
                string con = HttpContext.Session["dbinfo"].ToString();
             //   MySqlConnection conn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
            //    string con = conn.ToString();

                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT name FROM `dns_list` where `id`='" + dns_Id.Trim() + "'");
                MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(con, strSql.ToString());
                if (sdr.Read())
                {
                    if (int.Parse(sdr["name"].ToString()) > 0)
                    {
                        return sdr["name"].ToString();
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }
        //检查该条记录是否存在
        private bool DnsIsOrNotExist(string dns) //,string ip,string tablename
        {
            try
            {
                string con = HttpContext.Session["dbinfo"].ToString();
             //   MySqlConnection conn = new MySqlConnection("User Id=root;Host=192.168.22.199;Database=cache_rightgo_net_ex;password=111111;charset=gbk");
             //   string con = conn.ToString();

                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT id FROM `dns_list` where `name`='" + dns.Trim() + "'"); // and `rdata`='" + ip.Trim() + "' and `tablename`='" + tablename.Trim() + "'
                MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(con, strSql.ToString());
                if (sdr.Read())
                {
                    if (int.Parse(sdr["id"].ToString()) > 0)
                    {
                        return true; 
                    }
                }
            }
            catch(Exception e)
            {
                throw e;
            }
            return false;
        }

        //通过数据库连接字符串获取域名列表
        private List<DnsModels> GetDnsByConn(string conn)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `id`,`name`,`status`,`desc` FROM `dns_list` order by `id` asc"); //`rdata`,`id`,`ttl`,`type`,`tablename`,`rdtype`,`lasttime` 
                DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn.Trim(), strSql.ToString());
                if(ds.Tables[0]!=null)
                {
                    List<DnsModels> data = new List<DnsModels>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        DnsModels model = new DnsModels();
                        model.id = int.Parse(dr["id"].ToString());
                        model.name = dr["name"].ToString();
                        //model.ttl = int.Parse(dr["ttl"].ToString());
                        //model.rdtype = dr["rdtype"].ToString();
                        //model.rdata = dr["rdata"].ToString();
                        //model.tablename = dr["tablename"].ToString();
                        //model.type = dr["type"].ToString();
                        model.status = dr["status"].ToString();
                        model.desc = dr["desc"].ToString();
                        //model.lasttime = DateTime.Parse(dr["lasttime"].ToString());
                        data.Add(model);
                    }
                    return data;
                }
            }
            catch
            {
                return null;
            }
            return null;
        }

        //获取用户信息
        private bool GetUserInfo()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `ip` FROM `server_list` where `type`='dns_master'");
                MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (sdr.Read())
                {
                    if (sdr["ip"] != null)
                    {
                        HttpContext.Session["ip"] = sdr["ip"];    //用户ip
                        string sql = "SELECT `value`,`key` FROM `server_info` where `serverip`='" + sdr["ip"].ToString() + "'";
                        DataSet ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
                        if (ds.Tables[0] != null)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                if (dr["key"].ToString() == "dbinfo")
                                {
                                    HttpContext.Session["dbinfo"] = ReplaceConn(dr["value"].ToString()); 
                                }
                                if (dr["key"].ToString() == "hostname")
                                {
                                    HttpContext.Session["hostname"] = dr["value"];
                                }
                            }
                            return true;
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        //修改连接字符串
        private string ReplaceConn(string or_con)
        {
            //ip=192.168.22.199;port=3306;user=root;pass=111111;db=cache_rightgo_net;
            //User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk
            string[] connArr = or_con.Split(';');
            if (connArr.Length >= 5)
            {
                connArr[0] = connArr[0].Replace("ip", "Host");
                connArr[2] = connArr[2].Replace("user", "User Id");
                connArr[3] = connArr[3].Replace("pass", "password");
                //connArr[4] = connArr[4].Replace("db", "Database");
                connArr[4] = connArr[4].Replace("db=cache_rightgo_net", "Database=cache_rightgo_net_ex");
                return connArr[0] + ";" + connArr[2] + ";" + connArr[3] + ";" + connArr[4] + ";charset=gbk";
            }
            else
            {
                return "";
            }
        }

        //通过区域返回表名
        private string GetTableByArea(string area)
        {
            switch (area.Trim())
            { 
                case "东北电信":
                    return "cache_rightgo_net_ct_db";
                case "华北电信":
                    return "cache_rightgo_net_ct_hb";
                case "华东电信":
                    return "cache_rightgo_net_ct_hd";
                case "华南电信":
                    return "cache_rightgo_net_ct_hn";
                case "华中电信":
                    return "cache_rightgo_net_ct_hz";
                case "西北电信":
                    return "cache_rightgo_net_ct_xb";
                case "西南电信":
                    return "cache_rightgo_net_ct_xn";
                case "其它电信":
                    return "cache_rightgo_net_ct_other";
                case "东北网通":
                    return "cache_rightgo_net_cnc_db";
                case "华北网通":
                    return "cache_rightgo_net_cnc_hb";
                case "华东网通":
                    return "cache_rightgo_net_cnc_hd";
                case "华南网通":
                    return "cache_rightgo_net_cnc_hn";
                case "华中网通":
                    return "cache_rightgo_net_cnc_hz";
                case "西北网通":
                    return "cache_rightgo_net_cnc_xb";
                case "西南网通":
                    return "cache_rightgo_net_cnc_xn";
                case "其它网通":
                    return "cache_rightgo_net_cnc_other";
                default:
                    return "cache_rightgo_net_ct_other";
            }
        }

        //通过区域返回表名
        private string GetAreaByTable(string table)
        {
            switch (table.Trim())
            {
                case "cache_rightgo_net_ct_db":
                    return "东北电信";
                case "cache_rightgo_net_ct_hb":
                    return "华北电信";
                case "cache_rightgo_net_ct_hd":
                    return "华东电信";
                case "cache_rightgo_net_ct_hn":
                    return "华南电信";
                case "cache_rightgo_net_ct_hz":
                    return "华中电信";
                case "cache_rightgo_net_ct_xb":
                    return "西北电信";
                case "cache_rightgo_net_ct_xn":
                    return "西南电信";
                case "cache_rightgo_net_ct_other":
                    return "其它电信";
                case "cache_rightgo_net_cnc_db":
                    return "东北网通";
                case "cache_rightgo_net_cnc_hb":
                    return "华北网通";
                case "cache_rightgo_net_cnc_hd":
                    return "华东网通";
                case "cache_rightgo_net_cnc_hn":
                    return "华南网通";
                case "cache_rightgo_net_cnc_hz":
                    return "华中网通";
                case "cache_rightgo_net_cnc_xb":
                    return "西北网通";
                case "cache_rightgo_net_cnc_xn":
                    return "西南网通";
                case "cache_rightgo_net_cnc_other":
                    return "其它网通";
                default:
                    return "其它电信";
            }
        }

        public ActionResult GetValidateCode()
        {
            ValidateCode vCode = new ValidateCode();
            string code = vCode.CreateValidateCode(5);
            Session["ValidateCode"] = code;
            byte[] bytes = vCode.CreateValidateGraphic(code);
            return File(bytes, @"image/jpeg");
        }

    }
}
