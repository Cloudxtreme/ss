﻿//初始化页面
$(function () {
    setDomHeight($("#left_tree"));
    setDomHeight($("#content"));
    setDomWidth($("#content"));
    //警示框
    $('#AlertMessage').dialog({
        autoOpen: false,
        width: 300,
        modal: true,
        buttons: {
            "确定": function () {
                $(this).dialog("close");
            }
        }
    });
    //确认框
    $('#ConfirmMessage').dialog({
        autoOpen: false,
        width: 300,
        modal: true,
        buttons: {
            "确定": function () {
                $(this).dialog('close');
                mDialogCallback(true);
            },
            "取消": function () {
                $(this).dialog('close');
                mDialogCallback(false);
            }
        }
    });

});
window.setInterval(DomResize, 200);

var mDialogCallback;
function ShowMsg(msg, callback) {
    if (callback == null) {
        $('#AlertMessageBody').html(msg);
        $('#AlertMessage').dialog('open');
    }
    else {
        mDialogCallback = callback;
        $('#ConfirmMessageBody').html(msg);
        $('#ConfirmMessage').dialog('open');
    }
};

function DomResize() {
    setDomHeight($("#left_tree"));
    setDomHeight($("#content"));
    setDomWidth($("#content"));
}

//计算主要内容区的宽度
var setDomWidth = function (selector) {
    var _s = $(selector);
    if (_s.is(':hidden')) return;
    _s.width($(window).width()-20);
}

//设置自适应高度
function setDomHeight(selector) {
//    var _s = $(selector);
//    if (_s.is(':hidden')) return;
//    _s.height($(window).height() - _s.offset().top - 20);
}

//获取地址栏参数
String.prototype.getQuery = function (name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

/***
* 含有中英文时，计算字串的字节数
*/
String.prototype.len = function () {
    return this.replace(/[^\x00-\xff]/g, "rr").length;
}
//返回指定长度的字符串
function getStr(str, len) {
    var strLen = str.len();
    if (strLen <= len) return str;
    var rgx = /[^\x00-\xff]/,
		resultStr = '',
		k = 0,
		m = 0;
    while (m < len) {
        var tempStr = str.charAt(k);
        rgx.test(tempStr) ? m += 2 : m++;
        k++;
        resultStr += tempStr;
    }
    return resultStr + '...';
}

//转码
function encodeStr(prev, str) {
    var tempStr = "";
    for (var i = 0; i < str.length; i++) {
        var hexStr = str.charCodeAt(i).toString(16);
        if (hexStr.length <= 2) {//按UTF-16进行编码		
            hexStr = "00" + hexStr;
        }
        tempStr += hexStr;
    }
    tempStr = "0x" + tempStr;
    return prev + "X-CUSTOM" + tempStr;
}

function HtmlEncode(sStr) {
    sStr = sStr.replace(/&/g, "&amp;");
    sStr = sStr.replace(/>/g, "&gt;");
    sStr = sStr.replace(/</g, "&lt;");
    sStr = sStr.replace(/"/g, "&quot;");
    sStr = sStr.replace(/'/g, "&#39;");
    return sStr;
}

function HtmlUnEncode(sStr) {
    sStr = sStr.replace(/&amp;/g, "&");
    sStr = sStr.replace(/&gt;/g, ">");
    sStr = sStr.replace(/&lt;/g, "<");
    sStr = sStr.replace(/&quot;/g, '"');
    sStr = sStr.replace(/&#39;/g, "'");
    return sStr;
}

//ajax结果提示
function ajaxTips(msg) {
    var at = $('#ajaxTips'), w = $(window);
    at.text(msg);
    at.css('top', 0).css('left', (w.width() - at.width()) / 2).show().delay(1500).fadeOut(500);
}

//log ajax提交
//添加日志上报logClass  long qqNo, String ip, String action,String ScreenWH,String coordinate,String content
//调用方法：$('.logClass').live("click", logSubmit);
function logSubmit(event) {
    var action = $(this).attr("name");
    var explore = navigator.appName + ';' + navigator.appVersion; //浏览器名称、版本号
    var platform = navigator.platform;  //操作系统
    var cookieEnable = navigator.cookieEnabled;  //是否启用cookie
    var userAgent = navigator.userAgent; //用户代理
    var javaEnable = navigator.javaEnabled(); //是否启用Java
    var screenWH = screen.width + "*" + screen.height;  //屏幕大小
    var color = window.screen.colorDepth; //浏览器颜色
    var strHref = window.location.href;
    var mouseXY = event.pageX + "*" + event.pageY; //鼠标位置
    var myDate = new Date();   //时间
    $.post("../OpratelogHandler.ashx", {
        action: action,
        time: myDate.getTime(),
        explore: explore,
        platform: platform,
        cookie: cookieEnable,
        agent: userAgent,
        java: javaEnable,
        href: strHref,
        color: color,
        screen: screenWH,
        coordinate: mouseXY,
        X_Content_Type: "json"
    });
}

//原型继承
function Extend(child, parent) {
    function f() { };
    f.prototype = parent;
    child.prototype = new f();
    child.prototype.constructor = child;
}

//分析result
var resolveResult = function (result, msg) {
    if (result == '-1000') {
        noLogin();
        return false;
    } else if (result == '-1') {
        ajaxTips(msg);
        return false;
    }
    return true;
}

var isLogin = function (callback) {
    $.ajax({
        url: '/check_login_json.jsp',
        type: 'POST',
        dataType: 'json',
        data: { myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json' },
        success: function (data) {
            data.result == '0' ? callback() : noLogin();
        }
    })
}

//未登陆处理
var noLogin = function () {
    top.location = '../Home/LogTimeOut';
}

/*var myDate = new Date();
myDate.getYear();        //获取当前年份(2位)  
myDate.getFullYear();    //获取完整的年份(4位,1970-????)  
myDate.getMonth();       //获取当前月份(0-11,0代表1月)  
myDate.getDate();        //获取当前日(1-31)  
myDate.getDay();         //获取当前星期X(0-6,0代表星期天)  
myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)  
myDate.getHours();       //获取当前小时数(0-23)  
myDate.getMinutes();     //获取当前分钟数(0-59)  
myDate.getSeconds();     //获取当前秒数(0-59)  
myDate.getMilliseconds();    //获取当前毫秒数(0-999)  
myDate.toLocaleDateString();     //获取当前日期  
var mytime = myDate.toLocaleTimeString();     //获取当前时间  
myDate.toLocaleString();        //获取日期与时间 */