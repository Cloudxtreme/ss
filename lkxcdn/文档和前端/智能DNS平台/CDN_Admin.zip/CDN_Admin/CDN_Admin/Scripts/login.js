
//ȥ��ո�
function ltrim(s){ 
    return s.replace( /^\s*/, ""); 
} 
//ȥ�ҿո�; 
function rtrim(s){ 
    return s.replace( /\s*$/, "");
}
$(function () {
    $("#valiCode").bind("click", function () {
        this.src = "../Home/GetValidateCode?time=" + (new Date()).getTime();
    });
});
function login() {
    var loginn = rtrim(ltrim(document.getElementById('txt_user').value));
    var loginp = rtrim(ltrim(document.getElementById('txt_pwd').value));
    var loginc = rtrim(ltrim(document.getElementById('txt_code').value));
    var cookie = $('#user_cookie').val();
    if (loginn == "") {
        document.getElementById('msg').innerHTML = "�������û�����";
        $("#use_ck").html("*");
        document.getElementById('txt_user').focus();
        return false;
    }
    else {
        $("#use_ck").html("");
    }
    if (loginp == "") {
        document.getElementById('msg').innerHTML = "���������룡";
        $("#pwd_ck").html("*");
        document.getElementById('txt_pwd').focus();
        return false;
    }
    else {
        $("#pwd_ck").html("");
    }
    if (loginp.length < 3) {
        document.getElementById('msg').innerHTML = "���벻��С��3λ��";
        $("#pwd_ck").html("*");
        document.getElementById('txt_pwd').focus();
        return false;
    }
    else {
        $("#pwd_ck").html("");
    }
    if (loginc == "" || loginc.length != 5) {
        document.getElementById('msg').innerHTML = "��������ȷ����֤�룡";
        document.all('txt_code').focus();
        return false;
    }
    $("#msg").html("������֤�У����Ժ�...");
    $.ajax(
            {
                url: '/Home/CheckLogin',
                data: "user=" + loginn + "&pwd=" + loginp + "&cookie=" + cookie + "&code=" + loginc,  // 
                type: "POST",
                //contentType: "charset=utf-8",
                dataType: "text",
                success: function (data) {
                    if (data == null || data.length == 0) {
                        alert("��֤ʧ�ܣ�");
                        return false;
                    } else {
                        if (data == "true") {
                            window.location = "../Home/dns_Mgr";
                        }
                        else {
                            $("#msg").html("");
                            alert(data);
                        }
                    }
                },
                error: function (data) {
                    alert(data.statusText);
                }
            });
}

function reset() {
    $('#txt_user').val("");
    $('#txt_pwd').val("");
    $('#txt_code').val("");
}

