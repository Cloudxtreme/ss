﻿function showLoad() {
    $('#progressbar').window({
        modal: true,
        shadow: false,
        title: ""
    });
}
function showHide() {
    $('#progressbar').window('close');
}