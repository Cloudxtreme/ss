﻿function DeleDns(num) {
    var r = confirm("确定删除吗？");
    if (r == true) {
        var id = $("#td_" + num).html();
        $.ajax(
        {
            url: '/Home/DeleDnsObj',
            data: "id=" + id,
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                alert(data);
                window.location.reload();
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
}
//添加新纪录
function SaveAdd() {
    var dns = $("#add_dns").val();
    var desc = $("#add_desc").val();
 //   var statu = $("#add_statu").val();
    if (String(dns).length == 0 || dns == null) {
        alert("域名是必填项！");
        return false;
    }
    $.ajax(
    {
        url: '/Home/AddNew',
        data: "dns=" + dns + "&desc=" + desc + "&statu=false",
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            alert(data);
            window.location.reload();
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}
//保存DNS的修改
function SaveDns(num) {
    var id = $("#td_" + num).html();
    var dns = $("#dns_" + num).val();
    var desc = $("#desc_" + num).val();
    var statu = $("#statu_" + num).val();
    $.ajax(
    {
        url: '/Home/EditDnsObj',
        data: "id=" + id + "&dns=" + dns + "&desc=" + desc + "&statu=" + statu,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            alert(data);
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}

//添加服务器
function ShowAddIp(addr) {
    var dns = $("#add_dns_" + addipid).val();
    RemoveDetailTable();  //删除表格数据
    $('#win').window({
        closed: false,
        title: "添加域名 " + dns + " 的 IP 绑定"
    });
}

//获取该域名的所有ip绑定
function DnsDetail(id, name) {
    $('#win').window({
        closed: false,
        title: "域名 " + name + " 绑定情况"
    });
    $.ajax(
    {
        url: '/Home/GetListByDns',
        data: "dns=" + id,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            //alert(data);
            if (data == null || data.length == 0) {
                alert("数据获取失败！");
            } else {
                SetData(data, id);
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}

function SetData(data, dns_id) {
    ClearData();
    $('#dns_ip_add').val(dns_id); //绑定域名id
    var arr = data.split('|');
    for (var i = 0; i < arr.length; i++) {
        var str = arr[i].split('&');
        gotoAdd(str[0],str[1]);
    }
}
//添加数据行
function gotoAdd(tb, str) {
    var tableElement;
    if (tb == "东北电信") {
        tableElement = $("#tb_db_ct");
    }
    else if (tb == "东北网通") {
        tableElement = $("#tb_db_cnc");
    }
    else if (tb == "华北电信") {
        tableElement = $("#tb_hb_ct");
    }
    else if (tb == "华北网通") {
        tableElement = $("#tb_hb_cnc");
    }
    else if (tb == "华东电信") {
        tableElement = $("#tb_hd_ct");
    }
    else if (tb == "华东网通") {
        tableElement = $("#tb_hd_cnc");
    }
    else if (tb == "华中电信") {
        tableElement = $("#tb_hz_ct");
    }
    else if (tb == "华中网通") {
        tableElement = $("#tb_hz_cnc");
    }
    else if (tb == "华南电信") {
        tableElement = $("#tb_hn_ct");
    }
    else if (tb == "华南网通") {
        tableElement = $("#tb_hn_cnc");
    }
    else if (tb == "西北电信") {
        tableElement = $("#tb_xb_ct");
    }
    else if (tb == "西北网通") {
        tableElement = $("#tb_xb_cnc");
    }
    else if (tb == "西南电信") {
        tableElement = $("#tb_xn_ct");
    }
    else if (tb == "西南网通") {
        tableElement = $("#tb_xn_cnc");
    }
    else if (tb == "其它电信") {
        tableElement = $("#tb_qt_ct");
    }
    else if (tb == "其它网通") {
        tableElement = $("#tb_qt_cnc");
    }
    var arr = str.split('*');
    for (var k = 0; k < arr.length; k++) {
        var itemArr = arr[k].split(',');
        if (itemArr.length == 7) {
            if (itemArr[6] == "false") {
                tableElement.append("<tr>"
                + "<td id=\"id_" + itemArr[0] + "\">" + itemArr[0] + "</td>" //id
                + "<td id=\"ip_" + itemArr[0] + "\">" + itemArr[3] + "</td>" //ip
                + "<td id=\"net_" + itemArr[0] + "\">" + itemArr[4] + "</td>" //nettype
                + "<td id=\"desc_" + itemArr[0] + "\">" + itemArr[5] + "</td>" //desc
                + "<td>" + itemArr[1] + "</td>" //时间
                + "<td><input type=\"input\" id=\"ttl_" + itemArr[0] + "\" style=\"width:50px\" value=\"" + itemArr[2] + "\" /></td>" //ttl
                + "<td><input type=\"checkbox\" id=\"ck_" + itemArr[0] + "\" /></td>"
                + "<td><input type=\"button\" value=\"保 存\" onclick=\"SaveDetailIp(\'" + itemArr[0] + "\',\'" + tb + "\')\" /></td>"
                + "</tr>");
            }
            else {
                tableElement.append("<tr>"
                + "<td id=\"id_" + itemArr[0] + "\">" + itemArr[0] + "</td>" //id
                + "<td id=\"ip_" + itemArr[0] + "\">" + itemArr[3] + "</td>" //ip
                + "<td id=\"net_" + itemArr[0] + "\">" + itemArr[4] + "</td>" //nettype
                + "<td id=\"desc_" + itemArr[0] + "\">" + itemArr[5] + "</td>" //desc
                + "<td>" + itemArr[1] + "</td>" //时间
                + "<td><input type=\"input\" id=\"ttl_" + itemArr[0] + "\" style=\"width:50px\" value=\"" + itemArr[2] + "\" /></td>" //ttl
                + "<td><input type=\"checkbox\" checked id=\"ck_" + itemArr[0] + "\" /></td>"
                + "<td><input type=\"button\" value=\"保 存\" onclick=\"SaveDetailIp(\'" + itemArr[0] + "\',\'" + tb + "\')\" /></td>"
                + "</tr>");
            }
        }
        else {
            alert('显示内容出错！');
        }
    }
}

function SaveDetailIp(id, area) {
    var editNum = $("#id_" + id).html();
    if ($('#ck_' + id).attr("checked")) {
        if (editNum.indexOf('_') > 0) { //新增对象
            //alert("新增");
            SaveDetailAdd(id, area);
        }
        else {
            //保存修改
            //alert("修改");
            SaveDetailEdit(id, area);
        }
    }
    else {
        if (editNum.indexOf('_') > 0) {
            //alert("不操作");
            return false;
        }
        else {
            //alert("删除");
            DeleIp(id);
        }
    }
}

//新增ip对象
function SaveDetailAdd(addNum,area) {
    var ip = $("#ip_" + addNum).html();
    var ttl = $("#ttl_" + addNum).val();
    var dnsID = $('#dns_ip_add').val();
    if (dnsID == null || dnsID.lenght == 0 || ttl == null || ttl.lenght == 0) {
        alert("资料不完整！");
        return false;
    }
    if ($('#ck_' + addNum).attr("checked")) {
        $.ajax(
        {
            url: '/Home/AddIpObj',
            data: "dns=" + dnsID + "&ip=" + String(ip) + "&area=" + area + "&ttl=" + ttl,
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0 || data.indexOf('！') > 0) {
                    alert("添加失败！");
                } else {
                    alert("添加成功！");
                    $("#id_" + addNum).html(data);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
}
//保存ip对象的编辑
function SaveDetailEdit(Num,area) {
    //获取id值
    var editNum = $("#id_" + Num).html();
    var ttl = $("#ttl_" + editNum).val();
    if (ttl.length == 0 || ttl == null) {
        alert("ttl不能为空！");
        return false;
    }
    $.ajax(
    {
        url: '/Home/EditIpObj',
        data: "id=" + Number(editNum) + "&ttl=" + Number(ttl),
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            if (data == null || data.length == 0) {
                alert("操作返回失败！");
            } else {
                alert(data);
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}

//删除ip对象
function DeleIp(Num) {
    var editNum = $("#id_" + Num).html();
    $.ajax(
    {
        url: '/Home/DeleIpObj',
        data: "id=" + Number(editNum),
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            alert(data);
            $("#id_" + Num).html("dele_id");
            //window.location.reload();
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}

var ClearData = function () {
    $('#dns_ip_add').val("");
    $("#tb_db_ct tr:not(:first)").remove();
    $("#tb_db_cnc tr:not(:first)").remove();
    $("#tb_hb_ct tr:not(:first)").remove();
    $("#tb_hb_cnc tr:not(:first)").remove();
    $("#tb_hd_ct tr:not(:first)").remove();
    $("#tb_hd_cnc tr:not(:first)").remove();
    $("#tb_hz_ct tr:not(:first)").remove();
    $("#tb_hz_cnc tr:not(:first)").remove();
    $("#tb_hn_ct tr:not(:first)").remove();
    $("#tb_hn_cnc tr:not(:first)").remove();
    $("#tb_xb_ct tr:not(:first)").remove();
    $("#tb_xb_cnc tr:not(:first)").remove();
    $("#tb_xn_ct tr:not(:first)").remove();
    $("#tb_xn_cnc tr:not(:first)").remove();
    $("#tb_qt_ct tr:not(:first)").remove();
    $("#tb_qt_cnc tr:not(:first)").remove();
}