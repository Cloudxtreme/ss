﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web;

namespace CDN_File_Client.Core
{
    public class MySqlConn
    {
        private static string _MYSQL_SERVER = String.Empty;
        private static string _MYSQL_SERVER_STATUS = String.Empty;
        private static string _Weblogdw_SERVER = String.Empty;
        private static string _HotFile_Server = String.Empty;
        private static string _FileDownload_Server = String.Empty;
        private static string _CatchMgr_SERVER = String.Empty;

        /// <summary>
        /// dtl_server数据库连接串
        /// </summary>
        public static string MYSQL_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_SERVER))
                {
                    if (ConfigurationManager.ConnectionStrings["MySql_Server"] == null)
                    {
                        throw new Exception("the config node 'MySql_Server' is required in web.config");
                    }

                    lock (_MYSQL_SERVER)
                    {
                        _MYSQL_SERVER = ConfigurationManager.ConnectionStrings["MySql_Server"].ConnectionString;
                    }
                }
                return _MYSQL_SERVER;
            }
        }

        public static string Weblogdw_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_Weblogdw_SERVER))
                {
                    if (ConfigurationManager.ConnectionStrings["Filelog_Server"] == null)
                    {
                        throw new Exception("the config node 'Filelog_Server' is required in web.config");
                    }

                    lock (_Weblogdw_SERVER)
                    {
                        _Weblogdw_SERVER = ConfigurationManager.ConnectionStrings["Filelog_Server"].ConnectionString;
                    }
                }
                return _Weblogdw_SERVER;
            }
        }

        public static string HotFile_Server
        {
            get
            {
                if (String.IsNullOrEmpty(_HotFile_Server))
                {
                    if (ConfigurationManager.ConnectionStrings["HotFile_Server"] == null)
                    {
                        throw new Exception("the config node 'HotFile_Server' is required in web.config");
                    }

                    lock (_HotFile_Server)
                    {
                        _HotFile_Server = ConfigurationManager.ConnectionStrings["HotFile_Server"].ConnectionString;
                    }
                }
                return _HotFile_Server;
            }
        }

        public static string FileDownload_Server
        {
            get
            {
                if (String.IsNullOrEmpty(_FileDownload_Server))
                {
                    if (ConfigurationManager.ConnectionStrings["FileDownload_Server"] == null)
                    {
                        throw new Exception("the config node 'FileDownload_Server' is required in web.config");
                    }

                    lock (_FileDownload_Server)
                    {
                        _FileDownload_Server = ConfigurationManager.ConnectionStrings["FileDownload_Server"].ConnectionString;
                    }
                }
                return _FileDownload_Server;
            }
        }

        public static string CATCHMGR_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_CatchMgr_SERVER))
                {
                    if (ConfigurationManager.ConnectionStrings["CatchMgr_MySql_Server"] == null)
                    {
                        throw new Exception("the config node 'CatchMgr_MySql_Server' is required in web.config");
                    }

                    lock (_CatchMgr_SERVER)
                    {
                        _CatchMgr_SERVER = ConfigurationManager.ConnectionStrings["CatchMgr_MySql_Server"].ConnectionString;
                    }
                }
                return _CatchMgr_SERVER;
            }
        }

        //获取流量查询连接字符串
        public static string GetStatsConn()
        {
            try
            {
                string strSql = "select `ip` from `server_list` where `type` = 'cdn_file_stats'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string sql = "select `value` from `server_info` where `serverip` = '" + Ds.Tables[0].Rows[0][0].ToString().Trim() + "'";
                    DataSet endDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
                    //string s = ReplaceConn(endDs.Tables[0].Rows[0][0].ToString()) + "Database=cdn_server_stats;charset=gbk";
                    string s = ReplaceConn(endDs.Tables[0].Rows[0][0].ToString()) + "Database=cdn_portrate_stats;charset=gbk";
                    return s;
                }
            }
            catch
            {
                return "";
            }
            return "";
        }

        //修改连接字符串
        public static string ReplaceConn(string or_con)
        {
            //ip=121.9.13.246;port=3306;user=cdn;pass=cdncdncdn
            //User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk
            string[] connArr = or_con.Split(';');
            if (connArr.Length >= 4)
            {
                connArr[0] = connArr[0].Replace("ip", "Host");
                connArr[2] = connArr[2].Replace("user", "User Id");
                connArr[3] = connArr[3].Replace("pass", "password");
                return connArr[0] + ";" + connArr[2] + ";" + connArr[3] + ";";
            }
            else
            {
                return "";
            }
        }




    }
}