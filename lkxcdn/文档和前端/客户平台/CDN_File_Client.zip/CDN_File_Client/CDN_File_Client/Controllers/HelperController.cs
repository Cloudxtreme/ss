﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CDN_File_Client.Controllers
{
    public class HelperController : Controller
    {
        [HttpGet]  //使用帮助
        public ActionResult Helper()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        [HttpGet]  //使用帮助
        public ActionResult Index()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]  //使用帮助
        public ActionResult help_1()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]  //使用帮助
        public ActionResult help_2()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]  //使用帮助
        public ActionResult help_3()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]  //使用帮助
        public ActionResult help_4()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]  //使用帮助
        public ActionResult help_5()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

    }
}
