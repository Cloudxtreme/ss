﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using System.Data;
using CDN_File_Client.Core;

namespace CDN_File_Client.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetValidateCode()
        {
            ValidateCode vCode = new ValidateCode();
            string code = vCode.CreateValidateCode(5);
            Session["ValidateCode"] = code;
            byte[] bytes = vCode.CreateValidateGraphic(code);
            return File(bytes, @"image/jpeg");
        }

        public ActionResult Login()
        {
            if (HttpContext.Session["user"] != null)
            {
                HttpContext.Session["user"] = null;    //用户名
                HttpContext.Session["pwd"] = null;
                HttpContext.Session["path"] = null;   //文件夹名
                HttpContext.Session["stats"] = null;  //数据库名称
                HttpContext.Session["desc"] = null;
                //Session["ValidateCode"] = null;
            }
            Cookie Cookie = new Cookie();
            ViewData["name"] = "";
            ViewData["pwd"] = "";
            string name = Cookie.getCookie("fileClientName");//取值
            string pwd = Cookie.getCookie("fileClientPwd");
            if (!string.IsNullOrEmpty(name))
            {
                ViewData["name"] = name;
            }
            if (!string.IsNullOrEmpty(pwd))
            {
                ViewData["pwd"] = pwd;
            }
            return View();
        }
        public ActionResult LogTimeOut()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }

        //Ajax Mothed
        public string ChangePwd(string oldPwd, string newPwd)
        {
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(oldPwd) | r.IsMatch(newPwd))
                {
                    //SQL注入
                    return "请不要攻击该系统，您的行为已经被我们记录！";
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Clear();
                    strSql.Append("SELECT Count(`user`),`user` FROM `user` where `user`='" + HttpContext.Session["user"].ToString().Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(oldPwd.Trim(), "MD5").ToLower() + "' and status='true'");
                    MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (sdr.Read())
                    {
                        if (int.Parse(sdr["Count(`user`)"].ToString()) == 1)
                        {
                            strSql.Clear();
                            strSql.Append("update `user` set `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(newPwd.Trim(), "MD5").ToLower() + "' where `user`='" + HttpContext.Session["user"].ToString().Trim() + "'");
                            int result = MySql.Data.MySqlClient.MySqlHelper.ExecuteNonQuery(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                            if (result == 1)
                            {
                                HttpContext.Session["pwd"] = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(newPwd.Trim(), "MD5").ToLower();
                                return "修改成功！";
                            }
                        }
                        else
                        {
                            return "原始密码错误！";
                        }
                    }
                }
                return "修改失败！";
            }
            catch
            {
                return "修改出错，请联系管理员！";
            }
        }

        public string CheckLogin(string user, string pwd, string code, string type, string cookie)
        {
            string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
            Regex r = new Regex(pat);
            if (r.IsMatch(user) | r.IsMatch(pwd) | r.IsMatch(code))
            {
                //SQL注入
                return "请不要尝试注入我们的系统，您的行为我们已经记录！";
            }
            else
            {
                Cookie Cookie = new Cookie();
                if (cookie.Trim() == "记住")
                {
                    Cookie.setCookie("fileClientName", user, 1);
                    Cookie.setCookie("fileClientPwd", pwd, 1);
                }
                else
                {
                    Cookie.delCookie("fileClientName");
                    Cookie.delCookie("fileClientPwd");
                }
                if (type != "company")
                {
                    if (code.Trim() != Session["ValidateCode"].ToString())
                    {
                        return "验证码错误！";
                    }
                }
                if (CheckUser(user.Trim(), pwd.Trim(), type.Trim()))
                {
                    return "true";
                }
            }
            return "验证失败！";
        }
        //私有方法
        private bool CheckUser(string name, string pwd, string type)
        {
            MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(name) | r.IsMatch(pwd))
                {
                    //SQL注入
                    return false;
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    if (type == "company")
                    {
                       strSql.Append("SELECT Count(`user`),`user`,`path`,`type`,`stats`,`desc` FROM `user` where `user`='" + name.Trim() + "'  and status='true'");
                    }
                    else
                    {
                      //  strSql.Append("SELECT Count(`user`),`user`,`path`,`type`,`stats`,`desc` FROM `user` where `user`='" + name.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd, "MD5").ToLower() + "' and status='true'");
                        strSql.Append("SELECT Count(`user`),`user`,`path`,`type`,`stats`,`desc` FROM `user` where `user`='" + name.Trim() + "'  and status='true'");
                    }
                    DataSet sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql.ToString());
                    conn.Close();
                    if (sdr.Tables[0] != null)
                    {
                        if (int.Parse(sdr.Tables[0].Rows[0]["Count(`user`)"].ToString()) == 1)
                        {
                            HttpContext.Session["user"] = sdr.Tables[0].Rows[0]["user"];    //用户名
                            if (type == "company")
                            {
                                HttpContext.Session["pwd"] = pwd.Trim().ToLower();
                                HttpContext.Session["userType"] = sdr.Tables[0].Rows[0]["type"];
                            }
                            else
                            {
                                HttpContext.Session["pwd"] = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd, "MD5").ToLower();
                            }
                            HttpContext.Session["path"] = sdr.Tables[0].Rows[0]["path"];   //文件夹名
                            HttpContext.Session["stats"] = sdr.Tables[0].Rows[0]["stats"];  //数据库名称
                            HttpContext.Session["desc"] = sdr.Tables[0].Rows[0]["desc"];  //备注、名称
                            HttpContext.Session["userType"] = sdr.Tables[0].Rows[0]["type"];   
                            return true;
                        }
                    }
                }
                return false;
            }
            catch
            {
                if (conn != null)
                {
                    conn.Close();
                }
                return false;
            }
        }
    }
}
