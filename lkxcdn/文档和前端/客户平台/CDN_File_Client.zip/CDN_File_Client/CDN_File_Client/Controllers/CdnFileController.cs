﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CDN_File_Client.Models;
using CDN_File_Client.Core;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections;

namespace CDN_File_Client.Controllers
{
    public class CdnFileController : Controller
    {
        //
        // GET: /CdnFile/

        public ActionResult Index()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult VisitRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult newVisitRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                //ViewData["domain"] = GetHostListByUser(user);

                List<AddrModels> hostList = GetHostListByUser(user);
                List<AddrModels> newHostList = new List<AddrModels>();
                if (hostList != null)
                {
                    foreach (AddrModels models in hostList)
                    {
                        if (models.hostname.IndexOf("*") != 0 && models.hostname.IndexOf(".") != 0)
                        {
                            newHostList.Add(models);
                        }
                    }

                    ViewData["domain"] = newHostList;
                }
                return View();
            }
        }

        public ActionResult MapRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                //ViewData["domain"] = GetHostListByUser(user);

                List<AddrModels> hostList = GetHostListByUser(user);
                List<AddrModels> newHostList = new List<AddrModels>();

                if (hostList != null)
                {
                    foreach (AddrModels models in hostList)
                    {
                        if (models.hostname.IndexOf("*") != 0 && models.hostname.IndexOf(".") != 0)
                        {
                            newHostList.Add(models);
                        }
                    }
                    ViewData["domain"] = newHostList;
                }

                return View();
            }
        }

        public ActionResult FileList()
        {
            if (HttpContext.Session["user"] != null && HttpContext.Session["path"] != null)
            {
                string user = HttpContext.Session["user"].ToString();
                string path = HttpContext.Session["path"].ToString();
                List<FileModels> files = GetFileList(user, 1, path.Trim());
                int totalNum = GetFilesNum(HttpContext.Session["path"].ToString());
                ViewData["TotalNum"] = totalNum;
                ViewData["user"] = user;
                ViewData["md5"] = HttpContext.Session["pwd"].ToString();
                List<FileModels> list = GetClientDomain(HttpContext.Session["user"].ToString());
                string domainStr = "";
                if (list != null)
                {
                    foreach(FileModels item in list)
                    {
                        domainStr += item.FilePath + "@";
                    }
                }
                ViewData["clientDomain"] = domainStr;
                ViewData["TaskList"] = GetTaskList(HttpContext.Session["user"].ToString());
                if (files != null)
                {
                    return View(files);
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        public ActionResult HotFileList(string start = "", string end = "",string filename="")
        {
            if (HttpContext.Session["user"] != null )
            {
                if (HttpContext.Session["userType"].ToString() == "cdnfile_hot")
                {
                    DateTime dtBegin;
                    DateTime dtEnd;
                    if (start.Trim().Length <= 0 || end.Trim().Length <= 0)
                    {
                        dtBegin = DateTime.Now.AddDays(-1);
                        dtEnd = DateTime.Now;
                    }
                    else
                    {
                        dtBegin = Convert.ToDateTime(start);
                        dtEnd = Convert.ToDateTime(end);
                    }

                    string user = HttpContext.Session["user"].ToString();
                    List<HotFileModels> files = GetHotFileList(user, 1, dtBegin, dtEnd,filename);
                    int totalNum = GetHotFilesNum(user,dtBegin,dtEnd);
                    ViewData["TotalNum"] = totalNum;
                    ViewData["user"] = user;
                    ViewData["start"] = dtBegin.ToString("yyyy-MM-dd");
                    ViewData["end"] = dtEnd.ToString("yyyy-MM-dd");
                    ViewData["filename"] = filename;
                    // ViewData["md5"] = HttpContext.Session["pwd"].ToString();

                    if (files != null)
                    {
                        return View(files);
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        public ActionResult ClientDomain()
        {
            if (HttpContext.Session["user"] != null)
            {
                List<FileModels> list = GetClientDomainFromInfo(HttpContext.Session["user"].ToString());
                if (list != null)
                {
                    return View(list);
                }
                return View();
            }
            else
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }

        //流量统计
        [HttpGet]
        public ActionResult TrafficRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                return View();
            }
        }

        //流量统计
        [HttpGet]
        public ActionResult DLCount()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                return View();
            }
        }

        //峰值统计
        [HttpGet]
        public ActionResult TopRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                string timeSpan = GetDateTable();
                if (!string.IsNullOrEmpty(timeSpan))
                {
                    ViewData["TimeSpan"] = timeSpan;
                }
                return View();
            }
        }
        //流量监控
        [HttpGet]
        public ActionResult TrafficMnt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                string IpPort = GetIpPortByUser(user.Trim());
                string timeSpan = GetDateTable();
                ViewData["area"] = null;
                ViewData["TimeSpan"] = null;
                ViewData["server"] = null;
                if (!string.IsNullOrEmpty(IpPort))
                {
                    ViewData["server"] = IpPort;
                    string[] IpArr = IpPort.Split(',');
                    string IpStr = "";
                    for (int m = 0; m < IpArr.Length; m++)
                    {
                        string[] s = IpArr[m].Split(':');
                        if (m == 0)
                        {
                            IpStr = "'" + s[0] + "'";
                        }
                        else
                        {
                            IpStr += ",'";
                            IpStr += s[0] + "'";
                        }
                    }
                    string area = GetAreaByIp(IpStr);
                    ViewData["area"] = area;
                }
                if (!string.IsNullOrEmpty(timeSpan))
                {
                    ViewData["TimeSpan"] = timeSpan;
                }
                return View();
            }
        }
        //日志下载
        public ActionResult Download()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                System.Net.WebClient clinet = new System.Net.WebClient();
                string url = "http://filelogdw.cdn.efly.cc/cdn_file_log/log_file_list.php?client=" + user + "";
                System.IO.Stream stream = clinet.OpenRead(url);
                System.IO.StreamReader reader = new System.IO.StreamReader(stream, Encoding.GetEncoding("UTF-8"));
                string result = reader.ReadToEnd();
                ViewData["result"] = result;

                return View();
            }
        }

        ////////
        //-----Ajax Post Method
        ///////

        [HttpPost, ActionName("DeleAutoTask")]
        public string DeleAutoTask(string id)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "登录超时，请重新登录！";
            }
            else
            {
                MySqlConnection mycn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                if (mycn != null)
                {
                    try
                    {
                        StringBuilder strSql = new StringBuilder();
                        strSql.Clear();
                        mycn.Open();
                        strSql.Append("delete from `auto_delivery` where id = '" + id.Trim() + "' and `owner` = '" + HttpContext.Session["user"].ToString() + "'");
                        MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                        int result = cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        mycn.Close();
                        if (1 == result)
                            return "删除成功！";
                    }
                    catch
                    {
                        if (mycn != null) mycn.Close();
                    }
                }
                return "删除失败！";
            }
        }

        [HttpPost, ActionName("DoAutoTask")]
        public string DoAutoTask(string fileName, string filePath, string fileNum, string fileMd5)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "登录超时，请重新登录！";
            }
            else
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("select `id` from `auto_delivery` where `filename`='" + fileName.Trim() + "' and `filepath`='" + filePath.Trim() + "' and `owner`='" + HttpContext.Session["user"].ToString() + "' and `status`='true'");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        return "已经存在该文件的自动任务！";
                    }
                    else
                    {
                        strSql.Clear();
                        MySqlConnection mycn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                        mycn.Open();
                        strSql.Append("insert into `auto_delivery`(`filename`,`filepath`,`filesize`,`md5`,`timestamp`,`owner`,`status`)values('" + fileName.Trim() + "','" + filePath.Trim() + "','" + fileNum.Trim() + "','" + fileMd5.Trim() + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + HttpContext.Session["user"].ToString() + "','true')");
                        MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                        int result = cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        mycn.Close();
                        if (1 == result)
                            return "添加成功！";
                    }
                }
                catch
                {
                    return "添加报错，请联系管理员！";
                }
                return "添加失败！";
            }
        }

        [HttpPost, ActionName("GetVisitChartData")]
        public string GetVisitChartData(string start, string end)
        {
            try
            {
                Hashtable ipArea = GetIpAreaMap();
                Hashtable ipNettype = GetIpNettypeMap();
                if (ipArea != null && ipNettype != null)
                {
                    DateTime DateStart = DateTime.Parse(start.Trim());
                    DateTime DateEnd = DateTime.Parse(end.Trim());
                    TimeSpan span = DateEnd - DateStart;
                    string db = HttpContext.Session["stats"].ToString();
                    string conStr = MySqlConn.GetStatsConn().Replace("cdn_portrate_stats", db);
                    if (!string.IsNullOrEmpty(conStr))
                    {
                        MySqlConnection conn = new MySqlConnection(conStr);
                        Hashtable TotalData = new Hashtable();
                        for (int i = 0; i < span.TotalDays; i++)
                        {
                            if (MyTableIsExist(conStr, DateStart.AddDays(i)))
                            {
                                Hashtable itemData = new Hashtable();
                                itemData = DoGetDayVisitData(DateStart.AddDays(i), conn);
                                if (itemData.Count > 0)
                                {
                                    foreach (DictionaryEntry obj in itemData)
                                    {
                                        if (TotalData.ContainsKey(obj.Key))
                                        {
                                            Double tmp_num = 0;
                                            tmp_num = double.Parse(TotalData[obj.Key].ToString()) + double.Parse(obj.Value.ToString());
                                            TotalData.Remove(obj.Key);
                                            TotalData.Add(obj.Key, tmp_num);
                                        }
                                        else
                                        {
                                            TotalData.Add(obj.Key, obj.Value);
                                        }
                                    }
                                }
                            }
                        }
                        if (TotalData.Count > 0)
                        {
                            Hashtable areaResult = new Hashtable();
                            Hashtable netypeResult = new Hashtable();
                            double traffic_total = 0; 
                            foreach (DictionaryEntry obj in TotalData)
                            {
                                //区域数据
                                string tmp_area = "";
                                try
                                {
                                    tmp_area = ipArea[obj.Key].ToString();
                                }
                                catch
                                {
                                }
                                if (!string.IsNullOrEmpty(tmp_area))
                                {
                                    if (areaResult.Contains(tmp_area))
                                    {
                                        Double tmp_area_num = 0;
                                        tmp_area_num = double.Parse(areaResult[ipArea[obj.Key].ToString()].ToString()) + double.Parse(obj.Value.ToString());
                                        areaResult.Remove(ipArea[obj.Key].ToString());
                                        areaResult.Add(ipArea[obj.Key].ToString(), tmp_area_num);
                                    }
                                    else
                                    {
                                        areaResult.Add(ipArea[obj.Key].ToString(), double.Parse(obj.Value.ToString()));
                                    }
                                }

                                //网络类型数据
                                string tmp_nettype = "";
                                try
                                {
                                    tmp_nettype = ipNettype[obj.Key].ToString();
                                }
                                catch
                                {
                                }
                                if (!string.IsNullOrEmpty(tmp_nettype))
                                {
                                    if (netypeResult.Contains(tmp_nettype))
                                    {
                                        Double tmp_netype_num = 0;
                                        tmp_netype_num = double.Parse(netypeResult[ipNettype[obj.Key].ToString()].ToString()) + double.Parse(obj.Value.ToString());
                                        netypeResult.Remove(ipNettype[obj.Key].ToString());
                                        netypeResult.Add(ipNettype[obj.Key].ToString(), tmp_netype_num);
                                    }
                                    else
                                    {
                                        netypeResult.Add(ipNettype[obj.Key].ToString(), double.Parse(obj.Value.ToString()));
                                    }
                                }
                                traffic_total += double.Parse(obj.Value.ToString());
                            }
                            //获取json数据
                            string area_json = "[";
                            if (areaResult.Count > 0)
                            {
                                foreach (DictionaryEntry o in areaResult)
                                {
                                    area_json += "['" + o.Key + "'," + ((double)o.Value * 100 / traffic_total).ToString("F3") + "],";
                                }
                            }
                            if (area_json.Length > 1)
                            {
                                area_json = area_json.Substring(0, area_json.Length - 1) + "]";
                            }
                            else
                            {
                                area_json = "[]";
                            }

                            string netype_json = "[";
                            if (netypeResult.Count > 0)
                            {
                                foreach (DictionaryEntry o in netypeResult)
                                {
                                    netype_json += "['" + o.Key + "'," + ((double)o.Value * 100 / traffic_total).ToString("F3") + "],";
                                }
                            }
                            if (netype_json.Length > 1)
                            {
                                netype_json = netype_json.Substring(0, netype_json.Length - 1) + "]";
                            }
                            else
                            {
                                netype_json = "[]";
                            }
                            return area_json + "#" + netype_json;
                        }
                    }
                    else
                    {
                        return "数据库信息读取失败！";
                    }
                }
            }
            catch{
            }
            return "";
        }


        [HttpPost, ActionName("GetNewVisitChartData")]
        public string GetNewVisitChartData(string start, string end)
        {
            if (HttpContext.Session["user"] == null)
            {
                return null;
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                DateTime t1 = DateTime.Parse(start);
                DateTime t2 = DateTime.Parse(end);
                System.TimeSpan ts = t2 - t1;
                int days = ts.Days;

                string dateJson = "[";
                for (int i = 0; i <= days; i++)
                {
                    dateJson += "'" + t1.AddDays(i).ToString("MM-dd") + "',";
                }
                dateJson = dateJson.Substring(0, dateJson.Length - 1) + "]";

                DataSet ds = new DataSet();

                string sql = string.Empty;

                if (TableIsExistByDomain("'" + user.ToString() + "'", MySqlConn.Weblogdw_SERVER))
                {
                    for (int i = 0; i <= days; i++)
                    {
                        sql += "select sum(`cnt`),`nettype` from `" + user.ToString() + "` where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' group by `nettype` order by `nettype`;";
                    }
                    ds = MySqlHelper.ExecuteDataset(MySqlConn.Weblogdw_SERVER, sql);
                }


                string nettypeJson = string.Empty;

                if (ds.Tables.Count > 0)
                {
                    nettypeJson = "{\"data\": {";
                    for (int count = 0; count < ds.Tables[0].Rows.Count; count++)
                    {
                        nettypeJson += "\"content" + count.ToString() + "\":[";
                        for (int row = 0; row < ds.Tables.Count; row++)
                        {
                            nettypeJson += ds.Tables[row].Rows[count][0].ToString() + ",";
                        }
                        nettypeJson = nettypeJson.Substring(0, nettypeJson.Length - 1) + "],";
                    }
                    nettypeJson = nettypeJson.Substring(0, nettypeJson.Length - 1) + "}}";
                }

                return dateJson + "#" + nettypeJson;
            }
        }

        [HttpPost, ActionName("GetMapData")]
        public string GetMapData(string start, string end)
        {
            if (HttpContext.Session["user"] == null)
            {
                return null;
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();

                DateTime t1 = DateTime.Parse(start);
                DateTime t2 = DateTime.Parse(end);
                System.TimeSpan ts = t2 - t1;
                int days = ts.Days;

                //string domainStr = GetDomainByUser(HttpContext.Session["user"].ToString());

                ////获取区域数据
                //string[] domArr = SplitDomain(domainStr);
                //string sql = string.Empty;
                //if (!string.IsNullOrEmpty(domArr[1])) //无*的
                //{
                //    string[] dom_item_Arr = domArr[1].Split(',');

                //    if (TableIsExistByDomain(dom_item_Arr[0].ToString(), MySqlConn.Weblogdw_SERVER))
                //    {
                //        for (int i = 0; i <= days; i++)
                //        {
                //            sql += "select sum(`cnt`),`zone` from " + dom_item_Arr[0].Replace("'", "`").ToString() + " where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' group by `zone` order by `zone`;";
                //        }
                //    }
                //}
                DataSet ds = new DataSet();
                string sql = string.Empty;

                if (TableIsExistByDomain("'" + user.ToString() + "'", MySqlConn.Weblogdw_SERVER))
                   // if (TableIsExistByDomain("'" + domain.ToString() + "'", MySqlConn.Weblogdw_SERVER))
                {
                    for (int i = 0; i <= days; i++)
                    {
                        // sql += "select sum(`cnt`),`nettype` from `" + domain.ToString() + "` where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' group by `nettype` order by `nettype`;";
                        sql += "select sum(`cnt`),`zone` from `" + user.ToString() + "` where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' and `zone`!='其它'  group by `zone` order by `zone`;";
                    }
                    ds = MySqlHelper.ExecuteDataset(MySqlConn.Weblogdw_SERVER, sql);
                }

                //ds = MySqlHelper.ExecuteDataset(MySqlConn.Weblogdw_SERVER, sql);
                string nettypeJson = string.Empty;

                DataTable dt = new DataTable();
                dt.Columns.Add("cnt", typeof(int));
                dt.Columns.Add("zone", typeof(string));
                //处理掉无数据的datatable
                DataSet resultDS = new DataSet();
                for (int count = 0; count < ds.Tables.Count; count++)
                {
                    if (ds.Tables[count].Rows.Count > 0)
                    {
                        DataTable cdt = ds.Tables[count].Copy();

                        resultDS.Tables.Add(cdt);
                        resultDS.AcceptChanges();
                    }
                }
                if (resultDS.Tables.Count > 0)
                {
                    for (int num = 0; num < resultDS.Tables[0].Rows.Count; num++)
                    {
                        DataRow dr = dt.NewRow();
                        dr[1] = ConvertCode(resultDS.Tables[0].Rows[num][1].ToString());
                        int cnt = 0;
                        for (int tbcount = 0; tbcount < resultDS.Tables.Count; tbcount++)
                        {
                            cnt += Convert.ToInt32(resultDS.Tables[tbcount].Rows[num][0].ToString());
                        }
                        dr[0] = cnt.ToString();
                        dt.Rows.Add(dr);
                        dt.AcceptChanges();
                    }

                    string zoneJson = string.Empty;
                    zoneJson = "{\"data\": {";
                    for (int count = 0; count < dt.Rows.Count; count++)
                    {
                        zoneJson += "\"" + dt.Rows[count][1].ToString() + "\":\"";

                        zoneJson += dt.Rows[count][0].ToString() + ",";

                        zoneJson = zoneJson.Substring(0, zoneJson.Length - 1) + "\",";
                    }
                    zoneJson = zoneJson.Substring(0, zoneJson.Length - 1) + "}}";

                    return zoneJson;
                }

                return null;
            }
        }

        //把中午地区转换为编码，格式由vectormap定义
        protected string ConvertCode(string zone)
        {
            string code = string.Empty;

            switch (zone)
            {
                case "香港": code = "HKG";
                    break;
                case "海南": code = "HAI";
                    break;
                case "云南": code = "YUN";
                    break;
                case "北京": code = "BEJ";
                    break;
                case "天津": code = "TAJ";
                    break;
                case "新疆": code = "XIN";
                    break;
                case "西藏": code = "TIB";
                    break;
                case "青海": code = "QIH";
                    break;
                case "甘肃": code = "GAN";
                    break;
                case "内蒙古": code = "NMG";
                    break;
                case "宁夏": code = "NXA";
                    break;
                case "山西": code = "SHX";
                    break;
                case "辽宁": code = "LIA";
                    break;
                case "吉林": code = "JIL";
                    break;
                case "黑龙江": code = "HLJ";
                    break;
                case "河北": code = "HEB";
                    break;
                case "山东": code = "SHD";
                    break;
                case "河南": code = "HEN";
                    break;
                case "陕西": code = "SHA";
                    break;
                case "四川": code = "SCH";
                    break;
                case "重庆": code = "CHQ";
                    break;
                case "湖北": code = "HUB";
                    break;
                case "安徽": code = "ANH";
                    break;
                case "江苏": code = "JSU";
                    break;
                case "上海": code = "SHH";
                    break;
                case "浙江": code = "ZHJ";
                    break;
                case "福建": code = "FUJ";
                    break;
                case "台湾": code = "TAI";
                    break;
                case "江西": code = "JXI";
                    break;
                case "湖南": code = "HUN";
                    break;
                case "贵州": code = "GUI";
                    break;
                case "广西": code = "GXI";
                    break;
                case "广东": code = "GUD";
                    break;
                case "澳门": code = "MAC";
                    break;
                default:
                    break;
            }

            return code;
        }

        //根据域名判断数据库是否存在该表
        private bool TableIsExistByDomain(string domain, string conn)
        {
            try
            {
                string strSql = "SHOW TABLES like " + domain + "";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql);
                if (Ds.Tables.Count>0&&Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        [HttpPost, ActionName("DeleUserDomain")]
        public string DeleUserDomain(string id)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "登录超时，请从新登录！";
            }
            else
            {
                MySqlConnection mycn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                try
                {
                    int domain_id = int.Parse(id);
                    StringBuilder strSql = new StringBuilder();
                    strSql.Clear();
                    mycn.Open();
                    strSql.Append("delete from `user_hostname` where `id`=" + domain_id);
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    mycn.Close();
                    if (1 == result)
                        return "删除成功！";
                }
                catch
                {
                    mycn.Close();
                }
                return "删除失败！";
            }
        }

        [HttpPost, ActionName("AddUserDomain")]
        public string AddUserDomain(string domain)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "登录超时，请从新登录！";
            }
            else
            {
                MySqlConnection mycn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Clear();
                    mycn.Open();
                    strSql.Append("insert into `user_hostname`(`hostname`,`status`,`owner`)values('" + domain.Trim() + "','true','" + HttpContext.Session["user"].ToString() + "')");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    mycn.Close();
                    if (1 == result)
                        return "添加成功！";
                }
                catch
                {
                    mycn.Close();
                }
                return "添加失败！";
            }
        }

        //获取chart数据
        [HttpPost, ActionName("GetChartDataByServer")]
        public string GetChartDataByServer(string server, string day, int span)
        {
            if (HttpContext.Session["user"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            string ipStr = "";
            string portStr = "";
            if (server.IndexOf('|') > 0)
            {
                string[] list = server.Trim().Split('|');
                for (int i = 0; i < list.Length - 1; i++)
                {
                    string[] s = list[i].Split(':');
                    if (i == 0)
                    {
                        ipStr = "'" + s[0] + "'";
                        portStr = s[1];
                    }
                    else
                    {
                        ipStr += ",'" + s[0] + "'";
                       // portStr += "," + s[1];
                    }
                }
            }
            else
            {
                string IpPortStr = GetIpPortByUser(HttpContext.Session["user"].ToString());
                string[] IpArr = IpPortStr.Split(',');
                string[] sarr = IpArr[0].Split(':');
                portStr = sarr[1];
                ipStr = "全部";
            }
            GetRptData getData = new GetRptData();
            List<TrafficModels> result = getData.GetRptDataList(DateTime.Parse(day), span, ipStr, portStr);
            return GetChartJson(result);
            //return "查询条件为空！";
        }

        //[HttpPost, ActionName("GetTotalStream")]
        //public string GetTotalStream(string start, string end)
        //{
        //    if (HttpContext.Session["user"] == null)
        //    {
        //        return "LogTimeOut";
        //    }
        //    else
        //    {
        //        try
        //        {
        //            DateTime _start = DateTime.Parse(start.Trim());
        //            DateTime _end = DateTime.Parse(end.Trim());
        //            TimeSpan span = _end - _start;
        //            string user = HttpContext.Session["user"].ToString();

        //            string conStr = "Host=filelogdw.cdn.efly.cc;User Id=root;password=rjkj@rjkj;Database=cdn_file_url_stats;charset=gbk";
        //            if (span.TotalDays >= 0 && !string.IsNullOrEmpty(conStr))
        //            {
        //                Double totalNum = 0;
        //                Double totalStream = 0;

        //                if (span.TotalDays > 0)  //超过一天
        //                {
        //                    for (int i = 0; i <= span.TotalDays; i++)
        //                    {
        //                        if (TableIsExistByDomain("'" + user + "'", conStr))
        //                        {
        //                            string sql = "select sum(`cnt`) scnt, sum(`sent`) ssent from `" + user + "` where `date`='" + _start.AddDays(i).ToString("yyyy-MM-dd") + "'";
        //                            DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
        //                            if (ds.Tables[0].Rows.Count > 0)
        //                            {
        //                                totalNum += ds.Tables[0].Rows[0]["scnt"].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0]["scnt"].ToString()) : 0;
        //                                totalStream += ds.Tables[0].Rows[0]["ssent"].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0]["ssent"].ToString()) / 1024 / 1024 : 0;
        //                            }
        //                        }
        //                        else
        //                        {
        //                            continue;
        //                        }
        //                    }
        //                }
        //                else       //查询一天
        //                {
        //                    if (TableIsExistByDomain("'" + user + "'", conStr))
        //                    {
        //                        string sql = "select sum(`cnt`) scnt, sum(`sent`) ssent from `" + user + "` where `date`='" + _start.ToString("yyyy-MM-dd") + "'";
        //                        DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
        //                        if (ds.Tables[0].Rows.Count > 0)
        //                        {
        //                            totalNum += ds.Tables[0].Rows[0]["scnt"].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0]["scnt"].ToString()) : 0;
        //                            totalStream += ds.Tables[0].Rows[0]["ssent"].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0]["ssent"].ToString()) / 1024 / 1024 : 0;
        //                        }
        //                    }
        //                }
        //                return totalNum.ToString() + "|" + totalStream.ToString("F4");
        //            }
        //            return "Error!";
        //        }
        //        catch
        //        {
        //            return "Error";
        //        }
        //    }
        //}

        //获取所有流量总和
        [HttpPost, ActionName("GetTotalStream")]
        public string GetTotalStream(string start, string end)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    DateTime _start = DateTime.Parse(start.Trim());
                    DateTime _end = DateTime.Parse(end.Trim());
                    TimeSpan span = _end - _start;
                    string db = HttpContext.Session["stats"].ToString();
                    string conStr = MySqlConn.GetStatsConn().Replace("cdn_portrate_stats", db);
                    if (span.TotalDays >= 0 && !string.IsNullOrEmpty(conStr))
                    {
                        Double totalNum = 0;
                        Double totalStream = 0;
                        Double totalIp = 0;

                        if (span.TotalDays > 0)  //超过一天
                        {
                            for (int i = 0; i <= span.TotalDays; i++)
                            {
                                if (MyTableIsExist(conStr, _start.AddDays(i)))
                                {
                                    string sql = "select count(`ip`), sum(`cnt`), sum(`sent`) from `" + _start.AddDays(i).ToString("yyyy-MM-dd") + "`  where `ip` !=`serverip`  ";
                                    DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
                                    if (ds.Tables[0].Rows.Count > 0)
                                    {
                                        totalIp += ds.Tables[0].Rows[0][0].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0][0].ToString()) : 0;
                                        totalNum += ds.Tables[0].Rows[0][1].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0][1].ToString()) : 0;
                                        totalStream += ds.Tables[0].Rows[0][2].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0][2].ToString()) / 1024 / 1024 : 0;
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                        else       //查询一天
                        {
                            if (MyTableIsExist(conStr, _start))
                            {
                                string sql = "select count(`ip`), sum(`cnt`), sum(`sent`) from `" + _start.ToString("yyyy-MM-dd") + "` where `ip` !=`serverip` ";
                                DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    totalIp = ds.Tables[0].Rows[0][0].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0][0].ToString()) : 0;
                                    totalNum = ds.Tables[0].Rows[0][1].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0][1].ToString()) : 0;
                                    totalStream = ds.Tables[0].Rows[0][2].ToString() != "" ? Double.Parse(ds.Tables[0].Rows[0][2].ToString()) / 1024 / 1024 : 0;
                                }
                            }
                        }
                        return totalIp.ToString() + "|" + totalNum.ToString() + "|" + totalStream.ToString("F4");
                    }
                    return "Error!";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        //获取下载统计
        [HttpPost, ActionName("GetDLCount")]
        public string GetDLCount(string start, string end)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    string user = HttpContext.Session["user"].ToString();
                    DateTime _start = DateTime.Parse(start.Trim());
                    DateTime _end = DateTime.Parse(end.Trim());

                    string result = "[";
                    string conStr = MySqlConn.FileDownload_Server;

                    string sql = "select * from `file_download_stats`  where `user` ='" + user + "' and  `download_date` between '" + _start + "' and  '" + _end + "' order by `download_date` desc ";
                    DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            result += "{ \"date\":\"" + Convert.ToDateTime(ds.Tables[0].Rows[i]["download_date"]).ToString("yyyy-MM-dd") + "\",\"file\":\"" + ds.Tables[0].Rows[i]["download_file"].ToString() + "\",\"suss\":\"" + ds.Tables[0].Rows[i]["download_succ_count"].ToString() + "\",\"fail\":\"" + ds.Tables[0].Rows[i]["download_fail_count"].ToString() + "\"},";
                        }

                        result = result.Substring(0, result.Length - 1);
                        result += "]";

                        return result;
                    }

                    return "Error";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        //获取峰值统计数据
        [HttpPost, ActionName("GetTopRpt")]
        public string GetTopRpt(string start, string span, int bfb)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                List<TrafficModels> TopList = new List<TrafficModels>();
                DateTime _start = DateTime.Parse(start.Trim());
                string _span = span.Trim();
                string IpPortStr = GetIpPortByUser(HttpContext.Session["user"].ToString());
                if (!string.IsNullOrEmpty(IpPortStr))
                {
                    string[] IpArr = IpPortStr.Split(',');
                    string portStr = "";
                    string[] sarr = IpArr[0].Split(':');
                    portStr = sarr[1];
                    List<TrafficModels> Data = new List<TrafficModels>();
                    GetRptData DoGetData = new GetRptData();
                    if (span == "一天")
                    {
                        Data = DoGetData.GetTopRpt(_start, 0, "全部", portStr);
                    }
                    if (span == "一周")
                    {
                        Data = DoGetData.GetTopRpt(_start, 7, "全部", portStr);
                    }
                    if (span == "一月")
                    {
                        Data = DoGetData.GetTopRpt(_start, 30, "全部", portStr);
                    }
                    List<TrafficModels> inList = new List<TrafficModels>();
                    List<TrafficModels> outList = new List<TrafficModels>();
                    if (Data != null)
                    {
                        //Data.Sort(new TrafficInComparer());
                        //foreach (TrafficModels item in Data)
                        //{
                        //    item.out_value = item.out_value * 1.2;
                        //    item.in_value = item.in_value * 1.2;

                        //    inList.Add(item);
                        //}
                        Data.Sort(new TrafficOutComparer());
                        foreach (TrafficModels item in Data)
                        {
                            item.out_value = item.out_value * 1.2;
                            item.in_value = item.in_value * 1.2;

                            outList.Add(item);
                        }
                        //int start_in_num = Convert.ToInt16(inList.Count * ((bfb - 1) / 100.0));
                        //int end_in_num = Convert.ToInt16(inList.Count * ((bfb + 1) / 100.0));
                       // int start_out_num = Convert.ToInt16(outList.Count * ((bfb - 1) / 100.0));
                       // int end_out_num = Convert.ToInt16(outList.Count * ((bfb + 1) / 100.0));

                        //int start_in_num = Convert.ToInt16(inList.Count * ((99 - bfb) / 100.0));
                        //int end_in_num = Convert.ToInt16(inList.Count * ((101 - bfb) / 100.0));
                        //int start_out_num = Convert.ToInt16(outList.Count * ((99 - bfb) / 100.0));
                        //int end_out_num = Convert.ToInt16(outList.Count * ((101 - bfb) / 100.0));

                        //int getX = Convert.ToInt16(outList.Count * ((100 - bfb) / 100.0));

                        //List<TrafficModels> rslt_inList = new List<TrafficModels>();
                        //List<TrafficModels> rslt_outList = new List<TrafficModels>();

                        


                        ////int getX = Convert.ToInt16(outList.Count * ((100 - bfb) / 100.0));

                        ////List<TrafficModels> rslt_inList = new List<TrafficModels>();
                        ////List<TrafficModels> rslt_outList = new List<TrafficModels>();
                        //for (int z = start_in_num; z < end_in_num; z++)
                        //{
                        //    double s = 100 - z / Convert.ToDouble(inList.Count) * 100.0;
                        //    inList[z].bfb = s.ToString("F2") + "%";

                        //    if (z == getX)
                        //    {
                        //        inList[z].bfb = bfb.ToString() + "%";
                        //        rslt_inList.Add(inList[z]);
                        //    }

                        //    //rslt_inList.Add(inList[z]);
                        //}
                        //for (int x = start_out_num; x < end_out_num; x++)
                        //{
                        //    double s = 100 - x / Convert.ToDouble(outList.Count) * 100.0;
                        //    outList[x].bfb = s.ToString("F2") + "%";

                        //    if (x == getX)
                        //    {
                        //        outList[x].bfb = bfb.ToString() + "%";
                        //        rslt_outList.Add(outList[x]);
                        //    }

                        //    //rslt_outList.Add(outList[x]);
                        //}
                        ////string ss = GetTopJson(rslt_outList) + "|" + GetTopJson(rslt_inList);
                        //return GetTopJson(rslt_outList) + "|" + GetTopJson(rslt_inList);



                        int start_out_num = Convert.ToInt16(outList.Count * ((99 - bfb) / 100.0));
                        int end_out_num = Convert.ToInt16(outList.Count * ((101 - bfb) / 100.0));

                        int getX = Convert.ToInt16(outList.Count * ((100 - bfb) / 100.0));

                        List<TrafficModels> rslt_outList = new List<TrafficModels>();
                        for (int x = start_out_num; x < end_out_num; x++)
                        {
                            //double s = x / Convert.ToDouble(outList.Count) * 100.0;
                            double s = 100.0 - x / Convert.ToDouble(outList.Count) * 100.0;
                            outList[x].bfb = s.ToString("F2") + "%";

                            if (x == getX)
                            {
                                outList[x].bfb = bfb.ToString() + "%";
                                rslt_outList.Add(outList[x]);
                            }

                            // rslt_outList.Add(outList[x]);
                        }
                        return GetTopJson(rslt_outList);
                    }
                }
                return "[]|[]";
            }
        }

        public class TrafficOutComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.out_value.CompareTo(x.out_value));
            }
        }
        public class TrafficInComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.in_value.CompareTo(x.in_value));
            }
        }

        //获取单个文件的访问次数、数据量
        //[HttpPost, ActionName("GetFileTotal")]
        //public string GetFileTotal(string start, string end, string file)
        //{
        //    DateTime _start = DateTime.Parse(start.Trim());
        //    DateTime _end = DateTime.Parse(end.Trim());
        //    TimeSpan span = _end - _start;
        //    if (HttpContext.Session["user"] == null)
        //    {
        //        RedirectToAction("LogTimeOut", "Home");
        //    }
        //    else
        //    {
        //        string conStr = "Host=filelogdw.cdn.efly.cc;User Id=root;password=rjkj@rjkj;Database=cdn_file_url_stats;charset=gbk";

        //        if (span.TotalDays > 0)  //超过一天
        //        {
        //            List<FileTotalModels> Data = new List<FileTotalModels>();
        //            for (int i = 0; i <= span.TotalDays; i++)
        //            {
        //                if(TableIsExistByDomain("'"+HttpContext.Session["user"].ToString()+"'",conStr))
        //                {
        //                    FileTotalModels model = new FileTotalModels();
        //                    model = GetSingleFileTotal(_start.AddDays(i), file.Trim(), HttpContext.Session["user"].ToString());
        //                    if (model != null)
        //                    {
        //                        Data.Add(model);
        //                    }
        //                }
        //                else
        //                {
        //                    continue;
        //                }
        //            }
        //            if (Data != null)
        //            {
        //                Double totalNum = 0.0;
        //                Double totalStream = 0.0;
        //               // Double totalIp = 0;
        //                foreach (FileTotalModels obj in Data)
        //                {
        //                    totalStream += obj.totalStream;
        //                    totalNum += obj.totalNum;
        //                  //  totalIp += obj.totalIp;
        //                }
        //                return totalNum.ToString() + "|" + totalStream.ToString("F2");
        //            }
        //        }

        //    }
        //    return "查询条件的结果为空！";
        //}

        //获取单个文件的下载流量、次数
        [HttpPost, ActionName("GetFileTotal")]
        public string GetFileTotal(string start, string end, string file)
        {
            DateTime _start = DateTime.Parse(start.Trim());
            DateTime _end = DateTime.Parse(end.Trim());
            TimeSpan span = _end - _start;
            if (HttpContext.Session["user"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string conStr = MySqlConn.GetStatsConn();
                string db = HttpContext.Session["stats"].ToString();
                if (span.TotalDays > 0)  //超过一天
                {
                    List<FileTotalModels> Data = new List<FileTotalModels>();
                    for (int i = 0; i <= span.TotalDays; i++)
                    {
                        if (MyTableIsExist(conStr.Replace("cdn_portrate_stats", db), _start.AddDays(i)))
                        {
                            FileTotalModels model = new FileTotalModels();
                            model = GetSingleFileTotal(_start.AddDays(i), file.Trim(), db);
                            if (model != null)
                            {
                                Data.Add(model);
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                    if (Data != null)
                    {
                        Double totalNum = 0.0;
                        Double totalStream = 0.0;
                        Double totalIp = 0;
                        foreach (FileTotalModels obj in Data)
                        {
                            totalStream += obj.totalStream;
                            totalNum += obj.totalNum;
                            totalIp += obj.totalIp;
                        }
                        return totalNum.ToString() + "|" + totalStream.ToString("F2") + "|" + totalIp;
                    }
                }
                else       //查询一天
                {
                    try
                    {
                        if (MyTableIsExist(conStr.Replace("cdn_portrate_stats", db), _start))  //表存在
                        {
                            FileTotalModels model = new FileTotalModels();
                            model = GetSingleFileTotal(_start, file.Trim(), db);
                            if (model != null)
                            {
                                return model.totalNum.ToString() + "|" + model.totalStream.ToString("F2") + "|" + model.totalIp;
                            }
                        }
                    }
                    catch
                    {
                        return "查询出错！";
                    }
                }
            }
            return "查询条件的结果为空！";
        }

        //编辑文件属性
        [HttpPost, ActionName("EditFile")]
        public string EditFile(string id, string statu, string desc)
        {
            if (HttpContext.Session["user"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            if (string.IsNullOrEmpty(id))
            {
                return "未选择文件！";
            }
            int fID = int.Parse(id);
            string status = statu.Trim();
            string setdDes = desc.Trim();
            if (DoEditFile(fID, statu, setdDes))
            {
                return HttpContext.Session["user"].ToString() + "|" + HttpContext.Session["pwd"].ToString(); ;
            }
            else
                return "修改失败！";
        }
        //编辑文件属性, 无须修改分发属性
        [HttpPost, ActionName("EditFileNoStatu")]
        public string EditFileNoStatu(string id, string desc)
        {
            if (HttpContext.Session["user"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            int fID = int.Parse(id);
            string setdDes = desc.Trim();
            if (DoEditFile(fID, "", setdDes))
                return "修改成功！";
            else
                return "修改失败！";
        }

        //获取文件列表页
        [HttpPost, ActionName("GetFilesPage")]
        public string GetFilesPage(string page)
        {
            if (!string.IsNullOrEmpty(page))
            {
                try
                {
                    int count = int.Parse(page.Trim());
                    if (HttpContext.Session["path"] == null || HttpContext.Session["user"] == null)
                    {
                        RedirectToAction("LogTimeOut", "Home");
                    }
                    else
                    {
                        string path = HttpContext.Session["path"].ToString();
                        string user = HttpContext.Session["user"].ToString();
                        List<FileModels> files = GetFileList(user, count, path);
                        System.Text.StringBuilder outStream = new System.Text.StringBuilder();
                        for (int i = 0; i < files.Count; i++)
                        {
                            outStream.Append(files[i].id.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].FileID.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].FileName.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].FilePath.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].FileSize.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].Status.ToString()); //状态
                            outStream.Append(",");
                            outStream.Append(files[i].TimeStamp.ToString()); //时间
                            outStream.Append(",");
                            outStream.Append(files[i].FullGet.ToString());  //进度
                            outStream.Append(",");
                            outStream.Append(files[i].Desc.ToString());
                            outStream.Append("*");
                        }
                        return outStream.ToString();
                    }
                }
                catch
                { return ""; }
            }
            return "";
        }

        //获取文件列表页
        [HttpPost, ActionName("GetHotFilesPage")]
        public string GetHotFilesPage(string page,DateTime start,DateTime end,string filename)
        {
            if (!string.IsNullOrEmpty(page))
            {
                try
                {
                    int count = int.Parse(page.Trim());
                    if (HttpContext.Session["user"] == null)
                    {
                        RedirectToAction("LogTimeOut", "Home");
                    }
                    else
                    {
                        string user = HttpContext.Session["user"].ToString();
                        List<HotFileModels> files = GetHotFileList(user, count,start,end,filename);
                        System.Text.StringBuilder outStream = new System.Text.StringBuilder();
                        for (int i = 0; i < files.Count; i++)
                        {
                            outStream.Append(files[i].id.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].FileName.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].FileSize.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].LastModify.ToString());
                            outStream.Append(",");
                            outStream.Append(files[i].Status.ToString()); //状态
                            outStream.Append(",");
                            outStream.Append(files[i].Progress.ToString());
                            outStream.Append("*");
                        }
                        return outStream.ToString();
                    }
                }
                catch
                { return ""; }
            }
            return "";
        }

        ///////////-----------------//////////
        //相关操作
        //////////-----------------//////////

        private List<TaskModels> GetTaskList(string owner)
        {
            try
            {
                string sql = "select * from `auto_delivery` where `owner`='" + owner + "' and `status`='true'";
               // DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.CATCHMGR_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<TaskModels> ret = new List<TaskModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        TaskModels item = new TaskModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.filename = dr["filename"].ToString();
                        item.filepath = dr["filepath"].ToString();
                        item.filesize = dr["filesize"].ToString();
                        item.md5 = dr["md5"].ToString();
                        item.timestamp = dr["timestamp"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //获取1天访问数据
        private Hashtable DoGetDayVisitData(DateTime table, MySqlConnection conn)
        {
            try
            {
                string sql = "select sum(`sent`) as traffic,`serverip` from `" + table.ToString("yyyy-MM-dd") + "` group by `serverip`";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable ret = new Hashtable();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret.Add(dr["serverip"].ToString(), dr["traffic"].ToString());
                    }
                    return ret;
                }
            }
            catch {
            }
            return null;
        }

        //获取网络类型哈希表
        private Hashtable GetIpNettypeMap()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `nettype`,`zone`,`ip`,`port` FROM `server_list` where `type`='node' order by `nettype`");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable ret = new Hashtable();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret.Add(dr["ip"].ToString(), dr["nettype"].ToString());
                    }
                    return ret;
                }
            }
            catch { }
            return null;
        }
        //获取区域哈希表
        private Hashtable GetIpAreaMap()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `zone`,`ip`,`port` FROM `server_list` where `type`='node' order by `zone`");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable ret = new Hashtable();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret.Add(dr["ip"].ToString(), dr["zone"].ToString());
                    }
                    return ret;
                }
            }
            catch { }
            return null;
        }

        private List<FileModels> GetClientDomain(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT * FROM `user_hostname` where `owner`='" + user + "' and `status` = 'true'");
               //  DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
               DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<FileModels> data = new List<FileModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        FileModels item = new FileModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.FilePath = dr["hostname"].ToString();
                        data.Add(item);
                    }
                    return data;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        private List<FileModels> GetClientDomainFromInfo(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT * FROM `user_hostname` where `owner`='" + user + "' and `status` = 'true'");
                  DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
               // DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<FileModels> data = new List<FileModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        FileModels item = new FileModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.FilePath = dr["hostname"].ToString();
                        data.Add(item);
                    }
                    return data;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        //获取修改文件属性的Url
        private string GetFileMgrUrl()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `value` FROM server_info,server_list where server_list.`type` = 'source' and server_list.ip = server_info.serverip and `key` = 'filemgrurl'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return Ds.Tables[0].Rows[0][0].ToString();
                }
                return "";
            }
            catch
            {
                return "";
            }
        }

        //根据用户的所有ip得到所拥有的（区域|ip）
        private string GetAreaByIp(string ip)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `zone`,`ip` FROM `server_list` where `ip` in(" + ip + ") Order by `zone`");  // Group by `zone`
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                    }
                    return result;
                }
                return "";
            }
            catch
            {
                return null;
            }
        }
        //得到数据库里存在的天的表   cdn_server_stats库
        private string GetDateTable()
        {
            try
            {
                string strSql = "SHOW TABLES";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetStatsConn(), strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                    }
                    return result;
                }
            }
            catch
            {
                return "Error";
            }
            return "Null";
        }


        //private FileTotalModels GetSingleFileTotal(DateTime _start, string file,string user)
        //{
        //    string conStr = "Host=filelogdw.cdn.efly.cc;User Id=root;password=rjkj@rjkj;Database=cdn_file_url_stats;charset=gbk";
        //    //if (MyTableIsExist(conStr, _start))
        //    if (TableIsExistByDomain("'" + HttpContext.Session["user"].ToString() + "'", conStr))
        //    {
        //        MySqlConnection con = new MySqlConnection(conStr);
        //        string sql = "select * from `" + user + "` where `date`='" + _start.ToString("yyyy-MM-dd") + "' and `url`='" + file + "'";
                
        //        con.Open();
        //        DataSet ds = MySqlHelper.ExecuteDataset(con, sql);
        //        con.Close();

        //            if (ds.Tables[0].Rows.Count > 0)
        //            {
        //                FileTotalModels obj = new FileTotalModels();
        //                obj.totalNum = Double.Parse(ds.Tables[0].Rows[0]["cnt"].ToString());
        //                obj.totalStream = Double.Parse(ds.Tables[0].Rows[0]["sent"].ToString()) / 1024 / 1024;
        //               // obj.totalIp = Double.Parse(ds.Tables[0].Rows[0][2].ToString());
        //                return obj;
        //            }

        //    }
        //    return null;
        //}

        //查询单个文件下载及总流量
        private FileTotalModels GetSingleFileTotal(DateTime _start, string file, string dataBase)
        {
            string conStr = Core.MySqlConn.GetStatsConn().Replace("cdn_portrate_stats", dataBase);
            if (MyTableIsExist(conStr, _start))
            {
                MySqlConnection con = new MySqlConnection(conStr);
                string sql = "select sum(`cnt`), sum(`sent`), count(`ip`) from `" + _start.ToString("yyyy-MM-dd") + "` where `request` = '/" + file.Trim() + "'";
                con.Open();
                DataSet ds = MySqlHelper.ExecuteDataset(con, sql);
                con.Close();
                if (ds.Tables[0].Rows[0][0] != null)
                {
                    if (ds.Tables[0].Rows[0][0].ToString().Length > 0)
                    {
                        FileTotalModels obj = new FileTotalModels();
                        obj.totalNum = Double.Parse(ds.Tables[0].Rows[0][0].ToString());
                        obj.totalStream = Double.Parse(ds.Tables[0].Rows[0][1].ToString()) / 1024 / 1024;
                        obj.totalIp = Double.Parse(ds.Tables[0].Rows[0][2].ToString());
                        return obj;
                    }
                }
            }
            return null;
        }
        //根据数据库连接是否存在该表
        private bool MyTableIsExist(string conn, DateTime date)
        {
            try
            {
                string mySql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet myDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, mySql);
                if (myDs.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        //根据用户名数据库和日期判断是否存在该表
        private bool StatsTableIsExist(DateTime date)
        {
            try
            {
                string strSql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetStatsConn(), strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        //执行编辑文件属性
        private bool DoEditFile(int id, string statu, string desc)
        {
            MySqlConnection mycn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
            if (mycn != null)
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Clear();
                    mycn.Open();
                    if (statu == "")
                    {
                        strSql.Append("update `public_file` set `desc`='" + desc.Trim() + "' where `id`=" + id + "");
                    }
                    else
                    {
                        strSql.Append("update `public_file` set `status`='" + statu.Trim() + "',`desc`='" + desc.Trim() + "' where `id`=" + id + "");
                    }
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), mycn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    mycn.Close();
                    if (1 == result)
                        return true;
                }
                catch
                {
                    if (mycn != null) mycn.Close();
                }
                return false;
            }
            return false;
        }


        private List<AddrModels> GetHostListByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `hostname` FROM `user_hostname` where `owner`='" + user + "' and `status`='true'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<AddrModels> data = new List<AddrModels>();
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        AddrModels item = new AddrModels();
                        item.hostname = Ds.Tables[0].Rows[i]["hostname"].ToString();
                        data.Add(item);
                    }
                    return data;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //获取文件列表
        private List<FileModels> GetFileList(string user, int page, string path)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT * FROM `public_file` where `status`!='' and (`filepath` like '" + path + "' or `filepath` like '" + path + "/%') order by id desc LIMIT 10 OFFSET " + (page - 1) * 10);
                //DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<FileModels> obj = new List<FileModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        FileModels model = new FileModels();
                        model.id = int.Parse(dr["id"].ToString());
                        model.FileID = dr["fileid"].ToString();
                        model.FileName = dr["filename"].ToString();
                        string str = dr["filepath"].ToString().Replace("/var/ftp/pub/" + HttpContext.Session["user"].ToString(), "");
                        if (string.IsNullOrEmpty(str))
                        {
                            model.FilePath = "/";
                        }
                        else
                        {
                            model.FilePath = str;
                        }
                        model.FileSize = dr["filesize"].ToString();
                        model.Status = dr["status"].ToString();
                        model.TimeStamp = dr["timestamp"].ToString();
                        model.FullGet = GetFileJindu(user.Trim(), model.FileID).ToString() + "%";
                        model.Desc = dr["desc"].ToString();
                        //model.TotalNum = totalNum;
                        obj.Add(model);
                    }
                    return obj;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //获取文件列表
        private List<HotFileModels> GetHotFileList(string user, int page,DateTime start,DateTime end,string filename)
        {
            try
            {
                string begin = start.ToString("yyyy-MM-dd");
                string en = end.AddDays(1).ToString("yyyy-MM-dd");

                //int totalCount = 0;
                //int finish = 0;

                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT * FROM `file_list` where `owner` ='" + user + "' and `extract` ='' and filename like '%"+ filename+ "%'  and (`lastmodify` between cast('" + begin + "'  as date) and cast( '" + en + "' as date))  order by id desc LIMIT 10 OFFSET " + (page - 1) * 10);
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
               // DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<HotFileModels> obj = new List<HotFileModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        HotFileModels model = new HotFileModels();
                        model.id = int.Parse(dr["id"].ToString());
                      //  model.FileName = dr["filename"].ToString();

                        string[] name = dr["filename"].ToString().Split('/');
                        model.FileName = name[name.Length - 1];

                        model.Progress = dr["percent"].ToString() + "%";
                        string type = dr["type"].ToString();
                        switch (type)
                        {
                            case "push": model.Type = "添加";
                                break;
                            case "delete": model.Type = "删除";
                                break;
                            default: break;
                        }

                        model.FileSize = dr["filesize"].ToString();

                        string status = dr["status"].ToString();
                        switch (status)
                        {
                            case "ready": model.Status = "操作准备中";
                                break;
                            case "doing": model.Status = "操作进行中";
                                break;
                            case "finish": model.Status = "操作完成";
                                break;
                            case "fail": model.Status = "操作失败";
                                break;
                            default: break;
                        }
                        //model.Status = dr["status"].ToString();
                       // model.LastCheck = dr["lastcheck"].ToString();
                        model.LastModify = dr["lastmodify"].ToString();
                        //model.TotalNum = totalNum;
                        obj.Add(model);
                    }
                    return obj;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        private double GetFileJindu(string user, string fileName)
        {
            try
            {

                StringBuilder strSql = new StringBuilder();
                strSql.Append("select count(*) from node_file where `filemd5id` = '" + fileName + "'");
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                double num = double.Parse(Ds.Tables[0].Rows[0][0].ToString());

                //strSql.Clear();
                //strSql.Append("select count(*) from server_list where `type` = 'super_node'");
                //DataSet allDs1 = MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());

                strSql.Clear();
                strSql.Append("SELECT count(*) FROM `user_nginx` where `user` = '" + user + "' and ip in (select ip from server_list where `type` = 'node') ");
                DataSet allDs2 = MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());

                double allnum = double.Parse(allDs2.Tables[0].Rows[0][0].ToString()); //double.Parse(allDs1.Tables[0].Rows[0][0].ToString()) + 
                double ret = double.Parse((num / allnum * 100).ToString("F2")) <= 100 ? double.Parse((num / allnum * 100).ToString("F2")) : 100;
                return ret;
            }
            catch
            {
                return 0;
            }
        }

        private int GetFilesNum(string path)  //UserModels user
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT Count(*) FROM `public_file` where `status`!='' and (`filepath` like '" + path + "' or `filepath` like '" + path + "/%')");
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
               // DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
            }
            catch
            {
                return 0;
            }
        }

        private int GetHotFilesNum(string user,DateTime start,DateTime end)  //UserModels user
        {
            try
            {
                string begin = start.ToString("yyyy-MM-dd");
                string en = end.AddDays(1).ToString("yyyy-MM-dd");

                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT Count(*) FROM `file_list` where `extract` ='' and `owner` ='" + user + "' and (`lastmodify` between cast('" + begin + "'  as date) and cast( '" + en + "' as date)) ");
                //DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
            }
            catch
            {
                return 0;
            }
        }

        //private int GetIPCount()
        //{
        //    try
        //    {
        //        StringBuilder strSql = new StringBuilder();
        //        strSql.Append("SELECT Count(distinct ip) FROM `server_list` where `type` = 'node' and `nettype` != '移动' ");
        //        DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
        //        return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
        //    }
        //    catch
        //    {
        //        return 0;
        //    }
        //}

        private int GetFilePushCount(string filename)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT Count(*) FROM `file_push` where filename = '" + filename + "' and `status` = 'finish' ");
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
                return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
            }
            catch
            {
                return 0;
            }
        }

        private int GetFilePusTotalhCount(string filename)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append(" select count(*) from file_push where filename ='" + filename + "'; ");
                DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
                return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
            }
            catch
            {
                return 0;
            }
        }

        //private int GetFinishCount(string filename)
        //{
        //    try
        //    {
        //        StringBuilder strSql = new StringBuilder();
        //        strSql.Append(" select count(*) from file_push where filename in ( SELECT filename FROM `file_list`  where extract ='" + filename + "' and `status` = 'finish_check' ) and `status` = 'finish' ");
        //        DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
        //        return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
        //    }
        //    catch
        //    {
        //        return 0;
        //    }
        //}

        //private int GetTotalCount(string filename)
        //{
        //    try
        //    {
        //        StringBuilder strSql = new StringBuilder();
        //        strSql.Append("select count(*) from file_push where filename in ( SELECT filename FROM `file_list`  where extract ='"+filename+"' and `status` = 'finish_check' ) ");
        //        DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
        //        return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
        //    }
        //    catch
        //    {
        //        return 0;
        //    }
        //}

        //private int GetDelFinishCount(string filename)
        //{
        //    try
        //    {
        //        StringBuilder strSql = new StringBuilder();
        //        strSql.Append(" select count(*) from file_push where filename  ='" + filename + "' and `status` = 'delete_finish' ");
        //        DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
        //        return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
        //    }
        //    catch
        //    {
        //        return 0;
        //    }
        //}

        //private int GetDelTotalCount(string filename)
        //{
        //    try
        //    {
        //        StringBuilder strSql = new StringBuilder();
        //        strSql.Append("select count(*) from file_push where filename='" + filename + "' ");
        //        DataSet Ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.HotFile_Server, strSql.ToString());
        //        return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
        //    }
        //    catch
        //    {
        //        return 0;
        //    }
        //}

        ////根据ip、端口号和日期查询流量
        //private List<TrafficModels> GetStreamByAll(string IpPort, string date)
        //{
        //    try
        //    {
        //        string[] IpArr = IpPort.Split(',');
        //        string IpStr = "";
        //        string portStr = "";
        //        for (int m = 0; m < IpArr.Length; m++)
        //        {
        //            string[] s = IpArr[m].Split(':');
        //            if (m == 0)
        //            {
        //                IpStr = "'" + s[0] + "'";
        //                portStr = s[1];
        //            }
        //            else
        //            {
        //                IpStr += ",'" + s[0] + "'";
        //                //portStr += "," + s[1];
        //            }
        //        }
        //        StringBuilder sqlStr = new StringBuilder();
        //        //StringBuilder dstStr = new StringBuilder();
        //        sqlStr.Append("SELECT `outrate`,`inrate`,`time`,`portdir` FROM `" + date + "` WHERE `port`=" + portStr + " and ip in(" + IpStr + ") and `portdir`='src'");
        //        //dstStr.Append("SELECT `rate`,`time`,`portdir` FROM `" + date + "` WHERE `port` in(" + portStr + ") and ip in(" + IpStr + ") and `portdir`='dst'");
        //        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetStatsConn(), sqlStr.ToString());
        //        //DataSet dstDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetStatsConn(), dstStr.ToString());
        //        List<TrafficModels> streamObj = new List<TrafficModels>();
        //        //List<TrafficModels> out_obj = new List<TrafficModels>();
        //        Dictionary<string, List<TrafficModels>> Data = new Dictionary<string, List<TrafficModels>>();
        //        //src流出流量
        //        if (Ds.Tables[0].Rows.Count > 0)
        //        {
        //            for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
        //            {
        //                string time = DateTime.Parse(Ds.Tables[0].Rows[i]["time"].ToString()).ToString("HH:mm");
        //                if (i > 0 && time == DateTime.Parse(Ds.Tables[0].Rows[i - 1]["time"].ToString()).ToString("HH:mm"))
        //                //如果前后两项时间相等，就进行相加
        //                {
        //                    streamObj[streamObj.Count - 1].out_value += Convert.ToDouble(Ds.Tables[0].Rows[i]["outrate"].ToString());
        //                    streamObj[streamObj.Count - 1].in_value += Convert.ToDouble(Ds.Tables[0].Rows[i]["inrate"].ToString());
        //                }
        //                else
        //                {
        //                    TrafficModels model = new TrafficModels();
        //                    model.time = date + " " + Ds.Tables[0].Rows[i]["time"].ToString();
        //                    model.out_value = Convert.ToDouble(Ds.Tables[0].Rows[i]["outrate"].ToString());
        //                    model.in_value = Convert.ToDouble(Ds.Tables[0].Rows[i]["inrate"].ToString());
        //                    streamObj.Add(model);
        //                }
        //            }
        //        }
        //        //Data.Add("out", out_obj);
        //        //Data.Add("in", in_obj);
        //        return streamObj;
        //    }
        //    catch
        //    {
        //        return null;
        //    }
        //}

        //根据用户名获取ip地址和端口号
        private string GetIpPortByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `ip`,`port` FROM `user_nginx` where `user`='" + user + "'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                            result += ":";
                            result += Ds.Tables[0].Rows[i]["port"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                            result += ":";
                            result += Ds.Tables[0].Rows[i]["port"].ToString();
                        }
                    }
                    return result;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //峰值统计转换成json格式字符串
        private string GetTopJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                //StringBuilder json = new StringBuilder();
                //json.Append("[");
                //for (int i = 0; i < t.Count; i++)
                //{
                //    if (t[i].out_value > 0 || t[i].in_value > 0)
                //    {
                //        if (i != t.Count - 1)
                //        {
                //            json.Append("{ id: \"" + t[i].bfb + "\",");
                //            json.Append("out_stream: \"" + t[i].out_value + "\",");
                //            json.Append("in_stream: \"" + t[i].in_value + "\",");
                //            json.Append("datetime: \"" + t[i].time + "\" },");
                //        }
                //        else
                //        {
                //            json.Append("{ id: \"" + t[i].bfb + "\",");
                //            json.Append("out_stream: \"" + t[i].out_value + "\",");
                //            json.Append("in_stream: \"" + t[i].in_value + "\",");
                //            json.Append("datetime: \"" + t[i].time + "\" }");
                //        }
                //    }
                //}
                //json.Append("]");
                //return json.ToString();
                string json = "[";
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].in_value > 0 || t[i].out_value > 0)
                    {
                        json += "{ id: \"" + t[i].bfb + "\",";
                        json += "out_stream: \"" + t[i].out_value + "\",";
                        json += "in_stream: \"" + t[i].in_value + "\",";
                        json += "datetime: \"" + t[i].time + "\" },";
                    }
                }
                if (json.Length > 1)
                {
                    json = json.Substring(0, json.Length - 1) + "]";
                    return json.ToString();
                }
                return "[]";
            }
            catch
            {
                return "";
            }
        }

        //转换成json格式字符串
        private string GetJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                StringBuilder json = new StringBuilder();
                json.Append("[");
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].out_value > 0 || t[i].in_value > 0)
                    {
                        if (i != t.Count - 1)
                        {
                            json.Append("{ id: \"" + (i + 1) + "\",");
                            json.Append("out_stream: \"" + t[i].out_value + "\",");
                            json.Append("in_stream: \"" + t[i].in_value + "\",");
                            json.Append("datetime: \"" + t[i].time + "\" },");
                        }
                        else
                        {
                            json.Append("{ id: \"" + (i + 1) + "\",");
                            json.Append("out_stream: \"" + t[i].out_value + "\",");
                            json.Append("in_stream: \"" + t[i].in_value + "\",");
                            json.Append("datetime: \"" + t[i].time + "\" }");
                        }
                    }
                }
                json.Append("]");
                return json.ToString();
            }
            catch
            {
                return "";
            }
        }

        //图表专用
        private string GetChartJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                TrafficModels maxOutObj = new TrafficModels();
                TrafficModels maxInObj = new TrafficModels();
                string out_json = "";
                string in_json = "";
                foreach (TrafficModels model in t)
                {
                    if (model != t[t.Count - 1])
                    {
                        out_json += model.out_value + ",";
                        in_json += model.in_value + ",";
                    }
                    else
                    {
                        out_json += model.out_value;
                        in_json += model.in_value;
                    }
                    if (maxOutObj.out_value < model.out_value)
                    {
                        maxOutObj.out_value = model.out_value;
                        maxOutObj.time = model.time;
                    }
                    if (maxInObj.in_value < model.in_value)
                    {
                        maxInObj.in_value = model.in_value;
                        maxInObj.time = model.time;
                    }
                }
                string ret_json = maxInObj.time + "," + maxInObj.in_value + "#[" + in_json + "]" + "|" + maxOutObj.time + "," + maxOutObj.out_value + "#[" + out_json + "]";
                return ret_json;
                //return GetChartJson(result["in"]) + "|" + GetChartJson(result["out"]);
            }
            catch
            {
                return "";
            }
        }

    }
}
