/**
 * 联系人列表超类
 */
PIM.Contacts = {
	//设置参数
	setParams: function(options){
		$.extend(this.params,options);
	},
	//初始化列表数据
	init: function(){
		this.bindEvents();
	},
	
	//获取联系人数据
	getContactData: function(options){
		if(options){
			this.setParams(options);
		}
		$.ajax({
			url: this.urlContact,
			dataType: 'json',
			type: 'POST',
			data: this.params,
			success: $.proxy(this,'createContact')
		});
	},
	
	//生成联系人列表
	createContact: function(data){
		if( !resolveResult(data.result,data.msg) ) return;
		
	    var info = data.info,
	    	vcards = info["vacrds"],
	    	html = '';
	    
	    //分组下没有联系人的情况
	    if(info.totalRecordCount == 0){
	    	if(!this.params.key){
	    		html = this.getNoContentHtml();
	    	}else{
	    		html = '<tr><td colspan="6" class="no-line"><div class="search-no-content">很努力地找过了，确实没有相关联系人记录。</div></td></tr>';
	    	}
	    	$('#sortByName2').show();
	    	$('#sortByName').hide();
	    }
	    //有联系人就生成联系人列表
	    else{
    		html = this.createList(vcards);
    		$('#sortByName2').hide();
	    	$('#sortByName').show();
	    }
	    
	    this.contactBox.html(html);
	    
	    //显示切换
		showModule(this.viewArea);
		setDomHeight({selector:'#contactsListBox'});
	    //更新相关
	    this.updateRelatedInfo(info);
	},
	
	getNoContentHtml: function(){
		var hash = location.hash.split('/'),
			html = '';
		if(hash[1] && hash[1] == '-1'){
			html = '<tr><td colspan="6" class="no-line"><div class="contacts-blank-box"><div class="no-contact"><a target="blank" href="http://msoft.qq.com/step1.jsp?productid=1107">点击下载</a></div></div></td></tr>'; 
		}else {
			html = '<tr><td colspan="6" class="no-line"><div class="contacts-blank-box"><div class="group-no-contact"></div></div></td></tr>';
		}
		return html;
	},
	
	//生成列表html，返回html
	createList: function(data){
		var html = '',
			self = this,
			key = this.params.key;
		if(key && /PINYIN/.test(key)){
			key = '';
		}
		$.each(data,function(i,n){
			html += self.createRow(n,key);
		});
		return html;
	},
	
	//更新联系人相关（翻页、全选状态、搜索、过滤状态）
	updateRelatedInfo: function(info){
	    //更新翻页相关数据
	    this.page().update({
	    	pageNo: info.pageNo, 
	    	pageSize: info.pageSize,
	    	pageCount: info.pageCount,
	    	pageTotal: info.totalRecordCount
    	});
	    
	    //全选状态
	    $(':checkbox[name=chkAll]').attr('checked',false);
	    
	    //更新字母导航
	    if(this.getLetters) this.getLetters(info.totalRecordCount);
	    
	    //绑定拖动
	    if(this.draggable){
	    	setTimeout($.proxy(this,'bindDrag'),100);
	    }
	},
	
	//绑定联系人列表一系列事件
	bindEvents: function(){
		var self = this;
		this.contactBox.delegate(this.list,'click',function(e){
			var t = $(this),
				target = $(e.target);
			if(target.is(':checkbox')){
				self.setSelected(t,target.is(':checked'));
			}
			else if(target.closest('a.view').length){
				setHash('#contactEdit/'+$(this).find(':checkbox').attr('dataid'));
			}
			else{
				var bool = false;
				if(!t.is('.' + self.chkClass)){
					bool = true;
				}
				self.setSelected(t,bool);
			}
		});
//		.delegate(this.list,'hover',function(){
//		$(this).toggleClass(self.hoverClass);
//	})
		$(':checkbox[name=chkAll]').live('click',function(){
			var t = $(this),
				bool = t.is(':checked');
			self.selAll(bool);
		});
	},
	
	//获取联系详情
	getDetail: function(){
		this.getContactEditHtml();
	},
	
	//获取新增、编辑联系人的html
	getContactEditHtml: function(){
		var self = this,
			url = '',
			contactId = this.getEditContactId(),
			data = {myuinmd5: $.md5(myuinmd5)};
		if(contactId){
			url = g_path + '/card/edit_card.jsp';
			data.dataid = contactId;
		}else{
			url = g_path + '/card/add_card_ajax.jsp';
		}
		$.ajax({
			url: url,
			type: 'POST',
			data: data,
			success: function(html){
				$("#contactEdit").html(html);
				PIM.ContactEdit.getGroupInfo(contactId);
				showModule('#contactEdit');
				setDomHeight({selector:'#contactEdit'});
			}
		});
	},
	
	//绑定拖动
	bindDrag: function(){
		var self = this;
		if($.ui && $.ui.draggable){
			$(this.list,this.contactBox).draggable({
				revert: 'invalid',
				revertDuration: 200,
				cursorAt: { top: 5, left: 5 },
				addClasses: false,
				appendTo: 'body',
				distance: 30,
				cancel: 'a,.no-drag',
				containment: '#wrapper',
				scrollSensitivity: 100,
				helper: function( event ) {
					self.setSelected($(this),true,true);
					var count = self.getSelContacts().length;
					return $( '<div class="drag-move-helper">正拖动 '+ count +' 个联系人</div>' );
				}
			});
		}else{
			setTimeout($.proxy(arguments.callee,this),100);
		}
	},
	
	//设置选中状态
	setSelected: function(o,bool){
		bool ? o.addClass(this.chkClass) : o.removeClass(this.chkClass);
		o.find(':checkbox').attr('checked',bool);
	},
	
	//批量选择
	selAll: function(bool){
		var self = this,
			chks = this.contactBox.find(this.list); 
		chks.each(function(){
			self.setSelected($(this),bool);
		});
	},
	
	/*
	 * 获取选中的联系人id
	 * 返回 []
	 * */
	getSelContacts: function(){
		var selecteds = this.contactBox.find(':checkbox:checked'),
			tempArrs = [];
		selecteds.each(function(){
			tempArrs.push($(this).attr('dataid'));
		}); 
		return tempArrs;
	},
	//设置当前编辑的联系人id
	setEditContactId: function(contactId){
		this.contactId = contactId;
	},
	//获取当前编辑的联系人id
	getEditContactId: function(){
		return this.contactId;
	}
};

/**
 * 联系人列表类
 * */
function ContactsList(options){
	for(var i in options){
		this[i] = options[i];
	}
	//联系人参数
	this.params = {
		myuinmd5: $.md5(myuinmd5),
		X_Content_Type: 'json',
		groupId: '-1',
		pageNo: 1,
		pageSize: 50,
		key: '',
		sortBy: 'name', //按名字排列，时间为：time
		order: 'ASC' // 默认为升序，降序为：“DESC”
	};
	this.init();
}

//继承
Extend(ContactsList,PIM.Contacts);
	
ContactsList.prototype.init = function(){
	this.bindEvents();
	//绑定字母导航
	$('#filters').delegate('a','click',$.proxy(this,'filter'));
};
//生成一条列表，返回一条列表html
ContactsList.prototype.createRow = function(n,key){
	var vcard = n.vcard,
		tr = ['<tr dataid="'+ n.dataid +'">'],
		userName = '未命名',
		tel = ' ', telTitle = '', telCount = '', telName = 'TEL_CELL_0',
		qq = ' ', qqTitle = '', qqCount = '', qqName = 'X-TC-dwQQ_0',
		group = '';
	tr.push('<td class="o-h"><i class="icon-grippy"></i></td>');
	tr.push('<td><input name="contact_Select" type="checkbox" class="logClass" dataid="'+ n.dataid +'" /></td>');
	if(vcard['N']){
		userName = $.trim( vcard.N[0].VALUE.replace(/\\;/g,'[:]').replace(/;/g,'').replace(/\[:\]/g,';') );
		if(!userName) userName = '未命名';
	}
	if(vcard['TEL']){
		var vTel = vcard['TEL'];
			tlength = vTel.length
		if(tlength > 1){
			telCount = '<i class="count">(+'+ tlength +')</i>';
		}
		$.each(vTel,function(j,m){
			var type = '';
			switch(m['TYPE']){
			case 'CELL': type = '常用手机：'; break;
			case 'CELL_HOME': type = '常用家庭手机：'; break;
			case 'CELL_WORK': type = '常用办公手机：'; break;
			case 'HOME': type = '家庭电话：'; break;
			case 'WORK': type = '办公电话：'; break;
			case 'FAX': type = '传真：'; break;
			case 'FAX_HOME': type = '家庭传真：'; break;
			case 'WORK_HOME': type = '办公传真：'; break;
			case '':
				var xc = m['X-CUSTOM'];
				xc == '' ? type = '电话号码：' : type = xc + '：';
				break;
			}
			telTitle += type + m['VALUE'] + '; ';
		});
		tel = vTel[0].VALUE;
		telName = vTel[0].TYPE;
		if(telName){
			telName = 'TEL_' + telName +'_' + vTel[0]['TYPE_ORDER'];
		}else{
			if(!vTel[0]['X-CUSTOM']){
				telName = 'TEL_' + vTel[0]['TYPE_ORDER'];
			}else{
				telName = vTel[0]['X-CUSTOM-NAME'];
			}
		}
	}
	if(vcard['X-TC-dwQQ']){
		var qlength = vcard['X-TC-dwQQ'].length;
		if( qlength > 1){
			qqCount = '<i class="count">(+'+ qlength +')</i>';
		}
		qqTitle = '共'+ qlength +'个QQ号码：';
		$.each(vcard['X-TC-dwQQ'],function(j,m){
			qqTitle += m['VALUE'] + '; ';
		});
		qq = vcard['X-TC-dwQQ'][0].VALUE;
		qqName = 'X-TC-dwQQ_' + vcard['X-TC-dwQQ'][0]['TYPE_ORDER']
	}
	
	if(n['taglist'].length){
		$.each(n['taglist'],function(j,m){
			group += '<span class="group">'+ m +'</span> ';
		});
	}
	
	userName = HtmlEncode(userName);
	tel = HtmlEncode(tel);
	qq = HtmlEncode(qq);
	if(key){
		var rgx = new RegExp(key,'g');
		userName = userName.replace(rgx,'<b>'+key+'</b>');
		tel = tel.replace(rgx,'<b>'+key+'</b>');
		qq = qq.replace(rgx,'<b>'+key+'</b>');
	}
	
	tr.push('<td><a href="javascript:void(0)" class="logClass view" name="contact_Detail">' + userName + '</a></td>');
	tr.push('<td title="'+ HtmlEncode(telTitle) +'"><span class="no-drag">'+ tel + '</span>' + telCount +'</td>');
	tr.push('<td title="'+ HtmlEncode(qqTitle) +'"><span class="no-drag">'+ qq + '</span>' + qqCount+'</td>');
	tr.push('<td class="col6"><div class="c-g-b">'+ (group || '&nbsp;') +'</div></td>');
	tr.push('</tr>');
	
	return tr.join('');
};

//获取字母导航数据
ContactsList.prototype.getLetters = function(total){
	if(total){
		$.ajax({
			url: g_path + "/card/set_letters_json.jsp",
			dataType: 'json',
			type: 'POST',
			data: {myuinmd5:$.md5(myuinmd5)},
			success: $.proxy(this,'createLetters')
		});
	}else{
		this.createLetters({ info: {letters: []}, result: 0});
	}
};

//生成字母导航
ContactsList.prototype.createLetters = function(data){
	var letters = data.info.letters,
		str = '<a href="javascript:void(0)" class="logClass first" name="a_click_letter">全部</a>',
		letterArray = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "#"];
	if(!letters.length){
		str = '<span>全部</span>';
	}
    if (data.result == 0) {
        for (var j = 0, jl = letterArray.length; j < jl; j++) {
            c = letterArray[j];
            for (var i = 0, il = letters.length; i < il; i++) {
                if (c == letters[i]) {
                    str += '<a name="a_click_letter" class="logClass" href="javascript:void(0)">' + c + '</a>';
                    i = 100;
                }
            }
            if (i == letters.length) {
                str += '<span>' + c + '</span>';
            }
        }
        $('#filters').html(str);
        this.updateLetters();
        setFiltersWidth();
    }
};

//更新字母导航状态
ContactsList.prototype.updateLetters = function(){
	var tKey = this.params.key;
	var as = $('#filters').children('a');
    if(!tKey){
    	$('#searchInput').val('输入姓名、号码或邮件').removeClass('focus');
    	as.first().addClass('selected');
    }else{
    	if(/PINYIN/.test(tKey)){
    		var letter = /:(\w|\#)$/.exec(tKey);
    		if(letter){
    			as.filter(':contains('+letter[1]+')').addClass('selected');
    		}
    		$('#searchInput').val('输入姓名、号码或邮件').removeClass('focus');
    	}
    }
};

ContactsList.prototype.filter = function(e){
	var t = $(e.target),
		key = t.text();
	if(key != '全部'){
		key = 'PINYIN:' + key;
	}else{
		key = '';
	}
	t.addClass('selected').siblings('.selected').removeClass();
	setContactHash({ key: key, pageNo: 1});
};

/**
 * 联系人回收站列表类
 * */
function RecycleList(options){
	for(var i in options){
		this[i] = options[i];
	}
	this.init();
}
//继承
Extend(RecycleList,PIM.Contacts);

RecycleList.prototype.params = {
	myuinmd5: $.md5(myuinmd5),
	X_Content_Type: 'json',
	pageNo: 1,
	pageSize: 100
};
	
RecycleList.prototype.createRow = function(n){
	var tr = ['<tr dataid="'+ n.dataid +'">'],
		userName = '未命名',
		tel = n['TEL_CELL'] || n['TEL'],
		qq = n['X-TC-dwQQ'];
	if(n['N']){
		userName = n['N'].replace(/\\;/g,'[:]').replace(/;/g,'').replace(/\[:\]/g,';');
	}
	
	tr.push('<td class="o-h"><i class="icon-grippy"></i></td>');
	tr.push('<td><input name="contact_Select" type="checkbox" class="logClass" dataid="'+ n.dataid +'" /></td>');
	
	tr.push('<td>' + HtmlEncode(userName) + '</td>');
	tr.push('<td>'+ HtmlEncode(tel) +'</td>');
	tr.push('<td>'+ HtmlEncode(qq) +'</td>');
	tr.push('<td class="col6">'+ n['savedtime'] +'</td>');
	tr.push('</tr>');
	
	return tr.join('');
};



