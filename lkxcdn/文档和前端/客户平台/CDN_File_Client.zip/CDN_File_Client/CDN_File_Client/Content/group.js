/**
 * Group 联系人分组类
 * @param options {}
 * 		id: 分组箱id
 * 		
 * */
function Group(options){
	for(var i in options){
		this[i] = options[i];
	}
	this.init();
}

Group.prototype = {
	constructor: Group,
	init: function(){
		this.setCurGroupId('-1');
		this.getGroupData(true);
		setTimeout($.proxy(this,'bindEvents'),100);
	},
	//绑定group相关事件
	bindEvents: function(){
		var self = this;
		this.group.delegate('li','click',function(e){
			var groupId = $(this).attr('groupId');
			self.selGroup(groupId);
		})
		.delegate('li','mouseover',function(){
			var t = $(this);
			if(t.is('.edit-status')) return;
			else if(!t.is('.'+self.selClass)) t.addClass(self.hoverClass);
			if(t.is('.group')) self.showActionBtns(t);
		})
		
		.delegate('li','mouseleave',function(){
			var t = $(this);
			t.removeClass(self.hoverClass);
			self.hideActionBtns(t);
		})
		
		.delegate('a[class^=icon]','click',function(e){
			var t = $(this),
				tcn = t.attr('class'),
				li = t.closest('li');
			switch(tcn){
				case 'icon-edit':
					self.edit(li);
					if(li.is('.'+self.selClass)){
						self.addCancel();
						return false;
					} 
					break;
				case 'icon-cancel':
					li.is('.edit-status') ? self.editCancel(li) : self.addCancel(li);
					return false;
				case 'icon-del':
					self.addCancel();
					self.delGroup(li);
					return false;
				case 'icon-sure':
					var input = li.find('.edit-text'),
						value = HtmlEncode( $.trim( input.val() ) );
					if(value == '') {
						input.focus().alert('分组名不能为空',{ position: 'top'});
						return false;
					}
					li.is('.edit-status') ? self.editOk(value,input) : self.addOk(value,input);
					return false;
			}
		})
	
		.delegate(':text','keyup',function(e){
			e.stopPropagation();
			var t = $(this),
				li = t.closest('li'),
				value = '';
			if(e.keyCode == 13){
				value = t.val();
				if(value == '') {
					t.focus().alert('分组名不能为空',{ position: 'top'});
					return false;
				}
				li.is('.edit-status') ? self.editOk(value,t) : self.addOk(value,t);
			}else if(e.keyCode == 27){
				li.is('.edit-status') ? self.editCancel(li) : self.addCancel(li);
			}
		})
		.delegate(':text[name=groupNameInput]','click',function(e){
			return false;
		});
		
		//document
		$(document).click(function(e){
			var t = $(e.target);
			if( !t.closest('.icon-edit').length && !t.closest('#groupAdd').length && (!t.closest('.add-status').length || !t.closest('.edit-status').length) ){
				self.editCancel(self.group.children('li.edit-status'));
				self.addCancel(self.group.children('li.add-status'));
			}
		});
		
		//绑定添加操作
		$('#groupAdd').live('click',$.proxy(this,'add'));
	},
	
	/*
	 * 获取分组数据
	 * isGetContact bool; 是否加载联系人列表。
	 * */
	getGroupData: function(isGetContact){
		var self = this;
		$.ajax({
			url: self.urlGroupData,
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json'},
			type: 'POST',
			success: function(data){
				if(data.result === '0'){
					self.createGroup(data.info.groups,isGetContact);
				}else if(data.result == '-1'){
					ajaxTips(data.msg);
				}
			}
		})
	},
	
	/*
	 * 生成分组列表
	 * data{json} 如：[{}]
	 * */
	createGroup: function(data,isGetContact){
		var tempStr = '';
		$.each(data,function(i,n){
			var groupClass = '';
			if(n.groupId > 0) groupClass = 'group';
			tempStr += '<li name="group_other" class="logClass '+ groupClass +'" groupId="'+ n.groupId +'"><i class="icon-point"></i><a href="javascript:void(0)" name="'+ n.groupName +'" class="group-name"><span name="gName">'+ getStr( n.groupName, 8 ) +'</span>['+ n.dataListSize +']</a></li>';
		});
		if(data.length > 1){
			this.clearAllGroup();
			//所有列表生成
			this.group.html(tempStr);
		}
		else{
			this.group.children(':last').before(tempStr);
		}
		
		//选中当前分组
		var groupId = this.getCurGroupId();
		this.setRowClass(groupId);
		//是否获取联系人数据
		if(isGetContact){
			this.selGroup(groupId);
		}
		//计算是否显示控制条
		controlBarShow($('#groupBox'),$('#groupControlBar'));
		setTimeout($.proxy(this,'bindDrop'),100);
	},
	
	/*
	 * 选中分组，触发点击操作
	 * */
	selGroup: function(groupId){
		setContactHash({groupId: groupId, pageNo: 1, order: 'ASC', sortBy: 'name', key: ''});
	},
	
	/*
	 * 设置当前选中分组样式
	 * */
	setRowClass: function(groupId){
		var o = this.group.find('li[groupId='+ groupId +']');
		this.editCancel(o.addClass(this.selClass).siblings('.'+this.selClass).removeClass(this.selClass));
		this.setCurGroupId(groupId);
		this.addCancel(this.group.children('li.add-status'));
		
		//
		$('.side-nav-list').children().removeClass('current');
	},
	
	/*
	 * 取消分组选中
	 * */
	setRowUnSel: function(){
		this.group.find('.'+this.selClass).removeClass(this.selClass);
		this.setCurGroupId('-1000');
	},
	
	/*
	 * 获取联系人
	 * */
	getContact: function(pageNo){
		var groupId = this.getCurGroupId();
		PIM.Contact.getContactData({ groupId: groupId, pageNo: pageNo, key: ''});
	},
	
	/*
	 * 设置当前选中分组groupId
	 * */
	setCurGroupId: function(groupId){
		this.curGroupId = groupId;
	},
	
	/*
	 * 获取当前选中分组groupId
	 * */
	getCurGroupId: function(){
		return this.curGroupId;
	},
	
	getCurGroup: function(){
		return this.group.children('.' + this.selClass);
	},
	
	/*
	 * 点击添加分组按钮的操作
	 * */
	add: function(){
		var addStatus = this.group.find('.add-status');
		
		if(!addStatus.length) {
			addStatus = $('<li class="add-status"><i class="icon-point"></i><input name="groupNameInput" type="text" class="text edit-text" /><span class="btns-sure-cancel"><a href="javascript:void(0)" class="icon-sure" title="确认"></a><a href="javascript:void(0)" class="icon-cancel" title="取消"></a></span></li>');
			this.group.append(addStatus);
		}
		
		addStatus.children(':text').focus();
		
		//如有正在编辑状态的分组，处理
		this.editCancel(this.group.find('.edit-status'));
	},
	
	/*
	 * 取消新增分组
	 * */
	addCancel: function(li){
		if(!li){
			li = this.group.children('.add-status');
		}
		li.remove();
	},
	
	/*
	 * 新建分组添加成功
	 * */
	addOk: function(groupName,input){
		var self = this;
		$.ajax({
			url: this.urlGroupAdd,
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), groupName: groupName, X_Content_Type: 'json'},
			type: 'POST',
			success: function(data){
				var result = data.result,
					msg = data.msg;
				if(result == '0'){
					self.addCancel(self.group.children(':last'));
					self.createGroup([{groupId: data.info.groupId, groupName: groupName, dataListSize: 0}],false);
				}
				else if(result == '-1000'){
					noLogin();
				}else{
					input.focus().alert(msg,{ position: 'top'});
				}
				ajaxTips(msg);
			}
		});
	},
	
	/*
	 * 点击编辑分组按钮的操作
	 * */
	edit: function(li){
		li.addClass('edit-status');
		var a = li.find('.group-name'),
			value = a.attr('name');
		var editInput = li.find('.edit-text');
		if(editInput.length){
			editInput;
			li.find('.btns-sure-cancel');
		}else{
			editInput = $('<input name="groupNameInput" type="text" class="text edit-text" />');
			li.append(editInput);
			li.append('<span class="btns-sure-cancel"><a href="javascript:void(0)" title="确认" class="icon-sure"></a><a href="javascript:void(0)" title="取消编辑" class="icon-cancel"></a></span>');
		}
		editInput.val(value).select().focus();
		
		this.hideActionBtns(li);
	},
	
	/*
	 * 取消分组编辑
	 * */
	editCancel: function(li){
		li.removeClass('edit-status');//.find('.group-name').show().siblings('.edit-text').hide().siblings('.btns-sure-cancel').hide();
	},
	
	/*
	 * 发送编辑分组请求
	 * */
	editOk: function(newName,input){
		var self = this;
		$.ajax({
			url: this.urlGroupEdit,
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), groupId: this.getCurGroupId(), newName: newName, X_Content_Type: 'json'},
			type: 'POST',
			success: function(data){
				var result = data.result,
					msg = data.msg;
				if(result == '0'){
					self.updateGroupName(newName);
				}
				else if(result == '-1000'){
					noLogin();
				}else{
					input.focus().alert(msg,{ position: 'top'});
				}
				ajaxTips(msg);
			}
		})
	},
	
	/*
	 * 编辑分组成功的返回状态
	 * */
	updateGroupName: function(newName){
		var curGroup = this.getCurGroup(),
			a = curGroup.find('.group-name'),
			nameObj = a.children('span[name=gName]');
		nameObj.text(getStr(newName,8));
		a.attr('name',newName);
		this.editCancel(curGroup);
	},
		
	/*
	 * 删除分组
	 * */
	delGroup: function(li){
		var title = '删除分组',
			msg = '确定要删除该分组？<br /><br />删除分组不会删除该分组下的联系人。',
			self = this,
			groupId = li.attr('groupId');
		PIM.Dialog.confirm(title,msg,function(){
			$.ajax({
				url: self.urlGroupDel,
				dataType: 'json',
				data: {myuinmd5: $.md5(myuinmd5), groupId: groupId, X_Content_Type: 'json'},
				type: 'POST',
				success: function(data){
					if( !resolveResult(data.result,data.msg) ) return;
					ajaxTips(data.msg);
					self.setCurGroupId('-1');
					self.updateGroup(true);
				}
			});
		});
	},
	
	/*
	 * 更新分组
	 * */
	updateGroup: function(isGetContact){
		this.getGroupData(isGetContact);
	},
	
	clearAllGroup: function(){
		var ul = $('#' + this.id);
		ul.children().filter('.accordian-noraml').remove();
	},
	
	showActionBtns: function(li){
		var actionBox = li.find('.btns-edit-del');
		if(actionBox.length){
			actionBox.show();
		}else{
			li.append('<span class="btns-edit-del"><a class="icon-edit" title="编辑分组" href="javascript:void(0)"></a><a class="icon-del" title="删除分组" href="javascript:void(0)"></a></span>');
		}
	},
	
	hideActionBtns: function(li){
		li.find('.btns-edit-del').hide();
	},
	
	bindDrop: function(){
		if($.ui && $.ui.droppable){
			$('.group').droppable({
				accept: "tr",
				addClasses: false,
				hoverClass: "group-highlight",
				tolerance: 'pointer',
				drop: function(event,ui){
					var groupId = $(this).attr('groupid');
					PIM.Actions.groupOperation(groupId,null,'add');
				}
			});
		}else{
			setTimeout($.proxy(arguments.callee,this),100);
		}
	}
}
