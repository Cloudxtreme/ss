//计算主要内容区的宽度
var windowResize = function(dom) {
	var $window = $(window),
		$contentBox = $('#contentBox'),
		$width = $window.width() - 200;
	if( $width < 720){
		$width = 720;
		$('body').addClass('body-x-scroll');
	}else{
		$('body').removeClass('body-x-scroll');
	}
	if($.browser.version == '6.0'){
		$contentBox.width( $width );
	}
	
	$.each(dom,function(i,n){
		setDomHeight(n);
	})
	
	setFiltersWidth();
};
//设置自适应高度
function setDomHeight(n){
	var selector = n.selector,
		callback = n.callback,
		_s = $(selector);
	if(_s.is(':hidden')) return;
	_s.height($(window).height() - _s.offset().top);
	if(callback){
		callback();
	}
}

function setFiltersWidth(){
	var _filter = $('#filters'),
		_c = _filter.children(),
		p = _filter.parent(),
		_w = ( p.width() - 200 ) / 28;
	_c.width(_w);
	if(_w > 30){
		_c.first().width(_w);
	}else{
		_c.first().width(30);
	}
	
}
/***
 * 含有中英文时，计算字串的字节数
 */
String.prototype.len = function(){
    return this.replace(/[^\x00-\xff]/g, "rr").length;
}
//返回指定长度的字符串
function getStr(str,len){
	var strLen = str.len();
	if(strLen <= len) return str;
	var rgx = /[^\x00-\xff]/,
		resultStr = '',
		k = 0,
		m = 0;
	while(m < len){
		var tempStr = str.charAt(k);
		rgx.test(tempStr) ? m += 2 : m++;
		k++;
		resultStr += tempStr;
	}
	return resultStr + '...';
}

//转码
function encodeStr(prev,str){
	var tempStr="";
	for(var i=0;i<str.length;i++){
		var hexStr=str.charCodeAt(i).toString(16);
		if(hexStr.length<=2){//按UTF-16进行编码		
			hexStr="00"+hexStr;
		}
		tempStr+=hexStr;
	}
	tempStr = "0x"+tempStr;
	return prev+"X-CUSTOM"+tempStr;
}

function HtmlEncode(sStr){
	sStr = sStr.replace(/&/g,"&amp;");
	sStr = sStr.replace(/>/g,"&gt;");
	sStr = sStr.replace(/</g,"&lt;");
	sStr = sStr.replace(/"/g,"&quot;");
	sStr = sStr.replace(/'/g,"&#39;");
	return sStr;
}

function HtmlUnEncode(sStr){
	sStr = sStr.replace(/&amp;/g,"&");
	sStr = sStr.replace(/&gt;/g,">");
	sStr = sStr.replace(/&lt;/g,"<");
	sStr = sStr.replace(/&quot;/g,'"');
	sStr = sStr.replace(/&#39;/g,"'");
	return sStr;
}
//ajax结果提示
function ajaxTips(msg){
	var at = $('#ajaxTips'), w = $(window);
	at.text(msg);
	at.css('top',0).css('left',( w.width() - at.width() ) / 2).show().delay(1500).fadeOut(500);
}

//log ajax提交
//添加日志上报logClass  long qqNo, String ip, String action,String ScreenWH,String coordinate,String content
function logSubmit(event){
	var action = $(this).attr("name");
    var screenWH = "screenWH:" + screen.width + "*" + screen.height;
    var mouseXY = "mouseXY:" + event.pageX + "*" + event.pageY;
    $.post(g_parepath + "/statistic_Analysis/pim_index_action.jsp", {
        action: action,
        screenWH: screenWH,
        coordinate: mouseXY,
        X_Content_Type: "json",
        myuinmd5:$.md5(myuinmd5)
    });
}
//原型继承
function Extend(child,parent){
	function f(){};
	f.prototype = parent;
	child.prototype = new f();
	child.prototype.constructor = child;
}

PIM.Dialog = {
	alert: function(title,msg,dialogClass){
		var dialog = PIM.Dialog.createDialog({title: title, msg: msg});
		if(!dialogClass) dialogClass = 'ui-dialog-alert';
		dialog.dialog({
			modal: true,
			width: 350,
			dialogClass: dialogClass,
			buttons: [{
		          'text': '确    定',
		          'class': 'btn-cancel',
		          'click': function(){
		        	  $(this).dialog('close');
		          }
			}]
		});
	},
	confirm: function(title,msg,callback){
		var dialog = PIM.Dialog.createDialog({title: title, msg: msg});
		dialog.dialog({
			modal: true,
			width: 350,
			buttons: [{
		          'text': '确    定',
		          'class': 'btn-sure',
		          'click': function(){
		        	  callback();
		        	  $(this).dialog('close');
		          }
			},{
				  'text': '取 消',
		          'class': 'btn-cancel',
		          'click': function(){$(this).dialog('close');}
			}],
			close: function(){
				$(this).dialog('destroy');
			}
		});
	},
	
	warn: function(title,msg){
		PIM.Dialog.alert(title,msg,'ui-dialog-warn');
	},
	
	error: function(title,msg){
		PIM.Dialog.alert(title,msg,'ui-dialog-error');
	},
	
	success: function(title,msg){
		PIM.Dialog.alert(title,msg,'ui-dialog-ok');
	},
	
	createDialog: function(options){
		var dialog = $('<div>').attr('title',options.title);
		dialog.appendTo('body');
		if(options.id){
			dialog.attr('id',options.id)
		}
		dialog.html('<div class="dialog-window">'+options.msg+'</div>');
		return dialog;
	}
};

function editPwd(e){
	var t = $(this);
		i = t.find('i');
	if(i.is('.icon-close')){
		t.next().slideDown(100);
		i.attr('class','icon-expand');
	}else{
		t.next().slideUp(100);
		i.attr('class','icon-close');
	}
}

//分析result
var resolveResult = function(result,msg){
	if(result == '-1000'){
		noLogin();
		return false;
	}else if(result == '-1'){
		ajaxTips(msg);
		return false;
	}
	return true;
},

isLogin = function(callback){
	$.ajax({
		url: '/check_login_json.jsp',
		type: 'POST',
		dataType: 'json',
		data: {myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json'},
		success: function(data){
			data.result == '0' ? callback() : noLogin();
		}
	})
},

//未登陆处理
noLogin = function(){
	top.location = '/login.jsp';
},

//各个模块之间的显示切换
showModule = function(o){
	$(o).siblings().hide().end().show();
};

function controlBarFn(e){
	var gb =  $(e.data.data),
		gbs = gb.scrollTop(),
		h = gb.height() - 58,
		name = $(this).attr('name');
	gb.stop();
	name == 'up' ? gb.animate({scrollTop: gbs - h},500) 
			: gb.animate({scrollTop: gbs + h},500);
	return false;
}

function controlBarShow(gb,cb){
	gb.height() < gb.children().height() ? cb.show() : cb.hide();
}
