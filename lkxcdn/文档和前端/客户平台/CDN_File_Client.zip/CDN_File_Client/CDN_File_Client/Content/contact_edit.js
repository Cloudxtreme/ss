/*
 * *
 * pim_vcard_labels: {
	    "N": "姓名",
	    "X-TC-dwQQ": "QQ",
	    "BDAY": "生日",
	    "TITLE": "职位",
	    "ORG": "部门",
	    "NOTE": "备注",
	    "TEL": "电话号码",
	    "TEL_HOME": "家庭电话",
	    "TEL_WORK": "办公电话",
	    "TEL_CELL": "常用手机",
	    "TEL_CELL_HOME": "常用家庭手机",
	    "TEL_CELL_WORK": "常用办公手机",
	    "TEL_FAX": "传真",
	    "TEL_FAX_HOME": "家庭传真",
	    "TEL_FAX_WORK": "办公传真",
	    "EMAIL": "电子邮箱",
	    "EMAIL_HOME": "家庭邮箱",
	    "EMAIL_WORK": "办公邮箱",
	    "URL": "网址",
	    "URL_HOME": "家庭网址",
	    "URL_WORK": "办公网址",
	    "ADR": "地址",
	    "ADR_HOME": "家庭地址",
	    "ADR_WORK": "办公地址"
	},
	
 * */
PIM.ContactEdit = {
	
	init: function(){
		var self = this;
		$('.contact-edit-area')
		.delegate('a','click',function(e){
			var t = $(this),
				name = t.attr('name');
			switch(name){
			case 'editName':
				self.openEditNameDialog();
				return false;
			case 'addBtn'://添加项
				self.addContactItem(t);
				return false;
			case 'delBtn'://删除
				self.delRow(t);
				return false;
			case 'uploadFace':
				isLogin($.proxy(self,'openUploadFace'));
				return false;
			}
		});
		
		//下拉框的操作绑定
		$('.cbb-text').live('blur',function(){
			if($(this).attr('readonly') == false){
				$(this).closest('th').next().children(':text').attr("name",encodeStr("TEL_",$(this).val()));
			}
		});
		
		$('#noteTA').live('focus',function(){
			var t = $(this);
			if(t.hasClass('no-note')){
				t.removeClass('no-note').val('');
			}
		}).live('blur',function(){
			var t = $(this);
			if($.trim(t.val()) == ''){
				t.addClass('no-note').val('在这里添加对TA的备注吧\n\n初遇地点？特长？怪癖？…\n\n好记性不如烂笔头(*^__^*)');
			}
		});
		
	},
	/*
	 * 保存
	 * type 为保存类型，0表示新增，1表示编辑
	 * */
	save: function(type){
		//验证先
		if ( !this.chkAll() ) return;
		
		var url = '/card/add_card_json.jsp',
			paramsArrs = $('#field').serializeArray(),
			params = {
				myuinmd5: $.md5(myuinmd5),
				X_Content_Type: 'json'
			};
		
		$.each(paramsArrs,function(i,n){
			var nn = n['name'],
				nv = n['value'];
			params[nn] = HtmlUnEncode(nv);
		});
		
		if($('#noteTA').hasClass('no-note')){
			params['NOTE'] = '';
		}

		if(type){
			url = '/updateItem.jsp';
			params['dataid'] = this.getContactId();
		}
		
		$.ajax({
			url: g_path + url,
			dataType: 'json',
			type: 'POST',
			data: params,
			success: function(data){
				if( !resolveResult(data.result,data.msg) ) return;
				PIM.Group.updateGroup(true);
				
				ajaxTips(data.msg);
			}
		});
	},
	
	//获取分组信息
	getGroupInfo: function(contactId){
		var self = this;
		//新增
		if(!contactId){
			var g = PIM.Group,
				groupId = g.getCurGroupId(),
				groupName = '未分组';
			
			if(groupId > 0){
				groupName = g.getCurGroup().find('.group-name').attr('name');
			}else{
				groupId = '';
			}
			
			this.setGroupIds([{groupid: groupId, groupname: groupName}]);
			
			self.bindGroupInfo();
		}
		//编辑
		else{
			this.setContactId(contactId);
			$.ajax({
				url: g_path + '/inGroups.jsp',
				type: 'POST',
				dataType: 'json',
				data: {myuinmd5: $.md5(myuinmd5), id: contactId, X_Content_Type: 'json'},
				success: function(data){
					self.setGroupIds(data.info.groups);
					self.bindGroupInfo();
				}
			});
		}
	},
	
	setGroupIds: function(groups){
		this.groupIds = groups;
	},
	getGroupIds: function(){
		return this.groupIds;
	},
	
	//绑定分组信息
	bindGroupInfo: function(){
		var groups = this.getGroupIds(),
			str = '', arrs = [];
		if(!groups.length){ 
			str = '<span groupId="0" class="group">未分组</span>';
			$('#contactEditGroupIds').val('');
		}
		else{
			$.each(groups,function(i,n){
				str += '<span groupId="'+ n.groupid +'" class="group">'+ n.groupname +'</span>';
				arrs.push(n.groupid);
			});
			
			$('#contactEditGroupIds').val(arrs.join());
		}
		$('#c_group').html(str);
	},
	
	//增加分组
	addGroup: function(groupId,groupName){
		var groups = this.getGroupIds();
		if(groups.length == 1 && groups[0].groupid == ''){
			groups = [];
		}
		groups.push({groupid: groupId, groupname: groupName});
		this.setGroupIds(groups);
		this.bindGroupInfo();
	},
	
	//删减分组
	cutGroup: function(groupId){
		var groups = this.getGroupIds();
		for(var i = 0, j = groups.length; i < j; i++){
			var temp = groups[i];
			if( groupId == temp.groupid){
				groups.splice(i,1);
				break;
			}
		}
		if(groups.length == 0){
			groups.push({groupid: '', groupname: '未分组'});
		}
		this.setGroupIds(groups);
		this.bindGroupInfo();
	},
	
	getContactId: function(){
		return this.contactId;
	},
	setContactId: function(contactId){
		this.contactId = contactId;
	},
	//添加联系方式
	addContactItem: function(o){
		var tr = o.closest("tr"),
			type = tr.attr('name'),
			_type = '', text = '', _text = '', comboboxHtml = '', style = '',
			isCombo = true;
		switch(type){
		case 'tel':
			text = '常用电话';
			_text = '电话';
			_type = 'TEL';
			style = 'style="width: 300px;"';
			break;
		case 'fax':
			text = _text = '传真';
			_type = 'TEL_FAX';
			style = 'style="width: 300px;"';
			break;
		case 'email':
			text = _text = '电子邮箱';
			_type = 'EMAIL';
			style = 'style="width: 300px;"';
			break;
		case 'qq':
			text = _text = 'QQ';
			_type = 'X-TC-dwQQ';
			isCombo = false;
			break;
		case 'url':
			text = _text = '网址';
			_type = 'URL';
			style = 'style="width: 400px;"';
			break;
		case 'adr':
			text = _text = '地址';
			_type = 'ADR';
			style = 'style="width: 400px;"';
			break;
		}
		var count = this.getTypeCount(_type);
		if(isCombo){
			comboboxHtml = '<th><span class="combobox" name="'+ type +'"><input type="text" value="'+ text +'" class="cbb-text" style="width: 72px;" readonly="readonly"><i class="cbb-icon"></i></span></th><td>';
		}else{
			comboboxHtml = '<td>'
		}
		var selectHtml ='<tr name="'+ type +'">'
							+ comboboxHtml
							//+'<td>'
								+'<input class="text" type="text" name="'+ _type + '_' + count +'" '+ style +'> '
								+'<a href="" class="icon-item-del" name="delBtn" title="删除'+ _text +'"></a> '
								+'<a href="" class="icon-add" name="addBtn" title="新增'+ _text +'"></a>'
							+'</td>'
						+'</tr>';
		tr.after(selectHtml);
		tr.next().find(':text:last').focus();
	},
	
	//删除行
	delRow: function(o){
		var prev = o.prev(),
			tr = o.closest('tr'),
			type = tr.attr('name');
		if(tr.siblings('[name='+type+']').length){
			tr.remove();
		}else{
			prev.val('');
		}
	},
	
	/*
	 * 获取当前添加的类型 最大值
	 * 返回 数字
	 * */
	getTypeCount: function(type){
		var o = $(':text[name^='+ type +'_]'),
			arrs = [];
		if(!o.length) return 0;
		o.each(function(i,n){
			var name = $(n).attr('name');
			arrs.push(parseInt(/\d+$/.exec(name)[0],10));
		});
		var max = arrs[0];
		for(var i=0, j =arrs.length; i < j; i++){
			if(arrs[i] > max){
				max = arrs[i];
			}
		}
		return max + 1;
	},
	
	//单个验证
	chk: function(t){
		var type = /^[-a-zA-Z\d]+/.exec(t.attr('name'))[0],
			value = $.trim(t.val()),
			rgx = null, msg = '';
		if(!value) return true;
		switch(type){
		case 'TEL':
			rgx = /^[^\u4E00-\u9FA5]+$/;
			msg = '电话号码不能有中文！';
			break;
		case 'BDAY':
			rgx = /^\d{4}-\d{2}-\d{2}$/;
			msg = '日期格式错误！';
			break;
		case 'X-TC-dwQQ':
			rgx = /^\d{5,11}$/;
			msg = 'qq号为5-11位数字！';
			break;
		case 'EMAIL':
			rgx = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i;
			msg = '请填写正确的邮件格式 ！';
			break;
		}
		if(value && rgx){
			if( !rgx.test(value) ){
				t.focus().alert(msg,{ position: 'top'});
				return false;
			}
		}
		return true;
	},
	
	chkLength: function(t){
		var type = /^[-a-zA-Z\d]+/.exec(t.attr('name'))[0],
			length = 0, msg = '',
			value = t.val();
		switch(type){
		case 'N1':
			length = 20;
			msg = '姓氏长度不能超过20个字符'
			break;
		case 'N2':
			length = 20;
			msg = '名字长度不能超过20个字符'
			break;
		case 'TEL':
			length = 30;
			msg = '电话号码不能超过30个字符';
			break;
		case 'EMAIL':
			length = 50;
			msg = '电子邮箱不能超过50个字符';
			break;
		case 'ORG':
			length = 100;
			msg = '公司/部门不能超过100个字符';
			break;
		case 'NOTE':
			length = 100;
			msg = '备注不能超过100个字符';
			break;
		case 'URL':
			length = 300;
			msg = '网址不能超过300个字符';
			break;
		case 'ADR':
			length = 300;
			msg = '地址不能超过300个字符';
			break;
		}
		if(length && value.len() > length){
			t.focus().alert(msg,{ position: 'top'});
			return false;
		}
		return true;
	},
	
	//验证一遍
	chkAll: function(){
		var self = this,
			states = true;
		//验证看有没有最少填了一项
		var arrs = $('#field').serializeArray();
		var _isAllBlank = true;
		for(var kk = 0, mm = arrs.length; kk < mm; kk++){
			var _value = arrs[kk].value; 
			if(arrs[kk].name == 'NOTE'){
				if(!$('#noteTA').hasClass('no-note')){
					_isAllBlank = false;
					break;
				}
			}else{
				if(_value != ''){
					_isAllBlank = false;
					break;
				}
			}
		}
		if(_isAllBlank){
			PIM.Dialog.alert('消息框','请至少填写一项！');
			return false;
		}

		//验证联系方式和更多详情
		$(':input[name]:visible','#field').each(function(){
			var t = $(this);
			if ( !self.chkLength( t ) || !self.chk( t ) ){
				states = false;
				return false;
			}
		});
		return states;
	},
	
	openEditNameDialog: function(){
		var self = this,
			dialog = $('#editContactNameDialog');
		if(dialog.length){
			dialog.html(this.getNameEditHtml());
			dialog.dialog('open');
			return;
		}
		dialog = $('<div>').attr('id','editContactNameDialog').attr('title','姓名编辑');
		dialog.appendTo('body');
		dialog.html(this.getNameEditHtml());
		dialog.dialog({
			modal: true,
			width: 400,
			buttons: [
		          {
		        	  'text': '确定',
		        	  'class': 'btn-sure',
		        	  'click': function(){
		        		  var field = $(this).find(':text'),
		        		  	  vals = [];
		        		  if(self.chkLength(field.eq(0)) && self.chkLength(field.eq(1))){
			        		  field.each(function(i,n){
			        			  vals.push(HtmlEncode(n.value.replace(/;/g,'\\;')));
			        		  });
			        		  
			        		  $('#UserNameInput').val(vals.join(';'));
			        		  $('#UserNameB').html(vals.join(' ').replace(/\\;/g,';'));
			        		  $(this).dialog('close');
		        		  }
		        	  }
		          },
		          {
		        	  'text': '取消',
		        	  'class': 'btn-cancel',
		        	  'click': function(){$(this).dialog('close');}
		          }
	          ]
		});
	},
	
	getNameEditHtml: function(){
		var names = HtmlUnEncode($('#UserNameInput').val()).replace(/\\;/g,'[:]').split(';');
		var html = '<div class="dialog-window">'
					  +'<p class="field"><label for="nameX">姓氏：</label> <input type="text" name="N1" id="nameX" class="text" value="'+ names[0].replace(/\[:\]/g,';') +'" /></p>'
					  +'<p class="field"><label for="nameM">名字：</label> <input type="text" name="N2" id="nameM class="text" value="'+ (names[1] || '').replace(/\[:\]/g,';') +'" /></p>'
					+'</div>';
		return html;
	},
	
	openUploadFace: function(){
		var dialog = $('#uploadFaceDialog');
		if(dialog.length){
			dialog.dialog('open');
			return;
		}
		dialog = $('<div>').attr('id','uploadFaceDialog').attr('title','编辑头像');
		dialog.appendTo('body');
		dialog.load(g_path + '/modFace.jsp',$.proxy(this,'openUploadFaceBack'));
		
	},
	
	openUploadFaceBack: function(){
		var self = this;
		var dialog = $('#uploadFaceDialog');
		dialog.dialog({
			modal: true,
			width: 460,
			height: 330,
			open: function(){
				$('#uploadFaceImg').attr('src',$('#faceImg').attr('src'));
				$('#fileToUpload').val('');
			},
			buttons: [
	          {
	        	  'text': '上传',
	        	  'class': 'btn-sure',
	        	  'click': function(){
	        		  var file = $('#fileToUpload'),
	        		  	  value = file.val();
	        		  if(!value){
	        			  file.alert('请选择要上传的图片！',{position: 'top'});
	        		  }
	        		  else if(/\.(bmp|gif|png|jpg)$/i.test(value)){
	        			  isLogin($.proxy(self,'upload'));
	        			  $(this).dialog('close');
	        		  }else{
	        			  file.alert('请上传指定格式的图片！',{position: 'top'});
	        		  }
	        	  }
	          },
	          {
	        	  'text': '取消',
	        	  'class': 'btn-cancel',
	        	  'click': function(){$(this).dialog('close');}
	          }
            ]
		});
	},
	upload: function(){
		var self = this;
		$.ajaxFileUpload({
        	url: '../pim/contact/uploadAvatar.jsp',            		//需要链接到服务器地址
            secureuri:false,
            fileElementId: 'fileToUpload',                        	//文件选择框的id属性
            dataType:'json',                                		//服务器返回的格式，可以是json
            success: function (data){
            	if(data.result == '0'){
            		self.uploadBack(data.info);
            	}else{
            		PIM.Dialog.alert('上传提示',data.msg);
            	}
            },
            error: function(data){
            	PIM.Dialog.error('上传出错',data.msg);
            }
		});
	},
	uploadBack: function(data){
		var photoid = data.photoid,
			imageType = data.imgct;
		var imgType = imageType.split("\/");
		if(imgType.length<2){
			 return;
		}
		$("#photoid").val(photoid).attr({"name":"X-MPS-PHOTO_"+imgType[1]});
		//使用远程图片替换原有的图片
		var imgUrl = "../pim/contact/avatar.jsp?X_Content_Type=json&photoid=" + photoid + "&imgType=" + imgType[1];
		$("#faceImg").attr({"src":imgUrl}).siblings('span').addClass('edit').text('点击修改图像');
	}
};

$(function(){
	PIM.ContactEdit.init();
})
