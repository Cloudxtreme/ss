﻿/*
* 页面初始化调用
* */
$(function () {

    //ajax状态显示
    $("#loading")
    .ajaxStart(function () {
        var t = $(this), w = $(window);
        t.css('top', 0).css('left', (w.width() - t.width()) / 2).show();
    })
    .ajaxStop(function () {
        $(this).hide();
    });

    //重置元素大小
    var _doms = [
         	{ selector: '#side' },
         	{ selector: '#groupBox' },
         	{ selector: '#contactEdit' },
            { selector: '#contentBox' }
		];
    windowResize(_doms);
    var _window = $(window);
    _window.resize(function () {
        windowResize(_doms);
    });

    $("#memuList li").hover(
             function () {
                 $(this).addClass("over"); //鼠标经过添加hover样式
             }, function () {
                 $(this).removeClass("over"); //鼠标离开移除hover样式
             });
     $("#memuList li").click(function () {
         $("#memuList li").removeClass("choose");
         $(this).addClass("choose"); //添加选中样式
     });

     $('#winInfo').window('close');
});