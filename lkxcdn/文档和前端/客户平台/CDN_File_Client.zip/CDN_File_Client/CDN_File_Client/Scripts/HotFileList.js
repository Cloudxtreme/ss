﻿
function ClearDomainTb() {
    $("#userDomainTb tr:not(:first)").remove();
}

function changPwd() {
    $('#winInfo').window({
        modal: false,
        shadow: false,
        closed: false
    });
}

function ChangePage() {
    var start_date = String($("#date_start").val());
    var end_date = String($("#date_end").val());
    ClearData();
    var num = Number($("#pageNum").val());
    $.ajax(
        {
            url: '/CdnFile/GetHotFilesPage',
            data: "page=" + num + "&start=" + start_date + "&end=" + end_date + "",
            type: "POST",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                //添加表格行
                var dataArr = data.split('*');


                for (var j = 0; j < dataArr.length - 1; j++) {
                    gotoAdd(dataArr[j]);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function GotoPage(page) {
    var start_date = String($("#date_start").val());
    var end_date = String($("#date_end").val());
    var filename = String($("#filename").val());
    ClearData();
    $.ajax(
        {
            url: '/CdnFile/GetHotFilesPage',
            data: "page=" + page + "&start=" + start_date + "&end=" + end_date + "&filename="+filename,
            type: "POST",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                //添加表格行
                var dataArr = data.split('*');
                for (var j = 0; j < dataArr.length - 1; j++) {
                    gotoAdd(dataArr[j]);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function gotoAdd(data) {
    var tableTrElement = $("#dataTable tr");
    var len = tableTrElement.length;
    var tableElement = $("#dataTable");
    var arr = data.split(',');

    tableElement.append("<tr>"
        + "<td align=\'center\'>" + arr[0] + "</td>" //编号  
        + "<td align=\'center\'>" + arr[1] + "</td>" //文件路径
        + "<td align=\'center\'>" + arr[2] + "</td>" //文件大小
        + "<td align=\"center\">" + arr[3] + "</td>"
        + "<td align=\"center\">" + arr[5] + "</td>"
        + "</tr>");
}

var ClearData = function () {
    $("#dataTable tr").remove();
    
    var tableElement = $("#dataTable");
    tableElement.append("<tr>"
        + "<td align=\'center\'>编号</td>" //编号  
        + "<td align=\'center\'>文件名称</td>" //文件路径
        + "<td align=\'center\'>文件大小(字节)</td>" //文件大小
        + "<td align=\"center\">lastmodify</td>"
        + "<td align=\"center\">进度</td>"
        + "</tr>");
}

function GetHotFileList() {
    var start_date = String($("#date_start").val());
    var end_date = String($("#date_end").val());
    var filename = String($("#filename").val());
    if (start_date == null || start_date.length == 0 || end_date == null || end_date.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    window.location = "../CdnFile/HotFileList?start=" + start_date + "&end=" + end_date + "&filename=" + filename;
}

function showLoad() {
    $('#progressbar').window({
        modal: true,
        shadow: false,
        height: 30,
        title: ""
    });
}
function showHide() {
    $('#progressbar').window('close');
}

function adv_format(value,num) //四舍五入
{
var a_str = formatnumber(value,num);
var a_int = parseFloat(a_str);
if (value.toString().length>a_str.length)
{
var b_str = value.toString().substring(a_str.length,a_str.length+1)
var b_int = parseFloat(b_str);
if (b_int<5)
{
return a_str
}
else
{
var bonus_str,bonus_int;
if (num==0)
{
bonus_int = 1;
}
else
{
bonus_str = "0."
for (var i=1; i<num; i++)
bonus_str+="0";
bonus_str+="1";
bonus_int = parseFloat(bonus_str);
}
a_str = formatnumber(a_int + bonus_int, num)
}
}
return a_str
}

function formatnumber(value,num) //直接去尾
{
var a,b,c,i
a = value.toString();
b = a.indexOf('.');
c = a.length;
if (num==0)
{
if (b!=-1)
a = a.substring(0,b);
}
else
{
if (b==-1)
{
a = a + ".";
for (i=1;i<=num;i++)
a = a + "0";
}
else
{
a = a.substring(0,b+num+1);
for (i=c;i<=b+num;i++)
a = a + "0";
}
}
return a
}