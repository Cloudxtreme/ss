﻿function AutoTask() {
    //$('#auto_task').hide();
    $('#auto_task').show();
}
function AddAutoTask() {
    $('#addAutoTask').window('open');
}
function DoAddAutoTask() {
    var fileName = $('#txt_file').val();
    var filePath = $('#txt_path').val();
    var fileNum = $('#txt_num').val();
    var fileMd5 = $('#txt_md5').val();
    if (fileName == null || fileName.length == 0 || filePath == null || filePath.length == 0 || fileNum == null || fileNum.length == 0 || fileMd5 == null || fileMd5.length == 0) {
        $.messager.alert('操作错误', "请填写完整的信息！");
        return false;
    }
    $.ajax(
        {
            url: '/CdnFile/DoAutoTask',
            data: "fileName=" + fileName + "&filePath=" + filePath + "&fileNum=" + fileNum + "&fileMd5=" + fileMd5,
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    return false;
                } else {
                    alert(data);
                    window.location.reload();
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
    function DeleteTask(id) {
        $.messager.confirm('提示', '确定删除该自动分发任务吗？', function (r) {
            if (r) {
                $.ajax(
                {
                    url: '/CdnFile/DeleAutoTask',
                    data: "id=" + id,
                    type: "POST",
                    //contentType: "charset=utf-8",
                    dataType: "text",
                    beforeSend: showLoad,
                    complete: showHide,
                    success: function (data) {
                        if (data == null || data.length == 0) {
                            alert("删除失败！");
                            return false;
                        } else {
                            alert(data);
                            window.location.reload();
                        }
                    },
                    error: function (data) {
                        alert(data.statusText);
                    }
                });
            }
            else {
                return false;
            }
        });
    }

function checkMd5(id, name, path) {
    var user = $("#user").val();
    var md5 = $("#md5").val();
    var geturl = "http://cdnmgr.efly.cc/cdn_server_admin/cdn_file_checksum.php";
    geturl += "?user=" + user;
    geturl += "&pass=" + md5;
    geturl += "&filepath=" + path;
    geturl += "&filename=" + name;
    geturl += "&callback=?";
    //alert(geturl);
    $.getJSON(geturl,
                        function (data) {
                            if (data.error == "") {
                                //alert(data.md5);
                                $.messager.alert('返回结果', data.md5);
                            }
                            else {
                                alert(data.error);
                            }
                        }
                    );
}
function SaveStatus(id,name,path) {
    var sele = $("#dr_" + id).val();
    var desc = $("#put_" + id).val();
    var statu = $("#statu_" + id).val();
    if (statu == sele) {
        $.ajax(
        {
            url: '/CdnFile/EditFileNoStatu',
            data: "id=" + id + "&desc=" + desc + "",
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    return false;
                } else {
                    alert(data);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
    else {
        $.ajax(
        {
            url: '/CdnFile/EditFile',
            data: "id=" + id + "&statu=" + sele + "&desc=" + desc + "",
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    return false;
                } else {
                    var geturl = "http://cdnmgr.efly.cc/cdn_server_admin/cdn_source_file_mgr.php";
                    var changeStatu;
                    if (sele == "分发文件") {
                        changeStatu = "cdn";
                    }
                    else {
                        changeStatu = "uncdn";
                    }
                    var Arr = data.split('|');
                    geturl += "?user=" + Arr[0];
                    geturl += "&pass=" + Arr[1];
                    geturl += "&action=" + changeStatu;
                    geturl += "&filepath=" + path;
                    geturl += "&filename=" + name;
                    geturl += "&callback=?";
                    $.getJSON(geturl,
                        function (data) {
                            if (data.error == "") {
                                if (data.result == 0) {
                                    $("#statu_" + id).val(sele); //修改隐藏域的值
                                    alert('修改成功！');
                                }
                                else {
                                    $("#dr_" + id).val($("#statu_" + id).val());//还原下拉框的值
                                    alert('修改失败！');
                                }
                            }
                            else {
                                alert(data.error);
                            }
                        }
                    );
                    //SetStatuUrl(geturl);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
}

function FileDetail(id, name, name_md5, path) {
    $('#win').window({
        modal: true,
        shadow: false,
        closed: false,
        title: "文件名 " + name + " 请求详细情况"
    });
    // $("#file_name").val(String(name));
    $("#file_name").val(String(path).substring(1, path.legth) + "/" + String(name));
    
    $("#file_result").html("");
    $("#file_path").val("http://filecdn.efly.cc/cdnwebmgr/cdn_file/cdn_dl_make_link_zone.php?user_fileid=" + name_md5);
    var domainStr = $("#domain").val();
    if (domainStr == "null") {
        return false;
    }
    else {
        var dataArr = String(domainStr).split('@');
        //alert(domainStr);
        ClearDomainTb();
        for (var j = 0; j < dataArr.length - 1; j++) {
            winTableAdd(dataArr[j], path, name);
        }
    }
}

function winTableAdd(doamin,path,name) {
    var tb = $("#userDomainTb");
    if (doamin.length != 0) {
        if (path == '/') {
            tb.append("<tr><td><input type=\"text\" style=\"width:450px;\" value=\'http://" + doamin + path + "" + name + "\' title=\"\"/></td></tr>");
        }
        else {
            tb.append("<tr><td><input type=\"text\" style=\"width:450px;\" value=\'http://" + doamin + path + "/" + name + "\' title=\"\"/></td></tr>");
        }
    }
    else {
        alert('显示内容出错！');
    }
}

function ClearDomainTb() {
    $("#userDomainTb tr:not(:first)").remove();
}

function changPwd() {
    $('#winInfo').window({
        modal: false,
        shadow: false,
        closed: false
    });
}

function EditClientPwd() {
    var oldPwd = $("#txt_old").val();
    var newPwd = $("#txt_new").val();
    var newPwdSet = $("#txt_new_set").val();
    if (oldPwd == null || oldPwd.length == 0 || newPwd == null || newPwd.length == 0) {
        alert("请填写完整信息！");
        return false;
    }
    if (newPwd != newPwdSet) {
        alert("两次输入的密码不一致！");
        return false;
    }
    $.ajax(
        {
            url: '/Home/ChangePwd',
            data: "oldPwd=" + oldPwd + "&newPwd=" + newPwd,
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    alert("修改失败！");
                    return false;
                } else {
                    alert(data);
                    $('#winInfo').window('close');
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

//下载文件
function DownFile() {
    var url = $('#file_path').val();
    window.open(url, '_blank');
}

function ChangePage() {
    ClearData();
    var num = Number($("#pageNum").val());
    $.ajax(
        {
            url: '/CdnFile/GetFilesPage',
            data: "page=" + num + "",
            type: "POST",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                //添加表格行
                var dataArr = data.split('*');
                for (var j = 0; j < dataArr.length - 1; j++) {
                    gotoAdd(dataArr[j]);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function GotoPage(page) {
    ClearData();
    $.ajax(
        {
            url: '/CdnFile/GetFilesPage',
            data: "page=" + page + "",
            type: "POST",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                //添加表格行
                var dataArr = data.split('*');
                for (var j = 0; j < dataArr.length - 1; j++) {
                    gotoAdd(dataArr[j]);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function gotoAdd(data) {
    var tableTrElement = $("#dataTable tr");
    var len = tableTrElement.length;
    var tableElement = $("#dataTable");
    var arr = data.split(',');
    var OtherStatu = arr[5] == "不做分发" ? "分发文件" : "不做分发";
    var putID = "put_" + arr[0];
    var drID = "dr_" + arr[0];
    var statuID = "statu_" + arr[0];
    if (arr.length == 9) {
        tableElement.append("<tr>"
        + "<td align=\'center\'>" + arr[0] + "</td>" //编号
        + "<td><a href=\"javascript:void(0)\" onclick=\"FileDetail('" + arr[0] + "','" + arr[2] + "','" + arr[1] + "','" + arr[3] + "')\" title=\"点击查看文件详细信息\">" + arr[2] + "</a></td>" //文件名称
        + "<td>" + arr[3] + "</td>" //文件路径
        + "<td>" + arr[4] + "</td>" //文件大小
        + "<td align=\'center\'>" + arr[6] + "</td>" //时间
        + "<td style=\"width:86px\">"
        + "<input id=\"" + statuID + "\" type=\"hidden\"  value=\"" + arr[5] + "\" />"
        + "<select id=\'" + drID + "\'>"  //文件状态
            + "<option>" + arr[5] + "</option>"
            + "<option>" + OtherStatu + "</option>"
        + "</select></td>"
        + "<td align=\"center\">" + arr[7] + "</td>"
        + "<td align=\"center\"><input type=\"text\" value=\'" + arr[8] + "\' title=\"\" id=\"" + putID + "\"/></td>"
        + "<td align=\"center\"><input type=\"button\" icon=\'icon-save\' value=\"保 存\" onclick=\"SaveStatus(\'" + arr[0] + "\',\'" + arr[2] + "\',\'" + arr[3] + "\')\" /></td>"
        + "<td align=\"center\"><input type=\"button\" icon=\'icon-save\' value=\"MD5校验\" onclick=\"checkMd5(\'" + arr[0] + "\',\'" + arr[2] + "\',\'" + arr[3] + "\')\" /></td>"
        + "</tr>");
    }
    else {
        alert('显示内容出错！');
    }
}

var ClearData = function () {
    $("#dataTable tr").remove();
}

//function CheckTotal() {
//    var start_date = String($("#date_start").val());
//    var end_date = String($("#date_end").val());
//    if (start_date == null || start_date.length == 0 || end_date == null || end_date.length == 0) {
//        alert("请选择要查询的日期条件！");
//        return false;
//    }
//    var file = String($("#file_name").val());
//    $.ajax(
//        {
//            url: "/CdnFile/GetFileTotal",
//            type: "POST",
//            data: "start=" + start_date + "&end=" + end_date + "&file=" + file + "",
//            dataType: "text",
//            beforeSend: showLoad,
//            complete: showHide,
//            success: function (data) {
//                if (data == null || data.length == 0) {
//                    $("#file_result").html("[请求总次数：0]  [总流量：0 M]");
//                }
//                else {
//                    if (data.indexOf('|') > 0) {
//                        var dataArr = data.split('|');
//                        $("#file_result").html("[请求总次数：" + dataArr[0] + "] <br /> [总流量：" + dataArr[1] + "M]  按G换算：[请求总流量：" + adv_format(Number(dataArr[1]) / 1024, 2) + "G]（说明：M是指兆字节，即MBytes）");
//                    }
//                    else {
//                        $("#file_result").html(String(data));
//                    }
//                }
//            },
//            error: function (data) {
//                alert(data.statusText);
//            }
//        });
//}

function CheckTotal() {
    var start_date = String($("#date_start").val());
    var end_date = String($("#date_end").val());
    if (start_date == null || start_date.length == 0 || end_date == null || end_date.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    var file = String($("#file_name").val());
    $.ajax(
        {
            url: "/CdnFile/GetFileTotal",
            type: "POST",
            data: "start=" + start_date + "&end=" + end_date + "&file=" + file + "",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    $("#file_result").html("[请求总次数：0]  [总流量：0 M]");
                }
                else {
                    if (data.indexOf('|') > 0) {
                        var dataArr = data.split('|');
                        $("#file_result").html("[请求总IP数：" + dataArr[2] + "] [请求总次数：" + dataArr[0] + "] <br /> [总流量：" + dataArr[1] + "M]  按G换算：[请求总流量：" + adv_format(Number(dataArr[1]) / 1024, 2) + "G]（说明：M是指兆字节，即MBytes）");
                    }
                    else {
                        $("#file_result").html(String(data));
                    }
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function showLoad() {
    $('#progressbar').window({
        modal: true,
        shadow: false,
        height: 30,
        title: ""
    });
}
function showHide() {
    $('#progressbar').window('close');
}

function adv_format(value,num) //四舍五入
{
var a_str = formatnumber(value,num);
var a_int = parseFloat(a_str);
if (value.toString().length>a_str.length)
{
var b_str = value.toString().substring(a_str.length,a_str.length+1)
var b_int = parseFloat(b_str);
if (b_int<5)
{
return a_str
}
else
{
var bonus_str,bonus_int;
if (num==0)
{
bonus_int = 1;
}
else
{
bonus_str = "0."
for (var i=1; i<num; i++)
bonus_str+="0";
bonus_str+="1";
bonus_int = parseFloat(bonus_str);
}
a_str = formatnumber(a_int + bonus_int, num)
}
}
return a_str
}

function formatnumber(value,num) //直接去尾
{
var a,b,c,i
a = value.toString();
b = a.indexOf('.');
c = a.length;
if (num==0)
{
if (b!=-1)
a = a.substring(0,b);
}
else
{
if (b==-1)
{
a = a + ".";
for (i=1;i<=num;i++)
a = a + "0";
}
else
{
a = a.substring(0,b+num+1);
for (i=c;i<=b+num;i++)
a = a + "0";
}
}
return a
}