﻿function GetMapData() {
    var start = String($("#date_start").val());
    var end = String($("#date_end").val());
   // var domain = $("#domain").val();
    if (start == null || start.length == 0 || end == null || end.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    $.ajax(
        {
            url: '/CdnFile/GetMapData',
            data: "start=" + start + "&end=" + end,
            type: "POST",
            dataType: "JSON",
            // beforeSend: showLoad,
            // complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0 || data.length == 11) {
                    alert("您查询的域名暂时没数据!");
                } else {
                    // alert(data);

                    var tojson = eval('(' + data + ')');
                    domap(tojson);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}


function domap(getJson) {
    $('#container').empty();
    var addata = getJson.data;
    //数据可以动态生成，格式自己定义，cha对应china-zh.js中省份的简称
    var dataStatus = [{ cha: 'HKG', name: '香港', des: addata.HKG },
                             { cha: 'HAI', name: '海南', des: addata.HAI },
                             { cha: 'YUN', name: '云南', des: addata.YUN },
                             { cha: 'BEJ', name: '北京', des: addata.BEJ },
                             { cha: 'TAJ', name: '天津', des: addata.TAJ },
                             { cha: 'XIN', name: '新疆', des: addata.XIN },
                             { cha: 'TIB', name: '西藏', des: addata.TIB },
                             { cha: 'QIH', name: '青海', des: addata.QIH },
                             { cha: 'GAN', name: '甘肃', des: addata.GAN },
                             { cha: 'NMG', name: '内蒙古', des: addata.NMG },
                             { cha: 'NXA', name: '宁夏', des: addata.NXA },
                             { cha: 'SHX', name: '山西', des: addata.SHX },
                             { cha: 'LIA', name: '辽宁', des: addata.LIA },
                             { cha: 'JIL', name: '吉林', des: addata.JIL },
                             { cha: 'HLJ', name: '黑龙江', des: addata.HLJ },
                             { cha: 'HEB', name: '河北', des: addata.HEB },
                             { cha: 'SHD', name: '山东', des: addata.SHD },
                             { cha: 'HEN', name: '河南', des: addata.HEN },
                             { cha: 'SHA', name: '陕西', des: addata.SHA },
                             { cha: 'SCH', name: '四川', des: addata.SCH },
                             { cha: 'CHQ', name: '重庆', des: addata.CHQ },
                             { cha: 'HUB', name: '湖北', des: addata.HUB },
                             { cha: 'ANH', name: '安徽', des: addata.ANH },
                             { cha: 'JSU', name: '江苏', des: addata.JSU },
                             { cha: 'SHH', name: '上海', des: addata.SHH },
                             { cha: 'ZHJ', name: '浙江', des: addata.ZHJ },
                             { cha: 'FUJ', name: '福建', des: addata.FUJ },
                             { cha: 'TAI', name: '台湾', des: addata.TAI },
                             { cha: 'JXI', name: '江西', des: addata.JXI },
                             { cha: 'HUN', name: '湖南', des: addata.HUN },
                             { cha: 'GUI', name: '贵州', des: addata.GUI },
                             { cha: 'GXI', name: '广西', des: addata.GXI },
                             { cha: 'MAC', name: '澳门', des: addata.MAC },
                             { cha: 'GUD', name: '广东', des: addata.GUD}];
    $('#container').vectorMap({ map: 'china_zh',
        color: "#B4B4B4", //地图颜色
        onLabelShow: function (event, label, code) {//动态显示内容
            $.each(dataStatus, function (i, items) {
                if (code == items.cha) {
                    // items.des = "被访问";
                    label.html(items.name + '<br/>' + items.des + "个访问量");
                }
            });
        }
    })
    var max = 1000;
    var temp = new Array();
    var tempdes;
    //找出最大值
    $.each(dataStatus, function (i, items) {
        max = Math.max(max, items.des);
        temp[i] = items;

    });
    //冒泡排序
    var num = 1;
    while (num <= temp.length) {
        var j = temp.length - 1;
        while (j >= num) {
            if (parseInt(temp[j].des) >= parseInt(temp[j - 1].des)) {
                tempdes = temp[j];
                temp[j] = temp[j - 1];
                temp[j - 1] = tempdes;
            }
            j--;
        }
        num++;
    }
    showtxt.innerHTML = "<p style='padding-left:1px;text-algin:left;'>此期间访问量排行：</p><br>";
    for (n = 0; n < 10; n++) {
        showtxt.innerHTML += "<p style='font-size:13px;color:red;padding-left:10px;text-algin:left;'>" + (n + 1) + "、" + temp[n].name + "(" + number_format(temp[n].des) + ")</p><br>";
    }



    $.each(dataStatus, function (i, items) {

//        if (items.des / max > 0 && items.des / max < 0.2) {
//            var josnStr = "{" + items.cha + ":'#FFCC00'}";
//            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
//        }
//        if (items.des / max >= 0.2 && items.des / max < 0.4) {
//            var josnStr = "{" + items.cha + ":'#FF9900'}";
//            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
//        }
//        if (items.des / max >= 0.4 && items.des / max < 0.6) {
//            var josnStr = "{" + items.cha + ":'#FF6600'}";
//            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
//        }
//        if (items.des / max >= 0.6 && items.des / max < 0.8) {
//            var josnStr = "{" + items.cha + ":'#FF3300'}";
//            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
//        }
//        if (items.des / max >= 0.8 && items.des / max <= 1) {
//            var josnStr = "{" + items.cha + ":'#FF0000'}";
//            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        //        }
        if (items.des / max == 0) {
            var josnStr = "{" + items.cha + ":'#0000FF'}";
            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        }
        if (items.des / max > 0 && items.des / max < 0.2) {
            // var josnStr = "{" + items.cha + ":'#FFCC00'}";
            var josnStr = "{" + items.cha + ":'#EE9A00'}";
            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        }
        if (items.des / max >= 0.2 && items.des / max < 0.4) {
            //var josnStr = "{" + items.cha + ":'#FF9900'}";
            var josnStr = "{" + items.cha + ":'#CDCD00'}";
            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        }
        if (items.des / max >= 0.4 && items.des / max < 0.6) {
            // var josnStr = "{" + items.cha + ":'#FF6600'}";
            var josnStr = "{" + items.cha + ":'#66CD00'}";
            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        }
        if (items.des / max >= 0.6 && items.des / max < 0.8) {
            //var josnStr = "{" + items.cha + ":'#FF3300'}";
            var josnStr = "{" + items.cha + ":'#7CFC00'}";
            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        }
        if (items.des / max >= 0.8 && items.des / max <= 1) {
            //var josnStr = "{" + items.cha + ":'#FF0000'}";
            var josnStr = "{" + items.cha + ":'#00CD00'}";
            $('#container').vectorMap('set', 'colors', eval('(' + josnStr + ')'));
        }

    });
    $('.jvectormap-zoomin').click(); //放大
}


function number_format(number, decimals, dec_point, thousands_sep) {
    number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals), sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
            var k = Math.pow(10, prec); return '' + Math.round(n * k) / k;
        };

    // Fix for IE parseFloat(0.55).toFixed(0) = 0;
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}