﻿function DrawHitChart() {
    $("#container_net").empty();
    chart_net = new Highcharts.Chart({
        chart: {
            renderTo: 'container_net',
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false
        },
        title: {
            text: '运营商访问统计分析'
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.point.name + '</b>: ' + this.y + ' %';
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    color: Highcharts.theme.textColor || '#000000',
                    connectorColor: Highcharts.theme.textColor || '#000000',
                    formatter: function () {
                        return '<b>' + this.point.name + '</b>: ' + this.y + ' %';
                    }
                },
                showInLegend: true
            }
        },
        series: [{
            type: 'pie',
            name: 'Steam share',
            data: []
        }]
    });

    $("#container_area").empty();
    chart_area = new Highcharts.Chart({
        chart: {
            renderTo: 'container_area',
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false
        },
        title: {
            text: '区域访问统计分析'
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.point.name + '</b>: ' + this.y + ' %';
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    color: Highcharts.theme.textColor || '#000000',
                    connectorColor: Highcharts.theme.textColor || '#000000',
                    formatter: function () {
                        return '<b>' + this.point.name + '</b>: ' + this.y + ' %';
                    }
                },
                showInLegend: true
            }
        },
        series: [{
            type: 'pie',
            name: 'Steam share',
            data: []
        }]
    });
}