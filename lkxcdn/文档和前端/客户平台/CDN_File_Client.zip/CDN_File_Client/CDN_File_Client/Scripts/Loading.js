﻿function showLoad() {
    $('#progressbar').window({
        modal: true,
        shadow: false,
        height: 31,
        title: ""
    });
}
function showHide() {
    $('#progressbar').window('close');
}