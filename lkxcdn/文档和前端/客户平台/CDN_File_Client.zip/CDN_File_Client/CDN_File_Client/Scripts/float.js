﻿//Enter "frombottom" or "fromtop"
var verticalpos = "frombottom"
if (!document.layers)
    document.write('</div>')
function JSFX_FloatTopDiv() {
    var startX = document.body.clientWidth - 205;
    startY = 685;
    var ns = (navigator.appName.indexOf("Netscape") != -1);
    var d = document;
    function ml(id) {
        var el = d.getElementById ? d.getElementById(id) : d.all ? d.all[id] : d.layers[id];
        if (d.layers) el.style = el;
        el.sP = function (x, y) { this.style.left = x; this.style.top = y; };
        el.x = startX;
        if (verticalpos == "fromtop")
            el.y = startY;
        else {
            el.y = ns ? pageYOffset + innerHeight : document.body.scrollTop + document.body.clientHeight;
            el.y -= startY;
        }
        return el;
        // setInterval('play()',10);
    }


    window.stayTopLeft = function () {
        if (verticalpos == "fromtop") {
            var pY = ns ? pageYOffset : document.body.scrollTop;
            ftlObj.y += (pY + 190 - ftlObj.y) / 8;
            ftlObj.x += (document.body.clientWidth - 203 + document.body.scrollLeft - ftlObj.x) / 8;

        }
        else {
            var pY = ns ? pageYOffset + innerHeight : document.body.scrollTop;
            var px = ns ? pageYOffset + innerWidth : document.body.scrollLeft;

            if (document.body.clientHeight < 600) {
                if (window.ActiveXObject)
                    ftlObj.y += (document.body.clientHeight - 350 + document.body.scrollTop - ftlObj.y) / 8;
                else if (window.XMLHttpRequest)
                    ftlObj.y += (document.body.clientHeight - 320 + document.body.scrollTop - ftlObj.y) / 8;
            }
            else {
                if (window.ActiveXObject)
                    ftlObj.y += (pY + 190 - ftlObj.y) / 8;
                else if (window.XMLHttpRequest)
                    ftlObj.y += (pY - 320 - ftlObj.y) / 8;
            }
            ftlObj.x += (document.body.clientWidth - 203 + document.body.scrollLeft - ftlObj.x) / 8;

        }
        ftlObj.sP(ftlObj.x, ftlObj.y);
        setTimeout("stayTopLeft()", 10);
    }
    ftlObj = ml("divStayTopLeft");
    stayTopLeft();
}
JSFX_FloatTopDiv();