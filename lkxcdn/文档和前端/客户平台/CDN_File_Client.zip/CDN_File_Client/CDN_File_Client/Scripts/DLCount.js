﻿function SelectFile() {
    var start_date = String($("#date_start").val());
    var end_date = String($("#date_end").val());
    if (start_date == null || start_date.length == 0 || end_date == null || end_date.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    $.ajax(
    {
        url: '/CdnFile/GetDLCount',
        data: "start=" + start_date + "&end=" + end_date,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            if (data == null || data.length == 0) {
                alert("查询结果为空！");
                return false;
            } else {
                if (data == "Error") {
                    alert("此期间木有相关数据");
                    return false;
                }

                $("#resultDT").empty();
                $("#resultDT").append("<tr style=\"width:100%\"><td style=\"width:20%\" >日 期</td><td style=\"width:40%\">文 件</td><td style=\"width:20%\">下载成功ip总数</td><td style=\"width:20%\">下载中断ip总数</td></tr>");
                //  var getResult = $("#getResult").val();
                var jsonData = eval("(" + data + ")");
                $.each(jsonData, function (i, key) {
                    $("#resultDT").append("<tr style=\"width:100%\"><td style=\"width:20%\" >" + jsonData[i].date + " </td><td style=\"width:40%;text-align:left\">  " + jsonData[i].file + "  </td><td style=\"width:20%\">  " + jsonData[i].suss + " </td><td style=\"width:20%\"> " + jsonData[i].fail + "</td></tr>");
                });
                $("#msg")[0].style.display = "block";
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}


function showLoad() {
    $('#progressbar').window({
        modal: true,
        shadow: false,
        title: ""
    });
}
function showHide() {
    $('#progressbar').window('close');
}