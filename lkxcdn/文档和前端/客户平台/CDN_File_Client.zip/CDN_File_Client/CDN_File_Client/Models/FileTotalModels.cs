﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CDN_File_Client.Models
{
    public class FileTotalModels
    {
        [Required(ErrorMessage = "请求总次数是必选项！")]
        [Display(Name = "请求总次数")]
        public Double totalNum { get; set; }

        [Required(ErrorMessage = "请求总流量是必选项！")]
        [Display(Name = "请求总流量")]
        public Double totalStream { get; set; }

        [Required(ErrorMessage = "请求总IP是必选项！")]
        [Display(Name = "请求总IP")]
        public Double totalIp { get; set; }
    }
}