﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CDN_File_Client.Models
{
    public class HotFileModels
    {
        [Display(Name = "文件编号")]
        public int id { get; set; }

        [Required(ErrorMessage = "文件名称是必选项！")]
        [Display(Name = "文件名称")]
        public string FileName { get; set; }

        [Required(ErrorMessage = "文件大小是必选项！")]
        [Display(Name = "文件大小")]
        public string FileSize { get; set; }

        [Required(ErrorMessage = "时间是必选项！")]
        [Display(Name = "时间")]
        public string LastModify { get; set; }

        [Required(ErrorMessage = "时间是必选项！")]
        [Display(Name = "时间")]
        public string LastCheck { get; set; }

        [Required(ErrorMessage = "文件状态是必选项！")]
        [Display(Name = "文件状态")]
        public string Status { get; set; }

        public string Progress { get; set; }

        public string Type { get; set; }

    }
}