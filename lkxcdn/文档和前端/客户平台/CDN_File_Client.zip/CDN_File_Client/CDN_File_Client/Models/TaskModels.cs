﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_File_Client.Models
{
    public class TaskModels
    {
        public int id { get; set; }

        public string filename { get; set; }

        public string filepath { get; set; }

        public string filesize { get; set; }

        public string md5 { get; set; }

        public string timestamp { get; set; }
    }
}