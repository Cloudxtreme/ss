﻿			$(function(){
				 check_login_user_acc( $("#_login_type").val(),'web', 3, 31 );
				 var user = get_login_user();
			   var settype = "_init";
			 	 
			 	 var date = new Date();
				 $("#startDate").val(date.format("yyyy-MM-dd")); 
				 $("#endDate").val(date.format("yyyy-MM-dd")); 
			 		
			   $.post("../function/web.bandwidth.fun.php",{"user":user,"get_type":settype},function(data){
			   			var arr = data.split("***");
			   		  var zone = eval("("+arr[1]+")");
			   		  var channel = eval("("+arr[0]+")");
			   		  var isp = eval("("+arr[2]+")");
			   		  
			   		  for( count = 0; count < zone.length; count++ ){
			   		  	$("#regionCode").append('<option value="'+zone[count]+'">'+zone[count]+'</option>');
			   		  }
			   		  
			   		  for( count = 0; count < channel.length; count++ ){
			   		  	$("#channel").append('<option value="'+channel[count]+'">'+channel[count]+'</option>');
			   		  }
			
			   		  for( count = 0; count < isp.length; count++ ){
			   		  	$("#selectedIsps").append('<option value="'+isp[count]+'">'+isp[count]+'</option>');
			   		  }
			   		  
			   		  $("select[id='channel']").multiselect(
			   		 		{ minWidth:187,
			   		 		  noneSelectedText:lang.multiselect.channel.noneSelectedText,
			   		 		  selectedText:lang.multiselect.channel.selectedText,
			   		 		  close:function(){changeTip();},
			   		 		  optionWidth:370}
			   		 	).multiselectfilter();
			
							$("select[id='regionCode']").multiselect(
			   		 		{ minWidth:127,
			   		 		  noneSelectedText:lang.multiselect.region.noneSelectedText,
			   		 		  selectedText:lang.multiselect.region.selectedText,
			   		 		  optionWidth:270}
			   		 	).multiselectfilter();
			   		 	   		 	
			   		 	$("select[id='selectedIsps']").multiselect(
			   		 		{ minWidth:140,
									noneSelectedText:lang.multiselect.isp.noneSelectedText,
									selectedText:lang.multiselect.isp.selectedText,
									optionWidth:270}
			   		 	).multiselectfilter();
			  // 		  $("#channel").multiSelect({   
				//	        selectAll: true,  
				//	        oneOrMoreSelected: '*',  
			//		        selectAllText: '全选',  
			//		        noneSelected: '请选择'
					        //minWidth:197,
			   		 			//noneSelectedText:lang.multiselect.channel.noneSelectedText,
			   		 			//selectedText:lang.multiselect.channel.selectedText 
			//		    }, function(){   //回调函数  
			//		        if($("[name='selectedChannels']:checked").length > 0)  
				//	        {  
			//		        	alert("check");
					            //$("#errRed").empty();  
			//		        }  
			//		        else  
				//	        {  
				//	        	alert("no checked");
					            //$("#errRed").text("请选择");  
					//        }  
			   	//	 });  
			   		 
			   })
			})
			
			function query(){
				 var        user = get_login_user();
			   var     settype = "_bandwidth";
				 var    time_str = "";
				 var    zone_str = "";
				 var channel_str = "";
				 var       start = $("#startDate").val();
				 var         end = $("#endDate").val();
					
				 var loading = new ol.loading({id:"chartdiv"});
				 loading.show();
					
				 time_str = "[\"" + start + "\",\"" + end +"\"]";
				 
				 zone = document.getElementById("regionCode");  
			   var zone_str = "[";  
			   for( i = 0; i < zone.length; i++ ){     
			        if( zone.options[i].selected ){  
			            zone_str += "\"" + zone.options[i].value + "\",";  
			        }  
			    }
			    zone_str = zone_str.substr(0,zone_str.length-1) + "]";   
				 
			   channel = document.getElementById("channel");  
			   var channel_str = "[";  
			   for( i = 0; i < channel.length; i++ ){     
			        if(channel.options[i].selected){  
			            channel_str += "\"" + channel.options[i].value + "\",";  
			        }  
			    }
			    channel_str = channel_str.substr(0,channel_str.length-1) + "]";
			    
			    isp = document.getElementById("selectedIsps");  
			    var isp_str = "[";  
			    for( i = 0; i < isp.length; i++ ){     
			         if(isp.options[i].selected){  
			             isp_str += "\"" + isp.options[i].value + "\",";  
			         }  
			     }
			    isp_str = isp_str.substr(0,isp_str.length-1) + "]";
			    
			    $.post("../function/web.bandwidth.fun.php",{"user":user,"get_type":settype,"time":time_str,"channel":channel_str,"zone":zone_str,"isp":isp_str},function(data){
			    		var chartData = [];
			    		var arr = data.split("***");
			    		arr_time = eval("("+arr[0]+")");
			    		arr_value = eval("("+arr[1]+")");
			    		arr_top = eval("("+arr[2]+")");
			    		
			    		add_row(arr_top);
			    		for( count=0;count<arr_time.length;count++ ){
									var mydate = parseDate(arr_time[count]);
						
			   					chartData.push({
				   						date : mydate,
				  						value: arr_value[count]
									});
			    		}
			    	
			     	  document.getElementById("max_value").innerHTML = arr[4] +  " Mbps";
			    		document.getElementById("max_time").innerHTML = arr[3];
			    		createStockChart(chartData);
			    		
			    		loading.hide();
			    })
			    
			}
			
			function add_row(_arr){
					$("#_top_table").empty();

					$("#_top_table").append('<tr><th width="30px" style=\"text-align:center;\" class=\"index\">序号</th><th width="230px" style=\"text-align:center;\">频道</th><th width="150px" style=\"text-align:center;\">峰值(Mbps)</th><th width="150px" style=\"text-align:center;\">峰值时间点</th><th width="100px" style=\"text-align:center;\">总流量&nbsp;&nbsp;</th></tr>');
					for( count = 1;count <= _arr.length;count++ ){
						$("#_top_table").append('<tr><td width="30px" style=\"text-align:center;\" class=\"index\">'+count+'</td><td width="230px" style=\"text-align:center;\">'+_arr[count-1][0]+'</td><td width="150px" style=\"text-align:center;\">'+_arr[count-1][1]+'</td><td width="150px" style=\"text-align:right;\">'+_arr[count-1][2]+'</td><td width="100px" style=\"text-align:center;\">'+_arr[count-1][3]+' MB</td></tr>');
					}
			}

			function createStockChart(chartData) {
				var chart = new AmCharts.AmStockChart();
				chart.pathToImages = "../amcharts/images/";
				
			  var categoryAxesSettings = new AmCharts.CategoryAxesSettings();
        //定义显示的最小时间段，前提是X轴是Date对象
        categoryAxesSettings.parseDates = true;
        categoryAxesSettings.minPeriod = "mm";
        chart.categoryAxesSettings = categoryAxesSettings;

				// DATASETS //////////////////////////////////////////
				var dataSet = new AmCharts.DataSet();
				dataSet.color = "#b0de09";
				dataSet.fieldMappings = [{
					fromField: "value",
					toField: "value"
				}];
				
				dataSet.dataProvider = chartData;
				dataSet.categoryField = "date";

				chart.dataSets = [dataSet];

				// PANELS ///////////////////////////////////////////                                                  
				var stockPanel = new AmCharts.StockPanel();
				stockPanel.showCategoryAxis = true;
				stockPanel.title = "Value";
				stockPanel.eraseAll = false;
				stockPanel.addLabel(0, 100, "", "center", 16);
				
				var graph = new AmCharts.StockGraph();
				graph.type = "smoothedLine";
				graph.title = "频道带宽";
				graph.valueField = "value";
				graph.lineAlpha = 1;
				graph.lineColor = "#d1cf2a";
				graph.fillAlphas = 0.3; 
				stockPanel.addStockGraph(graph); 

				var stockLegend = new AmCharts.StockLegend();
				stockLegend.valueTextRegular = " ";
				stockLegend.markerType = "none";
				stockPanel.stockLegend = stockLegend;
				stockPanel.drawingIconsEnabled = true;

				chart.panels = [stockPanel];

				// OTHER SETTINGS ////////////////////////////////////
				var scrollbarSettings = new AmCharts.ChartScrollbarSettings();
				scrollbarSettings.graph = graph;
				scrollbarSettings.updateOnReleaseOnly = true;
				chart.chartScrollbarSettings = scrollbarSettings;

				var cursorSettings = new AmCharts.ChartCursorSettings();
				cursorSettings.valueBalloonsEnabled = true;
				chart.chartCursorSettings = cursorSettings;

				// PERIOD SELECTOR ///////////////////////////////////
				var periodSelector = new AmCharts.PeriodSelector();
				periodSelector.position = "bottom";
				periodSelector.periods = [{
					period: "DD",
					count: 10,
					label: "10 days"
				}, {
					period: "MM",
					count: 1,
					label: "1 month"
				}, {
					period: "YYYY",
					count: 1,
					label: "1 year"
				}, {
					period: "YTD",
					label: "YTD"
				}, {
					period: "MAX",
					label: "MAX"
				}];
				chart.periodSelector = periodSelector;

				var panelsSettings = new AmCharts.PanelsSettings();
				chart.panelsSettings = panelsSettings;

				chart.write('chartdiv');
			}
			
      function parseDate(str_date) {
		               arr = str_date.split(' ');
					    date_str = arr[0];
					    time_str = arr[1];
					    date_arr = date_str.split('-');
					    time_arr = time_str.split(':');
			     date_result = new Date( date_arr[0], date_arr[1] - 1, date_arr[2], time_arr[0], time_arr[1], time_arr[2] );
	     
			     return date_result;
      }
      
    
      