﻿$(function(){
	 check_login_user_acc(  $("#_login_type").val(), 'file',  4, 48  );
	 
   var date  = new  Date();
	 $("#startDate").val(date.format("yyyy-MM-dd"));
	 $("#endDate").val(date.format("yyyy-MM-dd"));
})


function query() {
    var       user = get_login_user();
    var    settype = "_file";
    var start_date = $("#startDate").val();
    var   end_date = $("#endDate").val();
    var   filename = $("#filename").val();
     
    $.post("../function/base.file.fun.php",{"get_type":settype,"user": user,"startDate":start_date,"endDate":end_date,"filename":filename},function(data){
        arr_data = eval("("+data+")");
	      add_row(arr_data);
    })

    
}

function add_row(_arr){
		$("#file_table").empty();

		$("#file_table").append('<tr><th width="60px" style=\"text-align:center;\" class=\"index\">序号</th><th width="230px" style=\"text-align:center;\">文件名</th><th width="150px" style=\"text-align:center;\">文件大小(字节)</th><th width="150px" style=\"text-align:center;\">lastmodify</th><th width="100px" style=\"text-align:center;\">处理状态</th><th width="100px" style=\"text-align:center;\">进度</th><th width="100px" style=\"text-align:center;\">类型</th></tr>');
		for( count = 1;count <= _arr.length;count++ ){
		  $("#file_table").append('<tr><td width="60px" style=\"text-align:center;\" class=\"index\">'+count+'</td><td width="230px" style=\"text-align:left;\">'+_arr[count-1]['filename']+'</td>\
		       <td width="150px" style=\"text-align:center;\">'+_arr[count-1]['filesize']+'</td><td width="150px" style=\"text-align:center;\">'+_arr[count-1]['lastmodify']+'</td><td width="100px" style=\"text-align:center;\">'+_arr[count-1]['status']+'</td>\
		       <td width="100px" style=\"text-align:center;\">'+_arr[count-1]['percent']+'</td><td width="100px" style=\"text-align:center;\">'+_arr[count-1]['type']+'</td></tr>');
		}
}

