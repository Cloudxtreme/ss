﻿<div class="tree">
  	<div class="menu">导航菜单</div>
      <h1>我的配置</h1>
	      <div id="memu_class_0" style="display:none;">
		      <ul>
		      		<li><a id="memu_class_01" href="/cdn/base/msgconf.php">个人信息维护</a></li>
		      </ul>
	      </div>
      <h1>基础功能</h1>
	      <div id="memu_class_2" style="display:none;">
		      <ul>
			      	<li><a id="memu_class_21" href="/cdn/base/order.php">我的订单</a></li>
		      </ul>
		    </div>
      <h1>网页加速</h1>
	      <div id="memu_class_3" style="display:none;">
	         <ul>
		          <li><a id="memu_class_31" href="/cdn/web/bandwidth.php">带宽统计</a></li>
		          <li><a id="memu_class_32" href="/cdn/web/flow.php">流量统计</a></li>
		          <li><a id="memu_class_33" href="/cdn/web/hit.php">访问概况</a></li>
		          <li><a id="memu_class_34" href="/cdn/web/visitor.php">访客分析</a></li>
		          <li><a id="memu_class_35" href="/cdn/web/url.php">URL分析</a></li>
		          <li><a id="memu_class_36" href="/cdn/web/referrer.php">来源统计</a></li>
		          <li><a id="memu_class_37" href="/cdn/web/logdown.php">日志下载</a></li>
		          <li><a id="memu_class_38" href="/cdn/base/dns.php">DNS设置</a></li>
		          <li><a id="memu_class_39" href="/cdn/base/url.php">内容管理</a></li>
	         </ul>
	      </div>
      <h1>下载加速</h1>
	      <div id="memu_class_4" style="display:none;">
		      <ul>
				      <li><a id="memu_class_41" href="/cdn/file/bandwidth.php">带宽统计</a></li>
				      <li><a id="memu_class_42" href="/cdn/file/flow.php">流量统计</a></li>
				      <li><a id="memu_class_43" href="/cdn/file/hit.php">访问概况</a></li>
				      <li><a id="memu_class_44" href="/cdn/file/visitor.php">访客分析</a></li>
				      <li><a id="memu_class_45" href="/cdn/file/url.php">URL分析</a></li>
				      <li><a id="memu_class_46" href="/cdn/file/performance.php">性能分析</a></li>
				      <li><a id="memu_class_47" href="/cdn/file/logdown.php">日志下载</a></li>
				      <li><a id="memu_class_48" href="/cdn/base/file.php">文件列表</a></li>
				       <li><a id="memu_class_49" href="/cdn/base/domain.php">自定义域名</a></li>
		      </ul>
	      </div>
      <h1>CDN使用帮助</h1>
	      <div id="memu_class_5" style="display:none;">
		      <ul>
		      		<li><a id="memu_class_51" href="/cdn/help/help.html" target="_blank">使用手册</a></li>
		      		<li><a id="memu_class_52" href="/cdn/help/CDNManual.htm" target="_blank">基础知识</a></li>
		      </ul>
	     </div>   
</div>