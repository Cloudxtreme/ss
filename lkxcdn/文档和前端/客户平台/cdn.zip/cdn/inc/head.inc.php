﻿<div class="header">
        <div>
        	<div class="h_left"></div>
        	<div class="h_right"><a href="/cdn/inc/exit.inc.php">退出</a></div>
        </div>
    </div>
    
    <div class="nav">
    	<div>
        	<ul>
            	<li class="r_border"><a href="/cdn/help/help.html">帮 助</a></li>
                <li><a href="/cdn/base/msgconf.php">账号维护</a></li>
                <li><a href="/cdn/index.php" class="atvd">首 页</a></li>
                <li class="phonenum">全国客服： 400-066-2212</li>
            </ul>
            <div id="_session"><b><?php require('session.inc.php'); ?></b> 欢迎您!</div> 
        </div>
    </div>
