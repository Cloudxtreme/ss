﻿<div class="footer">
    	<div>
        	<p class="contact">联系方式： <a href="tencent://message/?uin=2523801584" title=""><img src="http://wpa.qq.com/pa?p=1:2523801584:4" border="0"/>睿江CDN</a>　|　Email： <a  href="mailto:cdn@efly.cc">cdn@efly.cc</a>　|　电话： 400-066-2212 </p>
        	<p>Copyright.Ruijiang Technology,Inc.All Rights Reserved<br />广东睿江科技有限公司版权所有</p>
        </div>
    </div>
