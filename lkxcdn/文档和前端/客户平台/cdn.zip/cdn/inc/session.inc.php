﻿<?php
		session_start();
		if( $_SESSION["login_user"] ){ echo $_SESSION["login_user"]; }
		if( session_is_registered("login_type") ){ echo '<input type="hidden" id="_login_type" value="'.$_SESSION["login_type"].'" />'; }
		else{
				session_destroy(); 
				echo "<script language='javascript'>alert('登陆超时,请重新登陆');</script>"; 
				echo "<script language='javascript'>window.location.href='/cdn/login.php';</script>"; 
		};
?>