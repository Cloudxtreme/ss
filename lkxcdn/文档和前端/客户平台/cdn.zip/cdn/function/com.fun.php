﻿<?php
//common
?>