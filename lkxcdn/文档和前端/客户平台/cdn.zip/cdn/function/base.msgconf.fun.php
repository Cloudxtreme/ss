﻿<?php

	require_once('../common/mysql.com.php');
	require_once('./log.fun.php');
	$usr  = '';
	$pwd  = '';
	$newpwd  = '';

	if( !isset($_POST['get_type']) ) { exit; }
	if( isset($_POST['user']) && strlen($_POST['user']) > 0 ) { $usr = $_POST['user']; }
	if( isset($_POST['pwd']) && strlen($_POST['pwd']) > 0 ) { $pwd = $_POST['pwd']; }
	if( isset($_POST['newpwd']) && strlen($_POST['newpwd']) > 0 ) { $newpwd = $_POST['newpwd']; }
	
	switch( $_POST['get_type'] ) {
		
		case "_init" :
			print_r( query_user( $usr ) );
			break;
			
		case "_msg_upd":
			print_r( msg_upd( $usr  ));
			break; 
			
		case "_msg_pwd_upd":
			echo msg_pwd_upd( $usr, $newpwd, $pwd );
			break;  
			
		case "_msg_check_pwd":
			print_r( msg_check_pwd( $usr, $pwd ) );
			break;     
			
		default :  
			exit; 
			break;
	}
	syslog_user_action($_POST['user'],$_SERVER['SCRIPT_NAME'],$_POST['get_type'],null,null);
	
	function query_user( $usr ){
		
			$mysql_class = new MySQL('ibss');
   		$mysql_class -> opendb("IBSS_TEST", "utf8");
   		$sql = "select * from `CDN_User` where  `User` = '$usr' ";
   
   		$result = $mysql_class -> query( $sql );
   		
   		if ( $result ) { 
	   			while( ( $row = mysql_fetch_array($result) ) ){
		   				$user = $row['User'];
							$name = $row['Name'];
							$email = $row['Email'];
							$phone = $row['Phone'];
							$tel = $row['Tel'];
							$desc = $row['Desc'];
	   			}
   		}
   		
   		mysql_free_result($result);
   		
   		$res[] = array( 'user' => $user, 'name' => $name, 'email' => $email, 'phone' => $phone, 'tel' => $tel, 'desc' => $desc );
			
			return json_encode( $res );
	}
	
	function msg_upd( $usr ){
		
			$mysql_class = new MySQL('ibss');
   		$mysql_class -> opendb("IBSS_TEST", "utf8");
   		
   		$name = '';
			$email = '';
			$phone = '';
			$tel = '';
			$desc = '';
   		
   		if( isset($_POST['name']) && strlen($_POST['name']) > 0 ) { $name = $_POST['name']; }
   		if( isset($_POST['email']) && strlen($_POST['email']) > 0 ) { $email = $_POST['email']; }
   		if( isset($_POST['phone']) && strlen($_POST['phone']) > 0 ) { $phone = $_POST['phone']; }
   		if( isset($_POST['tel']) && strlen($_POST['tel']) > 0 ) { $tel = $_POST['tel']; }
   		if( isset($_POST['desc']) && strlen($_POST['desc']) > 0 ) { $desc = $_POST['desc']; }
			
   		
   		$sql = "update `CDN_User` set `Name` = '$name', `Desc` = '$desc', `Email` = '$email',`Phone`='$phone',`Tel`='$tel' where `User` = '$usr' ";
   
   		$result = $mysql_class -> query( $sql );
   		if( $result ){ return "true"; }
   		else{ return "error"; }
	}
	
	function msg_check_pwd( $usr, $pwd ){
		
			$mysql_class = new MySQL('ibss');
   		$mysql_class -> opendb("IBSS_TEST", "utf8");
			
   		$sql = "select count(*) from `CDN_User` where `User` = '$usr' and `Pass` = '".md5($pwd)."' ";
   
   		$result = $mysql_class -> query( $sql );
   		$row = mysql_fetch_row($result);

	    if( $row[0] == 1 ){ return "true"; }
	   	else{ return "false"; }
	}
	
	function msg_pwd_upd( $usr, $new_pwd, $old_pwd ){
		
			$mysql_class = new MySQL('ibss');
   		$mysql_class -> opendb("IBSS_TEST", "utf8");
			
   		$sql = "update `CDN_User` set `Pass` = '".md5($new_pwd)."'  where `User` = '$usr' and `Pass` = '".md5($old_pwd)."' ";
   		$result = $mysql_class -> query( $sql );

	    if( $result ){ return "true"; }
	   	else{ return "false"; }
	}
	
?>