<?PHP
phpinfo();
?>
