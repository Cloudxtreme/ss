
<?php
openlog("myScriptLog", LOG_PID | LOG_PERROR, LOG_LOCAL3);

// some code

//if (authorized_client()) {
    // do something
//} else {
    // unauthorized client!
    // log the attempt
    $access = date("Y/m/d H:i:s");
    syslog(LOG_WARNING, "Unauthorized client: $access {$_SERVER['REMOTE_ADDR']} {$_SERVER['SCRIPT_NAME']}({$_SERVER['HTTP_USER_AGENT']})");


closelog();
?> 
