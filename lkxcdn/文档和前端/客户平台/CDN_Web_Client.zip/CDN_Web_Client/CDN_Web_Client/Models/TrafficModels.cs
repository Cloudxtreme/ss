﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CDN_Web_Client.Models
{
    public class TrafficModels
    {
        [Required(ErrorMessage = "kbit/s是必选项！")]
        [Display(Name = "kbit/s")]
        public Double in_value { get; set; }

        public Double out_value { get; set; }

        [Required(ErrorMessage = "时间是必选项！")]
        [Display(Name = "时间")]
        public string time { get; set; }

        public string bfb { get; set; }
    }
}