﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Web_Client.Models
{
    public class CatchMgrModels
    {
        public string url { get; set; }

        public string owner { get; set; }

        public string start_time { get; set; }

        public string finish_time { get; set; }

        public string status { get; set; }
    }
}