﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Web_Client.Models
{
    public class HostTotalModels
    {
        //public Double totalPv { get; set; }

        public Double totalNum { get; set; }

        public Double totalStream { get; set; }
    }
}