﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Web_Client.Models
{
    public class AddrModels
    {
        public string hostname { get; set; }

        public string desc { get; set; }
    }
}