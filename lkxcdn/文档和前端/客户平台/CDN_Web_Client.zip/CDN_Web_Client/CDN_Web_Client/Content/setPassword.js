PIM.PWD = {
	setHtml: '<div class="dialog-window">'
		+ '<p class="tips">温馨提示：设置通讯录密码，能让您的资料得到更充分的保护。马上行动吧! </p>'
		+ '<p class="field"><label for="input1">设置密码</label><input maxlength="16" id="input1" type="password" /></p>'
		+ '<p class="field"><label for="input2">确认密码</label><input maxlength="16" id="input2" type="password" /></p>'
		+ '<div>',
	
	resetHtml: '<div class="dialog-window">'
		+ '<p class="field"><label for="reset_input0">原&nbsp;&nbsp;密&nbsp;&nbsp;码</label><input id="reset_input0" type="password" /></p>'
		+ '<p class="field"><label for="reset_input1">重置密码</label><input maxlength="16" id="reset_input1" type="password" /></p>'
		+ '<p class="field"><label for="reset_input2">确认密码</label><input maxlength="16" id="reset_input2" type="password" /></p>'
		+ '<div>',
	
	removeHtml: '<div class="dialog-window">' 
			+ '<p class="field"><label for="remove_input">输入密码</label><input id="remove_input" type="password" /></p>'
			+ '<div>',
	
	set: function(){
		var dialog = $('#setTxlPwd');
		if(dialog.length){
			dialog.dialog('open');
			return;
		}
		var dialog = this.createDialog('setTxlPwd','设置通讯录密码',this.setHtml);
		var fieldset = $([]).add($('#input1')).add($('#input2'));
		dialog.dialog({
			modal: true,
			width: 400,
			buttons: [{
				'text': '确定',
				'class': 'btn-sure',
				'click': $.proxy(PIM.PWD,'setSure')
			},{
				'text': '取消',
				'class': 'btn-cancel',
				'click': function(){$(this).dialog('close');}
			}],
			close: function(){
				fieldset.val('');
			}
		});
	},
	
	setSure: function(){
		var input1 = $('#input1'),
			input2 = $('#input2'),
			input1Value = $.trim(input1.val()),
			input2Value = $.trim(input2.val());
		if(!input1Value){
			input1.alert("请输入密码！", {position: 'top'});
		}else if(!input2Value){
			input2.alert("请输入确认密码！", {position: 'top'});
		}else if(input1Value != input2Value){
			input2.alert("密码不一致，请重新输入！", {position: 'top'});
		}else{
			//设置通讯录密码
	        $.post(g_parepath + "/setting/setPimPwd.jsp", {
	        	pimpwdMd5: $.md5(input1Value),
	            myuinmd5:$.md5(myuinmd5)
	        }, function(data){
	        	if( !resolveResult(data.result,data.msg) ) return;
	        	
	        	PIM.PWD.setBack('1');
	        	$('#setTxlPwd').dialog('close');
	        },"json");
		}
	},
	
	reset: function(){
		var dialog = $('#resetTxlPwd');
		if(dialog.length){
			dialog.dialog('open');
			return;
		}
		var dialog = this.createDialog('resetTxlPwd','修改通讯录密码',this.resetHtml);
		var input0 = $('#reset_input0'),
			input1 = $('#reset_input1'),
			input2 = $('#reset_input2'),
			fieldset = $([]).add(input0).add(input1).add(input2);
		dialog.dialog({
			modal: true,
			width: 400,
			buttons: [{
				'text': '确定',
				'class': 'btn-sure',
				'click': $.proxy(PIM.PWD,'resetSure')
			},{
				'text': '取消',//取消
				'class': 'btn-cancel',
				'click': function(){$(this).dialog('close');}
			}],
			close: function(){
				fieldset.val('');
			}
		});
	},
	
	resetSure: function(){
		var input0 = $('#reset_input0'),
			input1 = $('#reset_input1'),
			input2 = $('#reset_input2'),
			input0Value = $.trim(input0.val()),
			input1Value = $.trim(input1.val()),
			input2Value = $.trim(input2.val());
		if(!input0Value){
			input0.alert("请输入原密码！", {position: 'top'});
			return;
		}else if(!input1Value){
			input1.alert("请输入重置密码！", {position: 'top'});
		}else if(!input2Value){
			input2.alert("请输入确认密码！", {position: 'top'});
		}else if(input1Value != input2Value){
			input2.alert("密码不一致，请重新输入！", {position: 'top'});
		}else{
			//y
			$.post(g_parepath + "/setting/verifyPwd.jsp", {
	        	pimpwdMd5: $.md5(input0Value),
	            myuinmd5:$.md5(myuinmd5)
	        }, function(data){
	        	if(data.result == '0'){
	        		//设置通讯录密码
		            $.post(g_parepath + "/setting/resetPimPwd.jsp", {
		            	pimpwdMd5: $.md5(input1Value),
	                	passwordOldmd5:$.md5(input0Value),
		                myuinmd5:$.md5(myuinmd5)
		            }, function(data){
		            	if( !resolveResult(data.result,data.msg) ) return;
		            	
		            	PIM.PWD.setBack('2');
		            	$('#resetTxlPwd').dialog('close');
		            },'json');
	        	}else{
	        		input0.alert("原密码输入错误，请重新输入！", {position: 'top'});
	        	}
	        },'json');
		}
	},
	
	remove: function(){
		var dialog = $('#removeTxlPwd');
		if(dialog.length){
			dialog.dialog('open');
			return;
		}
		var dialog = this.createDialog('removeTxlPwd','清除通讯录密码',this.removeHtml);
		dialog.dialog({
			modal: true,
			width: 400,
			buttons: [{
	          'text': '确定',
	          'class': 'btn-sure',
	          'click': $.proxy(PIM.PWD,'removeSure')
			},{
				'text': '取消',//取消
	          'class': 'btn-cancel',
	          'click': function(){ $(this).dialog('close');}
			}],
			close: function(){
				$('#remove_input').val('');
			}
		});
	},
	
	removeSure: function(){
  	  	var input1 = $('#remove_input'),
			input1Value = $.trim(input1.val());
		if(!input1Value){
			input1.alert("请输入密码！", {position: 'top'});
		}else{
			//清除通讯录密码
		    $.post(g_parepath + "/setting/clearPwd.jsp", {
		    	passwordOldmd5: $.md5(input1Value),
		        myuinmd5:$.md5(myuinmd5)
		    }, function(data){
		    	if( data.result == '0' ){
		    		PIM.PWD.setBack('3');
		        	$('#removeTxlPwd').dialog('close');
		    	}else{
		    		input1.alert("密码错误，请重新输入！", {position: 'top'});
		    	}
		    	
		    },"json");
		}
	},
	
	setBack: function(type){
		var title = '', tips = '',
		html = '<a href="javascript:void(0)" name="pwd_reset">[修改]</a> | <a href="javascript:void(0)" name="pwd_remove">[取消]</a>';
		switch(type){
		case '1':
			title = '设置通讯录密码';
			tips = '<div class="dialog-window"><p class="tips">您的通讯录密码设置成功，请牢记。</p></div>';
			break;
		case '2':
			title = '修改通讯录密码';
			tips = '<div class="dialog-window"><p class="tips">您的通讯录密码修改成功，请牢记。</p></div>';
			break;
		case '3':
			title = '清除通讯录密码';
			tips = '<div class="dialog-window"><p class="tips">已成功取消通讯录密码。以后进QQ面板的应用盒子，网络通讯录将直接显示。</p></div>';
			html = '<a href="javascript:void(0)" name="pwd_set">[设置]</a>';
			break;
		}
		$('.edit-txl-pwd .op').html(html);
		PIM.Dialog.success(title,tips);

	},
	
	createDialog: function(id,title,html){
		var dialog = $('<div>').attr('id',id);
		dialog.appendTo('body');
		dialog.attr('title',title).html(html);
		return dialog;
	}
};

$(function(){
	$('.edit-txl-pwd').delegate('a','click',function(e){
		var t = $(e.target),
			name = t.attr('name');
		switch(name){
		case 'pwd_set':
			isLogin($.proxy(PIM.PWD,'set'));
			break;
		case 'pwd_reset':
			isLogin($.proxy(PIM.PWD,'reset'));
			break;
		case 'pwd_remove':
			isLogin($.proxy(PIM.PWD,'remove'));
			break;
		}
	});

	$('.field input').live('focus',function(){
		$(this).closest('.field').addClass('field-focus');
	}).live('focusout',function(){
		$(this).closest('.field').removeClass('field-focus');
	}).live('keyup',function(e){
		var t = $(this),
			id = t.attr('id');
		if(e.keyCode == 13){
			switch(id){
			case 'input1':
			case 'input2':
				PIM.PWD.setSure();
				break;
			case 'reset_input0':
			case 'reset_input1':
			case 'reset_input2':
				PIM.PWD.resetSure();
				break;
			case 'remove_input':
				PIM.PWD.removeSure();
				break;
			}	
		}
	});
});
