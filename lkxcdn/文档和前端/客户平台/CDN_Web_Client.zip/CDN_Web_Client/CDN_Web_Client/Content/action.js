/**************************** hashChange ***********************************/

function setHash(a) {
    $.browser.msie ? $.locationHash(a) : location.hash = a;
}

function doHash() {
    var hash = location.hash.split('/');

    switch (hash[0]) {
        case '#list': //列表
            var o = {
                groupId: hash[1],
                pageNo: hash[2],
                pageSize: hash[3],
                order: hash[4],
                sortBy: hash[5],
                key: hash[6]
            };
            PIM.Group.setRowClass(hash[1]);
            PIM.ContactsList.getContactData(o);
            setDomHeight({ selector: '#contactsListBox' });
            break;
        case "#contactEdit": //联系人编辑
            //$('#contactRepeat').html('');
            var pc = PIM.ContactsList;
            pc.setEditContactId(hash[1]);
            isLogin($.proxy(pc.getDetail, pc));
            //setDomHeight({selector:'#contactEdit'});
            break;
        case '#contactAdd': //联系人新增
            var pc = PIM.ContactsList;
            pc.setEditContactId('');
            isLogin($.proxy(pc.getDetail, pc));
            //setDomHeight({selector:'#contactEdit'});
            break;
        case '#import': //导入联系人
            showModule('#contactImport');
            $('#contactImport').load(g_rootpath + '/pim/contact/import_contact/import_html.jsp?dd=13');
            setDomHeight({ selector: '#contactImport' });
            break;
        case '#repeat': //合并重复
            //$('#contactEdit').html('');
            //isLogin($.proxy(PIM.Repeat,'open'));
            showModule('#contactRepeat');
            break;
        case '#recyle': //联系人回收站
            PIM.RecycleList.getContactData({ pageNo: hash[1] });
            showModule('#recycleList');
            setDomHeight({ selector: '#recycleListBox' });
            break;
        case '#time': //时光机
            PIM.Actions.openTimeBox();
            showModule('#contactTime');
            setDomHeight({ selector: '#contactTime' });
            break;
    }

}
//设置联系人hash
function setContactHash(options) {
    var oldHash = PIM.ContactsList.params;

    $.extend(oldHash, options);
    setHash('list/' + oldHash.groupId + '/' + oldHash.pageNo + '/' + oldHash.pageSize + '/' + oldHash.order + '/' + oldHash.sortBy + '/' + oldHash.key + '/' + new Date().getTime());
}
//设置回收站hash
function setRecyleHash(options) {
    setHash('#recyle/' + options.pageNo + '/' + new Date().getTime());
}
/**************************** hashChange end ***********************************/

/*****************************PIM静态方法***********************************/
PIM.Actions = {

    //打开域名列表
    openList: function () {
        $('#contactImport').show();
        $('#domainList').hide();
        //alert("域名列表");
    },

    //带宽统计
    trafficRpt: function () {
        $('#contactImport').hide();
        $('#domainList').hide();
        $('#recycleList').show();
        //alert("带宽统计");
    },

    //峰值统计
    topTraffic: function () {
        alert("峰值统计");
    },

    //命中率统计
    hitRpt: function () {
        alert("带宽统计");
    },

    //访问分析
    visitRpt: function (t) {
        alert("访问分析");
    },

    /*
    * 缓存管理
    * */
    cacheMgr: function (data, t) {
        alert("缓存管理");
    },

    //添加联系人
    addContact: function () {
    },
    //删除联系人
    delContact: function (selContacts) {
    },

    //返回
    btnReturn: function () {
    },

    //联系人按姓名排序
    sortByName: function (e) {
    },

    //设置回收站能放置拖动删除
    recycleBindDrop: function () {
    },

    //打开回收站
    openRec: function () {
    },

    //回收站 - 还原
    contactsRevert: function () {
    },

    //回收站 - 永久清除
    contactsDelForever: function () {
    },

    //回收站 - 清空
    spaceRecycle: function () {
    },

    //分组管理
    groupManage: function (t) {
    },

    /*
    * 分组管理生成html 并显示
    * */
    showGroupTipsBox: function (data, t) {
    },

    groupTipsBoxClick: function (e) {
    },

    contactToGroup: function (url, data) {
    },

    //分组管理层的操作：添加到分组和从分组去除
    groupOperation: function (groupId, groupName, type) {
    },

    //时光机
    openTimeBox: function () {
    },

    bindTimeData: function (data) {
    },

    replaceWithVer: function () {
    }
};

/*
* 页面初始化调用
* */
$(function () {

    //ajax状态显示
    $("#loading").ajaxStart(function () {
        var t = $(this),
			w = $(window);
        t.css('top', 0).css('left', (w.width() - t.width()) / 2).show();
    }).ajaxStop(function () {
        $(this).hide();
    });

    var _window = $(window);
    var _doms = [
         	{ selector: '#side' },
         	{ selector: '#groupBox', callback: function () { controlBarShow($('#groupBox'), $('#groupControlBar')) } },
         	{ selector: '#contactsListBox' },
         	{ selector: '#contactEdit' },
         	{ selector: '#contactImport' },
         	{ selector: '#contactRepeat' },
         	{ selector: '#contactTime' },
         	{ selector: '#recycleListBox' }
		];
    windowResize(_doms);
    //	if($.browser.version == '6.0'){
    _window.resize(function () {
        windowResize(_doms);
    });
    //	}
    //hashchange
    _window.hashchange(doHash);

    var _pim = PIM,
		_pathContact = g_path;

    //实例化分组
    _pim.Group = new Group({
        group: $('#groupObj'),
        urlGroupData:  '/group/all_group_json',
        urlGroupEdit: '/group/modify_group_json',
        urlGroupDel: '/group/delete_group_json',
        urlGroupAdd: '/group/add_group_json',
        selClass: 'current',
        hoverClass: 'hover'
    });

    //实例化联系人
    _pim.ContactsList = new ContactsList({
        contactBox: $('#contactsBody'),
        viewArea: $('#contactsList'),
        list: 'tr',
        chkClass: 'selected',
        urlContact: _pathContact + '/card/search_by_key_json.jsp',
        draggable: true,
        page: function () {
            if (!PIM.Page) {
                PIM.Page = new Page({
                    page: '.page-contact',
                    callback: setContactHash
                });
            }
            return PIM.Page;
        }
    });

    //绑定log提交
    $('.logClass').live("click", logSubmit);

    //搜索框的事件
    $('#searchInput').live('keyup', function (e) {
        if (e.keyCode == 13) {
            PIM.Actions.searchContact();
        }
    })
	.live('focusin', function () {
	    var t = $(this);
	    if (t.val() == '输入姓名、号码或邮件') {
	        t.addClass('focus').val('');
	    }
	})
	.live('focusout', function () {
	    var t = $(this);
	    if ($.trim(t.val()) == '') {
	        t.removeClass('focus').val('输入姓名、号码或邮件');
	    }
	});

    //表单类的点击操作事件代理
    $('body').delegate(':input[name],a[name]', 'click', function (e) {
        var t = $(this),
			name = t.attr('name');
        switch (name) {
            //新增按钮  
            case 'btn_AddContact':
                setHash('#contactAdd');
                //PIM.Actions.isLogin(PIM.Actions.addContact);
                break;
            //删除按钮  
            case 'btn_DellContact':
                PIM.Actions.delContact();
                break;
            //编辑 - 删除单个联系人  
            case 'btn_del':
                PIM.Actions.delContact([PIM.ContactEdit.getContactId()]);
                break;
            //返回  
            case 'btn_return':
                PIM.Actions.btnReturn();
                break;
            //添加 - 新增  
            case 'btn_save':
                PIM.ContactEdit.save(0);
                break;
            //编辑保存  
            case 'btn_edit_save':
                PIM.ContactEdit.save(1);
                break;

            //联系人全选  
            case 'chkall':
            case 'chkallRec':
                var bool = t.is(':checked')
                $(':checkbox[name=' + name + ']').attr('checked', bool);
                name == 'chkall' ?
					PIM.ContactList.setAll(bool) :
						PIM.recyContactList.setAll(bool);
                break;
            //分组管理   
            case 'btn_ManagerContGroup':
                PIM.Actions.groupManage(t);
                break;
            //搜索  
            case 'btn_Search':
                PIM.Actions.searchContact($('#searchInput').val());
                break;
            //回收站 - 还原  
            case 'contactsRevert':
                PIM.Actions.contactsRevert();
                break;
            //回收站 - 永久清除  
            case 'contactsDelForever':
                PIM.Actions.contactsDelForever();
                break;
            //回收站 - 清空  
            case 'spaceRecycle':
                PIM.Actions.spaceRecycle();
                break;
        }
    });


    //绑定加载联系人按名字排序
    $('#sortByName').tips({ relation: '#contactSortDiv', position: 'b', offset: true, tgClass: 'current', margin: { l: 0, t: 5 }, eventType: 'mouseenter' });
    $('#contactSortDiv').delegate('a', 'click', PIM.Actions.sortByName);


    //绑定分组下拉
    $('.btn-group-manage').tips({ relation: '#groupTipsBox', position: 'b', offset: true, tgClass: 'current', margin: { l: 0, t: 0} });

    $('#groupTipsBox').delegate('p', 'click', PIM.Actions.groupTipsBoxClick)
	.delegate('p', 'mouseover', function () {
	    $(this).closest('#groupTipsBox').find('p').removeClass('hover');
	    $(this).addClass('hover');
	});

    //绑定可直接拖动到垃圾回收站
    PIM.Actions.recycleBindDrop();

    //左侧四个功能操作事件代理（合并重复、导入导出和回收站）
    $('.side-nav-list').delegate('li.f', 'click', function () {
        var t = $(this),
			name = t.attr('name');
        switch (name) {
            case 'domain_list':
                PIM.Actions.openList();
                break;
            case 'traffic_rpt':
                PIM.Actions.trafficRpt();
                break;
            case 'top_traffic':
                PIM.Actions.topTraffic();
                break;
            case 'hit_rpt':
                PIM.Actions.hitRpt();
                break;
            case 'visit_rpt':
                PIM.Actions.visitRpt();
                break;
            case 'cache_mgr':
                PIM.Actions.cacheMgr();
                break;
        }
        PIM.Group.setRowUnSel();
        t.addClass('current').siblings().removeClass('current');
    });

    $('.text').live('focus', function () {
        $(this).addClass('text-focus');
    }).live('blur', function () {
        $(this).removeClass('text-focus');
    });

    //combobox
    Combobox.init({
        config: {
            'tel': {
                'options': [
		             { value: 'TEL', text: '电话号码' }, { value: 'TEL_HOME', text: '家庭电话' },
		             { value: 'TEL_WORK', text: '办公电话' },
		             { value: 'TEL_CELL', text: '常用手机' }, { value: 'TEL_CELL_HOME', text: '常用家庭手机' },
		             { value: 'TEL_CELL_WORK', text: '常用办公手机' }, { value: '自定义', text: '自定义' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'fax': {
                'options': [
		             { value: 'TEL_FAX', text: '传真' },
		             { value: 'TEL_FAX_HOME', text: '家庭传真' }, { value: 'TEL_FAX_WORK', text: '办公传真' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'email': {
                'options': [
		            { value: 'EMAIL', text: '电子邮箱' },
		            { value: 'EMAIL_HOME', text: '家庭邮箱' }, { value: 'EMAIL_WORK', text: '办公邮箱' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'url': {
                'options': [
		            { value: 'URL', text: '网址' },
		            { value: 'URL_HOME', text: '家庭网址' }, { value: 'URL_WORK', text: '办公网址' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'adr': {
                'options': [
		            { value: 'ADR', text: '地址' },
		            { value: 'ADR_HOME', text: '家庭地址' }, { value: 'ADR_WORK', text: '办公地址' }
	            ],
                'handle': PIM.Drop.setVcard
            }
        }
    });

    //绑定左侧通讯录密码修改
    $('#editTxlPwd').live('click', editPwd);

    //group control
    $('#groupControlBar').delegate('a', 'click', { data: '#groupBox' }, controlBarFn);

    $('#timeBox').delegate('button', 'click', PIM.Actions.replaceWithVer);
});

//下拉框的方法集合
PIM.Drop = {
    setVcard: function (value) {
        var cbb = Combobox.currentCbb,
			inputReadonly = Combobox.currentCbbText,
			count = 0;

        //先判断是不是自定义
        if (value == '自定义') {
            inputReadonly.attr('readonly', false).val('').focus();
            return;
        } else {
            inputReadonly.attr('readonly', true);
        }
        var count = PIM.ContactEdit.getTypeCount(value);
        var cbbn = cbb.parent().next().children(':text');
        var cbbnContent = cbbn.val();

        cbbn.attr('name', value + '_' + count); //更改保存值的文本框的name
    }
}
