PIM.Repeat = {
	open: function(){
		$.ajax({
			url: g_path + '/merge/check.jsp',
			type: 'POST',
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json'},
			success: function(data){
				if( !resolveResult(data.result,data.msg) ) return;
				if(data.info.needMerge){
					PIM.Repeat.getFirstStep();
				}else{
					PIM.Dialog.alert('合并提示','太好了，没有找到重复联系人！');
				}
			}
		});
		
	},
	getFirstStep: function(){
		$.ajax({
			url: g_path + '/merge/merge_first_json.jsp',
			type: 'POST',
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json'},
			success: function(data){
				if( !resolveResult(data.result,data.msg) ) return;
				var resultList = data.info.resultList;
				if(resultList.length){
					$('#contactRepeat').load(g_parepath + '/repeat/step1.html',function(){
						PIM.Repeat.createRepeatList(resultList);
						setDomHeight({selector:'#contactRepeat'});
					});
				}else{
					PIM.Repeat.getSecondStep();
				}
				
			}
		});
	},
	createRepeatList: function(data){
		var html = '<ul class="repeat-list">';
		$.each(data,function(i,n){
			var v = n.vcard,
				userName = PIM.Repeat.getUserName(v.N),
				imgUrl = PIM.Repeat.getUserAvatar(v['X-MPS-PHOTO']);
			html += '<li userid="'+ n.dataid +'">'
					+ '<a href="" class="user-avatar"><img src="'+ imgUrl +'" alt="" /><i></i></a>'
					+ '<span class="name">'+ userName +'</span>'
				+ '</li>';
		});
		$('#repeatListBox').html(html);
		showModule('#contactRepeat');
	},
	
	getUserName: function(n){
		return n ?  $.trim( n[0].VALUE.replace(/\\;/g,'[:]').replace(/;/g,'').replace(/\[:\]/g,';') ) : '未命名';
	},
	
	getUserAvatar: function(photo){
		return photo ? g_parepath + '/contact/avatar.jsp?X_Content_Type=json&photoid='+ photo[0].VALUE : '../images/card_face_default.png';
	},
	
	repeatGroups: null,
	
	currentRepeatIdx: 0,
	
	currentRepeatDataIds: [],
	
	getSecondStep: function(){
		$.ajax({
			url: g_path + '/merge/show_second_json.jsp',
			type: 'POST',
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json'},
			success: function(data){
				if( !resolveResult(data.result,data.msg) ) return;
				var groups = data.info.repeatGroups;
				if(groups.length){
					PIM.repeatGroups = groups;
					$('#contactRepeat').load(g_parepath + '/repeat/step2.html',function(){
						PIM.Repeat.createRepeatGroups(0);
						setDomHeight({selector:'#contactRepeat'});
						$('#repeatGroupControlBar').undelegate().delegate('a','click',{data: '.repeat-groups-box'},controlBarFn);
					});
				}else{
					PIM.repeatGroups = null;
					$('#contactRepeat').load(g_parepath + '/repeat/step3.html');
				}
			}
		});
	},
	createRepeatGroups: function(idx){
		var allGroups = PIM.repeatGroups;
		if(!allGroups && !allGroups.length) return;
		
		PIM.Repeat.currentRepeatIdx = idx;
		var gl = allGroups.length;
		if(idx >= gl){
			PIM.Repeat.getThirdStep();
			return;
		}
		var groups = allGroups[idx],
			html = '';
		
		$('#repeatGroupsNote').html('您已合并 <b>'+ idx +'</b> 组重复联系人，还有 <b>'+ (gl - idx) +'</b> 组推荐您合并。');
		$('#repeatPrecent').width(idx*100 / gl + '%');
		PIM.Repeat.currentRepeatDataIds.length = 0;
		
		$.each(groups,function(i,n){
			var v = n.vcard,
				userName = PIM.Repeat.getUserName(v.N),
				imgUrl = PIM.Repeat.getUserAvatar(v['X-MPS-PHOTO']);
			html += '<li userid="'+ n.dataid +'">'
					+ '<div class="chk-box"><i class="icon-chked"></i></div>'
					+ '<div class="item-info">'
						+ '<span class="img"><img class="drag-user-avatar" src="'+ imgUrl +'" alt="'+ userName +'" /><i></i></span>'
						+ '<span class="name">'+ userName +'</span>'
					+ '</div>'	
				+ '</li>';
			PIM.Repeat.currentRepeatDataIds[i] = n.dataid;
		});
		PIM.Repeat.getRepeatPage();
		$('#repeatGroupsBox').html(html);
		
		showModule('#contactRepeat');
		setTimeout($.proxy(PIM.Repeat,'bindDrag'),100);
	},
	
	getRepeatPage: function(){
		var ids = PIM.Repeat.currentRepeatDataIds;
		isLogin(function(){
			$.ajax({
				url: g_path + '/merge/edit_card.jsp',
				type: 'POST',
				data: {myuinmd5: $.md5(myuinmd5), ids: ids.join()},
				success: function(html){
					var rp = $('#repeatPage'),
						rgb = $('.repeat-groups-box');
					rp.html(html);
					rgb.height(rp.height());
					controlBarShow(rgb,$('#repeatGroupControlBar'));
					setTimeout($.proxy(PIM.Repeat,'bindDrop'),100);
				}
			});
		});
	},
	
	mergeToNext: function(){
		var idx = PIM.Repeat.currentRepeatIdx + 1;
		$.ajax({
			url: g_path + '/merge/mergerItems.jsp',
			type: 'POST',
			dataType: 'json',
			data: {myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json'},
			success: function(data){
				if( !resolveResult(data.result,data.msg) ) return;
				
				PIM.Repeat.createRepeatGroups(idx);
			}
		});
	},
	
	getThirdStep: function(){
		$('#contactRepeat').load(g_parepath + '/repeat/step3.html');
	},
	
	bindDrag: function(){
		$('.drag-user-avatar','#repeatGroupsBox').draggable({
			revert: 'invalid',
			revertDuration: 200,
			cursorAt: { top: 5, left: 5 },
			addClasses: false,
			appendTo: '#contactRepeat',
			containment: 'parent',
			distance: 5,
			zIndex: 110,
			helper: function(e){
				var t = $(this);
				return '<img width="'+ t.width() +'" height="'+ t.height() +'" src="'+ t.attr('src') +'" />';
			}
		});
	},
	
	bindDrop: function(){
		$('.face','#field').droppable({
			accept: ".drag-user-avatar",
			addClasses: false,
			hoverClass: "drop-hover",
			tolerance: 'pointer',
			drop: function(event,ui){
				var src = ui.draggable.attr('src'),
					photoid = src.split('photoid=');
				if(photoid.length && photoid[1]){
					$('#photoid').val(photoid[1]);
				}else{
					$('#photoid').val('');
				}
				$('#faceImg').attr('src',src);
			}
		});
	}
};

$(function(){
	$('#step1ToNext').live('click',function(){
		PIM.Repeat.getSecondStep();
		return false;
	});
	
	$('#step2ToNext').live('click',function(){
		PIM.Repeat.mergeToNext();
		return false;
	});
	
	$('#step2Cancel').live('click',function(){
		PIM.Repeat.createRepeatGroups(PIM.Repeat.currentRepeatIdx + 1);
		return false;
	});
	
	$('.icon-chk').live('click',function(){
		var t = $(this),
			userId = t.closest('li').attr('userId');
		t.attr('class','icon-chked');
		PIM.Repeat.currentRepeatDataIds.push(userId);
		PIM.Repeat.getRepeatPage();
	});
	
	$('.icon-chked').live('click',function(){
		var t = $(this),
			userId = t.closest('li').attr('userId');
		t.attr('class','icon-chk');
		var ids = PIM.Repeat.currentRepeatDataIds;
		PIM.Repeat.currentRepeatDataIds = null;
		PIM.Repeat.currentRepeatDataIds = $.grep( ids, function(n,i){
			return n == userId;
		},true);
		PIM.Repeat.getRepeatPage();
	});
});