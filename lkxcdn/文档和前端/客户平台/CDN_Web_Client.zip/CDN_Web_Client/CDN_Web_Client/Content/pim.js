/**************************** hashChange ***********************************/

function setHash(a) {
    $.browser.msie ? $.locationHash(a) : location.hash = a;
}

function doHash() {
    var hash = location.hash.split('/');

    switch (hash[0]) {
        case '#list': //列表
            var o = {
                groupId: hash[1],
                pageNo: hash[2],
                pageSize: hash[3],
                order: hash[4],
                sortBy: hash[5],
                key: hash[6]
            };
            PIM.Group.setRowClass(hash[1]);
            PIM.ContactsList.getContactData(o);
            setDomHeight({ selector: '#contactsListBox' });
            break;
        case "#contactEdit": //联系人编辑
            //$('#contactRepeat').html('');
            var pc = PIM.ContactsList;
            pc.setEditContactId(hash[1]);
            isLogin($.proxy(pc.getDetail, pc));
            //setDomHeight({selector:'#contactEdit'});
            break;
        case '#contactAdd': //联系人新增
            var pc = PIM.ContactsList;
            pc.setEditContactId('');
            isLogin($.proxy(pc.getDetail, pc));
            //setDomHeight({selector:'#contactEdit'});
            break;
        case '#import': //导入联系人
            showModule('#contactImport');
            $('#contactImport').load(g_rootpath + '/pim/contact/import_contact/import_html.jsp?dd=13');
            setDomHeight({ selector: '#contactImport' });
            break;
        case '#repeat': //合并重复
            //$('#contactEdit').html('');
            //isLogin($.proxy(PIM.Repeat,'open'));
            showModule('#contactRepeat');
            break;
        case '#recyle': //联系人回收站
            PIM.RecycleList.getContactData({ pageNo: hash[1] });
            showModule('#recycleList');
            setDomHeight({ selector: '#recycleListBox' });
            break;
        case '#time': //时光机
            PIM.Actions.openTimeBox();
            showModule('#contactTime');
            setDomHeight({ selector: '#contactTime' });
            break;
    }

}
//设置联系人hash
function setContactHash(options) {
    var oldHash = PIM.ContactsList.params;

    $.extend(oldHash, options);
    setHash('list/' + oldHash.groupId + '/' + oldHash.pageNo + '/' + oldHash.pageSize + '/' + oldHash.order + '/' + oldHash.sortBy + '/' + oldHash.key + '/' + new Date().getTime());
}
//设置回收站hash
function setRecyleHash(options) {
    setHash('#recyle/' + options.pageNo + '/' + new Date().getTime());
}
/**************************** hashChange end ***********************************/

/*****************************PIM静态方法***********************************/
PIM.Actions = {

    //搜索联系人
    searchContact: function () {
        var iText = $('#searchInput'),
			key = $.trim(iText.val());
        if (key == '' || key == '输入姓名、号码或邮件') {
            return iText.alert('请输入要搜索的关键字', { position: 'top' });
        }
        setContactHash({ key: key, pageNo: 1 });
    },

    //添加联系人
    addContact: function () {
        $.ajax({
            url: g_path + '/card/add_card_ajax.jsp',
            type: 'POST',
            data: { myuinmd5: $.md5(myuinmd5) },
            success: function (html) {

                //清空1,2
                $("#contactDetailArea1 .list-warpper, #contactDetailArea2 .list-warpper").html('');

                $("#contactDetailArea0 .list-warpper").html(html);

                PIM.ContactEdit.getGroupInfo();
                showModule($('#contactDetailArea0'));
            }
        });
    },
    //删除联系人
    delContact: function (selContacts) {
        if (!selContacts) {
            selContacts = PIM.ContactsList.getSelContacts();
        }
        if (selContacts.length) {
            var title = '删除联系人',
				msg = '确认要删除选中的<b>' + selContacts.length + '</b>个联系人？<br \><br \>删除的联系人将会移至回收站。';
            PIM.Dialog.confirm(title, msg, function () {
                $.ajax({
                    url: g_path + '/card/delete_card_json.jsp',
                    type: 'POST',
                    dataType: 'json',
                    data: { myuinmd5: $.md5(myuinmd5), ids: selContacts.join(), X_Content_Type: 'json' },
                    success: function (data) {
                        if (!resolveResult(data.result, data.msg)) return;
                        var g = PIM.Group;
                        g.updateGroup(true);
                        ajaxTips(data.msg);
                    }
                });
            })

        } else {
            ajaxTips('请选择要删除的联系人');
        }
    },

    //返回
    btnReturn: function () {
        setContactHash({});
        showModule('#contactsList');
    },

    //联系人按姓名排序
    sortByName: function (e) {
        var t = $(e.target),
			name = t.attr('name'),
			type = t.attr('type'),
			iClass = t.children('i').attr('class');
        setContactHash({ pageNo: 1, order: name, sortBy: type });
        $('#sortByName').children('i:first').attr('class', iClass);
        t.parent().hide();
        return false;
    },

    //设置回收站能放置拖动删除
    recycleBindDrop: function () {
        if ($.ui && $.ui.droppable) {
            $('#recycleLi').droppable({
                accept: "#contactsBody tr",
                addClasses: false,
                hoverClass: "group-highlight",
                tolerance: 'pointer',
                drop: function (event, ui) {
                    PIM.Actions.delContact();
                }
            });
        }
        else {
            setTimeout($.proxy(arguments.callee, this), 100);
        }
    },

    //打开回收站
    openRec: function () {
        if (!PIM.RecycleList) {
            //实例化回收站联系人列表
            PIM.RecycleList = new RecycleList({
                contactBox: $('#recycleBody'),
                viewArea: $('#recycleList'),
                list: 'tr',
                chkClass: 'selected',
                urlContact: g_path + '/recyle.jsp',
                draggable: true,
                page: function () {
                    if (!PIM.PageRec) {
                        PIM.PageRec = new Page({
                            page: '.page-recycle',
                            callback: setRecyleHash
                        });
                    }
                    return PIM.PageRec;
                }
            })
        }
        //获取数据
        setRecyleHash({ pageNo: 1 });
    },

    //回收站 - 还原
    contactsRevert: function () {
        var selContacts = PIM.RecycleList.getSelContacts();
        if (!selContacts.length) return ajaxTips('请选择需要还原的联系人!');
        $.ajax({
            url: g_path + '/revertItems.jsp',
            type: 'POST',
            dataType: 'json',
            data: { myuinmd5: $.md5(myuinmd5), ids: selContacts.join(), X_Content_Type: 'json' },
            success: function (data) {
                if (!resolveResult(data.result, data.msg)) return;
                PIM.Group.updateGroup(false);

                PIM.RecycleList.getContactData();

                ajaxTips(data.msg);
            }
        });
    },

    //回收站 - 永久清除
    contactsDelForever: function () {
        var selContacts = PIM.RecycleList.getSelContacts();
        if (!selContacts.length) return ajaxTips('请选择需要彻底删除的联系人!');
        var title = '永久清除',
			msg = '在回收站进行永久清除，数据将无法恢复，是否继续？';
        PIM.Dialog.confirm(title, msg, function () {
            $.ajax({
                url: g_path + '/delItemsforever.jsp',
                type: 'POST',
                dataType: 'json',
                data: { myuinmd5: $.md5(myuinmd5), ids: selContacts.join(), X_Content_Type: 'json' },
                success: function (data) {
                    if (!resolveResult(data.result, data.msg)) return;
                    PIM.RecycleList.getContactData();
                    ajaxTips(data.msg);
                }
            });
        });
    },

    //回收站 - 清空
    spaceRecycle: function () {
        var title = '清空回收站',
			msg = '此操作将彻底删除回收站的所有名片，无法恢复，是否继续？';
        PIM.Dialog.confirm(title, msg, function () {
            $.ajax({
                url: g_path + '/delAllRecItems.jsp',
                type: 'POST',
                dataType: 'json',
                data: { myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json' },
                success: function (data) {
                    if (!resolveResult(data.result, data.msg)) return;
                    PIM.RecycleList.getContactData();
                    ajaxTips(data.msg);
                }
            });
        });
    },

    //分组管理
    groupManage: function (t) {
        //先分析是在哪个模块下进行的分组管理
        var data = {};
        //在联系人列表 模块
        if ($('#contactsList').is(':visible')) {
            var sc = PIM.ContactsList.getSelContacts();
            if (!sc.length) {
                return ajaxTips('请选择要添加到分组的名片');
            }
            data.ids = sc.join();
        }
        //在编辑状态模块
        else if ($('#contactEdit').is(':visible')) {
            data.ids = PIM.ContactsList.getEditContactId();
        }
        //在预览系人的模块
        //		else if($('#contactDetailArea1').is(':visible')){
        //			
        //		}
        //新增的不传ids
        data.myuinmd5 = $.md5(myuinmd5);
        data.X_Content_Type = 'json';
        $.ajax({
            url: g_path + '/group/edit_group_json.jsp',
            type: 'POST',
            dataType: 'json',
            data: data,
            success: function (data) {
                var result = data.result,
					info = data.info;
                if (!resolveResult(result, data.msg)) return;
                PIM.Actions.showGroupTipsBox(info, t);
            }
        });
    },

    /*
    * 分组管理生成html 并显示
    * */
    showGroupTipsBox: function (data, t) {
        var tipsBox = $('#groupTipsBox').height('auto'),
			position = t.offset(),
			top = position.top + t.outerHeight(),
			delList = data.delList,
			addList = data.addList,
			html = '';

        $.each(delList, function (i, n) {
            var cn = 'icon-check-mixed'
            if (n.type == 'allin') cn = 'icon-check-all';
            html += '<p groupId="' + n.groupId + '"><i class="' + cn + '"></i><span>' + getStr(n.groupName, 14) + '</span></p>';
        });
        $.each(addList, function (i, n) {
            html += '<p groupId="' + n.groupId + '"><i class="icon-check-null"></i><span>' + getStr(n.groupName, 14) + '</span></p>';
        });

        tipsBox.html(html);
        var tipsBoxHeight = tipsBox.outerHeight(),
			winHeight = $(window).height();

        if (tipsBoxHeight > winHeight - top) {
            if (position.top > winHeight - top) {
                if (tipsBoxHeight > position.top) {
                    tipsBoxHeight = position.top;
                    tipsBox.height(tipsBoxHeight - 6);
                }
                top = position.top - tipsBoxHeight;
            } else {
                tipsBoxHeight = winHeight - top;
                tipsBox.height(tipsBoxHeight - 6);
            }
        }

        tipsBox.css({ left: position.left, top: top });

        if ($('#contactEdit').is(':visible')) {
            var groups = PIM.ContactEdit.getGroupIds(),
				tipsBoxChilds = tipsBox.children('p');
            tipsBoxChilds.each(function (i, n) {
                $(n).find('i').attr('class', 'icon-check-null');
            });
            $.each(groups, function (i, n) {
                var groupid = n.groupid;
                tipsBoxChilds.filter('[groupId=' + groupid + ']').find('i').attr('class', 'icon-check-all');
            });
        }

        tipsBox.show();
    },

    groupTipsBoxClick: function (e) {
        var t = $(e.target);
        var tipsBox = $('#groupTipsBox');
        if (t.is('i')) {
            var cn = t.attr('class');
            switch (cn) {
                case 'icon-check-null':
                    t.attr('class', 'icon-check-all');
                    break;
                case 'icon-check-mixed':
                case 'icon-check-all':
                    t.attr('class', 'icon-check-null');
                    break;
            }
            if (!tipsBox.find('.save').length) {
                tipsBox.append('<div class="save"><p>确定</p></div>');
            }
        } else if (t.is('.save') || t.closest('.save').length) {
            var p = tipsBox.children('p'),
				chkedGroups = [],
				groupIds = [],
				delGroupIds = [];

            p.each(function (i, n) {
                var n = $(n),
					groupId = n.attr('groupId'),
					groupName = n.children('span').text(),
					i = n.children('i');
                if (i.is('.icon-check-all')) {
                    groupIds.push(groupId);
                    chkedGroups.push({ groupid: groupId, groupname: groupName });
                } else if (i.is('.icon-check-null')) {
                    delGroupIds.push(groupId);
                }
            });
            if ($('#contactsList').is(':visible')) {
                var url = '/card/save_card_and_group_json.jsp';

                PIM.Actions.contactToGroup(url, { groupIds: groupIds.join(), delGroupIds: delGroupIds.join() });
            } else if ($('#contactEdit').is(':visible')) {
                PIM.ContactEdit.setGroupIds(chkedGroups);
                PIM.ContactEdit.bindGroupInfo();
            }
            tipsBox.hide();
        } else {
            var type = 'add',
				p = t.closest('p'),
				chk = p.children('i'),
				groupName = p.children('span').text(),
				groupId = p.attr('groupId');
            if (chk.is('.icon-check-all')) type = 'del';
            PIM.Actions.groupOperation(groupId, groupName, type);
            tipsBox.hide();
        }
    },

    contactToGroup: function (url, data) {
        var selContacts = PIM.ContactsList.getSelContacts();
        data['myuinmd5'] = $.md5(myuinmd5);
        data['ids'] = selContacts.join();
        data['X_Content_Type'] = 'json';
        $.ajax({
            url: g_path + url,
            type: 'POST',
            dataType: 'json',
            data: data,
            success: function (data) {
                if (!resolveResult(data.result, data.msg)) return;

                PIM.Group.updateGroup(true);
                ajaxTips(data.msg);
            }
        });
    },

    //分组管理层的操作：添加到分组和从分组去除
    groupOperation: function (groupId, groupName, type) {
        //---------判断当前显示的模块-------------//

        var url = '',
			selContacts;
        type == 'add' ? url = '/card/add_card_to_group_json.jsp' : url = '/card/delete_card_from_group_json.jsp';

        //在联系人列表 模块
        if ($('#contactsList').is(':visible')) {
            PIM.Actions.contactToGroup(url, { groupId: groupId });
        }
        //回收站拖动还原
        else if ($('#recycleList').is(':visible')) {
            selContacts = PIM.RecycleList.getSelContacts();

            $.ajax({
                url: g_path + '/revertItemsToGroup.jsp',
                type: 'POST',
                dataType: 'json',
                data: { myuinmd5: $.md5(myuinmd5), ids: selContacts.join(), groupId: groupId, X_Content_Type: 'json' },
                success: function (data) {
                    if (!resolveResult(data.result, data.msg)) return;
                    //获取数据
                    PIM.Group.updateGroup(false);
                    setRecyleHash({ pageNo: PIM.PageRec.getCurrentPageNo() });
                    ajaxTips(data.msg);
                }
            });
        }
        //编辑联系人 和 新增联系人模块
        else {
            if (type == 'add') {
                PIM.ContactEdit.addGroup(groupId, groupName);
            } else {
                PIM.ContactEdit.cutGroup(groupId);
            }
        }
    },

    //时光机
    openTimeBox: function () {
        $.ajax({
            url: g_path + '/version/get_version_list_json.jsp',
            type: 'POST',
            dataType: 'json',
            data: { myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json' },
            success: function (data) {
                if (!resolveResult(data.result, data.msg)) return;
                if (data.result == '0') {
                    $('#isOpenCQ').show();
                    $('#noOpenCQ').hide();
                    PIM.Actions.bindTimeData(data.info.versions);
                } else {
                    $('#isOpenCQ').hide();
                    var noOpen = $('#noOpenCQ');
                    var img = noOpen.find('img');
                    img.attr('src', img.attr('_src'));

                    noOpen.show();
                }
                //ajaxTips(data.msg);
            }
        });
    },

    bindTimeData: function (data) {
        var html = '';
        $('#timeCount').text(data.length);
        $.each(data, function (i, n) {
            html += '<tr verId="' + n.verId + '">'
					+ '<td>' + n.verName + '</td>'
					+ '<td>联系人：' + n.dataCount + ' 分组：' + n.groupCount + '</td>'
					+ '<td><button type="button" class="btn-sure">恢复</button></td>'
				+ '</tr>';
        });
        $('#timeBox').html(html);
    },

    replaceWithVer: function () {
        var verId = $(this).closest('tr').attr('verId');
        $.ajax({
            url: g_path + '/version/rollback_version_json.jsp',
            type: 'POST',
            dataType: 'json',
            data: { myuinmd5: $.md5(myuinmd5), X_Content_Type: 'json', verid: verId },
            success: function (data) {
                if (!resolveResult(data.result, data.msg)) return;
                PIM.Dialog.alert('成功穿越', '数据还原成功！')
                PIM.Group.getGroupData(false);
                PIM.Actions.openTimeBox();
                ajaxTips(data.msg);
            }
        });
    }
};

/*
* 页面初始化调用
* */
$(function () {

    //ajax状态显示
    $("#loading").ajaxStart(function () {
        var t = $(this),
			w = $(window);
        t.css('top', 0).css('left', (w.width() - t.width()) / 2).show();
    }).ajaxStop(function () {
        $(this).hide();
    });

    var _window = $(window);
    var _doms = [
         	{ selector: '#side' },
         	{ selector: '#groupBox', callback: function () { controlBarShow($('#groupBox'), $('#groupControlBar')) } },
         	{ selector: '#contactsListBox' },
         	{ selector: '#contactEdit' },
         	{ selector: '#contactImport' },
         	{ selector: '#contactRepeat' },
         	{ selector: '#contactTime' },
         	{ selector: '#recycleListBox' }
		];
    windowResize(_doms);
    //	if($.browser.version == '6.0'){
    _window.resize(function () {
        windowResize(_doms);
    });
    //	}
    //hashchange
    _window.hashchange(doHash);

    var _pim = PIM,
		_pathContact = g_path;

    //实例化分组
    _pim.Group = new Group({
        group: $('#groupObj'),
        urlGroupData: _pathContact + '/group/all_group_json.jsp',
        urlGroupEdit: _pathContact + '/group/modify_group_json.jsp',
        urlGroupDel: _pathContact + '/group/delete_group_json.jsp',
        urlGroupAdd: _pathContact + '/group/add_group_json.jsp',
        selClass: 'current',
        hoverClass: 'hover'
    });

    //实例化联系人
    _pim.ContactsList = new ContactsList({
        contactBox: $('#contactsBody'),
        viewArea: $('#contactsList'),
        list: 'tr',
        chkClass: 'selected',
        urlContact: _pathContact + '/card/search_by_key_json.jsp',
        draggable: true,
        page: function () {
            if (!PIM.Page) {
                PIM.Page = new Page({
                    page: '.page-contact',
                    callback: setContactHash
                });
            }
            return PIM.Page;
        }
    });

    //绑定log提交
    $('.logClass').live("click", logSubmit);

    //搜索框的事件
    $('#searchInput').live('keyup', function (e) {
        if (e.keyCode == 13) {
            PIM.Actions.searchContact();
        }
    })
	.live('focusin', function () {
	    var t = $(this);
	    if (t.val() == '输入姓名、号码或邮件') {
	        t.addClass('focus').val('');
	    }
	})
	.live('focusout', function () {
	    var t = $(this);
	    if ($.trim(t.val()) == '') {
	        t.removeClass('focus').val('输入姓名、号码或邮件');
	    }
	});

    //表单类的点击操作事件代理
    $('body').delegate(':input[name],a[name]', 'click', function (e) {
        var t = $(this),
			name = t.attr('name');
        switch (name) {
            //新增按钮 
            case 'btn_AddContact':
                setHash('#contactAdd');
                //PIM.Actions.isLogin(PIM.Actions.addContact);
                break;
            //删除按钮 
            case 'btn_DellContact':
                PIM.Actions.delContact();
                break;
            //编辑 - 删除单个联系人 
            case 'btn_del':
                PIM.Actions.delContact([PIM.ContactEdit.getContactId()]);
                break;
            //返回 
            case 'btn_return':
                PIM.Actions.btnReturn();
                break;
            //添加 - 新增 
            case 'btn_save':
                PIM.ContactEdit.save(0);
                break;
            //编辑保存 
            case 'btn_edit_save':
                PIM.ContactEdit.save(1);
                break;

            //联系人全选 
            case 'chkall':
            case 'chkallRec':
                var bool = t.is(':checked')
                $(':checkbox[name=' + name + ']').attr('checked', bool);
                name == 'chkall' ?
					PIM.ContactList.setAll(bool) :
						PIM.recyContactList.setAll(bool);
                break;
            //分组管理  
            case 'btn_ManagerContGroup':
                PIM.Actions.groupManage(t);
                break;
            //搜索 
            case 'btn_Search':
                PIM.Actions.searchContact($('#searchInput').val());
                break;
            //回收站 - 还原 
            case 'contactsRevert':
                PIM.Actions.contactsRevert();
                break;
            //回收站 - 永久清除 
            case 'contactsDelForever':
                PIM.Actions.contactsDelForever();
                break;
            //回收站 - 清空 
            case 'spaceRecycle':
                PIM.Actions.spaceRecycle();
                break;
        }
    });


    //绑定加载联系人按名字排序
    $('#sortByName').tips({ relation: '#contactSortDiv', position: 'b', offset: true, tgClass: 'current', margin: { l: 0, t: 5 }, eventType: 'mouseenter' });
    $('#contactSortDiv').delegate('a', 'click', PIM.Actions.sortByName);


    //绑定分组下拉
    $('.btn-group-manage').tips({ relation: '#groupTipsBox', position: 'b', offset: true, tgClass: 'current', margin: { l: 0, t: 0} });

    $('#groupTipsBox').delegate('p', 'click', PIM.Actions.groupTipsBoxClick)
	.delegate('p', 'mouseover', function () {
	    $(this).closest('#groupTipsBox').find('p').removeClass('hover');
	    $(this).addClass('hover');
	});

    //绑定可直接拖动到垃圾回收站
    PIM.Actions.recycleBindDrop();

    //左侧四个功能操作事件代理（合并重复、导入导出和回收站）
    $('.side-nav-list').delegate('li.f', 'click', function () {
        var t = $(this),
			name = t.attr('name');
        switch (name) {
            case 'contact_merge':
                setHash('#repeat/' + new Date().getTime());
                break;
            case 'contact_import':
                isLogin(function () { setHash('#import'); });
                break;
            case 'contact_rec':
                PIM.Actions.openRec();
                break;
            case 'contact_time':
                setHash('#time');
                break;
        }
        PIM.Group.setRowUnSel();
        t.addClass('current').siblings().removeClass('current');
    });

    $('.text').live('focus', function () {
        $(this).addClass('text-focus');
    }).live('blur', function () {
        $(this).removeClass('text-focus');
    });

    //combobox
    Combobox.init({
        config: {
            'tel': {
                'options': [
		             { value: 'TEL', text: '电话号码' }, { value: 'TEL_HOME', text: '家庭电话' },
		             { value: 'TEL_WORK', text: '办公电话' },
		             { value: 'TEL_CELL', text: '常用手机' }, { value: 'TEL_CELL_HOME', text: '常用家庭手机' },
		             { value: 'TEL_CELL_WORK', text: '常用办公手机' }, { value: '自定义', text: '自定义' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'fax': {
                'options': [
		             { value: 'TEL_FAX', text: '传真' },
		             { value: 'TEL_FAX_HOME', text: '家庭传真' }, { value: 'TEL_FAX_WORK', text: '办公传真' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'email': {
                'options': [
		            { value: 'EMAIL', text: '电子邮箱' },
		            { value: 'EMAIL_HOME', text: '家庭邮箱' }, { value: 'EMAIL_WORK', text: '办公邮箱' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'url': {
                'options': [
		            { value: 'URL', text: '网址' },
		            { value: 'URL_HOME', text: '家庭网址' }, { value: 'URL_WORK', text: '办公网址' }
	            ],
                'handle': PIM.Drop.setVcard
            },
            'adr': {
                'options': [
		            { value: 'ADR', text: '地址' },
		            { value: 'ADR_HOME', text: '家庭地址' }, { value: 'ADR_WORK', text: '办公地址' }
	            ],
                'handle': PIM.Drop.setVcard
            }
        }
    });

    //绑定左侧通讯录密码修改
    $('#editTxlPwd').live('click', editPwd);

    //group control
    $('#groupControlBar').delegate('a', 'click', { data: '#groupBox' }, controlBarFn);

    $('#timeBox').delegate('button', 'click', PIM.Actions.replaceWithVer);
});

//下拉框的方法集合
PIM.Drop = {
    setVcard: function (value) {
        var cbb = Combobox.currentCbb,
			inputReadonly = Combobox.currentCbbText,
			count = 0;

        //先判断是不是自定义
        if (value == '自定义') {
            inputReadonly.attr('readonly', false).val('').focus();
            return;
        } else {
            inputReadonly.attr('readonly', true);
        }
        var count = PIM.ContactEdit.getTypeCount(value);
        var cbbn = cbb.parent().next().children(':text');
        var cbbnContent = cbbn.val();

        cbbn.attr('name', value + '_' + count); //更改保存值的文本框的name
    }
}

//延迟加载项
//$(window).load(function(){
//	setTimeout(function(){
//		var head = $('head'),
//			scriptArrs = [
//			              '../js/ui/jquery-ui-datepicker.js',
//	          '../js/contact_edit.js',
//	          
//	        ];
//		$.each(scriptArrs,function(i,n){
//			var script = $('<script />').attr('src',n);
//			head.append(script);
//		});
//	},100);
//});