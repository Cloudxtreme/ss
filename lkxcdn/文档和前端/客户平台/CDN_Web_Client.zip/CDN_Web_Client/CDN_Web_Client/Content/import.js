PIM.Import = {
	openDialog: function(type){
		this.type = type;
		if(this.openExist(type)) return;
		var dialog = $('<div>').attr('id',type + 'Dialog').attr('title','请上传需导入的'+ type + '文件');
		var html = '<div class="dialog-window">';
		var suffix = this.getSuffix(type),
			_suffix = suffix;
		if(suffix == 'xls'){
			suffix = 'xls或xlsx';
			_suffix = 'xlsx?';
		} 
		html += '<p class="tips">从您的电脑中选择'+ type +'(.'+ suffix +')文件，点击上传</p>';
		html += '<form id="form'+type+'" enctype="multipart/form-data" method="post" action="'+this.getUrl(type)+'"><input type="file" id="'+ type +'" name="'+ type +'" /></form>';
		html += '</div>';
		dialog.html(html);
		dialog.dialog({
			modal: true,
			width: 450,
			buttons: [
			          {
			        	  'text': '确定',
			        	  'class': 'btn-sure',
			        	  'click': function(){
			        		  var file = $('#'+type),
			        		  	  value = file.val();
			        		  if(new RegExp(_suffix+'$','i').test(value)){
			        			  isLogin(function(){PIM.Import.upload(type);});
			        		  }else{
			        			  file.alert('请上传'+suffix+'格式的文件',{position: 'top'});
			        		  }
			        	  }
			          },
			          {
			        	  'text': '取消',
			        	  'class': 'btn-cancel',
			        	  'click': function(){
			        		  $(this).dialog('close');
			        	  }
			          }
		          ]
		});
	},
	
	openExist: function(type){
		var dialog = $('#'+type+'Dialog');
		if(dialog.length){
			dialog.dialog('open');
			return true;
		}
		return false;
	},
	
	showHelp: function(type){
		$('#'+type+'Help').show().siblings().hide();
	},
	
	getSuffix: function(type){
		switch(type){
		case 'VCard': return 'vcf';
		case 'Outlook':return 'csv';
		case 'Excel': return 'xls';
		}
	},
	
	getUrl: function(type){
		switch(type){
		case 'VCard': 
		case 'Outlook':
		case 'Excel': return g_rootpath + '/pim/contact/import_contact/import_contact_2.jsp'
		}
	},
	
	upload: function(type){
		$.ajaxFileUpload({
        	url:PIM.Import.getUrl(type),            		//需要链接到服务器地址
            secureuri:false,
            fileElementId:type,                        		//文件选择框的id属性
            dataType:'json',                                //服务器返回的格式，可以是json
            success: function (data){
            	$('#'+type+'Dialog').dialog('close');
            	if(data.result == '0'){
            		PIM.Import.preImportBack(data.info,type);
            	}else{
            		PIM.Dialog.alert('导入提示',data.msg);
            	}
            },
            error: function(data){
            	PIM.Dialog.error('导入错误',data.msg);
            }
		});
	},
	
	disImport: function(){
		$('#importType').removeClass('can-click').addClass('dis-click');
	},
	
	canImport: function(){
		$('#tempItemHelp').remove();
		$('#importType').addClass('can-click').removeClass('dis-click').find('.selected').removeClass('selected');
		//还原
		this.showHelp('Click');
	},
	//预导入返回
	preImportBack: function(info,type){
		var html = '<div class="item" id="tempItemHelp">'
						+ '<h3>'+ type +'数据准备完成</h3>'
						+ '<div class="import-status-box">'
							+ '<p>预计导入结果</p>'
							+ '<div class="info">即将为您导入<b>'+ info.contactCnt +'</b>个联系人，<b>'+ info.groupCnt +'</b>个分组</div>'
							+ '<div class="import-btn-bar"><a href="" suffix="'+ info.type +'" class="link-btn-blur" encodedbuf="'+info.encodedBuf+'" name="sure" >确认导入</a> <a href="" class="link-btn-fff" name="cancel">取消本次导入</a></div>'
						+ '</div>'
					+ '</div>';
		$('.import-help').append(html);
		
		this.showHelp('tempItem');
		
		this.disImport();
	},
	
	//确认导入
	sureImport: function(encodedBuf,suffix){
		this.importProgress();
		$.post(g_rootpath + '/pim/contact/import_contact/commit_json.jsp?type=' + suffix, {
			myuinmd5 : $.md5(myuinmd5),
			csvBuf : encodedBuf
		}, function(data) {
			if(data.result == '0'){
				PIM.Import.sureImportBack(data.info);
			}else{
				ajaxTips(data.msg);
			}
		}, "json");
	},
	
	importProgress: function(){
		var tempItem =$('#tempItemHelp'),
			h3 = tempItem.find('h3'),
			btn = tempItem.find('.link-btn-blur'),
			type = this.type,
			percent = 0;
		btn.replaceWith('<span class="link-btn-dis">确认导入</span>');
		
		setTimeout(function(){
			h3.html(type + '数据导入中（'+ (percent++) +'%）...');
		},100);
		
	},
	
	//确认导入返回
	sureImportBack: function(info){
		PIM.Group.updateGroup(false);
		var tempItem =$('#tempItemHelp'),
			type = this.type;
		
		var html = '<h3>'+ type +'数据成功导入</h3>'
				+ '<div class="import-status-box">'
					+ '<p>导入结果</p>'
					+ '<div class="info"><span class="contact-count">已成功导入<b>'+ info.importSuccesNum +'</b>个联系人(自动合并<b>'+ info.deleteNum +'</b>个重复联系人)，<b>'+ info.groupCnt +'</b>个分组。 </div>'
					+ '<div class="import-btn-bar"><a href="" class="link-btn-blur" groupId="'+ info.groupId +'" name="view">立刻查看导入的联系人</a> <a href="" class="link-btn-fff" name="cancel">选中其他来源继续导入</a></div>'
				+ '</div>';
		
		tempItem.html(html).parent().addClass('import-success');
	},
	
	//取消导入
	cancelImport: function(){
		this.canImport();
	},
	
	//查看导入的联系人
	viewImportGroup: function(groupId){
		PIM.Group.selGroup(groupId);
	}
};

$(function(){
	$('#contactImport').delegate('.can-click a,.import-btn-bar a','click',function(){
		var t = $(this),
			name = t.attr('name');
		switch(name){
		case 'vcard':
			PIM.Import.showHelp('Click');
			PIM.Import.openDialog('VCard');
			break;
		case 'outlook':
			PIM.Import.showHelp('Outlook');
			break;
		case 'excel':
			PIM.Import.showHelp('Excel');
			break;
		case 'gmail':
			PIM.Import.showHelp('Gmail');
			break;
		case 'outlook_d':
			PIM.Import.openDialog('Outlook');
			break;
		case 'Excel_d':
			PIM.Import.openDialog('Excel');
			break;
		case 'sure':
			PIM.Import.sureImport(t.attr('encodedBuf'),t.attr('suffix'));
			break;
		case 'cancel':
			PIM.Import.cancelImport();
			break;
		case 'view':
			PIM.Import.viewImportGroup(t.attr('groupId'));
			break;
		}
		t.closest('ul').find('.selected').removeClass('selected');
		t.addClass('selected');
		return false;
	});
});