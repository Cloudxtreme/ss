var Combobox = {
		init: function(config){
			var o = {
					event: 'mouseenter',
					selector: '.combobox',
					config: null
			}
			$.extend(o,config);
			
			this.setConfig(o.config);
			var selector =$(o.selector);
			selector.live(o.event,this.show).live('mouseleave',this.mouseout);
				
		},
		
		setConfig: function(config){
			this.config = config;
		},
		
		getOptions: function(name){
			return this.config[name]['options'];
		},
		
		getBackHandle: function(){
			var name = this._getCurrentCbbName();
			return this.config[name]['handle'];
		},
		
		getName: function(name){
			return this.config[name]['name'];
		},
		
		_getCurrentCbbName: function(){
			return this.currentCbbName;
		},
		
		_setCurrentCbbName: function(name){
			this.currentCbbName = name;
		},
		
		show: function(e){
			if($(e.relatedTarget).closest('#comboboxDropdown').length
					|| $(e.relatedTarget).closest('.combobox').length) return;
			Combobox.currentCbb = $(e.currentTarget);
			Combobox.currentCbbText = Combobox.currentCbb.children(':text');
			
			if(Combobox.hideTimer){
				clearTimeout(Combobox.hideTimer);
				Combobox.hideTimer = 0;
			}
			//Combobox.hide();
			
			var selector = $(e.currentTarget),
				name = selector.attr('name'),
				p = selector.offset(),
				h = selector.outerHeight(),
				w = selector.width(),
				options = Combobox.getOptions(name),
				lis = '',
				logName = Combobox.getName(name) || '';
				
			//alert(h)
			Combobox._setCurrentCbbName(name);
			
			if(!Combobox.optionsContainer){
				Combobox.optionsContainer = $('<ul class="logClass" id="comboboxDropdown" name="'+ logName +'" />').appendTo($('body'))
					.delegate('li','click',Combobox.click)
					.delegate('li','hover',Combobox.hover);
				$('#comboboxDropdown').live('mouseleave',Combobox.mouseout)
			}
			else{
				Combobox.optionsContainer.attr('name',logName);
			}
			
			if ($.fn.bgiframe){
				Combobox.optionsContainer.bgiframe();
			}
			
			var oldText = Combobox.currentCbbText.val(),
				selClass = '';
			
			for(var i = 0, j = options.length; i < j; i++){
				if( oldText != options[i].text ){
					selClass = '';
				}else{
					selClass = 'class="selected"';
				}
				lis += '<li '+ selClass +' value="'+ options[i].value +'">'+ options[i].text +'</li>';
			}
			Combobox.optionsContainer.hide().html(lis);
			var oTop = p.top + h,
				cbbHeight = Combobox.optionsContainer.height();
			if(oTop + cbbHeight > $(document).height()){
				oTop = p.top - cbbHeight;
			}
			oTop -= 2;
			var css = {left: p.left, top: oTop, width: w - 4};
			Combobox.optionsContainer.css(css).slideDown(100);
		},
		
		hide: function(){
			if(this.optionsContainer)
				this.optionsContainer.hide();
		},
		
		mouseout: function(e){
			if($(e.relatedTarget).closest('#comboboxDropdown').length
					|| $(e.relatedTarget).closest('.combobox').length) return;
			if(!Combobox.hideTimer){
				Combobox.hideTimer = setTimeout(function(){Combobox.hide();},500);
			}
		},
		
		click: function(e){
			var t = $(e.currentTarget),
				value = t[0].getAttribute('value'),
				text = t.text(),
				callback = Combobox.getBackHandle();
			
			Combobox.setCbbText(text);
			if(callback) callback(value);
			Combobox.hide();
		},
		
		hover: function(e){
			var t = $(e.currentTarget);
			t.toggleClass('hover');
		},
		
		setCbbText: function(text){
			this.currentCbbText.val(text);
		}
}