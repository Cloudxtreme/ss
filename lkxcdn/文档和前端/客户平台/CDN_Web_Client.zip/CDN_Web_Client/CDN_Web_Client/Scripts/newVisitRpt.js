﻿function doDrawHitChart(ret) {

    var addata = ret.data;
//var chart;
 //   $(document).ready(function () {
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            defaultSeriesType: 'line', //图表类别，可取值有：line、spline、area、areaspline、bar、column等
            marginRight: 130,
            marginBottom: 25
        },
        title: {
            text: '用户访问数据分布分析', //设置一级标题
            x: -20 //center
        },
        subtitle: {
            text: '网络类型', //设置二级标题
            x: -20
        },
        xAxis: {
            //            categories: ['2011/1', '2011/2', '2011/3', '2011/4', '2011/5', '2011/6',
            // '2011/7', '2011/8', '2011/9', '2011/10', '2011/11', '2011/12']//设置x轴的标题
        //   categories: []

            categories: ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00']
        },
        yAxis: {
            title: {
                text: '访问量 (次)'//设置y轴的标题
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.series.name + '</b><br/>' +
 this.x + ': ' + this.y + '次'; //鼠标放在数据点的显示信息，但是当设置显示了每个节点的数据项的值时就不会再有这个显示信息
            }
        },
        legend: {
            layout: 'vertical',
            align: 'left', //设置说明文字的文字 left/right/top/
            verticalAlign: 'top',
            x: -10,
            y: 100,
            borderWidth: 0
        },
        exporting: {
            enabled: true //用来设置是否显示‘打印’,'导出'等功能按钮，不设置时默认为显示
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true //显示每条曲线每个节点的数据项的值
                },
                enableMouseTracking: false
            }
        },

        series: [{
            name: '电信',
            data: addata.content2
        }, {
            name: '移动',
            data: addata.content3
        }, {
            name: '网通',
            data: addata.content4
        }, {
            name: '铁通',
            data: addata.content5
        }, 
//        {
//            name: '其它', //每条线的名称
//            data: addata.content0   //每条线的数据
//        },
        {
            name: '教育网',
            data: addata.content1
        }
        ]


    });


//    });

}


//var chart;
function GetNewVisitData() {
    var start = String($("#date_start").val());
    var end = String($("#date_end").val());
    var domain = $("#domain").val();
    if (start == null || start.length == 0 || end == null || end.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    $.ajax(
        {
            url: '/CdnWeb/GetNewVisitChartData',
            data: "start=" + start + "&end=" + end + "&domain=" + domain,
            type: "POST",
            dataType: "JSON",
            // beforeSend: showLoad,
            // complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    alert("数据为空！");
                } else {
                    //alert(data);
                    $("#data").val(data);
                    var dataArr = data.split('#');

                    if (dataArr[1].length == 0) {
                        alert("您查询的域名暂时没数据");
                        return;
                    }

                    var toj = eval('(' + dataArr[1] + ')');

                    doDrawHitChart(toj);
                    var setCat = eval('(' + dataArr[0] + ')');

                    chart.xAxis[0].setCategories(setCat);

                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}
