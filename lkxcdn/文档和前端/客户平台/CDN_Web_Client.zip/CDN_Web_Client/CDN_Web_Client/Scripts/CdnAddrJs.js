﻿function SetDnsAddr(host) {
    $('#winSet').window({
        modal: false,
        shadow: false,
        closed: false,
        title: "节点DNS设置"
    });
    $('#host_name').html(host);
 //   $("#serverType").val(ip);
    removeServerTr();
    removeClientTr();
    AddDefaultRow();
}
//function SetDnsAddr(host) {
//    $('#winSet').window({
//        modal: false,
//        shadow: false,
//        closed: false,
//        title: "节点DNS设置"
//    });
//    $('#host_name').html(host);
//    removeServerTr();
//    removeClientTr();
//    $.ajax(
//         {
//             url: '/CdnWeb/GetServerList',
//             data: "host=" + host,  //&code=" + code + "
//             type: "POST",
//             //contentType: "charset=utf-8",
//             dataType: "text",
//             beforeSend: showLoad,
//             complete: showHide,
//             success: function (data) {
//                 if (data == null || data.length == 0) {
//                     alert("数据加载失败！");
//                     return false;
//                 } else {
//                     if (data.indexOf('|') > 0) {
//                         var arr = data.split('|');
//                         for (var n = 0; n < arr.length; n++) {
//                             gotoAdd(Number(n + 1), arr[n]);
//                         }
//                     }
//                     else {
//                         alert(data);
//                     }
//                 }
//             },
//             error: function (data) {
//                 alert(data.statusText);
//             }
//         });
//}
//添加数据行
//function gotoAdd(num, data) {
//    var tableElement = $("#serverTb");
//    //removeServerTr();
//    var arr = data.split(',');
//    if (arr.length == 4) {
//        tableElement.append("<tr id=\'server_tr_" + num + "\' align=\"center\">"
//            + "<td>" + num + "</td>"
//            + "<td>" + arr[1] + "</td>"
//            + "<td>" + arr[3] + "</td>"
//            + "<td><a href=\"javascript:void(0)\" onclick=\"GetDnsSet('" + arr[0] + "')\" title=\"\">查看域名设置</a></td></tr>"
//            );
//    }
//}
function GetDnsSet(ip) {
    if (ip == null || ip.length == 0) {
        return false;
    }
    
    removeClientTr();

    var trs = $("tr[class='add_tr']");
    for (i = 0; i < trs.length; i++) {
        trs[i].style.display = "block";
    }
    $("#addAddr").attr("disabled", false);
    var host = $("#host_name").html();

    $.ajax(
         {
             url: '/CdnWeb/GetClienDnsList',
             data: "serverType=" + ip + "&host=" + host,
             type: "POST",
             //contentType: "charset=utf-8",
             dataType: "text",
             beforeSend: showLoad,
             complete: showHide,
             success: function (data) {
                 if (data == null || data.length == 0) {
                     var tableElement = $("#clientTb");
                     tableElement.append("<tr align=\"center\">"
                            + "<td colspan=\"6\">该服务器还没有添加域名！</td></tr>"
                     );
                 } else {
                     //alert(data);
                     if (data.indexOf('|') > 0) {
                         var arr = data.split('|');
                         for (var n = 0; n < arr.length; n++) {
                             AddRow(arr[n]);
                         }
                     }
                     if (data.indexOf(',') > 0) {
                         AddRow(data);
                     }



                 }
                  var tableElement = $("#clientTb");
                  tableElement.append("<tr><td><input type=\"hidden\" value=\'" + ip + "\' id=\"sType\" title=\"\" /></td></tr>");
                // $("#sType").val(ip);
             },
             error: function (data) {
                 alert(data.statusText);
             }
         });
}
function AddRow(data) {
    var tableElement = $("#clientTb");
    var arr = data.split(',');
    var c_dns = "c_dns_" + arr[0];
    var c_ttl = "c_ttl_" + arr[0];
    var c_ip = "c_ip_" + arr[0];
    //var ip = "ct";var id = "sType";
    if (arr.length == 4) {
        tableElement.append("<tr id=\'" + arr[0] + "\' align=\"center\">"
            + "<td>" + arr[0] + "</td>"
            + "<td><input type=\"text\" value=\'" + arr[1] + "\' id=\'" + c_dns + "\' title=\"\" style=\"width:200px\" /></td>"
            + "<td><input type=\"text\" value=\'" + arr[2] + "\' id=\'" + c_ttl + "\' title=\"\" style=\"width:30px\" /></td>"
            + "<td><input type=\"text\" value=\'" + arr[3] + "\' id=\'" + c_ip + "\' title=\"\" style=\"width:100px\" /></td>"
            + "<td><a href=\"javascript:void(0)\" onclick=\"DeleDns('" + arr[0] + "')\" title=\"\">删除</a>"
            + "</td><td><a href=\"javascript:void(0)\" onclick=\"EditDns('" + arr[0] + "')\" title=\"\">修改</a></td></tr>"
            );
    }
}
function HostDetail(host) {
    $('#win').window({
        modal: false,
        shadow: false,
        closed: false,
        title: "主机名 " + host + " 请求详细情况"
    });
    $("#host_total").val(host);
}
function removeClientTr() {
    $("#clientTb tr:not(:first)").remove();
}
//添加数据行
function AddDefaultRow() {
    var tableElement = $("#serverTb");

        tableElement.append("<tr id=\'server_tr_1\' align=\"center\">"
            + "<td>1</td>"
            + "<td>电信</td>"
            + "<td>内部电信DNS数据源</td>"
            + "<td><a href=\"javascript:void(0)\" onclick=\"GetDnsSet('ct')\" title=\"\">查看域名设置</a></td></tr>"
            + "<tr id=\'server_tr_2\' align=\"center\">"
            + "<td>2</td>"
            + "<td>网通</td>"
            + "<td>内部网通DNS数据源</td>"
            + "<td><a href=\"javascript:void(0)\" onclick=\"GetDnsSet('cnc')\" title=\"\">查看域名设置</a></td></tr>"
            );   
}
function removeServerTr() {
    $("#serverTb tr:not(:first)").remove();
    $("#addAddr").attr("disabled", true);
    $("#host").val("");
    $("#ttl").val("300");
    $("#addr").val("");
    $("#sType").val("");
}
function AddClientDns() {
    var host = $("#host").val();
    var ttl = Number($("#ttl").val());
    var ip = $("#addr").val();
    var serverType = $("#sType").val();
    var serverHost = $("#host_name").html();
    if (serverType == null || serverType.length == 0) {
        alert("请先选择要添加到的服务器！提示：单击上面“域名服务器列表”的“操作项”");
        return false;
    }
    if (serverHost == null || serverHost.length == 0 || host == null || host.length == 0 || ttl == null || ip == null || ip.length == 0) {
        alert("资料填写不完整！");
        return false;
    }
    if (host.indexOf(serverHost) < 0) {
        alert("填写域名错误，格式为：***."+serverHost);
        return false;
    }
    $.ajax(
         {
             url: '/CdnWeb/AddClienDns',
             data: "serverHost=" + serverHost + "&serverType=" + serverType + "&host=" + host + "&ttl=" + ttl + "&ip=" + ip,
             type: "POST",
             //contentType: "charset=utf-8",
             dataType: "text",
             beforeSend: showLoad,
             complete: showHide,
             success: function (data) {
                 if (data == null || data.length == 0) {
                     alert("添加失败！");
                     return false;
                 } else {
                     alert(data);
                     if (data == "添加成功！") {
                         GetDnsSet(serverType); //重新加载数据
                         //                         var tableElement = $("#clientTb");
                         //                         var n = $("#clientTb tr").length;
                         //                         tableElement.append("<tr id=\'" + n + "\' align=\"center\">"
                         //                         + "<td>" + n + "</td>"
                         //                         + "<td><input type=\"text\" value=\'" + host + "\' title=\"\" style=\"width:200px\" /></td>"
                         //                         + "<td><input type=\"text\" value=\'" + ttl + "\' title=\"\" style=\"width:30px\" /></td>"
                         //                         + "<td><input type=\"text\" value=\'" + ip + "\' title=\"\" style=\"width:100px\" /></td>"
                         //                         + "<td colspan=\"2\"></td></tr>"
                         //                         );
                         $("#host").val("");
                         $("#ttl").val("300");
                         $("#addr").val("");
                     }
                 }
             },
             error: function (data) {
                 alert(data.statusText);
             }
         });
}
function EditDns(id) {
    var serverType = $("#sType").val();
    var serverHost = $("#host_name").html();
    var ehost = $("#c_dns_" + id).val();
    var ettl = $("#c_ttl_" + id).val();
    var eip = $("#c_ip_" + id).val();
    $.ajax(
         {
             url: '/CdnWeb/EditClienDns',
             data: "serverHost=" + serverHost + "&serverType=" + serverType + "&host=" + ehost + "&ttl=" + ettl + "&ip=" + eip + "&id=" + Number(id),
             type: "POST",
             //contentType: "charset=utf-8",
             dataType: "text",
             beforeSend: showLoad,
             complete: showHide,
             success: function (data) {
                 if (data == null || data.length == 0) {
                     alert("修改失败！");
                     return false;
                 } else {
                     alert(data);
                 }
             },
             error: function (data) {
                 alert(data.statusText);
             }
         });
}
function DeleDns(id) {
    $.messager.confirm('提示', '确定删除该条记录吗？', function (r) {
        if (r) {
            var serverType = $("#sType").val();
            var serverHost = $("#host_name").html();
            $.ajax(
            {
                url: '/CdnWeb/DeleClienDns',
                data: "serverHost=" + serverHost + "&serverType=" + serverType + "&id=" + Number(id),
                type: "POST",
                //contentType: "charset=utf-8",
                dataType: "text",
                beforeSend: showLoad,
                complete: showHide,
                success: function (data) {
                    if (data == null || data.length == 0) {
                        alert("删除失败！");
                        return false;
                    } else {
                        alert(data);
                        if (data == "删除成功！") {
                            var tableElement = $("#clientTb tr[id=" + id + "]");
                            tableElement.remove();
                        }
                    }
                },
                error: function (data) {
                    alert(data.statusText);
                }
            });
        }
    });
}
function CheckTotal() {
    var start = $("#date_start").val();
    var end = $("#date_end").val();
    var host = $("#host_total").val();
    if (start == null || start.length == 0 || end == null || end.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    $.ajax(
         {
             url: '/CdnWeb/GetHostTotal',
             data: "start=" + start + "&end=" + end + "&Host=" + host,
             type: "POST",
             //contentType: "charset=utf-8",
             dataType: "text",
             beforeSend: showLoad,
             complete: showHide,
             success: function (data) {
                 if (data == null || data.length == 0) {
                     alert("查询失败！");
                     return false;
                 } else {
                     //var arr = data.split('|');
                     $("#host_result").html("【请求总流量：" + Math.round(data) + "M】（说明：M是指兆字节，即MBytes）按G换算：[请求总流量：" + Math.round((Number(data) / 1000)) + "--" + adv_format(Number(data) / 1000, 0) + "G]");
                 }
             },
             error: function (data) {
                 alert(data.statusText);
             }
         });
     }

     function adv_format(value, num) //四舍五入
     {
         var a_str = formatnumber(value, num);
         var a_int = parseFloat(a_str);
         if (value.toString().length > a_str.length) {
             var b_str = value.toString().substring(a_str.length, a_str.length + 1)
             var b_int = parseFloat(b_str);
             if (b_int < 5) {
                 return a_str
             }
             else {
                 var bonus_str, bonus_int;
                 if (num == 0) {
                     bonus_int = 1;
                 }
                 else {
                     bonus_str = "0."
                     for (var i = 1; i < num; i++)
                         bonus_str += "0";
                     bonus_str += "1";
                     bonus_int = parseFloat(bonus_str);
                 }
                 a_str = formatnumber(a_int + bonus_int, num)
             }
         }
         return a_str
     }

     function formatnumber(value, num) //直接去尾
     {
         var a, b, c, i
         a = value.toString();
         b = a.indexOf('.');
         c = a.length;
         if (num == 0) {
             if (b != -1)
                 a = a.substring(0, b);
         }
         else {
             if (b == -1) {
                 a = a + ".";
                 for (i = 1; i <= num; i++)
                     a = a + "0";
             }
             else {
                 a = a.substring(0, b + num + 1);
                 for (i = c; i <= b + num; i++)
                     a = a + "0";
             }
         }
         return a
     }