﻿/**

* 封装装载XML的方法,并返回XML文档的根元素节点。

* @param flag true时参数xml表示xml文档的名称；false时参数xml是一个字符串，其内容是一个xml文档

* @param xml 根据flag参数的不同表示xml文档的名称或一个xml文档的字符串表示

*/

function loadXML(flag, xml) {

    var xmlDoc;

    //针对IE浏览器

    if (window.ActiveXObject) {

        var aVersions = ["MSXML2.DOMDocument.6.0", "MSXML2.DOMDocument.5.0", "MSXML2.DOMDocument.4.0", "MSXML2.DOMDocument.3.0", "MSXML2.DOMDocument", "Microsoft.XmlDom"];

        for (var i = 0; i < aVersions.length; i++) {

            try {

                //建立xml对象

                xmlDoc = new ActiveXObject(aVersions[i]);

                break;

            } catch (oError) {

            }

        }

        if (xmlDoc != null) {

            //同步方式加载XML数据

            xmlDoc.async = false;

            //根据XML文档名称装载

            if (flag == true) {

                xmlDoc.load(xml);

            } else {

                //根据表示XML文档的字符串装载

                xmlDoc.loadXML(xml);

            }

            //返回XML文档的根元素节点。

            return xmlDoc.documentElement;

        }

    } else {

        //针对非IE浏览器

        if (document.implementation && document.implementation.createDocument) {

            /*

            第一个参数表示XML文档使用的namespace的URL地址

            第二个参数表示要被建立的XML文档的根节点名称

            第三个参数是一个DOCTYPE类型对象，表示的是要建立的XML文档中DOCTYPE部分的定义，通常我们直接使用null

            这里我们要装载一个已有的XML文档，所以首先建立一个空文档，因此使用下面的方式

            */

            xmlDoc = document.implementation.createDocument("", "", null);

            if (xmlDoc != null) {

                //根据XML文档名称装载

                if (flag == true) {

                    //同步方式加载XML数据

                    xmlDoc.async = false;

                    xmlDoc.load(xml);

                } else {

                    //根据表示XML文档的字符串装载

                    var oParser = new DOMParser();

                    xmlDoc = oParser.parseFromString(xml, "text/xml");

                }

                //返回XML文档的根元素节点。

                return xmlDoc.documentElement;

            }

        }

    }

    return null;

}