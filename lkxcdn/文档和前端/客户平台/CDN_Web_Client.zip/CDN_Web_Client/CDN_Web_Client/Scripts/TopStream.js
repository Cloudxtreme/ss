﻿function CheckTopStream() {
    //$("#tb_In").datagrid('loadData', projectlist);
    var start_date = String($("#date_start").val());
    var day_span = String($("#dl_span").val());
    var domain = $("#dl_domain").val();
    var bfb = $("#bfb").val();
    if (start_date == null || start_date.length == 0 || day_span == null || day_span.length == 0 || bfb == null || bfb.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    if (Number(bfb) == 0) {
        alert("查询百分比不能为0！");
        return false;
    }
    $.ajax(
        {
            url: '/CdnWeb/GetTopStream',
            data: "start=" + start_date + "&span=" + day_span + "&domain=" + domain + "&bfb=" + Number(bfb),
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    alert("查询结果为空！");
                    return false;
                } else {
                    //alert(data);
                    //var dataArr = data.split('|');
                    //$("#hide_ck_in").val(dataArr[1]);
                    $("#hide_ck_out").val(data);
                    $("#tb_Out").datagrid('loadData', eval('(' + data + ')'));
                    //$("#tb_In").datagrid('loadData', eval('(' + dataArr[1] + ')'));
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }

    function CheckNet(type) {
        if (type == 'in') {
            var inStr = $("#hide_ck_in").val();
            var inObj = eval('(' + inStr + ')');
            var num = $("#in_ck").val();
            if (num == "" || num == null) {
                alert("请输入查询百分比！");
            }
            else {
                var total = inObj.length;
                var atr = parseInt(total * (num / 100));
                $("#ck_in_msg").html("共" + total + "条记录，" + num + "%即为第" + atr + "条记录：时间【" + inObj[atr - 1].datetime + "】流量【" + inObj[atr - 1].stream + "Mbps】");
            }
        }
        else {
            var outStr = $("#hide_ck_out").val();
            var outObj = eval('(' + outStr + ')');
            var num = $("#out_ck").val();
            if (num == "" || num == null) {
                alert("请输入查询百分比！");
            }
            else {
                var total = outObj.length;
                var atr = parseInt(total * (num / 100));
                $("#ck_out_msg").html("共" + total + "条记录，" + num + "%即为第" + atr + "条记录：时间【" + outObj[atr - 1].datetime + "】流量【" + outObj[atr - 1].stream + "Mbps】");
            }
        }
    }