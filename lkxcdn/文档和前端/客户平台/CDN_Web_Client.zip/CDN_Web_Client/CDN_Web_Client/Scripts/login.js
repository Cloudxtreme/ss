﻿function ltrim(s) {
    return s.replace(/^\s*/, "");
}
//去右空格; 
function rtrim(s) {
    return s.replace(/\s*$/, "");
}

$(function () {  
    $("#valiCode").bind("click", function () {  
        this.src = "../Home/GetValidateCode?time=" + (new Date()).getTime();  
    });
});

function reset() {
    $('#txt_user').val("");
    $('#txt_pwd').val("");
    $('#txt_code').val("");
}

function login() {
    var loginn = rtrim(ltrim(document.getElementById('txt_user').value));
    var loginp = rtrim(ltrim(document.getElementById('txt_pwd').value));
    var loginc = rtrim(ltrim(document.getElementById('txt_code').value));
    var cookie = $('#user_cookie').val();
    if (loginn == "") {
        document.getElementById('msg').innerHTML = "请输入用户名！";
        document.all('txt_user').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginp == "") {
        document.getElementById('msg').innerHTML = "请输入密码！";
        document.all('txt_pwd').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginp.length < 3) {
        document.getElementById('msg').innerHTML = "密码不能小于3位！";
        document.all('txt_pwd').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginc == "" || loginc.length != 5) {
        document.getElementById('msg').innerHTML = "请输入正确的验证码！";
        document.all('txt_code').focus();
        return false;
    }
    $("#msg").html("正在验证中，请稍候...");
    $.ajax(
    {
        url: '/Home/CheckLogin',
        data: "user=" + loginn + "&pwd=" + loginp + "&code=" + loginc + "&type=user" + "&cookie=" + cookie,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        success: function (data) {
            if (data == null || data.length == 0) {
                alert("验证失败！");
                return false;
            } else {
                if (data == "true") {
                    if (confirm("我们有新版本，是否现在试用")) {
                        // window.open('http://portal.cdn.efly.cc/cdn/login.php', 'newwindow', 'fullscreen');
                       // document.getElementById('go_2_new').submit();
                        //$("#go_2_new").get(0).click();
                        window.location = "http://portal.cdn.efly.cc";
                        return;
                    }
                    window.location = "../CdnWeb/Index";
                }
                else {
                    document.getElementById('msg').innerHTML = data;
                }
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}