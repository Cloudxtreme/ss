﻿function GetRptData() {
    var date = $("#ck_time").val();
    if (date.length == 0 || date == null) {
        alert("请选择查询日期！");
        $("#ck_time").focus();
        return false;
    }
    var DateArr = date.split('-');
    var span = Number($("#chart_type").val());
    if (span == 0) {
        //alert(DateArr[1]);
        var sDate = addDay(date, 1);
        var sDateArr = sDate.split('-');
        reDrawChartForDay(DateArr[0], DateArr[1], DateArr[2], sDateArr[0], sDateArr[1], sDateArr[2]);
    }
    if (span == 30) {
        //var myDate = DateAdd('n', 1, date, 0);
        var myDate = addMonth(date, 1);
       
        //去掉当天
       // myDate = addDay(myDate, -1);

        var myDateArr = myDate.split('-');

        reDrawChartForMonth(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    if (span == 7) {
        //var sDate = DateAdd('w', 1, date, 0);

        //date = addDay(date, -1);

        var sDate = addDay(date,7);
        var sDateArr = sDate.split('-');
        reDrawChartForWeek(DateArr[0], DateArr[1], DateArr[2], sDateArr[0], sDateArr[1], sDateArr[2]);
    }
    var area = $("#dl_area").val();
    var domain = $("#dl_domain").val();
    $.ajax(
        {
            url: '/CdnWeb/GetChartDataByServer',
            data: "area=" + area + "&day=" + date + "&span=" + span + "&domain=" + domain,
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 11) {
                    alert("暂时没有您查询的数据！");
                    return false;
                } else {
                    var dataArr = data.split('|');
                    var inStr = dataArr[0].split('#');
                    // var outStrq = dataArr[1].split('#');
                    var outStr = dataArr[1].split('#');
                    var inMax = inStr[0].split(',');
                    var outMax = outStr[0].split(',');
                    //$("#maxInTime").html(inMax[0]);
                    //$("#maxInValue").html(inMax[1]);

                    $("#maxOutTime").html(outMax[0]);
                    $("#maxOutValue").html((outMax[1]*1.0).toFixed(2));

                    var inObj = eval('(' + inStr[1] + ')');
                    var outObj = eval('(' + outStr[1] + ')');
                    var outValue = eval('(' + outStr[1] + ')');

                    if (outValue[129] > 0) {
                        $("#pd").html(outValue[129].toFixed(2));
                    }

                    outValue.sort(mysortfunc);
                    var num = outValue.length * 0.95;
                    var count = parseInt(num);
                    if (outValue[count] > 0) {
                        $("#n-five").html(outValue[count].toFixed(2));
                    }
                    chart.series[0].setData(outObj);
                    //chart.series[1].setData(outObj);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }

    function addDay(sDate, num) {
        var aYmd = sDate.split('-');
        var dt = new Date(aYmd[0], aYmd[1], aYmd[2]);
        dt.setMonth(dt.getDate() + num);
        var y = dt.getFullYear();
        var m = dt.getMonth();
        var d = dt.getDate();
        if (m < 10) m = '0' + m;
        if (d < 10) d = '0' + d;
        return y + '-' + m + '-' + d;
    }

    function addMonth(sDate, num) {
        var aYmd = sDate.split('-');
        var dt = new Date(aYmd[0], aYmd[1], aYmd[2]);
        dt.setMonth(dt.getMonth() + num);
        var y = dt.getFullYear();
        var m = dt.getMonth();
        var d = dt.getDate();
        if (m < 10) m = '0' + m;
        if (d < 10) d = '0' + d;
        return y + '-' + m + '-' + d;
    }

    function mysortfunc(str1, str2) {
        return eval(str1) - eval(str2);
    } 
