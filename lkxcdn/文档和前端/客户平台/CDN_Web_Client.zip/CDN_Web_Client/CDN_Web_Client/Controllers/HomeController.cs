﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using System.Data;
using CDN_Web_Client.Core;

namespace CDN_Web_Client.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            if (HttpContext.Session["user"] != null)
            {
                HttpContext.Session["user"] = null;
                //Session["ValidateCode"] = null;
            }
            Cookie Cookie = new Cookie();
            ViewData["name"] = "";
            ViewData["pwd"] = "";
            string name = Cookie.getCookie("webClientName");//取值
            string pwd = Cookie.getCookie("webClientPwd");
            if (!string.IsNullOrEmpty(name))
            {
                ViewData["name"] = name;
            }
            if (!string.IsNullOrEmpty(pwd))
            {
                ViewData["pwd"] = pwd;
            }
            return View();
        }
        public ActionResult LogTimeOut()
        {   
            return View();
        }

        public ActionResult GetValidateCode()
        {
            ValidateCode vCode = new ValidateCode();
            string code = vCode.CreateValidateCode(5);
            Session["ValidateCode"] = code;
            byte[] bytes = vCode.CreateValidateGraphic(code);
            return File(bytes, @"image/jpeg");
        }
        //public ActionResult iframe()
        //{
        //    return View();
        //}

        //Ajax Mothed
        public string ChangePwd(string oldPwd, string newPwd)
        {
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(oldPwd) | r.IsMatch(newPwd))
                {
                    //SQL注入
                    return "请不要攻击该系统，您的行为已经被我们记录！";
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Clear();
                    strSql.Append("SELECT Count(`user`),`user` FROM `user` where `user`='" + HttpContext.Session["user"].ToString().Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(oldPwd.Trim(), "MD5").ToLower() + "' and status='true'");
                  //  strSql.Append("SELECT Count(`user`),`user` FROM `user` where `user`='" + HttpContext.Session["user"].ToString().Trim() + "'  and status='true'");
                    MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (sdr.Read())
                    {
                        if (int.Parse(sdr["Count(`user`)"].ToString()) == 1)
                        {
                            strSql.Clear();
                            strSql.Append("update `user` set `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(newPwd.Trim(), "MD5").ToLower() + "' where `user`='" + HttpContext.Session["user"].ToString().Trim() + "'");
                            int result = MySql.Data.MySqlClient.MySqlHelper.ExecuteNonQuery(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                            if (result == 1)
                            {
                                HttpContext.Session["pwd"] = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(newPwd.Trim(), "MD5").ToLower();
                                return "修改成功！";
                            }
                        }
                        else
                        {
                            return "原始密码错误！";
                        }
                    }
                }
                return "修改失败！";
            }
            catch
            {
                return "修改出错，请联系管理员！";
            }
        }
        public string CheckLogin(string user, string pwd, string code, string type, string cookie)
        {
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(user) | r.IsMatch(pwd) | r.IsMatch(code))
                {
                    //SQL注入
                    return "请不要尝试注入我们的系统，您的行为我们已经记录！";
                }
                else
                {
                    Cookie Cookie = new Cookie();
                    if (cookie.Trim() == "记住")
                    {
                        Cookie.setCookie("webClientName", user, 1);
                        Cookie.setCookie("webClientPwd", pwd, 1);
                    }
                    else
                    {
                        Cookie.delCookie("webClientName");
                        Cookie.delCookie("webClientPwd");
                    }
                    StringBuilder strSql = new StringBuilder();
                    if (type == "company")
                    {
                        strSql.Append("SELECT Count(`user`),`user`,`puser`  FROM `user` where `user`='" + user.Trim() + "' and status='true'");
                    }
                    else 
                    {
                        if (code != Session["ValidateCode"].ToString())
                        {
                            return "验证码输入错误！";
                        }

                        //string wnPwd = "rjkj" + DateTime.Now.ToString("yyyyMMdd");
                        //if (pwd.Trim() == wnPwd)
                        //{
                        //    strSql.Append("SELECT Count(`user`),`user`,`puser` FROM `user` where `user`='" + user.Trim() + "' and status='true'");
                        //}
                        //else
                        //{
                        //    strSql.Append("SELECT Count(`user`),`user`,`puser` FROM `user` where `user`='" + user.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower() + "' and status='true'");
                        //}

                       strSql.Append("SELECT Count(`user`),`user`,`puser` FROM `user` where `user`='" + user.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower() + "' and status='true'");
                      //  strSql.Append("SELECT Count(`user`),`user`,`puser` FROM `user` where `user`='" + user.Trim() + "' and status='true'");
                    }
                    MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (sdr.Read())
                    {
                        if (int.Parse(sdr["Count(`user`)"].ToString()) == 1)
                        {
                            HttpContext.Session["user"] = sdr["user"].ToString();    //用户名
                            HttpContext.Session["puser"] = sdr["puser"].ToString();    //父账号
                            if (type == "company")
                            {
                                HttpContext.Session["pwd"] = pwd.Trim().ToLower();
                            }
                            else
                            {
                                HttpContext.Session["pwd"] = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower();
                            }
                            return "true";
                        }
                    }
                }
                return "验证失败！";
            }
            catch
            {
                return "验证报错！";
            }
        }

        //私有方法

    }
}
