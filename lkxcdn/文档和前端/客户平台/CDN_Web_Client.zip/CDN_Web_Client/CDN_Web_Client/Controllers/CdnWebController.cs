﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using CDN_Web_Client.Core;
using CDN_Web_Client.Models;
using System.Collections;
using System.IO;

namespace CDN_Web_Client.Controllers
{
    public class CdnWebController : Controller
    {
        //
        // GET: /CdnWeb/

        public ActionResult Index()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult TrafficRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                List<AddrModels> model = GetHostListByName(HttpContext.Session["user"].ToString());
                return View(model);
            }
        }

        public ActionResult VisitRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult newVisitRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                //ViewData["domain"] = GetHostListByUser(user);

                List<AddrModels> hostList = GetHostListByUser(user);
                List<AddrModels> newHostList = new List<AddrModels>();
                if (hostList != null)
                {
                    foreach (AddrModels models in hostList)
                    {
                        if (models.hostname.IndexOf("*") != 0 && models.hostname.IndexOf(".") != 0)
                        {
                            newHostList.Add(models);
                        }
                    }
                    ViewData["domain"] = newHostList;
                }

                return View();
            }
        }

        public ActionResult MapRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                //ViewData["domain"] = GetHostListByUser(user);

                List<AddrModels> hostList = GetHostListByUser(user);
                List<AddrModels> newHostList = new List<AddrModels>();

                if (hostList != null)
                {
                    foreach (AddrModels models in hostList)
                    {
                        if (models.hostname.IndexOf("*") != 0 && models.hostname.IndexOf(".") != 0)
                        {
                            newHostList.Add(models);
                        }
                    }
                    ViewData["domain"] = newHostList;
                }

                return View();
            }
        }


        public ActionResult HitRpt()
        {
            try
            {
                List<AddrModels> model = GetHostListByUser(HttpContext.Session["user"].ToString());
                return View(model);
            }
            catch
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
        }
        public ActionResult CdnAddrList()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
                //return View();
            }
            else
            {
                List<AddrModels> model = GetHostListByName(HttpContext.Session["user"].ToString());
                return View(model);
            }
        }
        public ActionResult main()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                ViewData["user"] = user;
                ViewData["domain"] = GetHostListByUser(user);
                string IpStr = GetIpStr("全部");
                string timeSpan = GetDateTable();
                ViewData["TimeSpan"] = null;
                if (!string.IsNullOrEmpty(IpStr))
                {
                    string area = GetAreaByIp(IpStr);
                    ViewData["area"] = area;
                }
                if (!string.IsNullOrEmpty(timeSpan))
                {
                    ViewData["TimeSpan"] = timeSpan;
                }
                return View();
            }
        }
        public ActionResult TopStream()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string timeSpan = GetDateTable();
                if (!string.IsNullOrEmpty(timeSpan))
                {
                    ViewData["TimeSpan"] = timeSpan;
                }
                ViewData["domain"] = GetHostListByUser(HttpContext.Session["user"].ToString());
                return View();
            }
        }

        //public ActionResult CatchMgr()
        //{
        //    if (HttpContext.Session["user"] == null)
        //    {
        //        return RedirectToAction("LogTimeOut", "Home");
        //    }
        //    else
        //    {
        //        ViewData["user"] = HttpContext.Session["user"].ToString();
        //        ViewData["pwd"] = HttpContext.Session["pwd"].ToString();
        //        return View();
        //    }
        //}

        public ActionResult CatchMgr(string res)
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                ViewData["user"] = HttpContext.Session["user"].ToString();
                ViewData["pwd"] = HttpContext.Session["pwd"].ToString();

                List<CatchMgrModels> data = new List<CatchMgrModels>();
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    //strSql.Append("select `url`,`owner`,`start_time`,`status` from `url_purge` where `status`='true' and `owner` ='" + ViewData["user"].ToString() + "';");
                    strSql.Append("select `url`,`owner`,`start_time`,`finish_time`,`status`,`type` from `web_cache_mgr` where  `owner` ='" + ViewData["user"].ToString() + "' order by `start_time` desc ;");
                    DataSet catchMgrDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                   // DataSet catchMgrDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
         
                    if (catchMgrDs.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in catchMgrDs.Tables[0].Rows)
                        {
                            CatchMgrModels item = new CatchMgrModels();
                            item.url = dr["url"].ToString();
                            item.owner = dr["owner"].ToString();
                            item.start_time = dr["start_time"].ToString();
                            item.finish_time = dr["finish_time"].ToString();

                            string type ="";
                            if (dr["type"].ToString() == "clean")
                            {
                                type = "清除";
                            }
                            else if (dr["type"].ToString() == "push")
                            {
                                type = "推送";
                            }
                            else if (dr["type"].ToString() == "update")
                            {
                                type = "更新";
                            }

                            if (dr["status"].ToString() == "finish")
                            {
                                item.status = type + ":执行完成";
                            }
                            else if (dr["status"].ToString() == "ready")
                            {
                                item.status = type + ":准备执行";
                            }
                            else
                            {
                                item.status = type + ":正在执行";
                            }
                            data.Add(item);
                        }
                    }
    
                    ////上传列表查询
                    strSql.Remove(0, strSql.Length);
                    //strSql.Append("select `url`,`owner`,`start_time`,`status` from `postfile_url_update` where `status`='true' and `owner` ='" + ViewData["user"].ToString() + "';");
                    strSql.Append("select `url`,`owner`,`start_time`,`finish_time`,`status`,`type` from `web_cache_mgr` where `status`='ready' and `owner` ='" + ViewData["user"].ToString() + "' order by `start_time` desc;");
                    DataSet catchUplDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                   // DataSet catchUplDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());

                    if (res != null && res == "up")
                    {
                        ViewData["Msg"] = "上传成功！可点击“查看任务列表”按钮查看处理进度";
                    }

                    //删除已处理的列表文件
                    strSql.Remove(0, strSql.Length);
                    strSql.Append("select `url`,`owner`,`start_time`,`finish_time`,`status`,`type` from `web_cache_mgr` where `status`='finish' and `owner` ='" + ViewData["user"].ToString() + "' order by `start_time` desc;");

                 //  DataSet catchUpledDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    DataSet catchUpledDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                    if (catchUplDs.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in catchUpledDs.Tables[0].Rows)
                        {
                            string[] txtName1 = dr["url"].ToString().Split('/');
                            int count = txtName1.Length - 1; //string name = "xx.txt";
                            if (count > 0)
                            {
                                string name = txtName1[count].ToString();
                                string path = Request.PhysicalApplicationPath + "files\\";
                                string filePath = path + name;
                                
                                if (System.IO.File.Exists(filePath))
                                {
                                    System.IO.File.Delete(path + name);
                                }
                            }
                        }
                    }

                }

                catch (Exception e)
                {
                    throw e;
                }

                return View(data);
            }
        }

        //_______________________
        //Ajax Method

        //获取访问统计分析数据
        [HttpPost, ActionName("GetVisitChartData")]
        public string GetVisitChartData(string start, string end)
        {
            Hashtable ipArea = GetIpAreaMap();
            Hashtable ipNettype = GetIpNettypeMap();
            if (ipArea != null && ipNettype != null)
            {
                //string portStr = GetPort(HttpContext.Session["user"].ToString(), "全部"); ///以后就不用了
                string domainStr = GetDomainByUser(HttpContext.Session["user"].ToString());
                Hashtable areaResult = new Hashtable();
                Hashtable netypeResult = new Hashtable();
                double traffic_total = 0; 
                //获取区域数据
                string[] domArr = SplitDomain(domainStr);
                string sql = string.Empty;
                if (!string.IsNullOrEmpty(domArr[0])) //有*的
                {
                    string[] dom_item_Arr = domArr[0].Split(',');
                    sql = "select sum(`traffic`) as traffic,`ip` from `client_traffic` where (`hostname` like ";
               
                    for (int i = 0; i < dom_item_Arr.Length; i++)
                    {
                        string dom = dom_item_Arr[i].Replace('*', '%');
                        if (i == dom_item_Arr.Length - 1)
                        {
                            sql += dom;
                        }
                        else
                        {
                            sql += dom + " or `hostname` like ";
                        }
                    }

                    sql += ") and `time`>='" + start.Trim() + "' and `time`<='" + end.Trim() + "' group by `ip` order by traffic;  ";
                }

                if (!string.IsNullOrEmpty(domArr[1])) //无*的
                {
                    string[] dom_item_Arr = domArr[1].Split(',');
                    string strSql = string.Empty;
                    for (int i = 0; i < dom_item_Arr.Length; i++)
                    {
                        strSql += dom_item_Arr[i].ToString() + ",";
                    }
                    strSql = strSql.Substring(0, strSql.Length - 1);

                    sql += "select sum(`traffic`) as traffic,`ip` from `client_traffic` where `hostname` in(" + strSql + ") and `time`>='" + start.Trim() + "' and `time`<='" + end.Trim() + "' group by `ip` order by traffic;  ";
                }

                //string sql = "select sum(`traffic`) as traffic,`ip` from `client_traffic` where `hostname` in(" + domainStr + ") and `time`>='" + start.Trim() + "' and `time`<='" + end.Trim() + "' group by `ip` order by traffic  ";
                DataSet ds = MySqlHelper.ExecuteDataset(MySqlConn.HIT_SERVER, sql);

                if (ds.Tables.Count > 1)
                {
                    object[] objArray = new object[ds.Tables[0].Columns.Count];
                    for (int count = 0; count < ds.Tables[1].Rows.Count; count++)
                     {
                        ds.Tables[1].Rows[count].ItemArray.CopyTo(objArray, 0);
                        ds.Tables[0].Rows.Add(objArray);
                    }
                }

                //DataTable newDataTable = ds.Tables[0].Clone();                //创建新表 克隆以有表的架构。
                //object[] objArray = new object[newDataTable.Columns.Count];   //定义与表列数相同的对象数组 存放表的一行的值。
                //for (int i = 0; i < ds.Tables.Count; i++)
                //{
                //    for (int j = 0; j < ds.Tables[i].Rows.Count; j++)
                //    {
                //        ds.Tables[i].Rows[j].ItemArray.CopyTo(objArray, 0);    //将表的一行的值存放数组中。
                //        newDataTable.Rows.Add(objArray);                       //将数组的值添加到新表中。
                //    }
                //}


                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        //区域数据
                        string tmp_area = "";
                        try
                        {
                            tmp_area = ipArea[dr["ip"]].ToString();
                        }
                        catch
                        {
                        }
                        if (!string.IsNullOrEmpty(tmp_area))
                        {
                            if (areaResult.Contains(tmp_area))
                            {
                                Double tmp_area_num = 0;
                                tmp_area_num = double.Parse(areaResult[ipArea[dr["ip"]].ToString()].ToString()) + double.Parse(dr["traffic"].ToString());
                                areaResult.Remove(ipArea[dr["ip"]].ToString());
                                areaResult.Add(ipArea[dr["ip"]].ToString(), tmp_area_num);
                            }
                            else
                            {
                                areaResult.Add(ipArea[dr["ip"]].ToString(), double.Parse(dr["traffic"].ToString()));
                            }
                        }

                        //网络类型数据
                        string tmp_nettype = "";
                        try
                        {
                            tmp_nettype = ipNettype[dr["ip"]].ToString();
                        }
                        catch
                        {
                        }
                        if (!string.IsNullOrEmpty(tmp_nettype))
                        {
                            if (netypeResult.Contains(tmp_nettype))
                            {
                                Double tmp_netype_num = 0;
                                tmp_netype_num = double.Parse(netypeResult[ipNettype[dr["ip"]].ToString()].ToString()) + double.Parse(dr["traffic"].ToString());
                                netypeResult.Remove(ipNettype[dr["ip"]].ToString());
                                netypeResult.Add(ipNettype[dr["ip"]].ToString(), tmp_netype_num);
                            }
                            else
                            {
                                netypeResult.Add(ipNettype[dr["ip"]].ToString(), double.Parse(dr["traffic"].ToString()));
                            }
                        }
                        traffic_total += double.Parse(dr["traffic"].ToString());
                    }
                }               

                string area_json = "[";
                if(areaResult.Count > 0)
                {
                    foreach(DictionaryEntry o in areaResult)
                    {
                        area_json += "['" + o.Key + "'," + ((double)o.Value * 100 / traffic_total).ToString("F3") + "],";
                    }
                }
                if (area_json.Length > 1)
                {
                    area_json = area_json.Substring(0, area_json.Length - 1) + "]";
                }
                else
                {
                    area_json = "[]";
                }

                string netype_json = "[";
                if (netypeResult.Count > 0)
                {
                    foreach (DictionaryEntry o in netypeResult)
                    {
                        netype_json += "['" + o.Key + "'," + ((double)o.Value * 100 / traffic_total).ToString("F3") + "],";
                    }
                }
                if (netype_json.Length > 1)
                {
                    netype_json = netype_json.Substring(0, netype_json.Length - 1) + "]";
                }
                else
                {
                    netype_json = "[]";
                }
                return area_json + "#" + netype_json;
            }
            return "";
        }

        [HttpPost, ActionName("GetNewVisitChartData")]
        public string GetNewVisitChartData(string start, string end,string domain)
        {
            DateTime t1 = DateTime.Parse(start);
            DateTime t2 = DateTime.Parse(end); 
            System.TimeSpan ts = t2 - t1;
            int days = ts.Days;

            string dateJson = "[";
            for (int i = 0; i <= days; i++)
            {
                dateJson += "'"+ t1.AddDays(i).ToString("MM/dd") + "',";
            }
            dateJson = dateJson.Substring(0, dateJson.Length - 1) + "]";

            DataSet ds = new DataSet();

            string sql = string.Empty;

            if (TableIsExistByDomain("'"+domain.ToString()+"'", MySqlConn.Weblogdw_SERVER))
            {
                for (int i = 0; i <= days; i++)
                {
                    sql += "select sum(`cnt`),`nettype` from `" + domain.ToString() + "` where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' group by `nettype` order by `nettype`;";
                }
                ds = MySqlHelper.ExecuteDataset(MySqlConn.Weblogdw_SERVER, sql);
            }

           
            string nettypeJson = string.Empty;        

            if (ds.Tables.Count > 0)
            {
                nettypeJson = "{\"data\": {";
                for (int count = 0; count < ds.Tables[0].Rows.Count; count++)
                {
                    nettypeJson += "\"content" + count.ToString() + "\":[";
                    for (int row = 0; row < ds.Tables.Count; row++)
                    {
                        nettypeJson += ds.Tables[row].Rows[count][0].ToString() + ",";
                    }
                    nettypeJson = nettypeJson.Substring(0, nettypeJson.Length - 1) + "],";
                }
                nettypeJson = nettypeJson.Substring(0, nettypeJson.Length - 1) + "}}";
            }           

            return dateJson + "#" + nettypeJson;
        }

        [HttpPost, ActionName("GetMapData")]
        public string GetMapData(string start, string end,string domain)
        {
            DateTime t1 = DateTime.Parse(start);
            DateTime t2 = DateTime.Parse(end);
            System.TimeSpan ts = t2 - t1;
            int days = ts.Days;

            //string domainStr = GetDomainByUser(HttpContext.Session["user"].ToString());

            ////获取区域数据
            //string[] domArr = SplitDomain(domainStr);
            //string sql = string.Empty;
            //if (!string.IsNullOrEmpty(domArr[1])) //无*的
            //{
            //    string[] dom_item_Arr = domArr[1].Split(',');

            //    if (TableIsExistByDomain(dom_item_Arr[0].ToString(), MySqlConn.Weblogdw_SERVER))
            //    {
            //        for (int i = 0; i <= days; i++)
            //        {
            //            sql += "select sum(`cnt`),`zone` from " + dom_item_Arr[0].Replace("'", "`").ToString() + " where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' group by `zone` order by `zone`;";
            //        }
            //    }
            //}
            DataSet ds = new DataSet();
            string sql = string.Empty;

            if (TableIsExistByDomain("'" + domain.ToString() + "'", MySqlConn.Weblogdw_SERVER))
            {
                for (int i = 0; i <= days; i++)
                {
                   // sql += "select sum(`cnt`),`nettype` from `" + domain.ToString() + "` where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' group by `nettype` order by `nettype`;";
                    sql += "select sum(`cnt`),`zone` from `" + domain.ToString() + "` where `date`= '" + t1.AddDays(i).ToString("yyyy-MM-dd") + "' and `zone`!='其它'  group by `zone` order by `zone`;";
                }
                ds = MySqlHelper.ExecuteDataset(MySqlConn.Weblogdw_SERVER, sql);
            }

            //ds = MySqlHelper.ExecuteDataset(MySqlConn.Weblogdw_SERVER, sql);
            string nettypeJson = string.Empty;

            DataTable dt = new DataTable();
            dt.Columns.Add("cnt",typeof(int));
            dt.Columns.Add("zone", typeof(string));
            //处理掉无数据的datatable
            DataSet resultDS = new DataSet();
            for (int count = 0; count < ds.Tables.Count; count++)
            {
                if (ds.Tables[count].Rows.Count > 0)
                {
                    DataTable cdt = ds.Tables[count].Copy();

                    resultDS.Tables.Add(cdt);
                    resultDS.AcceptChanges();
                }
            }
            if (resultDS.Tables.Count > 0)
            {
                for (int num = 0; num < resultDS.Tables[0].Rows.Count; num++)
                {
                    DataRow dr = dt.NewRow();
                    dr[1] = ConvertCode(resultDS.Tables[0].Rows[num][1].ToString());
                    int cnt = 0;
                    for (int tbcount = 0; tbcount < resultDS.Tables.Count; tbcount++)
                    {
                        cnt += Convert.ToInt32(resultDS.Tables[tbcount].Rows[num][0].ToString());
                    }
                    dr[0] = cnt.ToString();
                    dt.Rows.Add(dr);
                    dt.AcceptChanges();
                }

                string zoneJson = string.Empty;
                zoneJson = "{\"data\": {";
                for (int count = 0; count < dt.Rows.Count; count++)
                {
                    zoneJson += "\"" + dt.Rows[count][1].ToString() + "\":\"";

                    zoneJson += dt.Rows[count][0].ToString() + ",";

                    zoneJson = zoneJson.Substring(0, zoneJson.Length - 1) + "\",";
                }
                zoneJson = zoneJson.Substring(0, zoneJson.Length - 1) + "}}";
             
                return zoneJson;
            }

            //string zoneJson = string.Empty;
            //zoneJson = "{\"data\": {";
            //for (int count = 0; count < dt.Rows.Count; count++)
            //{
            //    zoneJson += "\"" + dt.Rows[count][1].ToString() + "\":\"";

            //    zoneJson += dt.Rows[count][0].ToString() + ",";

            //    zoneJson = zoneJson.Substring(0, zoneJson.Length - 1) + "\",";
            //}
            //zoneJson = zoneJson.Substring(0, zoneJson.Length - 1) + "}}";
            //int lenth = zoneJson.ToString().Length;
            //return zoneJson;
             return null;
        }

        //把中午地区转换为编码，格式由vectormap定义
        protected string ConvertCode(string zone)
        {
            string code = string.Empty;

            switch (zone)
            {
                case "香港": code = "HKG";
                    break;
                case "海南": code = "HAI";
                    break;
                case "云南": code = "YUN";
                    break;
                case "北京": code = "BEJ";
                    break;
                case "天津": code = "TAJ";
                    break;
                case "新疆": code = "XIN";
                    break;
                case "西藏": code = "TIB";
                    break;
                case "青海": code = "QIH";
                    break;
                case "甘肃": code = "GAN";
                    break;
                case "内蒙古": code = "NMG";
                    break;
                case "宁夏": code = "NXA";
                    break;
                case "山西": code = "SHX";
                    break;
                case "辽宁": code = "LIA";
                    break;
                case "吉林": code = "JIL";
                    break;
                case "黑龙江": code = "HLJ";
                    break;
                case "河北": code = "HEB";
                    break;
                case "山东": code = "SHD";
                    break;
                case "河南": code = "HEN";
                    break;
                case "陕西": code = "SHA";
                    break;
                case "四川": code = "SCH";
                    break;
                case "重庆": code = "CHQ";
                    break;
                case "湖北": code = "HUB";
                    break;
                case "安徽": code = "ANH";
                    break;
                case "江苏": code = "JSU";
                    break;
                case "上海": code = "SHH";
                    break;
                case "浙江": code = "ZHJ";
                    break;
                case "福建": code = "FUJ";
                    break;
                case "台湾": code = "TAI";
                    break;
                case "江西": code = "JXI";
                    break;
                case "湖南": code = "HUN";
                    break;
                case "贵州": code = "GUI";
                    break;
                case "广西": code = "GXI";
                    break;
                case "广东": code = "GUD";
                    break;
                case "澳门": code = "MAC";
                    break;
                default:
                    break;
            }

            return code;
        }

        //清理缓存
        //[HttpPost, ActionName("ClearCache")]
        //public string ClearCache(string urlArr)
        //{
        //    if (urlArr.Trim().IndexOf('\n') > 0)
        //    {
        //        urlArr = urlArr.Trim().Replace('\n',',');
        //    }
        //    System.Net.WebClient clinet = new System.Net.WebClient();
        //    string url = "http://cdnmgr.efly.cc/cdn_server_admin/webcdn_cache_mgr.php?opcode=cache_purge&pass=" + HttpContext.Session["pwd"].ToString() + "&user=" + HttpContext.Session["user"].ToString() + "&url=" + urlArr + "&callback=?";
        //    System.IO.Stream stream = clinet.OpenRead(url);
        //    System.IO.StreamReader reader = new System.IO.StreamReader(stream, Encoding.GetEncoding("UTF-8"));
        //    string result = reader.ReadToEnd();
        //    clinet.Dispose();
        //    if (!string.IsNullOrEmpty(result))
        //    {
        //        if (result.IndexOf("\"result\":\"0\"") > 0)
        //        {
        //            return "清除成功！";
        //        }
        //    }
        //    return "清除失败！";
        //}


        [HttpPost, ActionName("ClearCache")]
        public string ClearCache(string urlArr)
        {
            if (HttpContext.Session["user"] == null)
            {
              //  return RedirectToAction("LogTimeOut", "Home");
                return "error";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.CATCHMGR_SERVER);
                   // MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    if (urlArr.Trim().IndexOf('\n') > 0)
                    {
                        urlArr = urlArr.Trim().Replace('\n', ',');
                    }

                    string[] url = urlArr.Split(',');
                    string owner = HttpContext.Session["user"].ToString();

                    for (int i = 0; i < url.Length; i++)
                    {
                        strSql.Remove(0, strSql.Length);
                        // strSql.Append("insert into `url_purge`(`url`,`owner`,`start_time`,`status`) values('" + url[i].ToString() + "','" + owner + "','" + DateTime.Now.ToString() + "','true')");
                        strSql.Append("insert into `web_cache_mgr`(`url`,`url_type`,`owner`,`type`,`status`) values('" + url[i].ToString() + "','single','" + owner + "','clean','ready') ");
                        strSql.Append(" ON DUPLICATE KEY UPDATE `url_type`='single', `owner`='" + owner + "',`type`='clean',`status`='ready', `finish_time`=NULL ");

                        MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
  
                    conn.Close();
                    /////////////////////////////////////
                    conn.Open();
                    ViewData["user"] = HttpContext.Session["user"].ToString();
                    ViewData["pwd"] = HttpContext.Session["pwd"].ToString();

                    List<CatchMgrModels> data = new List<CatchMgrModels>();
                    try
                    {
                        strSql.Remove(0, strSql.Length);
                        //strSql.Append("select `url`,`owner`,`start_time`,`status` from `url_purge` where `status`='true' and `owner` ='" + ViewData["user"].ToString() + "';");
                        strSql.Append("select `url`,`owner`,`start_time`,`status` from `web_cache_mgr` where `type`='clean' and `owner` ='" + ViewData["user"].ToString() + "';");
                        DataSet catchMgrDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                       // DataSet catchMgrDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                        if (catchMgrDs.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dr in catchMgrDs.Tables[0].Rows)
                            {
                                CatchMgrModels item = new CatchMgrModels();
                                item.url = dr["url"].ToString();
                                item.owner = dr["owner"].ToString();
                                item.start_time = dr["start_time"].ToString();
                                if (dr["status"].ToString() != "finish")
                                {
                                    item.status = "正在清理中";
                                }
                                else
                                {
                                    item.status = "清理完成";
                                }
                                data.Add(item);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    return   "ok";

                }
                catch (Exception e)
                {
                    throw e;
                }
               
            }
        }

        [HttpPost, ActionName("ClearPathCache")]
        public string ClearPathCache(string urlArr)
        {
            if (HttpContext.Session["user"] == null)
            {
                // return RedirectToAction("LogTimeOut", "Home");
                return "error";
            }
            else
            {
                try
                {
                   MySqlConnection conn = new MySqlConnection(Core.MySqlConn.CATCHMGR_SERVER);
                    // MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    if (urlArr.Trim().IndexOf('\n') > 0)
                    {
                        urlArr = urlArr.Trim().Replace('\n', ',');
                    }

                    string[] url = urlArr.Split(',');
                    string owner = HttpContext.Session["user"].ToString();

                    for (int i = 0; i < url.Length; i++)
                    {
                        strSql.Remove(0, strSql.Length);
                       // strSql.Append("insert into `path_url_purge`(`url`,`owner`,`start_time`,`status`) values('" + url[i].ToString() + "','" + owner + "','" + DateTime.Now.ToString() + "','true')");
                        strSql.Append("insert into `web_cache_mgr`(`url`,`url_type`,`owner`,`type`,`status`) values('" + urlArr.ToString() + "','path','" + owner + "','clean','ready')");
                        strSql.Append(" ON DUPLICATE KEY UPDATE `url_type`='path', `owner`='" + owner + "',`type`='clean',`status`='ready', `finish_time`=NULL  ");
                        //strSql.Append("select `url`,`owner`,`start_time`,`status` from `web_cache_mgr` where `type`='clean' `owner` ='" + ViewData["user"].ToString() + "';");
                        MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
                    conn.Close();
                    /////////////////////////////////////
                    conn.Open();
                    ViewData["user"] = HttpContext.Session["user"].ToString();
                    ViewData["pwd"] = HttpContext.Session["pwd"].ToString();

                    List<CatchMgrModels> data = new List<CatchMgrModels>();
                    try
                    {
                        strSql.Remove(0, strSql.Length);
                      //  strSql.Append("select `url`,`owner`,`start_time`,`status` from `path_url_purge` where `status`='true' and `owner` ='" + ViewData["user"].ToString() + "';");
                        strSql.Append("select `url`,`owner`,`start_time`,`status` from `web_cache_mgr` where `type`='clean' and `owner` ='" + ViewData["user"].ToString() + "';");
                        DataSet catchMgrDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.CATCHMGR_SERVER, strSql.ToString());
                       // DataSet catchMgrDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                        if (catchMgrDs.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow dr in catchMgrDs.Tables[0].Rows)
                            {
                                CatchMgrModels item = new CatchMgrModels();
                                item.url = dr["url"].ToString();
                                item.owner = dr["owner"].ToString();
                                item.start_time = dr["start_time"].ToString();
                                if (dr["status"].ToString() != "finish")
                                {
                                    item.status = "正在清理中";
                                }
                                else
                                {
                                    item.status = "清理完成";
                                }
                                data.Add(item);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                    return "ok";

                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        [HttpPost, ActionName("ClearRecord")]
        public string ClearRecord()
        {
            if (HttpContext.Session["user"] == null)
            {
                // return RedirectToAction("LogTimeOut", "Home");
                return "error";
            }
            else
            {
                try
                {
                    //MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.CATCHMGR_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();

                    string owner = HttpContext.Session["user"].ToString();

                    strSql.Append("delete from `web_cache_mgr` where `status`='finish' and `owner` ='" + owner + "';");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();

                    conn.Close();

                    return "ok";

                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        //命中率统计
        [HttpPost, ActionName("GetPieChartData")]
        public string GetPieChartData(string domain)
        {
            //string portStr = GetPort(HttpContext.Session["user"].ToString(), domain.Trim());
            //string sql = "select * from client_hit where port in(" + portStr + ")";
            if (domain == "全部")
            {
                string hostnameStr = GetHostnameByDomain(domain.Trim());
                if (!string.IsNullOrEmpty(hostnameStr))
                {
                    string[] arr = hostnameStr.Split(',');
                    double ct_req_rs = 0;
                    double ct_sent_rs = 0;
                    double cnc_req_rs = 0;
                    double cnc_sent_rs = 0;
                    double mobil_req_rs = 0;
                    double mobil_sent_rs = 0;
                    int ct_num = 0;
                    int cnc_num = 0;
                    int mobil_num = 0;
                    for (int i = 0; i < arr.Length; i++)
                    {
                        string sql = "select * from client_hit_ex where `hostname` like '" + arr[i] + "' and `ip` in('112.90.177.77','116.28.64.173','221.181.65.118') order by `timestamp`"; // LIMIT 1 OFFSET 0
                        DataSet ds = MySqlHelper.ExecuteDataset(MySqlConn.HIT_SERVER, sql);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int n = 0; n < ds.Tables[0].Rows.Count; n++)
                            {
                                if (ds.Tables[0].Rows[n]["ip"].ToString() == "116.28.64.173") //电信
                                {
                                    ct_req_rs += double.Parse(ds.Tables[0].Rows[n]["reqhit"].ToString());
                                    ct_sent_rs += double.Parse(ds.Tables[0].Rows[n]["senthit"].ToString());
                                    ct_num++;
                                }
                                else if (ds.Tables[0].Rows[n]["ip"].ToString() == "112.90.177.77") //网通
                                {
                                    cnc_req_rs += double.Parse(ds.Tables[0].Rows[n]["reqhit"].ToString());
                                    cnc_sent_rs += double.Parse(ds.Tables[0].Rows[n]["senthit"].ToString());
                                    cnc_num++;
                                }
                                else  //移动
                                {
                                    mobil_req_rs += double.Parse(ds.Tables[0].Rows[n]["reqhit"].ToString());
                                    mobil_sent_rs += double.Parse(ds.Tables[0].Rows[n]["senthit"].ToString());
                                    mobil_num++;
                                }
                            }
                        }
                    }
                    StringBuilder json = new StringBuilder();
                    json.Append("[");
                    json.Append("['点击命中'," + (ct_req_rs / ct_num) + "],");
                    json.Append("['没有命中'," + (100 - ct_req_rs / ct_num).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['内容命中'," + (ct_sent_rs / ct_num).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - ct_sent_rs / ct_num).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['点击命中'," + (cnc_req_rs / cnc_num).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - cnc_req_rs / cnc_num).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['内容命中'," + (cnc_sent_rs / cnc_num).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - cnc_sent_rs / cnc_num).ToString("F2") + "]");

                    json.Append("]#[");
                    json.Append("['点击命中'," + (mobil_req_rs / mobil_num).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - mobil_req_rs / mobil_num).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['内容命中'," + (mobil_sent_rs / mobil_num).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - mobil_sent_rs / mobil_num).ToString("F2") + "]");

                    json.Append("]");
                    return json.ToString();
                }
            }
            else
            {
                //string hostname = GetHostnameByDomain(domain.Trim());
                string sql = "select * from client_hit_ex where `hostname` like '" + domain.Replace('*', '%').Trim() + "' and `ip` in('112.90.177.77','116.28.64.173','221.181.65.118') order by `timestamp`"; // LIMIT 1 OFFSET 0
                DataSet ds = MySqlHelper.ExecuteDataset(MySqlConn.HIT_SERVER, sql);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    double ct_req_rs = 0;
                    double ct_sent_rs = 0;
                    double cnc_req_rs = 0;
                    double cnc_sent_rs = 0;
                    double mobil_req_rs = 0;
                    double mobil_sent_rs = 0;
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (ds.Tables[0].Rows[i]["ip"].ToString() == "116.28.64.173") //电信
                        {
                            ct_req_rs = double.Parse(ds.Tables[0].Rows[i]["reqhit"].ToString());
                            ct_sent_rs = double.Parse(ds.Tables[0].Rows[i]["senthit"].ToString());
                        }
                        else if (ds.Tables[0].Rows[i]["ip"].ToString() == "112.90.177.77") //网通
                        {
                            cnc_req_rs = double.Parse(ds.Tables[0].Rows[i]["reqhit"].ToString());
                            cnc_sent_rs = double.Parse(ds.Tables[0].Rows[i]["senthit"].ToString());
                        }
                        else 
                        {
                            mobil_req_rs = double.Parse(ds.Tables[0].Rows[i]["reqhit"].ToString());
                            mobil_sent_rs = double.Parse(ds.Tables[0].Rows[i]["senthit"].ToString());
                        }
                    }
                    StringBuilder json = new StringBuilder();
                    json.Append("[");
                    json.Append("['点击命中'," + (ct_req_rs) + "],");
                    json.Append("['没有命中'," + (100 - ct_req_rs).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['内容命中'," + (ct_sent_rs).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - ct_sent_rs).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['点击命中'," + (cnc_req_rs).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - cnc_req_rs).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['内容命中'," + (cnc_sent_rs).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - cnc_sent_rs).ToString("F2") + "]");

                    json.Append("]#[");
                    json.Append("['点击命中'," + (mobil_req_rs).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - mobil_req_rs).ToString("F2") + "]");
                    json.Append("]#[");
                    json.Append("['内容命中'," + (mobil_sent_rs).ToString("F2") + "],");
                    json.Append("['没有命中'," + (100 - mobil_sent_rs).ToString("F2") + "]");

                    json.Append("]");
                    return json.ToString();
                }
            }
            return "";
        }

        //峰值统计
        [HttpPost, ActionName("GetTopStream")]
        public string GetTopStream(string start, string span, string domain, int bfb)
        {
            if (string.IsNullOrEmpty(HttpContext.Session["user"].ToString()))
            {
                return "TimeOut";
            }
            else
            {
                DateTime _start = DateTime.Parse(start.Trim());
                string _span = span.Trim();
                string conStr = Core.MySqlConn.GetStatsConn();
                //string portStr = GetPort(HttpContext.Session["user"].ToString(), domain.Trim());
                string domainStr;
                if (domain == "全部")
                {
                    domainStr = GetDomainByUser(HttpContext.Session["user"].ToString());
                }
                else
                {
                    domainStr = "'" + domain.Trim() + "'";
                }
                if (!string.IsNullOrEmpty(domainStr))
                {
                    string[] domArr = SplitDomain(domainStr);
                    List<TrafficModels> Data_Is = new List<TrafficModels>();
                    List<TrafficModels> Data_No = new List<TrafficModels>();
                    if (!string.IsNullOrEmpty(domArr[1])) //没有*的
                    {
                        GetRptData DoGetData = new GetRptData();
                        if (span == "一天")
                        {
                            Data_No = DoGetData.GetTopRpt(_start, 0, domainStr);
                        }
                        if (span == "一周")
                        {
                            Data_No = DoGetData.GetTopRpt(_start, 7, domainStr);
                        }
                        if (span == "一月")
                        {
                            Data_No = DoGetData.GetTopRpt(_start, 30, domainStr);
                        }
                    }
                    if (!string.IsNullOrEmpty(domArr[0])) //有*的
                    {
                        GetXinRptData DoGetData = new GetXinRptData();
                        if (span == "一天")
                        {
                            Data_Is = DoGetData.GetTopRpt(_start, 0, domainStr);
                        }
                        if (span == "一周")
                        {
                            Data_Is = DoGetData.GetTopRpt(_start, 7, domainStr);
                        }
                        if (span == "一月")
                        {
                            Data_Is = DoGetData.GetTopRpt(_start, 30, domainStr);
                        }
                    }
                    List<TrafficModels> Data = new List<TrafficModels>();
                    if (Data_No != null && Data_No.Count > 0)
                    {
                        if (Data == null || Data.Count == 0)
                        {
                            Data.AddRange(Data_No);
                        }
                        else
                        {
                            for (int i = 0; i < Data_No.Count; i++)
                            {
                                //Data[i].in_value += Data_No[i].in_value;
                                Data[i].out_value += Data_No[i].out_value;
                            }
                        }
                    }
                    if (Data_Is != null && Data_Is.Count > 0)
                    {
                        if (Data == null || Data.Count == 0)
                        {
                            Data.AddRange(Data_Is);
                        }
                        else
                        {
                            for (int i = 0; i < Data_Is.Count; i++)
                            {
                                //Data[i].in_value += Data_No[i].in_value;
                                Data[i].out_value += Data_Is[i].out_value;
                            }
                        }
                    }
                    List<TrafficModels> outList = new List<TrafficModels>();
                    if (Data != null)
                    {
                        Data.Sort(new TrafficOutComparer());
                        foreach (TrafficModels item in Data)
                        {
                            item.out_value = item.out_value * 1.2;
                            item.in_value = item.in_value * 1.2;
                            outList.Add(item);
                        }
                       // int start_out_num = Convert.ToInt16(outList.Count * ((bfb - 1) / 100.0));
                       // int end_out_num = Convert.ToInt16(outList.Count * ((bfb + 1) / 100.0));

                        int start_out_num = Convert.ToInt16(outList.Count * ((99 - bfb) / 100.0));
                        int end_out_num = Convert.ToInt16(outList.Count * ((101 - bfb) / 100.0));

                        int getX = Convert.ToInt16(outList.Count * ( (100-bfb) / 100.0));

                        List<TrafficModels> rslt_outList = new List<TrafficModels>();
                        for (int x = start_out_num; x < end_out_num; x++)
                        {
                            //double s = x / Convert.ToDouble(outList.Count) * 100.0;
                            double s = 100.0 - x / Convert.ToDouble(outList.Count) * 100.0;
                            outList[x].bfb = s.ToString("F2") + "%";
                           
                            if (x == getX)
                            {
                                outList[x].bfb = bfb.ToString() + "%";
                                rslt_outList.Add(outList[x]);
                            }

                           // rslt_outList.Add(outList[x]);
                        }
                        return GetTopJson(rslt_outList);
                    }
                }
                return "[]|[]";
            }
        }

        //获取chart数据
        [HttpPost, ActionName("GetChartDataByServer")]
        public string GetChartDataByServer(string area, string day, int span, string domain)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                if (!string.IsNullOrEmpty(domain))
                {
                    //string portStr = GetPort(HttpContext.Session["user"].ToString(), domain.Trim());
                    string domainStr;
                    if (domain == "全部")
                    {
                        domainStr = GetDomainByUser(HttpContext.Session["user"].ToString());
                    }
                    else
                    {
                        domainStr = "'" + domain.Trim() + "'";
                    }
                    GetRptData getData = new GetRptData();
                    GetXinRptData getXinData = new GetXinRptData();
                    List<TrafficModels> result = new List<TrafficModels>();
                    string[] domArr = SplitDomain(domainStr);
                    if (!string.IsNullOrEmpty(domArr[0])) //有*的
                    {
                        string[] dom_item_Arr = domArr[0].Split(',');
                        foreach (string dom_item in dom_item_Arr)
                        {
                            List<TrafficModels> itemdata = getXinData.GetRptDataList(DateTime.Parse(day), span, dom_item);
                            if (itemdata != null && itemdata.Count > 0)
                            {
                                if (result == null || result.Count == 0)
                                {
                                    result.AddRange(itemdata);
                                }
                                else
                                {
                                    for (int i = 0; i < itemdata.Count; i++)
                                    {
                                        result[i].in_value += itemdata[i].in_value;
                                        result[i].out_value += itemdata[i].out_value;
                                    }
                                }
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(domArr[1])) //没有*的
                    {
                        List<TrafficModels> itemdata = getData.GetRptDataList(DateTime.Parse(day), span, domArr[1]);
                        if (itemdata != null && itemdata.Count > 0)
                        {
                            if (result == null || result.Count == 0)
                            {
                                result.AddRange(itemdata);
                            }
                            else
                            {
                                for (int i = 0; i < itemdata.Count; i++)
                                {
                                    result[i].in_value += itemdata[i].in_value;
                                    result[i].out_value += itemdata[i].out_value;
                                }
                            }
                        }
                    }
                    return GetChartJson(result);
                }
                return "查询条件为空！";
            }
        }

        //获取服务器列表
        [HttpPost, ActionName("GetServerList")]
        public string GetServerList(string host)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("SELECT `ip`,`nettype`,`zone`,`desc` FROM `server_list` where `type`='internal_dns_master'");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        string returnStr = "";
                        for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                        {
                            if (i == 0)
                            {
                                returnStr = Ds.Tables[0].Rows[i]["ip"].ToString() + "," + Ds.Tables[0].Rows[i]["nettype"].ToString() + "," + Ds.Tables[0].Rows[i]["zone"].ToString() + "," + Ds.Tables[0].Rows[i]["desc"].ToString();
                            }
                            else
                            {
                                returnStr += "|";
                                returnStr += Ds.Tables[0].Rows[i]["ip"].ToString() + "," + Ds.Tables[0].Rows[i]["nettype"].ToString() + "," + Ds.Tables[0].Rows[i]["zone"].ToString() + "," + Ds.Tables[0].Rows[i]["desc"].ToString();
                            }
                        }
                        return returnStr;
                    }
                    return "";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        //获取用户某个服务器下的域名列表
        [HttpPost, ActionName("GetClienDnsList")]
        public string GetClienDnsList(string serverType, string host)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                try
                {
                    //string conn = GetDbConnStr(serverIp.Trim());
                    string conn;

                    if (serverType == "cnc")
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_cnc;charset=gbk;";
                    }
                    else
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_ct;charset=gbk;";
                    }

                    
                    string TbStr = GetTableByHost(host.Trim());
                    if (!string.IsNullOrEmpty(conn) && !string.IsNullOrEmpty(TbStr))
                    {
                        StringBuilder strSql = new StringBuilder();
                        strSql.Append("select * from `" + TbStr + "` where `rdtype` = 'A' and `name` not like 'ns.%'");
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql.ToString());
                        string returnStr = "";
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                            {
                                if (i == 0)
                                {
                                    returnStr = Ds.Tables[0].Rows[i]["id"].ToString() + "," + Ds.Tables[0].Rows[i]["name"].ToString() + "," + Ds.Tables[0].Rows[i]["ttl"].ToString() + "," + Ds.Tables[0].Rows[i]["rdata"].ToString();
                                }
                                else
                                {
                                    returnStr += "|";
                                    returnStr += Ds.Tables[0].Rows[i]["id"].ToString() + "," + Ds.Tables[0].Rows[i]["name"].ToString() + "," + Ds.Tables[0].Rows[i]["ttl"].ToString() + "," + Ds.Tables[0].Rows[i]["rdata"].ToString();
                                }
                            }
                        }
                       // ViewData["sType"] = serverType;
                        return returnStr;
                    }
                    return "";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        //用户添加某个服务器下的域名
        [HttpPost, ActionName("AddClienDns")]
        public string AddClienDns(string serverHost, string serverType, string host, int ttl, string ip)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                try
                {
                   // string conn = GetDbConnStr(serverIp.Trim());
                    string conn;

                    if (serverType == "cnc")
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_cnc;charset=gbk;";
                    }
                    else
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_ct;charset=gbk;";
                    }
                    
                    string TbStr = GetTableByHost(serverHost.Trim());
                    if (!string.IsNullOrEmpty(conn) && !string.IsNullOrEmpty(TbStr))
                    {
                        if (DoAddClienDns(conn, TbStr, host.Trim(), ttl, ip.Trim()))
                        {
                            return "添加成功！";
                        }
                    }
                    return "添加失败！";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        [HttpPost, ActionName("EditClienDns")]
        public string EditClienDns(string serverHost, string serverType, string host, int ttl, string ip, int id)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                try
                {
                    //string conn = GetDbConnStr(serverIp.Trim());
                    string conn;

                    if (serverType == "cnc")
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_cnc;charset=gbk;";
                    }
                    else
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_ct;charset=gbk;";
                    }
                    
                    string TbStr = GetTableByHost(serverHost.Trim());
                    if (!string.IsNullOrEmpty(conn) && !string.IsNullOrEmpty(TbStr))
                    {
                        if (DoEditClientDns(conn, TbStr, host.Trim(), ttl, ip.Trim(), id))
                        {
                            return "保存成功！";
                        }
                    }
                    return "保存失败！";
                }
                catch 
                {
                    return "Error";
                }
            }
        }

        //用户删除某个服务器下的域名
        [HttpPost, ActionName("DeleClienDns")]
        public string DeleClienDns(string serverHost, string serverType, int id)
        {
            if (HttpContext.Session["user"] == null)
            {
                return "TimeOut";
            }
            else
            {
                try
                {
                    //string conn = GetDbConnStr(serverIp.Trim());

                    string conn;

                    if (serverType == "cnc")
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_cnc;charset=gbk;";
                    }
                    else
                    {
                        conn = "Host=squiddns.data.efly.cc;User Id=dnsadmin;password=dnsadmin;Database=squid_dns_ct;charset=gbk;";
                    }

                    string TbStr = GetTableByHost(serverHost.Trim());
                    if (!string.IsNullOrEmpty(conn) && !string.IsNullOrEmpty(TbStr))
                    {
                        if (DoDelClienDns(conn, TbStr, id))
                        {
                            return "删除成功！";
                        }
                    }
                    return "删除失败！";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        //查询单个域名下载及总流量
        [HttpPost, ActionName("GetHostTotal")]
        public string GetHostTotal(string start, string end, string Host)
        {
            if (string.IsNullOrEmpty(HttpContext.Session["user"].ToString()))
            {
                return "TimeOut";
            }
            else
            {
                DateTime s = DateTime.Parse(start.Trim());
                DateTime e = DateTime.Parse(end.Trim());
                TimeSpan span = e - s;
                string conStr = Core.MySqlConn.GetStatsConn().Replace("cdn_portrate_stats", "cdn_client_traffic");
               // int port = GetPortByHost(Host.Trim());
                if (conStr.Length > 0)
                {
                    if (span.TotalDays > 0)  //超过一天
                    {
                        List<HostTotalModels> data = new List<HostTotalModels>();
                        StringBuilder result = new StringBuilder();
                        for (int i = 0; i <= span.TotalDays; i++)
                        {
                            if (TableIsExist(s.AddDays(i), conStr))
                            {
                                HostTotalModels item = new HostTotalModels();
                                item = GetSingleHostTotal(conStr, s.AddDays(i), Host.Trim());
                                data.Add(item);
                            }
                            else
                            {
                                continue;
                            }
                        }
                        if (data != null)
                        {
                            Double totalStream = 0;
                            foreach (HostTotalModels obj in data)
                            {
                                totalStream += obj.totalStream;
                            }
                            return (totalStream).ToString("F4");
                        }
                    }
                    else       //查询一天
                    {
                        if (TableIsExist(s, conStr))  //表存在
                        {
                            HostTotalModels model = new HostTotalModels();
                            model = GetSingleHostTotal(conStr, s, Host.Trim());
                            if (model != null)
                            {
                                return (model.totalStream).ToString("F4");
                            }
                        }
                    }
                }
                return "";
            }
        }

        //private method
        private Hashtable GetIpNettypeMap()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `nettype`,`ip`,`port` FROM `server_list` where `type`='report' order by `nettype`");
               // strSql.Append("SELECT `nettype`,`ip`,`port` FROM `server_list` where `type`='cdn_stats' order by `nettype`");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable ret = new Hashtable();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret.Add(dr["ip"].ToString(), dr["nettype"].ToString());
                    }
                    return ret;
                }
            }
            catch { }
            return null;
        }
        private Hashtable GetIpAreaMap()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `zone`,`ip`,`port` FROM `server_list` where `type`='report' order by `zone`");
             //   strSql.Append("SELECT `zone`,`ip`,`port` FROM `server_list` where `type`='cdn_stats' order by `zone`");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    Hashtable ret = new Hashtable();
                    foreach(DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret.Add(dr["ip"].ToString(), dr["zone"].ToString());
                    }
                    return ret;
                }
            }
            catch { }
            return null;
        }

        //获取该用户的域名
        private string GetDomainByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `hostname` FROM `user_hostname` where `owner` ='" + user + "' and `status` = 'true';");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string ret = "";
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret += "'" + dr["hostname"].ToString() + "',";
                    }
                    return ret.Substring(0, ret.Length - 1);
                }
                return "";
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //新的
        private List<AddrModels> GetHostListByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `hostname` FROM `user_hostname` where `owner`='" + user + "' and `status`='true'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<AddrModels> data = new List<AddrModels>();
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        AddrModels item = new AddrModels();
                        item.hostname = Ds.Tables[0].Rows[i]["hostname"].ToString();
                        data.Add(item);
                    }
                    return data;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //
        private string GetHostnameByDomain(string domain)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                if (domain == "全部")
                {
                    strSql.Append("SELECT `hostname` FROM `user_hostname` where `owner` ='" + HttpContext.Session["user"].ToString() + "' and `status` = 'true';");
                }
                else
                {
                    strSql.Append("SELECT `hostname` FROM `user_hostname` where `domainname` ='" + domain + "' and `status` = 'true';");
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string ret = "";
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret += dr["hostname"].ToString() + ",";
                    }
                    return ret.Substring(0, ret.Length - 1).Replace("*", "%");
                }
                return "";
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        //根据日期判断数据库是否存在该表
        private bool TableIsExist(DateTime date, string conn)
        {
            try
            {
                string strSql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        //根据域名判断数据库是否存在该表
        private bool TableIsExistByDomain(string domain, string conn)
        {
            try
            {
                string strSql = "SHOW TABLES like " + domain + "";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        public class TrafficInComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.in_value.CompareTo(x.in_value));
            }
        }

        public class TrafficOutComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.out_value.CompareTo(x.out_value));
            }
        }


        //查询单个域名下载及总流量
        private HostTotalModels GetSingleHostTotal(string conn, DateTime _tb, string _domain)
        {
            string sql = "SELECT sum(traffic)/1024/1024 FROM `" + _tb.ToString("yyyy-MM-dd") + "` where `hostname` like '%." + _domain + "'";
            DataSet ds = MySqlHelper.ExecuteDataset(conn, sql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                HostTotalModels obj = new HostTotalModels();
                //obj.totalPv = Double.Parse(ds.Tables[0].Rows[0][0].ToString());
                //obj.totalNum = Double.Parse(ds.Tables[0].Rows[0][1].ToString());
                try
                {
                    obj.totalStream = string.IsNullOrEmpty(ds.Tables[0].Rows[0][0].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][0].ToString());
                }
                catch
                {
                    obj.totalStream = 0;
                }
                return obj;
            }
            return null;
        }

        private bool DoEditClientDns(string conn, string tb, string host, int ttl, string ip, int id)
        {
            StringBuilder strSql = new StringBuilder();
            try
            {
                strSql.Append("update `" + tb + "` set `name`='" + host + "',`ttl`=" + ttl + ",`rdata`='" + ip + "' where id=" + id);
                int i = MySql.Data.MySqlClient.MySqlHelper.ExecuteNonQuery(conn, strSql.ToString());
                if (i == 1)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        private bool DoDelClienDns(string conn, string tb, int id)
        {
            StringBuilder strSql = new StringBuilder();
            try
            {
                strSql.Append("delete from `" + tb + "` where `id`=" + id);
                int i = MySql.Data.MySqlClient.MySqlHelper.ExecuteNonQuery(conn, strSql.ToString());
                if (i == 1)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
        //添加用户域名
        private bool DoAddClienDns(string conn, string tb, string host, int ttl, string ip)
        {
            StringBuilder strSql = new StringBuilder();
            try
            {
                strSql.Append("insert into `" + tb + "` (`name`,`ttl`,`rdtype`,`rdata`)values('" + host + "'," + ttl + ",'A','" + ip + "')");
                int i = MySql.Data.MySqlClient.MySqlHelper.ExecuteNonQuery(conn, strSql.ToString());
                if (i == 1)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        //根据用户名获取域名列表
        private List<AddrModels> GetHostListByName(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT distinct(`domainname`) FROM `user_hostname` where `owner`='" + user + "' and status='true'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<AddrModels> data = new List<AddrModels>();
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        AddrModels item = new AddrModels();
                        item.hostname = Ds.Tables[0].Rows[i]["domainname"].ToString();
                        //item.desc = Ds.Tables[0].Rows[i]["desc"].ToString();
                        data.Add(item);
                    }
                    return data;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //通过域名得到表名, 结果只有一个
        private string GetTableByHost(string host)
        {
            if (!string.IsNullOrEmpty(host))
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("SELECT `tablename` FROM `user_hostname` where `domainname`='" + host.Trim() + "' and status='true'");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        return Ds.Tables[0].Rows[0]["tablename"].ToString();
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return null;
        }

        //根据ip获取数据库连接
        private string GetDbConnStr(string ip)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `value` FROM `server_info` where `key`='dbinfo' and serverip='" + ip + "'");
                DataSet endDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                string result = ReplaceConn(endDs.Tables[0].Rows[0]["value"].ToString());
                return result;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //获取ip地址
        private string GetIpStr(string area)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                //strSql.Append("SELECT `ip`,`port` FROM `user_squid` where `user`='" + user + "'");
                if (area == "全部")
                {
                    strSql.Append("select `ip` from server_list where `type` = 'node'");
                }
                else
                {
                    strSql.Append("select `ip` from server_list where `type` = 'node' and `zone`='" + area + "'");
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result = "'" + Ds.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                        else
                        {
                            result += ",'";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                    }
                    return result;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //得到数据库里存在的天的表，cdn_server_stats
        private string GetDateTable()
        {
            try
            {
                string strSql = "SHOW TABLES";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetStatsConn(), strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result = Ds.Tables[0].Rows[i][0].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                    }
                    return result;
                }
            }
            catch
            {
                return "Error";
            }
            return "Null";
        }
        //根据用户的所有ip得到所拥有的（区域|ip）
        private string GetAreaByIp(string ip)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `zone`,`ip`,`port` FROM `server_list` where `ip` in(" + ip + ") ORDER BY `zone`");  // Group by `zone` and port in(" + port + ")
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result = Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                    }
                    return result;
                }
                return "";
            }
            catch
            {
                return null;
            }
        }

        //修改连接字符串
        private string ReplaceConn(string or_con)
        {
            //ip=116.28.65.245;port=3306;user=bind9;pass=bind9;
            //User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk
            string[] connArr = or_con.Split(';');
            if (connArr.Length >= 5)
            {
                connArr[0] = connArr[0].Replace("ip", "Host");
                connArr[2] = connArr[2].Replace("user", "User Id");
                connArr[3] = connArr[3].Replace("pass", "password");
                connArr[4] = connArr[4].Replace("db", "Database");
                return connArr[0] + ";" + connArr[2] + ";" + connArr[3] + ";" + connArr[4] + ";charset=gbk;";
            }
            else
            {
                return "";
            }
        }
        //图表专用
        private string GetChartJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                TrafficModels maxOutObj = new TrafficModels();
                TrafficModels maxInObj = new TrafficModels();
                string out_json = "";
                string in_json = "";
                foreach (TrafficModels model in t)
                {
                    if (model != t[t.Count - 1])
                    {
                        out_json += model.out_value * 1.2 + ",";
                        in_json += model.in_value * 1.2 + ",";
                    }
                    else
                    {
                        out_json += model.out_value;
                        in_json += model.in_value;
                    }
                    if (maxOutObj.out_value < model.out_value)
                    {
                        maxOutObj.out_value = model.out_value;
                        maxOutObj.time = model.time;
                    }
                    if (maxInObj.in_value < model.in_value)
                    {
                        maxInObj.in_value = model.in_value;
                        maxInObj.time = model.time;
                    }
                }
               // string ret_json = maxInObj.time + "," + maxInObj.in_value + "#[" + in_json + "]" + "|" + maxOutObj.time + "," + maxOutObj.out_value + "#[" + out_json + "]";
                string ret_json = maxInObj.time + "," + maxInObj.in_value * 1.2 + "#[" + in_json + "]" + "|" + maxOutObj.time + "," + maxOutObj.out_value * 1.2 + "#[" + out_json + "]";
                return ret_json;
            }
            catch
            {
                return "";
            }
        }
        //峰值统计专用
        private string GetTopJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                string json = "[";
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].in_value > 0 || t[i].out_value > 0)
                    {
                            json += "{ id: \"" + t[i].bfb + "\",";
                            json += "out_stream: \"" + t[i].out_value + "\",";
                            json += "in_stream: \"" + t[i].in_value + "\",";
                            json += "datetime: \"" + t[i].time + "\" },";
                    }
                }
                if (json.Length > 1)
                {
                    json = json.Substring(0, json.Length - 1) + "]";
                    return json.ToString();
                }
                return "[]";
            }
            catch
            {
                return "";
            }
        }

        //拆分星号和不带星号域名
        private string[] SplitDomain(string domain)
        {
            string[] arr = domain.Split(',');
            string IsDomstr="";
            string NoDomstr="";
            foreach(string s in arr)
            {
                if (s.IndexOf('*') >= 0)
                {
                    IsDomstr += s + ",";
                }
                else
                {
                    if (s.IndexOf('.') == 1)
                    {
                        string tem = s.Remove(1, 1);
                        NoDomstr += tem + ",";
                    }
                    else
                    {
                        NoDomstr += s + ",";
                    }
                }
            }
            string retIs = string.IsNullOrEmpty(IsDomstr) ? "" : IsDomstr.Substring(0, IsDomstr.Length - 1);
            string retNo = string.IsNullOrEmpty(NoDomstr) ? "" : NoDomstr.Substring(0, NoDomstr.Length - 1);
            string[] ret = new string[2] { retIs, retNo };
            return ret;
        }

        public ActionResult Download()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                string user = HttpContext.Session["user"].ToString();
                System.Net.WebClient clinet = new System.Net.WebClient();
                string url = "http://weblogdw.cdn.efly.cc/cdn_web_log/log_file_list.php?client="+user+"";
                System.IO.Stream stream = clinet.OpenRead(url);
                System.IO.StreamReader reader = new System.IO.StreamReader(stream, Encoding.GetEncoding("UTF-8"));
                string result = reader.ReadToEnd();
                ViewData["result"] = result;

                return View();
            }
        }
         // System.IO.File.AppendAllText("d:\\aa.txt", dns.Trim(),Encoding.UTF8);
        //文件上传
        public ActionResult Upload()
        {     
            string res = string.Empty;    
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
               // MySqlConnection conn = new MySqlConnection(Core.MySqlConn.CATCHMGR_SERVER);
                MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                StringBuilder strSql = new StringBuilder();

                string owner = HttpContext.Session["user"].ToString();
                

                foreach (string upload in Request.Files)
                {
                    if (upload.Trim().ToString().Length > 0)
                    {
                        conn.Open();

                        string miniType = Request.Files[upload].ContentType;
                        Stream fileStream = Request.Files[upload].InputStream;
                        string path = AppDomain.CurrentDomain.BaseDirectory + "files/";
                      //  string urlPath = "http://192.168.22.71:1882/" + "files/";
                       // string urlPath = "http://wqliu-pc:1882/" + "files/";
                        string urlPath = "http://cdn.efly.cc:4554/" + "files/";
                        string filename = Path.GetFileName(Request.Files[upload].FileName);
                        if (filename.Trim().Length > 0)
                        {
                            string sysFilename = "(update)" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + filename;
                            string url = Path.Combine(urlPath, sysFilename);
                            // url = url.Replace("//", "////");

                            Request.Files[upload].SaveAs(Path.Combine(path, sysFilename));

                            //strSql.Append("insert into `postfile_url_update`(`url`,`owner`,`start_time`,`status`) values('" + url.ToString() + "','" + owner + "','" + DateTime.Now.ToString() + "','true')");
                            strSql.Append("insert into `web_cache_mgr`(`url`,`url_type`,`owner`,`type`,`status`) values('" + url.ToString() + "','multi','" + owner + "','update','ready')");
                            strSql.Append(" ON DUPLICATE KEY UPDATE `url_type`='multi', `owner`='" + owner + "',`type`='update',`status`='ready', `finish_time`=NULL  ");
                           
                            MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            res = "up";
                        }
                        conn.Close();
                    }
                }
            }
            return RedirectToAction("CatchMgr", "CdnWeb", new { res = res });
        }

        public ActionResult Update()
        {
            string res = string.Empty;
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                MySqlConnection conn = new MySqlConnection(Core.MySqlConn.CATCHMGR_SERVER);
              //  MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                StringBuilder strSql = new StringBuilder();

                string owner = HttpContext.Session["user"].ToString();


                foreach (string upload in Request.Files)
                {
                    if (upload.Trim().ToString().Length > 0)
                    {
                        conn.Open();

                        string miniType = Request.Files[upload].ContentType;
                        Stream fileStream = Request.Files[upload].InputStream;
                        string path = AppDomain.CurrentDomain.BaseDirectory + "files/";
                       // string urlPath = "http://192.168.22.71:1882/" + "files/";
                      //  string urlPath = "http://wqliu-pc:1882/" + "files/";
                        string urlPath = "http://cdn.efly.cc:4554/" + "files/";
                        string filename = Path.GetFileName(Request.Files[upload].FileName);
                        if (filename.Trim().Length > 0)
                        {
                            string sysFilename = "(purge)" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + filename;
                            string url = Path.Combine(urlPath, sysFilename);
                            // url = url.Replace("//", "////");

                            Request.Files[upload].SaveAs(Path.Combine(path, sysFilename));

                            //strSql.Append("insert into `postfile_url_purge`(`url`,`owner`,`start_time`,`status`) values('" + url.ToString() + "','" + owner + "','" + DateTime.Now.ToString() + "','true')");
                            strSql.Append("insert into `web_cache_mgr`(`url`,`url_type`,`owner`,`type`,`status`) values('" + url.ToString() + "','multi','" + owner + "','clean','ready')");
                            strSql.Append(" ON DUPLICATE KEY UPDATE `url_type`='multi', `owner`='" + owner + "',`type`='clean',`status`='ready', `finish_time`=NULL  ");

                            MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            res = "up";
                        }
                        conn.Close();
                    }
                }
            }
            return RedirectToAction("CatchMgr", "CdnWeb", new { res = res });
        }

        public ActionResult Delete()
        {
            string res = string.Empty;
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
               MySqlConnection conn = new MySqlConnection(Core.MySqlConn.CATCHMGR_SERVER);
                // MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                StringBuilder strSql = new StringBuilder();

                string owner = HttpContext.Session["user"].ToString();


                foreach (string upload in Request.Files)
                {
                    if (upload.Trim().ToString().Length > 0)
                    {
                        conn.Open();

                        string miniType = Request.Files[upload].ContentType;
                        Stream fileStream = Request.Files[upload].InputStream;
                        string path = AppDomain.CurrentDomain.BaseDirectory + "files/";
                       // string urlPath = "http://192.168.22.71:1882/" + "files/";
                       // string urlPath = "http://wqliu-pc:1882/" + "files/";
                        string urlPath = "http://cdn.efly.cc:4554/" + "files/";
                        string filename = Path.GetFileName(Request.Files[upload].FileName);
                        if (filename.Trim().Length > 0)
                        {
                            string sysFilename = "(push)" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + filename;
                            string url = Path.Combine(urlPath, sysFilename);
                            // url = url.Replace("//", "////");

                            Request.Files[upload].SaveAs(Path.Combine(path, sysFilename));

                           // strSql.Append("insert into `postfile_url_push`(`url`,`owner`,`start_time`,`status`) values('" + url.ToString() + "','" + owner + "','" + DateTime.Now.ToString() + "','true')");
                            strSql.Append("insert into `web_cache_mgr`(`url`,`url_type`,`owner`,`type`,`status`) values('" + url.ToString() + "','multi','" + owner + "','push','ready')");
                            strSql.Append(" ON DUPLICATE KEY UPDATE `url_type`='multi', `owner`='" + owner + "',`type`='push',`status`='ready', `finish_time`=NULL  ");
                            
                            MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                            cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            res = "up";
                        }
                        conn.Close();
                    }
                }
            }
            return RedirectToAction("CatchMgr", "CdnWeb", new { res = res });
        }

    }
}
