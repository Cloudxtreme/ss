﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CDN_Web_Client.Controllers
{
    public class HelperController : Controller
    {
        //
        // GET: /Helper/

        public ActionResult Help()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult login()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult main()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult TrafficRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult TopStream()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult HitRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult VisitRpt()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

        public ActionResult CatchMgr()
        {
            if (HttpContext.Session["user"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                return View();
            }
        }

    }
}
