﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CDN_Web_Mgr.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;

namespace CDN_Web_Mgr
{
    /// <summary>
    /// GetUserListHandler 的摘要说明
    /// </summary>
    public class GetUserListHandler : IHttpHandler, System.Web.SessionState.IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            int parentId = -1;//默认为-1,如果请求参数不正确,将不返回任何值
            string resultStr = string.Empty;
            if (!string.IsNullOrEmpty(context.Request.QueryString["admin"])) //获用户名
            {
                if (context.Request.QueryString["admin"].ToString() == System.Web.HttpContext.Current.Session["admin"].ToString())
                {
                    parentId = 0;
                }
                if (context.Request.QueryString["admin"].ToString() == System.Web.HttpContext.Current.Session["admin"].ToString() && context.Request.QueryString["admin"].ToString() == "test")
                {
                    parentId = 1;
                }
            }
            if (parentId >= 0)
            {
                //此处省略得到数据列表的代码
                resultStr = "";
                if (context.Request.QueryString["type"].ToString() == "CdnWeb")
                {
                    resultStr += "[";
                    List<ClientModels> data = GetClientList();
                    foreach (ClientModels item in data)
                    {
                        resultStr += "{";
                        resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\", \"state\": \"closed\",\"children\": {3}", item.id.ToString(), item.name, "username", GetOpration(item.id, item.name, item.desc,item.mydesc));
                        resultStr += "},";
                    }
                    resultStr = resultStr.Substring(0, resultStr.Length - 1);
                    resultStr += "]";
                    resultStr = Regex.Replace(resultStr, @"\s", "   ");
                }
                else 
                {
                    resultStr += "[";
                    List<ClientModels> data = GetFileClientList();
                    foreach (ClientModels item in data)
                    {
                        resultStr += "{";
                        resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\", \"state\": \"closed\",\"children\": {3}", item.id.ToString(), item.name, "username", GetFileOpration(item.id, item.name, item.desc, parentId,item.mydesc));
                        resultStr += "},";
                    }
                    resultStr = resultStr.Substring(0, resultStr.Length - 1);
                    resultStr += "]";
                    resultStr = Regex.Replace(resultStr, @"\s", "   ");
                }
            }
            //最后返回json数据
            context.Response.ContentType = "text/plain";
            context.Response.Write(resultStr);
        }

        private List<ClientModels> GetFileClientList()
        {
            try
            {
                List<ClientModels> Data = new List<ClientModels>();
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `id`,`user`,`pass`,`status`,`stats`,`desc`,`mydesc` FROM `user`"); // where `status`='true'
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientModels item = new ClientModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["user"].ToString() + "【" + dr["desc"].ToString() + "】";
                        item.stats = dr["stats"].ToString();
                        item.status = dr["status"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.mydesc = dr["mydesc"].ToString();
                        Data.Add(item);
                    }
                    return Data;
                }
            }
            catch { }
            return null;
        }

        private string GetFileOpration(int id, string name, string desc, int right, string mydesc)
        {
            string resultStr = "";
            resultStr += "[";

            resultStr += "{";
            resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "查看信息", name + "|" + desc + "|" + mydesc);
            resultStr += "},";

            if (right == 1)
            {
                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "流量监控", name);
                resultStr += "},";

                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "流量统计", name);
                resultStr += "},";

                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "峰值统计", name);
                resultStr += "},";

                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "服务器管理", name);
                resultStr += "}";
            }
            else
            {
                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "流量监控", name);
                resultStr += "},";

                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "流量统计", name);
                resultStr += "},";

                resultStr += "{";
                resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "峰值统计", name);
                resultStr += "}";
            }

            resultStr += "]";
            return resultStr;
        }

        private List<ClientModels> GetClientList()
        {
            try
            {
                List<ClientModels> Data = new List<ClientModels>();
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `id`,`user`,`pass`,`status`,`desc`,`mydesc` FROM `user` where `status`='true'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientModels item = new ClientModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["user"].ToString() + "【" + dr["desc"].ToString() + "】";
                        //item.password = dr["pass"].ToString();
                        item.status = dr["status"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.mydesc = dr["mydesc"].ToString();
                        Data.Add(item);
                    }
                    return Data;
                }
            }
            catch { }
            return null;
        }

        private string GetOpration(int id, string name, string desc,string mydesc)
        {
            string resultStr = "";
            resultStr += "[";

            resultStr += "{";
            resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "查看信息", name + "|" + desc + "|" + mydesc);
            resultStr += "},";

            resultStr += "{";
            resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "流量监控", name);
            resultStr += "},";

            resultStr += "{";
            resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "流量统计", name);
            resultStr += "},";

            resultStr += "{";
            resultStr += string.Format("\"id\": \"{0}\", \"text\": \"{1}\", \"attributes\": \"{2}\"", id.ToString(), "峰值统计", name);
            resultStr += "}";

            resultStr += "]";
            return resultStr;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}