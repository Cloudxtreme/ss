﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Web_Mgr.Models
{
    public class HostTotalModels
    {
        public Double totalNum { get; set; }

        public Double totalStream { get; set; }
    }
}