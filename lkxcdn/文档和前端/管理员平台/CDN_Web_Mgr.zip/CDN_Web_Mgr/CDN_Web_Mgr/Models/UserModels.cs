﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CDN_Web_Mgr.Models
{
    public class UserModels
    {
        public int id { get; set; }

        public string name { get; set; }

        public string password { get; set; }

        public string status { get; set; }

        public string domain { get; set; }

        public string saler { get; set; }

        public string linkphone { get; set; }

        public string mydesc { get; set; }

        public string puser { get; set; }
    }
}