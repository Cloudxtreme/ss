﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Web_Mgr.Models
{
    public class ClientModels
    {
        public int id { get; set; }

        public string name { get; set; }

        public int nginxport { get; set; }

        public string password { get; set; }

        public string status { get; set; }

        public string stats { get; set; }

        public string desc { get; set; }

        public string mydesc { get; set; }
    }
}