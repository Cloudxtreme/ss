﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CDN_Web_Mgr.Models
{
    public class HitModels
    {
        public string hostname { get; set; }

        public string nettype { get; set; }

        public string req_hit { get; set; }

        public string sent_hit { get; set; }

        public DateTime updateTime { get; set; }
    }
}