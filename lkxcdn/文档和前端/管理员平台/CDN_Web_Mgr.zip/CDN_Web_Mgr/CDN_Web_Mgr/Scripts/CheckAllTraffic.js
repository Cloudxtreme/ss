﻿function CheckAllTraffic() {
    var subtitle = '汇总流量查询';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            id: 'tab_all',
            title: subtitle,
            content: createFrame('/Home/AllTrafficRpt?user=' + name),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}
function GetAllRpt() {
    var date = $("#ck_time").val();
    if (date.length == 0 || date == null) {
        alert("请选择查询日期！");
        $("#ck_time").focus();
        return false;
    }
    var DateArr = date.split('-');
    var span = Number($("#chart_type").val());
    if (span == 0) {
        //alert(DateArr[1]);
        reDrawChartForDay(DateArr[0], DateArr[1], DateArr[2], DateArr[0], DateArr[1], Number(DateArr[2] + 1));
    }
    if (span == 30) {
        var myDate = DateAdd('n', 1, date, 0);
        var myDateArr = myDate.split('-');
        reDrawChartForMonth(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    if (span == 7) {
        var myDate = DateAdd('w', 1, date, 0);
        var myDateArr = myDate.split('-');
        reDrawChartForWeek(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    var type = $("#dl_type").val();
    var area = $("#dl_area").val();
    $.ajax(
    {
        url: '/Home/GetChartDataByServer',
        data: "type=" + type + "&area=" + area + "&day=" + date + "&span=" + span,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: window.top.showLoad,
        complete: window.top.showHide,
        success: function (data) {
            if (data == null || data.length == 0) {
                $("#maxInTime").html();
                $("#maxInValue").html();
                $("#maxOutTime").html();
                $("#maxOutValue").html();
                return false;
            } else {
                //alert(data);
                var dataArr = data.split('|');
                var inStr = dataArr[0].split('#');
                var outStr = dataArr[1].split('#');
                var inMax = inStr[0].split(',');
                var outMax = outStr[0].split(',');
                $("#maxInTime").html(inMax[0]);
                $("#maxInValue").html(inMax[1]);
                $("#maxOutTime").html(outMax[0]);
                $("#maxOutValue").html(outMax[1]);
                var inObj = eval('(' + inStr[1] + ')');
                var outObj = eval('(' + outStr[1] + ')');
                chart.series[0].setData(inObj);
                chart.series[1].setData(outObj);
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}