﻿function ltrim(s) {
    return s.replace(/^\s*/, "");
}
//去右空格; 
function rtrim(s) {
    return s.replace(/\s*$/, "");
}

function login() {
    var loginn = rtrim(ltrim(document.getElementById('txt_user').value));
    var loginp = rtrim(ltrim(document.getElementById('txt_pwd').value));
    var type = $('#txt_type').val();
    var user_type = $('#user_type').val();
    var cookie = $('#user_cookie').val();
    if (loginn == "") {
        document.getElementById('msg').innerHTML = "请输入用户名！";
        document.all('txt_user').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginp == "") {
        document.getElementById('msg').innerHTML = "请输入密码！";
        document.all('txt_pwd').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginp.length < 1) {
        document.getElementById('msg').innerHTML = "密码不能小于3位！";
        document.all('txt_pwd').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    $("#msg").html("正在验证中，请稍候...");
    if (user_type == "系统管理员") {
        $.ajax(
        {
            url: '/Home/CheckLogin',
            data: "user=" + loginn + "&pwd=" + loginp + "&cookie=" + cookie,  //&code=" + code + "
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            success: function (data) {
                if (data == null || data.length == 0) {
                    alert("验证失败！");
                    return false;
                } else {
                    if (data == "false") {
                        document.getElementById('msg').innerHTML = "用户名或密码错误！";
                    }
                    if (data == "true") {
                        if (type == "文件管理平台") {
                            window.location = "../CdnFile/Index?user=" + loginn;
                        }
                        else {
                            window.location = "../CdnWeb/Index?user=" + loginn;
                        }
                    }
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
    else {
        $.ajax(
        {
            url: '/Home/CheckIbssLogin',
            data: "user=" + loginn + "&pwd=" + loginp + "",  //&code=" + code + "
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            success: function (data) {
                if (data == null || data.length == 0) {
                    alert("验证失败！");
                    return false;
                } else {
                    if (data == "false") {
                        document.getElementById('msg').innerHTML = "用户名或密码错误！";
                    }
                    if (data == "true") {
                        if (type == "文件管理平台") {
                            window.location = "../CdnFile/Index?user=" + loginn;
                        }
                        else {
                            window.location = "../CdnWeb/Index?user=" + loginn;
                        }
                    }
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
    }
}