﻿function showLoad() {
    $('#progressbar').window({
        modal: true,
        shadow: false,
        height: 32,
        title: ""
    });
}
function showHide() {
    $('#progressbar').window('close');
}