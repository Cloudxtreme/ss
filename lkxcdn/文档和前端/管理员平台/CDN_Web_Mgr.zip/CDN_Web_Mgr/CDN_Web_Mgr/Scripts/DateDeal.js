﻿
//日期自动补零程序
function appendZero(n)
{
	return(("00"+ n).substr(("00"+ n).length-2));
}
//获得当年当月最大天数
function GetMonthMaxDay(theYear,theMonth){  
  var theDays = new Array(31,28,31,30,31,30,31,31,30,31,30,31); 
  var theMonthDay = 0, tmpYear = this.formatYear(theYear); 
  theMonthDay = theDays[theMonth]; 
  if (theMonth == 1){ //theMonth is February 
	  if (((tmpYear % 4 == 0) && (tmpYear % 100 != 0)) || (tmpYear % 400 == 0)){ 
		  theMonthDay++; 
	  } 
  } 
  return(theMonthDay); 
}
//把年份格式化成4位 
function formatYear(theYear){  
  var tmpYear = parseInt(theYear,10); 
  if (tmpYear < 100){ 
  tmpYear += 1900; 
  if (tmpYear < 1940){ 
  tmpYear += 100; 
  } 
  } 
  if (tmpYear < this.MinYear){ 
  tmpYear = this.MinYear; 
  } 
  if (tmpYear > this.MaxYear){ 
  tmpYear = this.MaxYear; 
  } 
  return(tmpYear); 
}
//对javascript日期进行格式化
//formattype是返回的时间类型
//返回：返回时间串
function formatDate(day,formattype){
	var dateString = "";

	var thisyear = formatYear(day.getFullYear());
	var thismonth = appendZero(day.getMonth()+1);
	var thisday = appendZero(day.getDate());
	var thishour = appendZero(day.getHours());
	var thismin  = appendZero(day.getMinutes());
	var thissec  = appendZero(day.getSeconds());

	switch (formattype){
		case 0:
			dateString = thisyear + "年" + thismonth + "月" + thisday + "日";
			break;
		case 1:
			dateString = thisyear + "-" + thismonth + "-" + thisday;
			break;
		case 2:
			dateString = thisyear + "-" + thismonth + "-" + thisday+ " " + appendZero(thishour) + ":" + appendZero(thismin) + ":" + appendZero(thissec);
			break;
		default:
			dateString = thisyear + "-" + thismonth + "-" + thisday;
	}
	return dateString;
}
//取得本周第一天
function getWeekFirstDay(formattype) 
{ 
	var Nowdate=new Date(); 
	var WeekFirstDay=new Date(Nowdate-(Nowdate.getDay()-1)*86400000);
	return formatDate(WeekFirstDay,formattype);
}
//取得本周第七天
function getWeekLastDay(formattype) 
{ 
	var Nowdate=new Date(); 
	var WeekFirstDay=new Date(Nowdate-(Nowdate.getDay()-1)*86400000); 
	var WeekLastDay=new Date((WeekFirstDay/1000+6*86400)*1000); 
	return formatDate(WeekLastDay,formattype);
}
//取得本月第一天 
function getMonthFirstDay(formattype) 
{ 
	var Nowdate=new Date(); 
	var MonthFirstDay=new Date(Nowdate.getYear(),Nowdate.getMonth(),1); 
	return formatDate(MonthFirstDay,formattype);
}
//取得本月最后一天 
function getMonthLastDay(formattype) 
{ 
	var Nowdate=new Date(); 
	var MonthNextFirstDay=new Date(Nowdate.getYear(),Nowdate.getMonth()+1,1); 
	var MonthLastDay=new Date(MonthNextFirstDay-86400000); 
	return formatDate(MonthLastDay,formattype);
} 

/*
下列函数返回需要的时间 偏移值不能大于30
参数：dadd是日偏移值，-表示向前推，+向后推
	  formattype是返回的时间类型
返回：返回时间串
*/
function getDiffDate(dadd,formattype)
{
  //可以加上错误处理
	var a = new Date();
	a = a.valueOf();
	a = a + dadd * 24 * 60 * 60 * 1000;
	a = new Date(a);
	return formatDate(a,formattype);
}

//getDiffDate(+2,0)

//取得指定日期的年月日时分秒
//参数：dateValue 是格式形如：2007/04/05 
function TimeCom(dateValue){
	var newCom = new Date(dateValue);
	this.year = newCom.getYear();
	this.month = newCom.getMonth()+1;
	this.day = newCom.getDate();
	this.hour = newCom.getHours();
	this.minute = newCom.getMinutes();
	this.second = newCom.getSeconds();
	this.msecond = newCom.getMilliseconds();
	this.week = newCom.getDay();
}

//取得两个日期之间的时间差
//参数：interval : y或year-表示取得相差的年份 n或month-表示相差的月份 d或day表示相差的天数 h或hour-表示相差的小时 m或minute-表示相差的分钟 s或second-表示相差的秒数 ms或msecond-表示相差的毫秒数 w或week-表示相差的周数
//      date1:起始日期
//      date2:结束日期
function DateDiff(interval,date1,date2)
{
	var TimeCom1 = new TimeCom(date1);
	var TimeCom2 = new TimeCom(date2);
	var result;
	switch(String(interval).toLowerCase())
	{
		case "y":
		case "year":
		result = TimeCom1.year-TimeCom2.year;
		break;
		case "n":
		case "month":
		result = (TimeCom1.year-TimeCom2.year)*12+(TimeCom1.month-TimeCom2.month);
		break;
		case "d":
		case "day":
		result = Math.round((Date.UTC(TimeCom1.year,TimeCom1.month-1,TimeCom1.day)-Date.UTC(TimeCom2.year,TimeCom2.month-1,TimeCom2.day))/(1000*60*60*24));
		break;
		case "h":
		case "hour":
		result = Math.round((Date.UTC(TimeCom1.year,TimeCom1.month-1,TimeCom1.day,TimeCom1.hour)-Date.UTC(TimeCom2.year,TimeCom2.month-1,TimeCom2.day,TimeCom2.hour))/(1000*60*60));
		break;
		case "m":
		case "minute":
		result = Math.round((Date.UTC(TimeCom1.year,TimeCom1.month-1,TimeCom1.day,TimeCom1.hour,TimeCom1.minute)-Date.UTC(TimeCom2.year,TimeCom2.month-1,TimeCom2.day,TimeCom2.hour,TimeCom2.minute))/(1000*60));
		break;
		case "s":
		case "second":
		result = Math.round((Date.UTC(TimeCom1.year,TimeCom1.month-1,TimeCom1.day,TimeCom1.hour,TimeCom1.minute,TimeCom1.second)-Date.UTC(TimeCom2.year,TimeCom2.month-1,TimeCom2.day,TimeCom2.hour,TimeCom2.minute,TimeCom2.second))/1000);
		break;
		case "ms":
		case "msecond":
		result = Date.UTC(TimeCom1.year,TimeCom1.month-1,TimeCom1.day,TimeCom1.hour,TimeCom1.minute,TimeCom1.second,TimeCom1.msecond)-Date.UTC(TimeCom2.year,TimeCom2.month-1,TimeCom2.day,TimeCom2.hour,TimeCom2.minute,TimeCom2.second,TimeCom1.msecond);
		break;
		case "w":
		case "week":
		result = Math.round((Date.UTC(TimeCom1.year,TimeCom1.month-1,TimeCom1.day)-Date.UTC(TimeCom2.year,TimeCom2.month-1,TimeCom2.day))/(1000*60*60*24)) % 7;
		break;
		default:
		result = "invalid";
	}
	return(result);
}
/*
下列函数返回需要的时间 偏移值不能大于30
参数：interval : y或year-表示取得相差的年份 n或month-表示相差的月份 d或day表示相差的天数 h或hour-表示相差的小时 m或minute-表示相差的分钟 s或second-表示相差的秒数 ms或msecond-表示相差的毫秒数 w或week-表示相差的周数
      num是偏移值，-表示向前推，+向后推
	  dateValue 指定的日期
	  formattype是返回的时间类型
返回：返回时间串
*/
function DateAdd(interval,num,dateValue,formattype)
{
	var newCom = new TimeCom(dateValue);
	switch(String(interval).toLowerCase())
	{
		case "y": case "year": newCom.year += num; break;
		case "n": case "month": newCom.month += num; break;
		case "d": case "day": newCom.day += num; break;
		case "h": case "hour": newCom.hour += num; break;
		case "m": case "minute": newCom.minute += num; break;
		case "s": case "second": newCom.second += num; break;
		case "ms": case "msecond": newCom.msecond += num; break;
		case "w": case "week": newCom.day += num*7; break;
		default: return("invalid");
	}
	var now = newCom.year+"/"+newCom.month+"/"+newCom.day+" "+newCom.hour+":"+newCom.minute+":"+newCom.second;
	//return(new Date(now));
	return formatDate(new Date(now),formattype);
}




