﻿function SelectArea(ipArea, server) {
    //alert(ipArea);
    var area = $("#dl_area").val();
    var ipArr = ipArea.split(',');
    var serverArr = server.split(',');
    var options = '<option>全部</option>';
    if (area == "全部") {
        for (var k = 0; k < serverArr.length; k++) {
            //var IpArr = serverArr[k].split(',');
            options += "<option>" + serverArr[k] + "</option>";
        }
    }
    else {
        for (var k = 0; k < ipArr.length; k++) {
            var s = ipArr[k].split('|');
            for (var n = 0; n < serverArr.length; n++) {
                var t = serverArr[n].split(':');
                if (t[0] == s[1] && area == s[0]) {
                    options += "<option>" + serverArr[n] + "</option>";
                }
            }
        }
    }
    $("#dl_server").empty();
    $('#dl_server').html(options);
}

function SelectServer(Area) {
    var server = $("#dl_server").val();
    var areaArr = Area.split(',');
    var options = '<option>全部</option>';
    if (server != '全部') {
        var tmp_area = "";
        for (var k = 0; k < areaArr.length; k++) {
            area = areaArr[k].split('|');
            if (area[0] != tmp_area) {
                options += "<option>" + area[0] + "</option>";
            }
            tmp_area = area[0];
        }
        options += "<option>单个</option>";
        $('#dl_area').html(options);
        $("#dl_area").val("单个");
    }
}

function GetRptData() {
    var date = $("#ck_time").val();
    if (date.length == 0 || date == null) {
        alert("请选择查询日期！");
        $("#ck_time").focus();
        return false;
    }
    var DateArr = date.split('-');
    var span = Number($("#chart_type").val());
    var user = $("#user").val();
    //alert(date);
    if (span == 0) {
        //alert(DateArr[1]);
        reDrawChartForDay(DateArr[0], DateArr[1], DateArr[2], DateArr[0], DateArr[1], Number(DateArr[2] + 1));
    }
    if (span == 30) {
        var myDate = DateAdd('n', 1, date, 0);
        var myDateArr = myDate.split('-');
        reDrawChartForMonth(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    if (span == 7) {
        var myDate = DateAdd('w', 1, date, 0);
        var myDateArr = myDate.split('-');
        reDrawChartForWeek(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    var allServer = "";
    var server = $("#dl_server").val();
    var areas = $("#dl_area").val();
    //alert(areas);
    if (areas == "全部") {   //则查询所有的服务器，即得到服务器列表
        allServer = "全部";
    }
    else {   //查询单台服务器
        if ($("#dl_server").val() == "全部") {
            $("#dl_server option").each(function () {
                if ($(this).val() != "全部") {
                    allServer += $(this).val() + "|";
                }
            });
        }
        else {
            allServer = $("#dl_server").val();
        }
    }
    //alert(allServer);
    $.ajax(
    {
        url: '/CdnWeb/GetChartDataByServer',
        data: "user=" + user + "&server=" + allServer + "&day=" + date + "&span=" + span,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: window.top.showLoad,
        complete: window.top.showHide,
        success: function (data) {
            if (data == null || data.length == 0) {
                $("#maxInTime").html();
                $("#maxInValue").html();
                $("#maxOutTime").html();
                $("#maxOutValue").html();
                return false;
            } else {
                if (data.indexOf('#') > 0 && data.indexOf('|') > 0) {
                    var dataArr = data.split('|');
                    var inStr = dataArr[0].split('#');
                    var outStr = dataArr[1].split('#');
                    var inMax = inStr[0].split(',');
                    var outMax = outStr[0].split(',');
                    $("#maxInTime").html(inMax[0]);
                    $("#maxInValue").html((inMax[1] * 1.2).toFixed(2));
                    $("#maxOutTime").html(outMax[0]);
                    $("#maxOutValue").html((outMax[1] * 1.2).toFixed(2));
                    var inObj = eval('(' + inStr[1] + ')');
                    var outObj = eval('(' + outStr[1] + ')');

                    var outValue = eval('(' + outStr[1] + ')');

                    for (var len = 0; len < outValue.length; len++) {
                        outValue[len] = outValue[len] * 1.2;
                    }


               //     $("#pd").html(outValue[129]);

                    outValue.sort(mysortfunc);
                    var num = outValue.length * 0.95;
                    var count = parseInt(num);

                    $("#n-five").html(outValue[count].toFixed(2));

                    for (var len = 0; len < outObj.length; len++) {
                        outObj[len] = outObj[len] * 1.2;
                    }

                    chart.series[0].setData(inObj);
                    chart.series[1].setData(outObj);
                }
                else {
                    alert(data);
                }
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}


function mysortfunc(str1, str2) {
    return eval(str1) - eval(str2);
} 