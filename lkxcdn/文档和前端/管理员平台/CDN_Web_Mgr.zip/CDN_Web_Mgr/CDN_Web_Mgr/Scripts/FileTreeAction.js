﻿function TreeAction(type, id, name) {
    if (type == "username") {
        return false;
    }
    else {
        if (name == "流量监控") {
            TrafficRpt(type);
            return false;
        }
        if (name == "查看信息") {
            showClientInfo(id, type);
            return false;
        }
        if (name == "服务器管理") {
            GetIpPortList(type);
            return false;
        }
        if (name == "流量统计") {
            GetTrafficTotal(type);
            return false;
        }
        if (name == "峰值统计") {
            GetTopRpt(type);
            return false;
        }
    }
}

function GetTrafficTotal(name) {
    var arr = name.split('【');
    $('#win').window({
        modal: false,
        shadow: false,
        closed: false,
        title: "用户 " + arr[0] + " 流量统计"
    });
    $("#user").val(arr[0]);
    $("#total_result").val("");
}

function GetTopRpt(name) {
    var arr = name.split('【');
    var subtitle = arr[0] + '峰值统计';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('TopRpt?user=' + arr[0]),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckOutTrafficSpan() {
    var subtitle = '实时流出流量对比';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('OutTrafficSpan'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckInTrafficSpan() {
    var subtitle = '实时流入流量对比';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('InTrafficSpan'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function GetIpPortList(name) {
    var arr = name.split('【');
    var subtitle = '【' + arr[0] + '】服务器列表';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: '<table id="tb_' + arr[0] + '"></table>',
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
    //填充表格
    editname = name;
    editcount = 0;
    setTable(name);
}

function setTable(name) {
    var arr = name.split('【');
    $('#tb_' + arr[0]).datagrid({
        title: '用户服务器列表',
        iconCls: 'icon-edit',
        width: 530,
        height: 250,
        singleSelect: true,
        pagination: true,
        rownumbers: true,
        fit: true,
        url: '/CdnFile/GetUserIpPort?user=' + arr[0],
        columns: [[
                    { field: 'id', title: '编号', width: 30 },
                    { field: 'ip', title: 'IP地址', width: 150, editor: 'text' },
                    { field: 'port', title: '端口号', width: 100, align: 'center', editor: 'numberbox' },
                    { field: 'action', title: '操作', width: 150, align: 'center',
                        formatter: function (value, row, index) {
                            var e = '<a href="#" id="edit_' + arr[0] + index + '" onclick="editRow(\'' + arr[0] + '\',' + index + ')">编辑</a> ';
                            var d = '<a href="#" id="dele_' + arr[0] + index + '" onclick="deleRow(\'' + arr[0] + '\',' + index + ')">删除</a>';
                            return e + d;
                        }
                    }
                ]],
        toolbar: [{
            text: '增加服务器',
            iconCls: 'icon-add',
            handler: addrow
        }, {
            text: '取消',
            iconCls: 'icon-cancel',
            handler: cancelall
        }],
        onBeforeEdit: function (index, row) {
            row.editing = true;
            $('#tb_' + name).datagrid('refreshRow', index);
            editcount++;
        },
        onAfterEdit: function (index, row) {
            row.editing = false;
            $('#tb_' + name).datagrid('refreshRow', index);
            editcount--;
        },
        onCancelEdit: function (index, row) {
            row.editing = false;
            $('#tb_' + name).datagrid('refreshRow', index);
            editcount--;
        }
    }).datagrid('acceptChanges');
}
//增加记录
//bug：方法不能传递参数
function addrow() {
    if (editcount > 0) {
        $.messager.alert('警告', '当前还有' + editcount + '条记录正在编辑，不能增加记录。');
        return;
    }
    //alert(editname);
    $('#tb_' + editname).datagrid('appendRow', {
        ip: '',
        port: ''
    });
}
//取消所有修改
//bug：方法不能传递参数
function cancelall() {
    $('#tb_' + editname).datagrid('rejectChanges');
}

function editRow(name, index) {
    //$.messager.alert("系统提示", value);
    var type = $('#edit_' + name + index).html();
    if (type == '编辑') {
        if (editcount > 0) {
            $.messager.alert('警告', '当前已有' + editcount + '条记录正在编辑，不能同时编辑多条记录！');
            return;
        }
        $('#edit_' + name + index).html('保存');
        $('#dele_' + name + index).html('取消');
        $('#tb_' + name).datagrid('beginEdit', index);
    }
    else {
        if (editcount > 1) {
            $.messager.alert('警告', '当前已有' + editcount + '条记录正在编辑，不能同时编辑多条记录！');
            return;
        }
        $('#tb_' + name).datagrid('endEdit', index); //编辑完成
        $('#tb_' + name).datagrid('refreshRow', index); //刷新该条记录
        //var rows = $('#tb_' + name).datagrid('getChanges', 'updated');
        var rows = $('#tb_' + name).datagrid('getSelected');
        if (rows.id == "" || rows.id == null) {  //新增记录
            if (rows.ip == "" || rows.port == "") {
                $.messager.alert("系统提示", "请填写完整！");
                return false;
            }
            $.ajax(
            {
                url: '/CdnFile/AddClientServer',
                data: "user=" + name + "&ip=" + rows.ip + "&port=" + Number(rows.port),
                type: "POST",
                dataType: "text",
                beforeSend: showLoad,
                complete: showHide,
                success: function (data) {
                    //添加成功
                    if (data == "true") {
                        $.messager.alert("系统提示", "添加成功！");
                    }
                    else {
                        $.messager.alert("系统提示", "添加失败！");
                    }
                },
                error: function (data) {
                    alert(data.statusText);
                }
            });
        }
        else {  //修改
            if (rows.id == "" || rows.ip == "" || rows.port == "") {
                $.messager.alert("系统提示", "请填写完整！");
                return false;
            }
            $.ajax(
            {
                url: '/CdnFile/EditClientServer',
                data: "id=" + Number(rows.id) + "&ip=" + rows.ip + "&port=" + Number(rows.port),
                type: "POST",
                dataType: "text",
                beforeSend: showLoad,
                complete: showHide,
                success: function (data) {
                    //编辑成功
                    if (data == "true") {
                        $.messager.alert("系统提示", "修改成功！");
                    }
                    else {
                        $.messager.alert("系统提示", "修改失败！");
                    }
                },
                error: function (data) {
                    alert(data.statusText);
                }
            });
        }
        $('#tb_' + name).datagrid('reload');
        //$('#edit_' + index).html('编辑');
        //$('#dele_' + index).html('删除');
    }
}
function deleRow(name, index) {
    var type = $('#dele_' + name + index).html();
    if (type == '删除') {
        $.messager.confirm('提示', '确定删除该条记录吗？', function (r) {
            if (r) {
                var rows = $('#tb_' + name).datagrid('getSelected');
                if (rows) {
                    if (rows.id == "" || rows.id == null) {
                        $('#tb_' + name).datagrid('rejectChanges'); //取消编辑状态
                        return false;
                    }
                    $.ajax(
                     {
                         url: '/CdnFile/DeleClientServer',
                         data: "id=" + Number(rows.id),
                         type: "POST",
                         dataType: "text",
                         beforeSend: showLoad,
                         complete: showHide,
                         success: function (data) {
                             //编辑成功
                             if (data == "true") {
                                 $.messager.alert("系统提示", "删除成功！");
                             }
                             else {
                                 $.messager.alert("系统提示", "删除失败！");
                             }
                         },
                         error: function (data) {
                             alert(data.statusText);
                         }
                     });
                    //$('#tb_' + name).datagrid('deleteRow', index);
                    $('#tb_' + name).datagrid('reload');
                }
            }
        });
    }
    else {
        $('#edit_' + name + index).html('编辑');
        $('#dele_' + name + index).html('删除');
        $('#tb_' + name).datagrid('cancelEdit', index);
    }
}

function saverow(name, index) {
    var selectedRow = $('#tb_' + name).datagrid('getSelected');
    alert(selectedRow.ip);
    $('#tb_' + name).datagrid('endEdit', index);
}
function cancelrow(name, index) {
    $('#tb_' + name).datagrid('cancelEdit', index);
}

function showClientInfo(id, info) {
    var strArr = info.split('|');
    $('#winInfo').window({
        modal: false,
        shadow: false,
        title: "【" + strArr[0] + "】客户信息查看"
    });
    $('#txt_name').val(strArr[0]);
    $('#txt_desc').val(strArr[1]);
    $('#txt_mydesc').val(strArr[2]);
    $('#txt_id').val(id);
}

function EditClientInfo() {
    var id = $('#txt_id').val();
    var desc = $('#txt_desc').val();
    var mydesc = $('#txt_mydesc').val();
    if (id == null || id.length == 0) {
        return false;
    }
    $.ajax(
    {
        url: '/CdnFile/SaveClientInfo',
        data: "id=" + Number(id) + "&desc=" + desc + "&mydesc=" + mydesc,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            alert(data);
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}