﻿function TrafficRpt(name) {
    var arr = name.split('【');
    var subtitle = '【' + arr[0] + '】流量监控';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            id: 'tab_' + arr[0],
            title: subtitle,
            content: createFrame('TrafficRpt?user=' + arr[0]),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function createFrame(url) {
    var s = '<iframe scrolling="auto" id="rpt_ifrm" frameborder="0"  src="' + url + '" style="width:100%;height:100%;vertical-align:top"></iframe>';
    return s;
}

function GetClientList() {
    var subtitle = '客户列表';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('ClientList'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function GetSubClientList() {
    var subtitle = '子账号列表';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('SubClientList'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckFileID() {
    var subtitle = '文件分发查询';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('FileList'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckOutSpanTraffic() {
    var subtitle = '实时流出流量对比';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('OutSpanTraffic'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckInSpanTraffic() {
    var subtitle = '实时流入流量对比';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('InSpanTraffic'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckTotalStream() {
    var start_date = String($("#date_start").val());
    var end_date = String($("#date_end").val());
    var user = String($("#user").val());
    if (start_date == null || start_date.length == 0 || end_date == null || end_date.length == 0) {
        alert("请选择要查询的日期条件！");
        return false;
    }
    if (user == null || user.length == 0) {
        alert("用户数据获取失败，请重新打开该页面！");
        return false;
    }
    $.ajax(
    {
        url: '/CdnFile/GetTotalStream',
        data: "user=" + user + "&start=" + start_date + "&end=" + end_date,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            if (data == null || data.length == 0) {
                alert("查询结果为空！");
                return false;
            } else {
                var dataArr = data.split('|');
                $("#total_result").html("[请求总IP数：" + dataArr[0] + "]  [请求总次数：" + dataArr[1] + "] <br /> [请求总流量：" + Math.round(dataArr[2]) + "M]  按G换算：[请求总流量：" + Math.round((Number(dataArr[2]) / 1000)) + "G]");
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}

function adv_format(value, num) //四舍五入
{
    var a_str = formatnumber(value, num);
    var a_int = parseFloat(a_str);
    if (value.toString().length > a_str.length) {
        var b_str = value.toString().substring(a_str.length, a_str.length + 1)
        var b_int = parseFloat(b_str);
        if (b_int < 5) {
            return a_str
        }
        else {
            var bonus_str, bonus_int;
            if (num == 0) {
                bonus_int = 1;
            }
            else {
                bonus_str = "0."
                for (var i = 1; i < num; i++)
                    bonus_str += "0";
                bonus_str += "1";
                bonus_int = parseFloat(bonus_str);
            }
            a_str = formatnumber(a_int + bonus_int, num)
        }
    }
    return a_str
}

function formatnumber(value, num) //直接去尾
{
    var a, b, c, i
    a = value.toString();
    b = a.indexOf('.');
    c = a.length;
    if (num == 0) {
        if (b != -1)
            a = a.substring(0, b);
    }
    else {
        if (b == -1) {
            a = a + ".";
            for (i = 1; i <= num; i++)
                a = a + "0";
        }
        else {
            a = a.substring(0, b + num + 1);
            for (i = c; i <= b + num; i++)
                a = a + "0";
        }
    }
    return a
}