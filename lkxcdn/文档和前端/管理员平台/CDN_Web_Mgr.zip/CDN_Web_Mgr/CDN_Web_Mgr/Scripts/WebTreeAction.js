﻿function TreeAction(type, id, name) {
    if (type == "username") {
        return false;
    }
    else{
        if (name == "流量监控") {
            TrafficRpt(type);
            return false;
        }
        if (name == "查看信息") {
            showClientInfo(id,type);
            return false;
        }
        if (name == "流量统计") {
            TrafficTotal(type);
            return false;
        }
        if (name == "峰值统计") {
            TopTraffic(type);
            return false;
        }
    }
}

function TrafficTotal(name) {
    var arr = name.split('【');
    $('#win').window({
        modal: false,
        shadow: false,
        closed: false,
        title: "用户 " + arr[0] + " 流量统计"
    });
    $("#traffic_total").val(arr[0]);
    $("#host_result").val("");
}

function TopTraffic(name) {
    var arr = name.split('【');
    var subtitle = '【' + arr[0] + '】峰值统计';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            id: 'tab_' + arr[0],
            title: subtitle,
            content: createFrame('TopTraffic?user=' + arr[0]),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function CheckHit() {
    var subtitle = '域名命中率列表';
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: createFrame('HitList'),
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
}

function showClientInfo(id,info) {
    var strArr = info.split('|');
    var arr = strArr[0].split('【');
    $('#winInfo').window({
        modal: false,
        shadow: false,
        title: "【" + arr[0] + "】客户信息查看"
    });
    $('#txt_name').val(arr[0]);
    $('#txt_desc').val(strArr[1]);
    $('#txt_mydesc').val(strArr[2]);
    $('#txt_id').val(id);
}

function EditClientInfo() {
    var id = $('#txt_id').val();
    var desc = $('#txt_desc').val();
    var mydesc = $('#txt_mydesc').val();
    if (id == null || id.length == 0) {
        return false;
    }
    $.ajax(
    {
        url: '/CdnWeb/SaveClientInfo',
        data: "id=" + Number(id) + "&desc=" + desc + "&mydesc=" + mydesc,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        beforeSend: showLoad,
        complete: showHide,
        success: function (data) {
            alert(data);
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}