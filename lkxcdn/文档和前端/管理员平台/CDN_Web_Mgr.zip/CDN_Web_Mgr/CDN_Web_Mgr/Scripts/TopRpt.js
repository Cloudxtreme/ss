﻿jQuery(document).ready(function () {
    jQuery("#list_out").jqGrid({
        datatype: "local",
        height: 200,
        width: 480,
        colNames: ['精确百分比', '流出流量（mbits）', '时间点'],
        colModel: [
   		                    { name: 'id', index: 'id', width: 60, sorttype: "int" },
   		                    { name: 'out_stream', index: 'out_stream', width: 110, sorttype: "int" },
   		                    { name: 'datetime', index: 'datetime', width: 110 }
   	                    ],
        rowNum: 10,
        rowList: [10, 20, 30, 50],
        pager: '#pager1',
        sortname: 'id',
        //viewrecords: true,
        sortorder: "asc",
        clearAfterAdd: true,
        //loadonce: false,
        caption: "流出峰值统计"
    });
    jQuery("#list_in").jqGrid({
        datatype: "local",
        height: 200,
        width: 480,
        colNames: ['精确百分比', '流入流量（mbits）', '时间点'],
        colModel: [
                                  { name: 'id', index: 'id', width: 60, sorttype: "int" },
                                  { name: 'in_stream', index: 'in_stream', width: 110, sorttype: "int" },
                                  { name: 'datetime', index: 'datetime', width: 110, sorttype: "date" }
                              ],
        rowNum: 10,
        rowList: [10, 20, 30, 50],
        pager: '#pager2',
        sortname: 'id',
        //viewrecords: true,
        sortorder: "asc",
        clearAfterAdd: false,
        caption: "流入峰值统计"
    });
    $('#progressbar').window('close');
});

function CheckTopRpt() {
    var start_date = String($("#date_start").val());
    var day_span = String($("#dl_span").val());
    var bfb = $("#bfb").val();
    var user = $("#user").val(); 
    if (start_date == null || start_date.length == 0 || day_span == null || day_span.length == 0 || bfb.length == 0 || bfb == null) {
        alert("请选择要查询的条件！");
        return false;
    }
    if (Number(bfb) == 0) {
        alert("百分比不能少于0！");
        return false;
    }
    if (user == null || user.length == 0) {
        alert("用户数据获取失败，请重新打开该页面！");
        return false;
    }
    $.ajax(
        {
            url: '/CdnFile/GetTopRpt',
            data: "user=" + user + "&start=" + start_date + "&span=" + day_span + "&bfb=" + Number(bfb),
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: showLoad,
            complete: showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    alert("查询结果为空！");
                    return false;
                } else {
                    var dataArr = data.split('|');
                    jQuery("#list_in").jqGrid('clearGridData');
                    //$("#list_in").trigger("reloadGrid"); //清空列表
                    jQuery("#list_out").jqGrid('clearGridData');
                    //$("#list_out").trigger("reloadGrid");
                    var out_stream = eval('(' + dataArr[0] + ')');
                    var in_stream = eval('(' + dataArr[1] + ')');
                    $("#hide_ck_in").val(dataArr[1]);
                    $("#hide_ck_out").val(dataArr[0]);
                    if (in_stream.length > 0) {
                        for (var j = 0; j < in_stream.length; j++) {
                            jQuery("#list_in").jqGrid('addRowData', j + 1, in_stream[j]);
                        }
                    }
                    if (out_stream.length > 0) {
                        for (var i = 0; i < out_stream.length; i++) {
                            jQuery("#list_out").jqGrid('addRowData', i + 1, out_stream[i]);
                        }
                    }
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function CheckNet(type) {
    if (type == 'in') {
        var inStr = $("#hide_ck_in").val();
        var inObj = eval('(' + inStr + ')');
        var num = $("#in_ck").val();
        if (num == "" || num == null) {
            alert("请输入查询百分比！");
        }
        else {
            var total = inObj.length;
            var atr = parseInt(total * (num / 100));
            $("#ck_in_msg").html("共" + total + "条记录，" + num + "%即为第" + atr + "条记录：时间【" + inObj[atr - 1].datetime + "】流量【" + inObj[atr - 1].stream + "mbits】");
        }
    }
    else {
        var outStr = $("#hide_ck_out").val();
        var outObj = eval('(' + outStr + ')');
        var num = $("#out_ck").val();
        if (num == "" || num == null) {
            alert("请输入查询百分比！");
        }
        else {
            var total = outObj.length;
            var atr = parseInt(total * (num / 100));
            $("#ck_out_msg").html("共" + total + "条记录，" + num + "%即为第" + atr + "条记录：时间【" + outObj[atr - 1].datetime + "】流量【" + outObj[atr - 1].stream + "mbits】");
        }
    }
}