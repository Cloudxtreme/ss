﻿var servereditcount = 0;
function GetServerList() {
    var subtitle = "";
    if (type == 'CdnWeb') {
        subtitle = '【Web服务器列表】';
    }
    else {
        subtitle = '【文件服务器列表】';
    }
    if (!$('#tabs_div').tabs('exists', subtitle)) {
        $('#tabs_div').tabs('add', {
            title: subtitle,
            content: '<table id="tb_server"></table>',
            fit: true,
            closable: true
        });
    }
    else {
        $('#tabs_div').tabs('select', subtitle);
        //tabClose();
    }
    //填充表格
    servereditcount = 0;
    setServerTable();
}

function setServerTable() {
    if (type == 'CdnWeb') {
        $('#tb_server').datagrid({
            title: '服务器列表',
            iconCls: 'icon-edit',
            width: 530,
            height: 250,
            singleSelect: true,
            pagination: true,
            rownumbers: true,
            fit: true,
            url: '/CdnWeb/GetServerList',
            columns: [[
                    { field: 'id', title: '编号', width: 30 },
                    { field: 'ip', title: 'IP地址', width: 150, editor: 'text' },
                    { field: 'port', title: '端口号', width: 100, align: 'center', editor: 'numberbox' },
                    { field: 'nettype', title: '网络类型', width: 150, editor: 'text' },
                    { field: 'zone', title: '区域', width: 150, editor: 'text' },
                    { field: 'desc', title: '备注', width: 150, editor: 'text' },
                    { field: 'action', title: '操作', width: 150, align: 'center',
                        formatter: function (value, row, index) {
                            var e = '<a href="#" id="server_edit_' + index + '" onclick="editRowServer(' + index + ')">编辑</a> ';
                            var d = '<a href="#" id="server_dele_' + index + '" onclick="deleRowServer(' + index + ')">删除</a>';
                            return e + d;
                        }
                    }
                ]],
            toolbar: [{
                text: '添加服务器',
                iconCls: 'icon-add',
                handler: addrowServer
            }, {
                text: '取消',
                iconCls: 'icon-cancel',
                handler: cancelallServer
            }],
            onBeforeEdit: function (index, row) {
                row.editing = true;
                $('#tb_server').datagrid('refreshRow', index);
                servereditcount++;
            },
            onAfterEdit: function (index, row) {
                row.editing = false;
                $('#tb_server').datagrid('refreshRow', index);
                servereditcount--;
            },
            onCancelEdit: function (index, row) {
                row.editing = false;
                $('#tb_server').datagrid('refreshRow', index);
                servereditcount--;
            }
        }).datagrid('acceptChanges');
    }
    else {
        $('#tb_server').datagrid({
            title: '服务器列表',
            iconCls: 'icon-edit',
            width: 530,
            height: 250,
            singleSelect: true,
            pagination: true,
            rownumbers: true,
            fit: true,
            url: '/CdnFile/GetServerList',
            columns: [[
                    { field: 'id', title: '编号', width: 30 },
                    { field: 'ip', title: 'IP地址', width: 150, editor: 'text' },
                    { field: 'port', title: '端口号', width: 100, align: 'center', editor: 'numberbox' },
                    { field: 'nettype', title: '网络类型', width: 150, editor: 'text' },
                    { field: 'zone', title: '区域', width: 150, editor: 'text' },
                    { field: 'desc', title: '备注', width: 150, editor: 'text' },
                    { field: 'action', title: '操作', width: 150, align: 'center',
                        formatter: function (value, row, index) {
                            var e = '<a href="#" id="server_edit_' + index + '" onclick="editFileRowServer(' + index + ')">编辑</a> ';
                            var d = '<a href="#" id="server_dele_' + index + '" onclick="deleFileRowServer(' + index + ')">删除</a>';
                            return e + d;
                        }
                    }
                ]],
            toolbar: [{
                text: '添加服务器',
                iconCls: 'icon-add',
                handler: addrowServer
            }, {
                text: '取消',
                iconCls: 'icon-cancel',
                handler: cancelallServer
            }],
            onBeforeEdit: function (index, row) {
                row.editing = true;
                $('#tb_server').datagrid('refreshRow', index);
                servereditcount++;
            },
            onAfterEdit: function (index, row) {
                row.editing = false;
                $('#tb_server').datagrid('refreshRow', index);
                servereditcount--;
            },
            onCancelEdit: function (index, row) {
                row.editing = false;
                $('#tb_server').datagrid('refreshRow', index);
                servereditcount--;
            }
        }).datagrid('acceptChanges');
    }
}

function editFileRowServer(index) {
    //$.messager.alert("系统提示", value);
    var type = $('#server_edit_' + index).html();
    if (type == '编辑') {
        if (servereditcount > 0) {
            $.messager.alert('警告', '当前已有' + servereditcount + '条记录正在编辑，请先取消上条记录的编辑状态！');
            return;
        }
        $('#server_edit_' + index).html('保存');
        $('#server_dele_' + index).html('取消');
        $('#tb_server').datagrid('beginEdit', index);
    }
    else {  //==保存
        if (servereditcount > 1) {
            $.messager.alert('警告', '当前已有' + servereditcount + '条记录正在编辑，请先取消上条记录的编辑状态！');
            return;
        }
        $('#tb_server').datagrid('endEdit', index); //编辑完成
        $('#tb_server').datagrid('refreshRow', index); //刷新该条记录
        //var rows = $('#tb_' + name).datagrid('getChanges', 'updated');
        var rows = $('#tb_server').datagrid('getSelected');
        if (rows.id == "" || rows.id == null) {  //新增记录
            if (rows.ip == "" || rows.port == "" || rows.nettype == "" || rows.zone == "") {
                $.messager.alert("系统提示", "请填写完整！");
                return false;
            }
            $.ajax(
                {
                    url: '/CdnFile/AddServer',
                    data: "ip=" + rows.ip + "&port=" + Number(rows.port) + "&nettype=" + rows.nettype + "&zone=" + rows.zone + "&desc=" + rows.desc,
                    type: "POST",
                    dataType: "text",
                    beforeSend: showLoad,
                    complete: showHide,
                    success: function (data) {
                        //编辑成功
                        if (data == "true") {
                            $.messager.alert("系统提示", "添加成功！");
                        }
                        else {
                            $.messager.alert("系统提示", "添加失败！");
                        }
                    },
                    error: function (data) {
                        alert(data.statusText);
                    }
                });
        }
        else {
            if (rows.id == "" || rows.ip == "" || rows.port == "" || rows.nettype == "" || rows.zone == "") {
                $.messager.alert("系统提示", "请填写完整！");
                return false;
            }
            $.ajax(
                {
                    url: '/CdnFile/EditServer',
                    data: "id=" + Number(rows.id) + "&ip=" + rows.ip + "&port=" + Number(rows.port) + "&nettype=" + rows.nettype + "&zone=" + rows.zone + "&desc=" + rows.desc,
                    type: "POST",
                    dataType: "text",
                    beforeSend: showLoad,
                    complete: showHide,
                    success: function (data) {
                        //编辑成功
                        if (data == "true") {
                            $.messager.alert("系统提示", "修改成功！");
                        }
                        else {
                            $.messager.alert("系统提示", "修改失败！");
                        }
                    },
                    error: function (data) {
                        alert(data.statusText);
                    }
                });
        }
        $('#tb_server').datagrid('reload');
    }
}
function deleFileRowServer(index) {
    var type = $('#server_dele_' + index).html();
    if (type == '删除') {
        $.messager.confirm('提示', '确定删除该条记录吗？', function (r) {
            if (r) {
                var rows = $('#tb_server').datagrid('getSelected');
                if (rows) {
                    if (rows.id == null || rows.id.length == 0) {
                        $('#tb_server').datagrid('rejectChanges'); //取消编辑状态
                        return false;
                    }
                    $.ajax(
                     {
                         url: '/CdnFile/DeleteServer',
                         data: "id=" + Number(rows.id),
                         type: "POST",
                         dataType: "text",
                         beforeSend: showLoad,
                         complete: showHide,
                         success: function (data) {
                             //编辑成功
                             if (data == "true") {
                                 $.messager.alert("系统提示", "删除成功！");
                             }
                             else {
                                 $.messager.alert("系统提示", "删除失败！");
                             }
                         },
                         error: function (data) {
                             alert(data.statusText);
                         }
                     });
                    //$('#tb_' + name).datagrid('deleteRow', index);
                    $('#tb_server').datagrid('reload');
                }
            }
        });
    }
    else {
        $('#server_edit_' + index).html('编辑');
        $('#server_dele_' + index).html('删除');
        $('#tb_server').datagrid('cancelEdit', index); //取消编辑状态
    }
}

function editRowServer(index) {
    //$.messager.alert("系统提示", value);
    var type = $('#server_edit_' + index).html();
    if (type == '编辑') {
        if (servereditcount > 0) {
            $.messager.alert('警告', '当前已有' + servereditcount + '条记录正在编辑，请先取消上条记录的编辑状态！');
            return;
        }
        $('#server_edit_' + index).html('保存');
        $('#server_dele_' + index).html('取消');
        $('#tb_server').datagrid('beginEdit', index);
    }
    else {  //==保存
        if (servereditcount > 1) {
            $.messager.alert('警告', '当前已有' + servereditcount + '条记录正在编辑，请先取消上条记录的编辑状态！');
            return;
        }
        $('#tb_server').datagrid('endEdit', index); //编辑完成
        $('#tb_server').datagrid('refreshRow', index); //刷新该条记录
        //var rows = $('#tb_' + name).datagrid('getChanges', 'updated');
        var rows = $('#tb_server').datagrid('getSelected');
        if (rows.id == "" || rows.id == null) {  //新增记录
            if (rows.ip == "" || rows.port == "" || rows.nettype == "" || rows.zone == "") {
                $.messager.alert("系统提示", "请填写完整！");
                return false;
            }
                $.ajax(
                {
                    url: '/CdnWeb/AddServer',
                    data: "ip=" + rows.ip + "&port=" + Number(rows.port) + "&nettype=" + rows.nettype + "&zone=" + rows.zone + "&desc=" + rows.desc,
                    type: "POST",
                    dataType: "text",
                    beforeSend: showLoad,
                    complete: showHide,
                    success: function (data) {
                        //编辑成功
                        if (data == "true") {
                            $.messager.alert("系统提示", "添加成功！");
                        }
                        else {
                            $.messager.alert("系统提示", "添加失败！");
                        }
                    },
                    error: function (data) {
                        alert(data.statusText);
                    }
                });
        }
        else {
            if (rows.id == "" || rows.ip == "" || rows.port == "" || rows.nettype == "" || rows.zone == "") {
                $.messager.alert("系统提示", "请填写完整！");
                return false;
            }
                $.ajax(
                {
                    url: '/CdnWeb/EditServer',
                    data: "id=" + Number(rows.id) + "&ip=" + rows.ip + "&port=" + Number(rows.port) + "&nettype=" + rows.nettype + "&zone=" + rows.zone + "&desc=" + rows.desc,
                    type: "POST",
                    dataType: "text",
                    beforeSend: showLoad,
                    complete: showHide,
                    success: function (data) {
                        //编辑成功
                        if (data == "true") {
                            $.messager.alert("系统提示", "修改成功！");
                        }
                        else {
                            $.messager.alert("系统提示", "修改失败！");
                        }
                    },
                    error: function (data) {
                        alert(data.statusText);
                    }
                });
        }
        $('#tb_server').datagrid('reload');
    }
}
function deleRowServer(index) {
    var type = $('#server_dele_' + index).html();
    if (type == '删除') {
        $.messager.confirm('提示', '确定删除该条记录吗？', function (r) {
            if (r) {
                var rows = $('#tb_server').datagrid('getSelected');
                if (rows) {
                    if (rows.id == null || rows.id.length == 0) {
                        $('#tb_server').datagrid('rejectChanges'); //取消编辑状态
                        return false;
                    }
                    $.ajax(
                     {
                         url: '/CdnWeb/DeleteServer',
                         data: "id=" + Number(rows.id),
                         type: "POST",
                         dataType: "text",
                         beforeSend: showLoad,
                         complete: showHide,
                         success: function (data) {
                             //编辑成功
                             if (data == "true") {
                                 $.messager.alert("系统提示", "删除成功！");
                             }
                             else {
                                 $.messager.alert("系统提示", "删除失败！");
                             }
                         },
                         error: function (data) {
                             alert(data.statusText);
                         }
                     });
                    //$('#tb_' + name).datagrid('deleteRow', index);
                    $('#tb_server').datagrid('reload');
                }
            }
        });
    }
    else {
        $('#server_edit_' + index).html('编辑');
        $('#server_dele_' + index).html('删除');
        $('#tb_server').datagrid('cancelEdit', index); //取消编辑状态
    }
}

//增加记录
function addrowServer(name) {
    if (servereditcount > 0) {
        $.messager.alert('警告', '当前已有' + servereditcount + '条记录正在编辑，请先取消上条记录的编辑状态！');
        return false;
    }
    $('#tb_server').datagrid('appendRow', {
        ip: '',
        port: '',
        nettype: '',
        zone: ''
    });
}
//取消所有修改
function cancelallServer(name) {
    $('#tb_server').datagrid('rejectChanges');
}