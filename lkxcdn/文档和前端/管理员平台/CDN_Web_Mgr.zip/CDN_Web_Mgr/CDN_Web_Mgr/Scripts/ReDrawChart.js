﻿function reDrawChartForDay(sy, sm, sd, ey, em, ed) {
    $("#chart_type").val('0');
    $("#container").empty();
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            zoomType: 'x',
            spacingRight: 30,
            //marginTop: 30,
            marginBottom: 80
        },
        title: {
            text: '网络流量监控——天流量图'
        },
        subtitle: {
            text: document.ontouchstart === undefined ?
					'[点击并拖动区域实现放大]' :
					'[拖动鼠标移动可见区域]'
        },
        xAxis: {
            type: 'datetime',
            maxZoom: 2 * 3600 * 1000, //2小时
            title: {
                text: null
            }
        },
        yAxis: {
            title: {
                text: '流入/流出(Mbps)'
            },
            min: 0.6,
            startOnTick: false,
            showFirstLabel: false
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.series.name + '</b><br/>[' +
						Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + ']： ' + this.y.toFixed(2) + ' Mbps';
            }
        },
        legend: {
            layout: 'horizontal', //vertical
            //align: 'right',
            verticalAlign: 'bottom',
            //x: 30,
            y: -25,
            borderWidth: 0
        },
        plotOptions: {
            area: {
                fillColor: {
                    linearGradient: [0, 0, 0, 300],
                    stops: [
							[0, Highcharts.theme.colors[0]],
							[1, 'rgba(2,0,0,0)']
						]
                },
                lineWidth: 1,
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            radius: 5
                        }
                    }
                },
                shadow: false,
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            }
        },
        series: [{
            type: 'area',
            name: '流入流量',
            pointInterval: 5 * 60 * 1000,  //五分钟间隔
            pointStart: Date.UTC(Number(sy), Number(sm-1), Number(sd)),
            pointEnd: Date.UTC(Number(ey), Number(em-1), Number(ed)),
            data: []
        }, {
            type: 'area',
            name: '流出流量',
            pointInterval: 5 * 60 * 1000,
            pointStart: Date.UTC(Number(sy), Number(sm-1), Number(sd)),
            pointEnd: Date.UTC(Number(ey), Number(em-1), Number(ed)),
            data: []
        }]
    });
}
function reDrawChartForWeek(sy, sm, sd, ey, em, ed) {
    $("#chart_type").val('7');
    $("#container").empty();
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            zoomType: 'x',
            spacingRight: 30,
            //marginTop: 30,
            marginBottom: 80
        },
        title: {
            text: '网络流量监控——星期流量图'
        },
        subtitle: {
            text: document.ontouchstart === undefined ?
					'[点击并拖动区域实现放大]' :
					'[拖动鼠标移动可见区域]'
        },
        xAxis: {
            type: 'datetime',
            maxZoom: 12 * 3600 * 1000, //12小时
            title: {
                text: null
            }
        },
        yAxis: {
            title: {
                text: '流入/流出(Mbps)'
            },
            min: 0.6,
            startOnTick: false,
            showFirstLabel: false
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.series.name + '</b><br/>[' +
						Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + ']： ' + this.y.toFixed(2) + ' Mbps';
            }
        },
        legend: {
            layout: 'horizontal', //vertical
            //align: 'right',
            verticalAlign: 'bottom',
            //x: 30,
            y: -25,
            borderWidth: 0
        },
        plotOptions: {
            area: {
                fillColor: {
                    linearGradient: [0, 0, 0, 300],
                    stops: [
							[0, Highcharts.theme.colors[0]],
							[1, 'rgba(2,0,0,0)']
						]
                },
                lineWidth: 1,
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            radius: 5
                        }
                    }
                },
                shadow: false,
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            }
        },
        series: [{
            type: 'area',
            name: '流入流量',
            pointInterval: 30 * 60 * 1000,  //半小时间隔
            pointStart: Date.UTC(Number(sy), Number(sm - 1), Number(sd)),
            pointEnd: Date.UTC(Number(ey), Number(em - 1), Number(ed)),
            data: []
        }, {
            type: 'area',
            name: '流出流量',
            pointInterval: 30 * 60 * 1000,
            pointStart: Date.UTC(Number(sy), Number(sm - 1), Number(sd)),
            pointEnd: Date.UTC(Number(ey), Number(em - 1), Number(ed)),
            data: []
        }]
    });
}

function reDrawChartForMonth(sy, sm, sd, ey, em, ed) {
    $("#chart_type").val('30');
    $("#container").empty();
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            zoomType: 'x',
            spacingRight: 30,
            //marginTop: 30,
            marginBottom: 80
        },
        title: {
            text: '网络流量监控——月流量图'
        },
        subtitle: {
            text: document.ontouchstart === undefined ?
					'[点击并拖动区域实现放大]' :
					'[拖动鼠标移动可见区域]'
        },
        xAxis: {
            type: 'datetime',
            maxZoom: 48 * 3600 * 1000, //最大缩放到48小时
            title: {
                text: null
            }
        },
        yAxis: {
            title: {
                text: '流入/流出(Mbps)'
            },
            min: 0.6,
            startOnTick: false,
            showFirstLabel: false
        },
        tooltip: {
            formatter: function () {
                return '<b>' + this.series.name + '</b><br/>[' +
						Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + ']： ' + this.y.toFixed(2) + ' Mbps';
            }
        },
        legend: {
            layout: 'horizontal', //vertical
            //align: 'right',
            verticalAlign: 'bottom',
            //x: 30,
            y: -25,
            borderWidth: 0
        },
        plotOptions: {
            area: {
                fillColor: {
                    linearGradient: [0, 0, 0, 300],
                    stops: [
							[0, Highcharts.theme.colors[0]],
							[1, 'rgba(2,0,0,0)']
						]
                },
                lineWidth: 1,
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            radius: 5
                        }
                    }
                },
                shadow: false,
                states: {
                    hover: {
                        lineWidth: 1
                    }
                }
            }
        },
        series: [{
            type: 'area',
            name: '流入流量',
            pointInterval: 120 * 60 * 1000,  //2小时间隔
            pointStart: Date.UTC(Number(sy), Number(sm - 1), Number(sd)),
            pointEnd: Date.UTC(Number(ey), Number(em - 1), Number(ed)),
            data: []
        }, {
            type: 'area',
            name: '流出流量',
            pointInterval: 120 * 60 * 1000,
            pointStart: Date.UTC(Number(sy), Number(sm - 1), Number(sd)),
            pointEnd: Date.UTC(Number(ey), Number(em - 1), Number(ed)),
            data: []
        }]
    });
}
