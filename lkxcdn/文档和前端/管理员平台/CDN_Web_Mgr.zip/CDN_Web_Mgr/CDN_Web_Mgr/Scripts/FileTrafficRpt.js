﻿function GetRptData(ipArea, server) {
    var date = $("#ck_time").val();
    if (date.length == 0 || date == null) {
        alert("请选择查询日期！");
        $("#ck_time").focus();
        return false;
    }
    var DateArr = date.split('-');
    var span = Number($("#chart_type").val());
    if (span == 0) {
        //alert(DateArr[1]);
        var myDate = addDay(date, 1);
        var myDateArr = myDate.split('-');
        reDrawChartForDay(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    if (span == 30) {
        var myDate = addMonth(date, 1);
        var myDateArr = myDate.split('-');
        reDrawChartForMonth(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    if (span == 7) {
        var myDate = addDay(date, 7);
        var myDateArr = myDate.split('-');
        reDrawChartForWeek(DateArr[0], DateArr[1], DateArr[2], myDateArr[0], myDateArr[1], myDateArr[2]);
    }
    //alert(date);
    var allServer = "";
    var area = $("#dl_area").val();
    var ipArr = ipArea.split(',');
    var serverArr = server.split(',');
    if (area == "全部") {
        //for (var k = 0; k < serverArr.length; k++) {
            //allServer += serverArr[k] + "|";
        //}
        var user = $("#user").val();
        allServer = user;
    }
    else {
        for (var k = 0; k < ipArr.length; k++) {
            var s = ipArr[k].split('|');
            for (var n = 0; n < serverArr.length; n++) {
                var t = serverArr[n].split(':');
                if (t[0] == s[1] && area == s[0]) {
                    allServer += serverArr[n] + "|";
                }
            }
        }
    }
    //alert(allServer);
    $.ajax(
        {
            url: '/CdnFile/GetChartDataByServer',
            data: "server=" + allServer + "&day=" + date + "&span=" + span,
            type: "POST",
            //contentType: "charset=utf-8",
            dataType: "text",
            beforeSend: window.top.showLoad,
            complete: window.top.showHide,
            success: function (data) {
                if (data == null || data.length == 0) {
                    $("#maxInTime").html();
                    $("#maxInValue").html();
                    $("#maxOutTime").html();
                    $("#maxOutValue").html();
                    return false;
                } else {
                    //alert(data);
                    var dataArr = data.split('|');
                    var inStr = dataArr[0].split('#');
                    var outStr = dataArr[1].split('#');
                    var inMax = inStr[0].split(',');
                    var outMax = outStr[0].split(',');
                    $("#maxInTime").html(inMax[0]);
                    $("#maxInValue").html((inMax[1] * 1.2).toFixed(2));
                    $("#maxOutTime").html(outMax[0]);
                    $("#maxOutValue").html((outMax[1] * 1.2).toFixed(2));
                    var inObj = eval('(' + inStr[1] + ')');
                    var outObj = eval('(' + outStr[1] + ')');

                    var outValue = eval('(' + outStr[1] + ')');
                    for (var len = 0; len < outValue.length; len++) {
                        outValue[len] = outValue[len] * 1.2;
                    }

                 //   $("#pd").html(outValue[129]);
                    outValue.sort(mysortfunc);
                    var num = outValue.length * 0.95;
                    var count = parseInt(num);

                    $("#n-five").html(outValue[count].toFixed(2));

                    for (var len = 0; len < outObj.length; len++) {
                        outObj[len] = outObj[len] * 1.2;
                    }
                    for (var len = 0; len < inObj.length; len++) {
                        inObj[len] = inObj[len] * 1.2;
                    }

                    chart.series[0].setData(inObj);
                    chart.series[1].setData(outObj);
                }
            },
            error: function (data) {
                alert(data.statusText);
            }
        });
}

function addDay(sDate, num) {
    var aYmd = sDate.split('-');
    var dt = new Date(aYmd[0], aYmd[1], aYmd[2]);
    dt.setMonth(dt.getDate() + num);
    var y = dt.getFullYear();
    var m = dt.getMonth();
    var d = dt.getDate();
    if (m < 10) m = '0' + m;
    if (d < 10) d = '0' + d;
    return y + '-' + m + '-' + d;
}

function addMonth(sDate, num) {
    var aYmd = sDate.split('-');
    var dt = new Date(aYmd[0], aYmd[1], aYmd[2]);
    dt.setMonth(dt.getMonth() + num);
    var y = dt.getFullYear();
    var m = dt.getMonth();
    var d = dt.getDate();
    if (m < 10) m = '0' + m;
    if (d < 10) d = '0' + d;
    return y + '-' + m + '-' + d;
}

function mysortfunc(str1, str2) {
    return eval(str1) - eval(str2);
} 