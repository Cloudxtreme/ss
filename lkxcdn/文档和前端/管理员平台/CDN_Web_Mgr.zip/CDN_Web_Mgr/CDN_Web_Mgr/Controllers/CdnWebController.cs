﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Text;
using CDN_Web_Mgr.Models;
using CDN_Web_Mgr.Core;
using MySql.Data.MySqlClient;

namespace CDN_Web_Mgr.Controllers
{
    public class CdnWebController : Controller
    {
        //
        // GET: /CdnWeb/

        public ActionResult Index(string user)
        {
            //List<UserModels> model = GetUserList();
            ViewData["admin"] = user;
            ViewData["adminType"] = HttpContext.Session["adminType"].ToString();
            return View();
        }

        public ActionResult ServerList()
        {
            return View();
        }

        public ActionResult TopTraffic(string user)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
            else
            {
                string timeSpan = GetDateTable();
                if (!string.IsNullOrEmpty(timeSpan))
                {
                    ViewData["TimeSpan"] = timeSpan;
                }
                ViewData["user"] = user;
                ViewData["domain"] = GetDoaminByClient(user.Trim());
                return View();
            }
            //return View();
        }

        public ActionResult ClientList()
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
             List<UserModels> model = new List<UserModels>();
             List<UserModels> clientList = GetUserList();
             if(clientList!=null)
             {
                 List<UserModels> Data =new List<UserModels>();
                foreach(UserModels item in clientList)
                {
                     List<UserModels> domainList = GetDoaminByClient(item.name);
                     if ( domainList!=null&&domainList.Count > 0)
                     {
                         foreach (UserModels m in domainList)
                         {
                             UserModels obj = new UserModels();
                             obj.status = item.status;
                             obj.name = item.name;
                             obj.password = item.password;
                             obj.domain = m.domain;
                             obj.mydesc = item.mydesc;
                             obj.puser = item.puser;
                             Data.Add(obj);
                         }

                         //UserModels obj = new UserModels();
                         //obj.status = item.status;
                         //obj.name = item.name;
                         //obj.password = item.password;
                         //string domain = "";

                         //foreach (UserModels m in domainList)
                         //{
                         //    domain += m.domain + "<br>";
                         //}
                         //obj.domain = domain.Substring(0, domain.Length - 1);

                         //Data.Add(obj);
                     }
                }
                model = Data;
             }
             return View(model);
        }

        public ActionResult SubClientList()
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
            
            List<UserModels> model = new List<UserModels>();
            List<UserModels> clientList = GetDistUserList();
            if (clientList != null)
            {
                model = clientList;
            }
            return View(model);
        }

        public string GetSubInfo(string name)
        {
            string res = GetSubUserInfo(name);

            return res;
        }

        public string SaveSubClient(string subname,string pwd,string puser,string desc,string mydesc)
        {
            string res = SaveClient(subname, pwd, puser,desc,mydesc);
            //if (res == "ok")
            //{
            //    SaveHostName(subname, domain);
            //}

            return "";
        }

        public string SaveClient(string subname, string pwd, string puser,string desc,string mydesc)
        {
            try
            {
                string pass = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5");
                MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                StringBuilder strSql = new StringBuilder();
                conn.Open();
                strSql.Append("insert into `user`(`user`,`pass`,`puser`,`status`,`desc`,`mydesc`) value('" + subname + "','" + pass + "','" + puser + "','true','" + desc + "','" + mydesc + "') ");
                MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                int result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                if (1 == result)
                    return "ok";
            }
            catch
            {
                return "error";
            }
            return "ok";
        }

        public string DelSubClient(string id)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                StringBuilder strSql = new StringBuilder();
                conn.Open();
                strSql.Append("delete from `user_hostname` where id = " + id + ";");
                MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                int result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                if (1 == result)
                    return "ok";
            }
            catch
            {
                return "error";
            }
            return "ok";
        }

        public string SaveHostName(string owner, string hostname)
        {
            try
            {
                string[] arr = hostname.Split(';');
                MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                StringBuilder strSql = new StringBuilder();
                conn.Open();
                foreach(string domain in arr){
                    string[] item = domain.Split(',');
                    strSql.Append("insert into `user_hostname`(`hostname`,`domainname`,`tablename` ,`owner`,`status`) value('" + item[0] + "','" + item[1] + "','" + item[2] + "','" + owner + "','true');");
                }
                
                MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                int result = cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                if (1 == result)
                    return "ok";
            }
            catch
            {
                return "error";
            }
            return "ok";
        }
        
        public ActionResult OutSpanTraffic()
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
            List<TrafficModels> listData = GetSpanData("out");
            if (listData != null) 
            {
                string domainStr = "";
                string inrate = "";
                string outrate = "";
                foreach (TrafficModels item in listData)
                {
                    domainStr += "'";
                    domainStr += item.domain;
                    domainStr += "',";

                    inrate += item.in_value.ToString("F2");
                    inrate += ",";

                    outrate += item.out_value.ToString("F2");
                    outrate += ",";
                }
                ViewData["client"] = MvcHtmlString.Create(domainStr.Substring(0, domainStr.Length - 1));
                ViewData["outrate"] = outrate;
                ViewData["inrate"] = inrate;
            }
            return View();
        }
        public ActionResult InSpanTraffic()
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
            List<TrafficModels> listData = GetSpanData("in");
            if (listData != null)
            {
                string domainStr = "";
                string inrate = "";
                string outrate = "";
                foreach (TrafficModels item in listData)
                {
                    domainStr += "'";
                    domainStr += item.domain;
                    domainStr += "',";

                    inrate += item.in_value.ToString("F2");
                    inrate += ",";

                    outrate += item.out_value.ToString("F2");
                    outrate += ",";
                }
                ViewData["client"] = MvcHtmlString.Create(domainStr.Substring(0, domainStr.Length - 1));
                ViewData["outrate"] = outrate;
                ViewData["inrate"] = inrate;
            }
            return View();
        }

        public ActionResult HitList(int page=1)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
            ViewData["page"] = page;
            ViewData["TotalNum"] = 1;
            List<HitModels> data = new List<HitModels>();
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("select * from client_hit_ex where `timestamp`>='"+DateTime.Now.AddMinutes(-5).ToString("yyyy-MM-dd HH:mm")+"' and `ip` in('112.90.177.77','116.28.64.173') order by `timestamp`");
                DataSet countDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.HIT_MYSQL_SERVER, strSql.ToString());
                if (countDs.Tables[0].Rows.Count > 0)
                {
                    ViewData["TotalNum"] = countDs.Tables[0].Rows.Count;
                }
                strSql.Clear();
                strSql.Append("select * from client_hit_ex where `timestamp`>='" + DateTime.Now.AddMinutes(-5).ToString("yyyy-MM-dd HH:mm") + "' and `ip` in('112.90.177.77','116.28.64.173') order by `timestamp` LIMIT 20 OFFSET " + (page - 1) * 20);
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.HIT_MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    foreach(DataRow dr in Ds.Tables[0].Rows)
                    {
                        HitModels item = new HitModels();
                        item.sent_hit = dr["senthit"].ToString() + "%";
                        item.req_hit = dr["reqhit"].ToString() + "%";
                        item.updateTime = DateTime.Parse(dr["timestamp"].ToString());
                        item.hostname = dr["hostname"].ToString();
                        if (dr["ip"].ToString() == "116.28.64.173")
                        {
                            item.nettype = "电信";
                        }
                        else
                        {
                            item.nettype = "网通";
                        }
                        data.Add(item);
                    }
                }
            }
            catch
            { }
            return View(data);
        }

        public ActionResult TrafficRpt(string user)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("Login", "Home");
            }
            ViewData["user"] = user;
            string IpStr = GetIpStr("全部");
            string timeSpan = GetDateTable();
            ViewData["area"] = null;
            ViewData["TimeSpan"] = null;
            ViewData["server"] = null;
            if (!string.IsNullOrEmpty(IpStr))
            {
                ViewData["server"] = IpStr.Replace("'", "");
                string area = GetAreaByIp(IpStr);
                ViewData["area"] = area;
            }
            if (!string.IsNullOrEmpty(timeSpan))
            {
                ViewData["TimeSpan"] = timeSpan;
            }
            return View();
        }

        //ajax method
        //查询单个用户总流量
        [HttpPost, ActionName("GetHostTotal")]
        public string GetHostTotal(string start, string end, string user)
        {
            if (string.IsNullOrEmpty(HttpContext.Session["admin"].ToString()))
            {
                return "TimeOut";
            }
            else
            {
                DateTime s = DateTime.Parse(start.Trim());
                DateTime e = DateTime.Parse(end.Trim());
                TimeSpan span = e - s;
                string conStr = Core.MySqlConn.GetStatsConn().Replace("cdn_portrate_stats", "cdn_client_traffic");
                string portStr = GetPortByUser(user.Trim());
                string domainStr = GetDomainByUser(user.Trim());
                if (conStr.Length > 0 && portStr.Length > 0)
                {
                    if (span.TotalDays > 0)  //超过一天
                    {
                        List<HostTotalModels> data = new List<HostTotalModels>();
                        StringBuilder result = new StringBuilder();
                        for (int i = 0; i <= span.TotalDays; i++)
                        {
                            if (TableIsExist(s.AddDays(i), conStr))
                            {
                                HostTotalModels item = new HostTotalModels();
                                item = GetSingleHostTotal(conStr, s.AddDays(i), portStr, domainStr);
                                data.Add(item);
                            }
                            else
                            {
                                continue;
                            }
                        }
                        if (data != null)
                        {
                            Double totalStream = 0;
                            foreach (HostTotalModels obj in data)
                            {
                                totalStream += obj.totalStream;
                            }
                            return (totalStream).ToString("F4");
                        }
                    }
                    else       //查询一天
                    {
                        if (TableIsExist(s, conStr))  //表存在
                        {
                            HostTotalModels model = new HostTotalModels();
                            model = GetSingleHostTotal(conStr, s, portStr, domainStr);
                            if (model != null)
                            {
                                return (model.totalStream).ToString("F4");
                            }
                        }
                    }
                }
                return "";
            }
        }

        //峰值统计
        [HttpPost, ActionName("GetTopStream")]
        public string GetTopStream(string user, string start, string span, string domain, int bfb)
        {
            if (string.IsNullOrEmpty(HttpContext.Session["admin"].ToString()))
            {
                return "TimeOut";
            }
            else
            {
                DateTime _start = DateTime.Parse(start.Trim());
                string _span = span.Trim();
                string conStr = Core.MySqlConn.GetStatsConn();
                //string IpStr = GetIpStr("全部");
                string IpStr = "全部";
                //string portStr = GetPortByDomain(user.Trim(), domain.Trim());
                string domainStr = GetDomainByUser(user.Trim());
                if (!string.IsNullOrEmpty(IpStr))
                {
                    string[] domArr = SplitDomain(domainStr);
                    List<TrafficModels> Data_Is = new List<TrafficModels>();
                    List<TrafficModels> Data_No = new List<TrafficModels>();
                    if (!string.IsNullOrEmpty(domArr[1])) //没有*的
                    {
                        GetRptData DoGetData = new GetRptData();
                        if (span == "一天")
                        {
                            Data_No = DoGetData.GetTopRpt(_start, 0, IpStr, domainStr);
                        }
                        if (span == "一周")
                        {
                            Data_No = DoGetData.GetTopRpt(_start, 7, IpStr, domainStr);
                        }
                        if (span == "一月")
                        {
                            Data_No = DoGetData.GetTopRpt(_start, 30, IpStr, domainStr);
                        }
                    }
                    if (!string.IsNullOrEmpty(domArr[0])) //有*的
                    {
                        GetXinRptData DoGetData = new GetXinRptData();
                        if (span == "一天")
                        {
                            Data_Is = DoGetData.GetTopRpt(_start, 0, IpStr, domainStr);
                        }
                        if (span == "一周")
                        {
                            Data_Is = DoGetData.GetTopRpt(_start, 7, IpStr, domainStr);
                        }
                        if (span == "一月")
                        {
                            Data_Is = DoGetData.GetTopRpt(_start, 30, IpStr, domainStr);
                        }
                    }
                    List<TrafficModels> Data = new List<TrafficModels>();
                    if (Data_No != null && Data_No.Count > 0)
                    {
                        if (Data == null || Data.Count == 0)
                        {
                            Data.AddRange(Data_No);
                        }
                        else
                        {
                            for (int i = 0; i < Data_No.Count; i++)
                            {
                                //Data[i].in_value += Data_No[i].in_value;
                                Data[i].out_value += Data_No[i].out_value;
                            }
                        }
                    }
                    if (Data_Is != null && Data_Is.Count > 0)
                    {
                        if (Data == null || Data.Count == 0)
                        {
                            Data.AddRange(Data_Is);
                        }
                        else
                        {
                            for (int i = 0; i < Data_Is.Count; i++)
                            {
                                //Data[i].in_value += Data_No[i].in_value;
                                Data[i].out_value += Data_Is[i].out_value;
                            }
                        }
                    }
                    List<TrafficModels> outList = new List<TrafficModels>();
                    if (Data != null)
                    {
                        Data.Sort(new TrafficOutComparer());
                        foreach (TrafficModels item in Data)
                        {
                            item.out_value = item.out_value * 1.2;
                            item.in_value = item.in_value * 1.2;

                            outList.Add(item);
                        }
                        //int start_out_num = Convert.ToInt16(outList.Count * ((bfb - 1) / 100.0));
                        //int end_out_num = Convert.ToInt16(outList.Count * ((bfb + 1) / 100.0));

                        int start_out_num = Convert.ToInt16(outList.Count * ((99 - bfb) / 100.0));
                        int end_out_num = Convert.ToInt16(outList.Count * ((101 - bfb) / 100.0));

                        //int getX = Convert.ToInt16(outList.Count * (bfb / 100.0));

                        //List<TrafficModels> rslt_outList = new List<TrafficModels>();
                        //for (int x = start_out_num; x < end_out_num; x++)
                        //{
                        //    double s = x / Convert.ToDouble(outList.Count) * 100.0;
                        //    outList[x].bfb = s.ToString("F2") + "%";

                        //    if (x == getX)
                        //    {
                        //        //outList[x].domain = "参考结果";
                        //        outList[x].bfb = bfb.ToString() + "%";
                        //        rslt_outList.Add(outList[x]);
                        //    }

                        //    //rslt_outList.Add(outList[x]);
                        //}
                        //string returnStr = GetTopJson(rslt_outList);
                        //return returnStr;

                        int getX = Convert.ToInt16(outList.Count * ((100 - bfb) / 100.0));

                        List<TrafficModels> rslt_outList = new List<TrafficModels>();
                        for (int x = start_out_num; x < end_out_num; x++)
                        {
                            //double s = x / Convert.ToDouble(outList.Count) * 100.0;
                            double s = 100.0 - x / Convert.ToDouble(outList.Count) * 100.0;
                            outList[x].bfb = s.ToString("F2") + "%";

                            if (x == getX)
                            {
                                outList[x].bfb = bfb.ToString() + "%";
                                rslt_outList.Add(outList[x]);
                            }

                            // rslt_outList.Add(outList[x]);
                        }
                        return GetTopJson(rslt_outList);
                    }
                }
                return "[]";
            }
        }

   

        //修改用户备注信息
        [HttpPost, ActionName("SaveClientInfo")]
        public string SaveClientInfo(int id, string desc,string mydesc)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "登录超时，请重新登录！";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("update `user` set `desc`='" + desc.Trim() + "', `mydesc`='" + mydesc.Trim() + "' where `id`=" + id);
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "修改成功！";
                }
                catch
                {
                    return "修改报错，请联系管理员！";
                }
                return "修改失败！";
            }
        }

        //获取服务器列表
        [HttpPost, ActionName("GetServerList")]
        public string GetServerList()
        {
            if (HttpContext.Session["adminType"].ToString() == "user")
            {
                return "";
            }
            else
            {
                string result = DoGetServerList();
                return result;
            }
        }

        //添加服务器
        [HttpPost, ActionName("AddServer")]
        public string AddServer(string ip, int port, string nettype, string zone, string desc)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("insert into `server_list`(`ip`,`port`,`nettype`,`zone`,`type`,`desc`) values('" + ip.Trim() + "'," + port + ",'" + nettype.Trim() + "','" + zone.Trim() + "','node','" + desc.Trim() + "')");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //编辑服务器
        [HttpPost, ActionName("EditServer")]
        public string EditServer(int id, string ip, int port, string nettype, string zone, string desc)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("update `server_list` set `ip`='" + ip.Trim() + "',`port`=" + port + ",`nettype`='" + nettype.Trim() + "',`zone`='" + zone.Trim() + "',`desc`='" + desc.Trim() + "' where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //删除服务器
        [HttpPost, ActionName("DeleteServer")]
        public string DeleteServer(int id)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("delete from `server_list` where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //获取chart数据
        [HttpPost, ActionName("GetChartDataByServer")]
        public string GetChartDataByServer(string user, string server, string day, int span)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                string ipStr = "";
                if (server.IndexOf('|') > 0)
                {
                    string[] list = server.Trim().Split('|');
                    for (int i = 0; i < list.Length - 1; i++)
                    {
                        string[] s = list[i].Split(':');
                        if (i == 0)
                        {
                            ipStr = "'" + s[0] + "'";
                        }
                        else
                        {
                            ipStr += ",'" + s[0] + "'";
                        }
                    }
                }
                else if (server == "全部")
                {
                    ipStr = "全部";
                }
                else
                {
                    ipStr = "'" + server + "'";
                }
                //string portStr = GetPort(user.Trim());
                string domainStr = GetDomainByUser(user.Trim());
                GetRptData getData = new GetRptData();
                GetXinRptData getXinData = new GetXinRptData();
                List<TrafficModels> result = new List<TrafficModels>();
                string[] domArr = SplitDomain(domainStr);
                if (!string.IsNullOrEmpty(domArr[0])) //有*的
                {
                    string[] dom_item_Arr = domArr[0].Split(',');
                    foreach (string dom_item in dom_item_Arr)
                    {
                        List<TrafficModels> itemdata = getXinData.GetRptDataList(DateTime.Parse(day), span, ipStr, dom_item);
                        if (itemdata != null && itemdata.Count > 0)
                        {
                            if (result == null || result.Count == 0)
                            {
                                result.AddRange(itemdata);
                            }
                            else
                            {
                                for (int i = 0; i < itemdata.Count; i++)
                                {
                                    result[i].in_value += itemdata[i].in_value;
                                    result[i].out_value += itemdata[i].out_value;
                                }
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(domArr[1])) //没有*的
                {
                    List<TrafficModels> itemdata = getData.GetRptDataList(DateTime.Parse(day), span, ipStr, domArr[1]);
                    if (itemdata != null && itemdata.Count > 0)
                    {
                        if (result == null || result.Count == 0)
                        {
                            result.AddRange(itemdata);
                        }
                        else
                        {
                            for (int i = 0; i < itemdata.Count; i++)
                            {
                                result[i].in_value += itemdata[i].in_value;
                                result[i].out_value += itemdata[i].out_value;
                            }
                        }
                    }
                }
                //List<TrafficModels> result = getData.GetRptDataList(DateTime.Parse(day), span, ipStr, portStr, domainStr);
                return GetChartJson(result);
                //return GetChartJson(result["in"]) + "|" + GetChartJson(result["out"]);
            }
        }

        public class TrafficInComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.in_value.CompareTo(x.in_value));
            }
        }

        public class TrafficOutComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.out_value.CompareTo(x.out_value));
            }
        }

        //private method
        //根据域名获取端口号
        private string GetPortByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                string portStr = "";
                strSql.Append("SELECT distinct `squidport` FROM `domain_info` where `owner`='" + user + "'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        portStr += "'" + dr["squidport"].ToString() + "',";
                    }
                    return portStr.Substring(0, portStr.Length - 1);
                }
                return "";
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //查询单个域名下载及总流量
        private HostTotalModels GetSingleHostTotal(string conn, DateTime _tb, string _port, string _domain)
        {
           // string sql = "SELECT sum(traffic)/1024/1024 FROM `" + _tb.ToString("yyyy-MM-dd") + "` where `port` in (" + _port + ") or `hostname` in(" + _domain + ")";
            string sql = "SELECT sum(traffic)/1024/1024 FROM `" + _tb.ToString("yyyy-MM-dd") + "` where  `hostname` in(" + _domain + ")";
            DataSet ds = MySqlHelper.ExecuteDataset(conn, sql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                HostTotalModels obj = new HostTotalModels();
                try
                {
                    obj.totalStream = Double.Parse(ds.Tables[0].Rows[0][0].ToString());
                }
                catch
                {
                    obj.totalStream = 0;
                }
                return obj;
            }
            return null;
        }

        //获取该用户的域名
        private string GetDomainByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `hostname` FROM `user_hostname` where `owner` ='" + user + "' and `status` = 'true';");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string ret = "";
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ret += "'" + dr["hostname"].ToString() + "',";
                    }
                    return ret.Substring(0, ret.Length - 1);
                }
                return "";
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //根据客户名获取域名列表
        private List<UserModels> GetDoaminByClient(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                //strSql.Append("SELECT * FROM `domain_info` where `owner`='" + user + "'");
                strSql.Append("SELECT distinct `domainname` FROM `user_hostname` where `owner`='" + user + "'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<UserModels> data = new List<UserModels>();
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        UserModels item = new UserModels();
                        //item.domain = Ds.Tables[0].Rows[i]["hostname"].ToString();
                        item.domain = Ds.Tables[0].Rows[i]["domainname"].ToString();
                        //item.status = Ds.Tables[0].Rows[i]["desc"].ToString();
                        data.Add(item);
                    }
                    return data;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        private List<TrafficModels> GetSpanData(string type)
        {
            try
            {
                //string ttt = DateTime.Now.ToString("HH:mm");
                //string s = ttt.Substring(ttt.Length - 1, 1);
                //string start = "";
                //string end = "";
                //if (int.Parse(s) <= 5 && int.Parse(s) > 0)
                //{
                //    start = ttt.Substring(0, 4) + "0";
                //    end = ttt.Substring(0, 4) + "5";
                //}
                //if (int.Parse(s) > 5)
                //{
                //    start = ttt.Substring(0, 4) + "5";
                //    end = ttt.Substring(0, 3) + (int.Parse(ttt.Substring(3, 1)) + 1).ToString() + "0";
                //}
                //if (int.Parse(s) == 0)
                //{
                //    start = ttt.Substring(0, 3) + (int.Parse(ttt.Substring(3, 1)) - 1).ToString() + "5";
                //    end = ttt;
                //}

              //  string ttt = DateTime.Now.AddMinutes(-10).ToString("HH:mm");
              //  string s = ttt.Substring(ttt.Length - 1, 1);
                string start = DateTime.Now.AddMinutes(-10).ToString("HH:mm");
                string end = DateTime.Now.ToString("HH:mm");
                

                StringBuilder sqlStr = new StringBuilder();
                sqlStr.Clear();
                string table = DateTime.Now.ToString("yyyy-MM-dd");
                if (type == "out")
                {
                    sqlStr.Append("SELECT sum(`inrate`), sum(`outrate`),`hostname` FROM `" + table + "` where `time`>= '" + start + "' and `time`<= '" + end + "' group by `hostname` order by sum(`outrate`) desc LIMIT 20 OFFSET 0");
                }
                else
                {
                    sqlStr.Append("SELECT sum(`inrate`), sum(`outrate`),`hostname` FROM `" + table + "` where `time`>= '" + start + "' and `time`<= '" + end + "' group by `hostname` order by sum(`inrate`) desc LIMIT 20 OFFSET 0");
                }
               
                MySqlConnection myStatsCn = new MySqlConnection(Core.MySqlConn.GetStatsConn());
                myStatsCn.Open();
                DataSet Ds3 = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(myStatsCn, sqlStr.ToString());
                myStatsCn.Close();
                if (Ds3.Tables[0].Rows.Count > 0)
                {
                    List<TrafficModels> Data = new List<TrafficModels>();
                    foreach (DataRow row in Ds3.Tables[0].Rows)
                    {
                        //if (row["hostname"].ToString() != tmp_host)
                        {
                            TrafficModels item = new TrafficModels();
                            item.domain = row["hostname"].ToString(); //GetDomainByPort(row["port"].ToString());
                            item.in_value = double.Parse(row["sum(`inrate`)"].ToString()) / 1024 / 1024 * 8;
                            item.out_value = double.Parse(row["sum(`outrate`)"].ToString()) / 1024 / 1024 * 8;
                            Data.Add(item);
                        }
                    }
                    return Data;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        //查询所有的服务器信息
        private string DoGetServerList()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `id`,`ip`,`port`,`nettype`,`zone`,`desc` FROM `server_list` where `type`='node'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    StringBuilder json = new StringBuilder();
                    json.Clear();
                    json.Append("[");
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i != Ds.Tables[0].Rows.Count - 1)
                        {
                            json.Append("{ \"id\": \"" + Ds.Tables[0].Rows[i]["id"].ToString() + "\",");
                            json.Append("\"ip\": \"" + Ds.Tables[0].Rows[i]["ip"].ToString() + "\",");
                            json.Append("\"port\": \"" + Ds.Tables[0].Rows[i]["port"].ToString() + "\",");
                            json.Append("\"nettype\": \"" + Ds.Tables[0].Rows[i]["nettype"].ToString() + "\",");
                            json.Append("\"zone\": \"" + Ds.Tables[0].Rows[i]["zone"].ToString() + "\",");
                            json.Append("\"desc\": \"" + Ds.Tables[0].Rows[i]["desc"].ToString() + "\" },");
                        }
                        else
                        {
                            json.Append("{ \"id\": \"" + Ds.Tables[0].Rows[i]["id"].ToString() + "\",");
                            json.Append("\"ip\": \"" + Ds.Tables[0].Rows[i]["ip"].ToString() + "\",");
                            json.Append("\"port\": \"" + Ds.Tables[0].Rows[i]["port"].ToString() + "\",");
                            json.Append("\"nettype\": \"" + Ds.Tables[0].Rows[i]["nettype"].ToString() + "\",");
                            json.Append("\"zone\": \"" + Ds.Tables[0].Rows[i]["zone"].ToString() + "\",");
                            json.Append("\"desc\": \"" + Ds.Tables[0].Rows[i]["desc"].ToString() + "\" }");
                        }
                    }
                    json.Append("]");
                    return json.ToString();
                }
                return "";
            }
            catch
            {
                return null;
            }
        }

        //得到数据库里存在的天的表   cdn_portrate_stats库
        private string GetDateTable()
        {
            try
            {
                string strSql = "SHOW TABLES";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetStatsConn(), strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                    }
                    return result;
                }
            }
            catch
            {
                return "Error";
            }
            return "Null";
        }

        //根据用户的所有ip得到所拥有的（区域|ip）
        private string GetAreaByIp(string ip)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `zone`,`ip`,`port` FROM `server_list` where `ip` in(" + ip + ")");  // Group by `zone` and port in(" + port + ")
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                    }
                    return result;
                }
                return "";
            }
            catch
            {
                return null;
            }
        }

        //获取用户列表
        private List<UserModels> GetUserList()
        {
            try
            {
                if (HttpContext.Session["admin"] == null)
                {
                    return null;
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    List<UserModels> Data = new List<UserModels>();
                    strSql.Append("SELECT * FROM `user` where `status`='true'");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in Ds.Tables[0].Rows)
                        {
                            UserModels item = new UserModels();
                            item.id = int.Parse(dr["id"].ToString());
                            item.name = dr["user"].ToString();
                            item.password = dr["pass"].ToString();
                            item.status = dr["desc"].ToString();
                            item.mydesc = dr["mydesc"].ToString();
                            item.puser = dr["puser"].ToString();
                            Data.Add(item);
                        }
                    }
                    return Data;
                }
            }
            catch
            {
                return null;
            }
        }

        //获取用户列表
        private List<UserModels> GetDistUserList()
        {
            try
            {
                if (HttpContext.Session["admin"] == null)
                {
                    return null;
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    List<UserModels> Data = new List<UserModels>();
                    strSql.Append("SELECT distinct `user` FROM `user` where `status`='true'");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in Ds.Tables[0].Rows)
                        {
                            UserModels item = new UserModels();
                        //    item.id = int.Parse(dr["id"].ToString());
                            item.name = dr["user"].ToString();
                         //   item.password = dr["pass"].ToString();
                         //   item.status = dr["desc"].ToString();
                        //    item.mydesc = dr["mydesc"].ToString();
                            Data.Add(item);
                        }
                    }
                    return Data;
                }
            }
            catch
            {
                return null;
            }
        }

        //获取用户列表
        private string GetSubUserInfo(string name)
        {
            try
            {
                if (HttpContext.Session["admin"] == null)
                {
                    return null;
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    StringBuilder strRes = new StringBuilder();
                    string str = string.Empty;
                    string temp = string.Empty;
                    string hostname = string.Empty;
                 
                    List<UserModels> Data = new List<UserModels>();
                    strSql.Append("SELECT * FROM `user_hostname` where `owner` = '" + name + "' and `status`='true';");
                    strSql.Append("SELECT * FROM `user_hostname` where `owner` in( SELECT distinct `user`  FROM `user` where `puser` = '" + name + "' and `status`='true') and `status`='true' order by `owner`;");
                    strSql.Append(" SELECT distinct `user`  FROM `user` where `puser` = '" + name + "' and `status`='true';");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in Ds.Tables[0].Rows)
                        {
                            strRes.Append(dr["hostname"].ToString() + "," + dr["domainname"].ToString() + "," + dr["tablename"].ToString() + ";");
                        }

                        str = strRes.ToString().Substring(0, strRes.Length - 1) ;
                    }
                    if (Ds.Tables[1].Rows.Count > 0)
                    {
                        strRes.Clear();
                        //strRes.Append("[");
                        foreach (DataRow dr in Ds.Tables[1].Rows)
                        {
                            strRes.Append(dr["hostname"].ToString() + "," + dr["domainname"].ToString() + "," + dr["tablename"].ToString() + "," + dr["id"].ToString() + "," + dr["owner"].ToString() + ";");
                            //strRes.Append("{\"hostname\":\"" + dr["hostname"].ToString() + "\",");
                            //strRes.Append("\"domainname\":\"" + dr["domainname"].ToString() + "\",");
                            //strRes.Append("\"tablename\":\"" + dr["tablename"].ToString() + "\"},");
                        }

                        temp = strRes.ToString().Substring(0, strRes.Length - 1);
                       
                    }

                    if (Ds.Tables[2].Rows.Count > 0)
                    {
                        strRes.Clear();
                        foreach (DataRow dr in Ds.Tables[2].Rows)
                        {
                            strRes.Append(dr["user"].ToString() + ",");
                        }

                        hostname = strRes.ToString().Substring(0, strRes.Length - 1);

                    }

                    str = str + "***"+ temp + "***" + hostname;
                    return str;
                }
            }
            catch
            {
                return null;
            }
        }


        //通过端口号得到域名
        private string GetDomainByPort(string port)
        {
            string sql = "select `hostname` from domain_info where `squidport` = '" + port + "'";
            DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
            if (Ds.Tables[0].Rows.Count > 0)
            {
                return Ds.Tables[0].Rows[0][0].ToString();
            }
            return null;
        }

        //获取端口号
        private string GetPort(string user)
        {
            string sql = "select `squidport` from domain_info where `owner` = '" + user + "'";
            DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
            if (Ds.Tables[0].Rows.Count > 0)
            {
                string result = "";
                for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                {
                    if (i == 0)
                    {
                        result = Ds.Tables[0].Rows[i]["squidport"].ToString();
                    }
                    else
                    {
                        result += ",";
                        result += Ds.Tables[0].Rows[i]["squidport"].ToString();
                    }
                }
                return result;
            }
            return null;
        }

        //通过区域获取ip地址
        private string GetIpStr(string area)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                //strSql.Append("SELECT `ip`,`port` FROM `user_squid` where `user`='" + user + "'");
                if (area == "全部")
                {
                   // strSql.Append("select `ip` from server_list where `type` = 'report'");
                    strSql.Append("select `ip` from server_list where `type` = 'cdn_stats'");
                }
                else
                {
                    strSql.Append("select `ip` from server_list where `type` = 'cdn_stats' and `zone`='" + area + "'");
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result = "'" + Ds.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                        else
                        {
                            result += ",'";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                    }
                    return result;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //转换成json格式字符串
        private string GetJson(List<IpPortModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                StringBuilder json = new StringBuilder();
                json.Append("[");
                for (int i = 0; i < t.Count; i++)
                {
                    if (i != t.Count - 1)
                    {
                        json.Append("{ \"id\": \"" + t[i].id + "\",");
                        json.Append("\"ip\": \"" + t[i].ip + "\",");
                        json.Append("\"port\": \"" + t[i].port + "\",");
                        json.Append("\"hostname\": \"" + t[i].hostname + "\" },");
                    }
                    else
                    {
                        json.Append("{ \"id\": \"" + t[i].id + "\",");
                        json.Append("\"ip\": \"" + t[i].ip + "\",");
                        json.Append("\"port\": \"" + t[i].port + "\",");
                        json.Append("\"hostname\": \"" + t[i].hostname + "\" }");
                    }
                }
                json.Append("]");
                return json.ToString();
            }
            catch
            {
                return "";
            }
        }

        //图表专用
        private string GetChartJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                TrafficModels maxOutObj = new TrafficModels();
                TrafficModels maxInObj = new TrafficModels();
                string out_json = "";
                string in_json = "";
                foreach (TrafficModels model in t)
                {
                    if (model != t[t.Count - 1])
                    {
                        out_json += model.out_value + ",";
                        in_json += model.in_value + ",";
                    }
                    else
                    {
                        out_json += model.out_value;
                        in_json += model.in_value;
                    }
                    if (maxOutObj.out_value < model.out_value)
                    {
                        maxOutObj.out_value = model.out_value;
                        maxOutObj.time = model.time;
                    }
                    if (maxInObj.in_value < model.in_value)
                    {
                        maxInObj.in_value = model.in_value;
                        maxInObj.time = model.time;
                    }
                }
                string ret_json = maxInObj.time + "," + maxInObj.in_value + "#[" + in_json + "]" + "|" + maxOutObj.time + "," + maxOutObj.out_value + "#[" + out_json + "]";
                return ret_json;
            }
            catch
            {
                return "";
            }
        }

        //根据日期判断数据库是否存在该表
        private bool TableIsExist(DateTime date, string conn)
        {
            try
            {
                string strSql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        //获取端口号
        private string GetPortByDomain(string user, string domain)
        {
            if (domain == "全部")
            {
                string sql = "select `squidport` from domain_info where `owner` = '" + user + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result = Ds.Tables[0].Rows[i]["squidport"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["squidport"].ToString();
                        }
                    }
                    return result;
                }
            }
            else
            {
                string sql = "select `squidport` from domain_info where `owner` = '" + user + "' and  `hostname`='" + domain + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return Ds.Tables[0].Rows[0]["squidport"].ToString();
                }
            }
            return null;
        }

        //峰值统计专用
        private string GetTopJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                StringBuilder json = new StringBuilder();
                json.Append("[");
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].in_value > 0 || t[i].out_value > 0)
                    {
                        if (i != t.Count - 1)
                        {
                            json.Append("{ id: \"" + t[i].bfb + "\",");
                            json.Append("out_stream: \"" + t[i].out_value + "\",");
                            json.Append("in_stream: \"" + t[i].in_value + "\",");

                            json.Append("domin: \"" + t[i].domain + "\",");

                            json.Append("datetime: \"" + t[i].time + "\" },");
                        }
                        else
                        {
                            json.Append("{ id: \"" + t[i].bfb + "\",");
                            json.Append("out_stream: \"" + t[i].out_value + "\",");
                            json.Append("in_stream: \"" + t[i].in_value + "\",");

                            json.Append("domin: \"" + t[i].domain + "\",");

                            json.Append("datetime: \"" + t[i].time + "\" }");
                        }
                    }
                }
                json.Append("]");
                return json.ToString();
            }
            catch
            {
                return "";
            }
        }

        //拆分星号和不带星号域名
        private string[] SplitDomain(string domain)
        {
            string[] arr = domain.Split(',');
            string IsDomstr = "";
            string NoDomstr = "";
            foreach (string s in arr)
            {
                if (s.IndexOf('*') >= 0)
                {
                    IsDomstr += s + ",";
                }
                else
                {
                    NoDomstr += s + ",";
                }
            }
            string retIs = string.IsNullOrEmpty(IsDomstr) ? "" : IsDomstr.Substring(0, IsDomstr.Length - 1);
            string retNo = string.IsNullOrEmpty(NoDomstr) ? "" : NoDomstr.Substring(0, NoDomstr.Length - 1);
            string[] ret = new string[2] { retIs, retNo };
            return ret;
        }

    }
}
