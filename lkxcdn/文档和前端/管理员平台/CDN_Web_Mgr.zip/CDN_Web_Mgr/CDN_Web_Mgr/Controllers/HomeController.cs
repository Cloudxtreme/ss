﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using CDN_Web_Mgr.Models;
using System.Data;
using CDN_Web_Mgr.Core;

namespace CDN_Web_Mgr.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            Cookie Cookie = new Cookie();
            ViewData["name"] = "";
            ViewData["pwd"] = "";
            string name = Cookie.getCookie("cndMgrName");//取值
            string pwd = Cookie.getCookie("cndMgrPwd");
            if(!string.IsNullOrEmpty(name))
            {
                ViewData["name"] = name;
            }
            if (!string.IsNullOrEmpty(pwd))
            {
                ViewData["pwd"] = pwd;
            }
            //Cookie.delCookie("name");//删除
            return View();
        }

        public ActionResult AllTrafficRpt()
        {
            if (HttpContext.Session["admin"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            ViewData["TimeSpan"] = GetDateTable();
            ViewData["server"] = GetServerList();
            return View();
        }

        public ActionResult Logout()
        {
            return View();
        }

        //Ajax Mothed
        //获取chart数据
        [HttpPost, ActionName("GetChartDataByServer")]
        public string GetChartDataByServer(string type, string area, string day, int span)
        {
            if (HttpContext.Session["admin"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            string ipStr = GetIpByTypeAndArea(type, area);
            GetAllTraffic getData = new GetAllTraffic();
            List<TrafficModels> result = getData.GetRptDataList(DateTime.Parse(day), span, ipStr);
            return GetChartJson(result);
            //return "查询条件为空！";
        }

        //用户登录验证
        public string CheckIbssLogin(string user, string pwd)
        {
            MySqlConnection conn = new MySqlConnection(Core.MySqlConn.MYSQL_LOGIN);
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(user) | r.IsMatch(pwd))
                {
                    //SQL注入
                    return "false";
                }
                else
                {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("SELECT `id`,`name` FROM `user` where `name`='" + user.Trim() + "' and `pass`='" + pwd + "'");
                  //  strSql.Append("SELECT `id`,`name` FROM `user` where `name`='" + user.Trim() + "'");
                 //   strSql.Append("SELECT `id`,`name` FROM `user`");

                    DataSet sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, strSql.ToString());
                    conn.Close();
                    if (sdr.Tables[0] != null)
                    {
                        if (!string.IsNullOrEmpty(sdr.Tables[0].Rows[0]["name"].ToString()))
                        {
                            HttpContext.Session["admin"] = sdr.Tables[0].Rows[0]["name"];    //用户名
                            HttpContext.Session["adminType"] = "user";    //用户权限
                            return "true";
                        }
                    }
                }
                return "false";
            }
            catch
            {
                if (conn != null)
                {
                    conn.Close();
                }
                return "false";
            }
        }
        //Ajax Mothed
        public string CheckLogin(string user, string pwd, string cookie)
        {
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(user) | r.IsMatch(pwd))
                {
                    //SQL注入
                    return "false";
                }
                else
                {
                    Cookie Cookie = new Cookie();
                    if (cookie.Trim() == "记住")
                    {
                        Cookie.setCookie("cndMgrName", user, 1);
                        Cookie.setCookie("cndMgrPwd", pwd, 1);
                    }
                    else
                    {
                        Cookie.delCookie("cndMgrName");
                        Cookie.delCookie("cndMgrPwd");
                    }
                    StringBuilder strSql = new StringBuilder();
                //    strSql.Append("SELECT Count(`user`),`user` FROM `admin` where `user`='" + user.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower() + "' and status='true'");
                      strSql.Append("SELECT Count(`user`),`user` FROM `admin` where `user`='" + user.Trim() + "' and status='true'");
                   
                    MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (sdr.Read())
                    {
                        if (int.Parse(sdr["Count(`user`)"].ToString()) == 1)
                        {
                            HttpContext.Session["admin"] = sdr["user"];    //用户名
                            HttpContext.Session["adminType"] = "admin";
                            return "true";
                        }
                    }
                }
                return "false";
            }
            catch
            {
                return "false";
            }
        }

        //private method
        private string GetIpByTypeAndArea(string type, string area)
        {
            string IpStr = "";
            StringBuilder webSql = new StringBuilder();
            StringBuilder fileSql = new StringBuilder();
            if (type == "全部")
            {
                if (area == "全部")
                {
                    return "全部";
                    //webSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node'");
                    //fileSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node'");
                }
                else
                {
                    webSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node' and `zone`= '" + area + "'");
                    fileSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node' and `zone`= '" + area + "'");
                }
            }
            else
            {
                if (type == "网站")
                {
                    if (area == "全部")
                    {
                        webSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node'");
                    }
                    else
                    {
                        webSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node' and `zone`= '" + area + "'");
                    }
                }
                else //文件
                {
                    if (area == "全部")
                    {
                        fileSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node'");
                    }
                    else
                    {
                        fileSql.Append("SELECT `id`,`ip` FROM `server_list` where `type`='node' and `zone`= '" + area + "'");
                    }
                }
            }
            if (webSql.ToString().IndexOf("SELECT") >= 0)
            {
                DataSet webDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, webSql.ToString());
                if (webDs.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < webDs.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            IpStr += "'" + webDs.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                        else
                        {
                            IpStr += ",";
                            IpStr += "'" + webDs.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                    }
                }
            }
            if (fileSql.ToString().IndexOf("SELECT") >= 0)
            {
                DataSet fileDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, fileSql.ToString());
                if (fileDs.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < fileDs.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            IpStr += "'" + fileDs.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                        else
                        {
                            IpStr += ",";
                            IpStr += "'" + fileDs.Tables[0].Rows[i]["ip"].ToString() + "'";
                        }
                    }
                }
            }
            return IpStr;
        }
        //查询所有的服务器信息
        private string[] GetServerList()
        {
            try
            {
                StringBuilder webSql = new StringBuilder();
                webSql.Append("SELECT `id`,`ip`,`zone` FROM `server_list` where `type`='node'");
                DataSet webDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, webSql.ToString());
                string result = "";
                string area = "";
                if (webDs.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < webDs.Tables[0].Rows.Count; i++)
                    {
                        if (area.IndexOf(webDs.Tables[0].Rows[i]["zone"].ToString()) < 0)
                        {
                            area += webDs.Tables[0].Rows[i]["zone"].ToString() + ",";
                        }
                        result += "网站:" + webDs.Tables[0].Rows[i]["zone"].ToString() + "|";
                        result += webDs.Tables[0].Rows[i]["ip"].ToString();
                        result += ",";
                    }
                }
                StringBuilder fileSql = new StringBuilder();
                fileSql.Append("SELECT `id`,`ip`,`zone` FROM `server_list` where `type`='node'");
                DataSet fileDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, fileSql.ToString());
                if (fileDs.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < fileDs.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += "文件:" + webDs.Tables[0].Rows[i]["zone"].ToString() + "|";
                            result += fileDs.Tables[0].Rows[i]["ip"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += "文件:" + webDs.Tables[0].Rows[i]["zone"].ToString() + "|";
                            result += fileDs.Tables[0].Rows[i]["ip"].ToString();
                        }
                        if (area.IndexOf(webDs.Tables[0].Rows[i]["zone"].ToString()) < 0)
                        {
                            area += webDs.Tables[0].Rows[i]["zone"].ToString() + ",";
                        }
                    }
                }
                string[] arr = { result, area };
                return arr;
            }
            catch
            {
                return null;
            }
        }

        //得到数据库里存在的天的表
        private string GetDateTable()
        {
            try
            {
                string strSql = "SHOW TABLES";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_ALLTRAFFIC, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                    }
                    return result;
                }
            }
            catch
            {
                return "Error";
            }
            return "Null";
        }
        //图表专用
        private string GetChartJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                TrafficModels maxOutObj = new TrafficModels();
                TrafficModels maxInObj = new TrafficModels();
                string out_json = "";
                string in_json = "";
                foreach (TrafficModels model in t)
                {
                    if (model != t[t.Count - 1])
                    {
                        out_json += model.out_value + ",";
                        in_json += model.in_value + ",";
                    }
                    else
                    {
                        out_json += model.out_value;
                        in_json += model.in_value;
                    }
                    if (maxOutObj.out_value < model.out_value)
                    {
                        maxOutObj.out_value = model.out_value;
                        maxOutObj.time = model.time;
                    }
                    if (maxInObj.in_value < model.in_value)
                    {
                        maxInObj.in_value = model.in_value;
                        maxInObj.time = model.time;
                    }
                }
                string ret_json = maxInObj.time + "," + maxInObj.in_value + "#[" + in_json + "]" + "|" + maxOutObj.time + "," + maxOutObj.out_value + "#[" + out_json + "]";
                return ret_json;
            }
            catch
            {
                return "";
            }
        }

    }
}
