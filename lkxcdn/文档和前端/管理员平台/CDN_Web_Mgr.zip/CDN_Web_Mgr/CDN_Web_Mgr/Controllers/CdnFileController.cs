﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MySql.Data.MySqlClient;
using System.Text;
using CDN_Web_Mgr.Models;
using System.Data;
using CDN_Web_Mgr.Core;

namespace CDN_Web_Mgr.Controllers
{
    public class CdnFileController : Controller
    {
        //
        // GET: /CdnFile/

        public ActionResult Index(string user)
        {
            ViewData["admin"] = user;
            ViewData["adminType"] = HttpContext.Session["adminType"].ToString();
            return View();
        }

        public ActionResult InTrafficSpan()
        {
            //List<ClientModels> users = GetUsersList();
            //StringBuilder usrStr = new StringBuilder();
            List<TrafficModels> listData = GetSpanData();
            if (listData != null)
            {
                string domainStr = "";
                string inrate = "";
                string outrate = "";
                foreach (TrafficModels item in listData)
                {
                    domainStr += "'";
                    domainStr += item.domain;
                    domainStr += "',";

                    inrate += item.in_value.ToString("F2");
                    inrate += ",";

                    outrate += item.out_value.ToString("F2");
                    outrate += ",";
                }
                ViewData["client"] = MvcHtmlString.Create(domainStr.Substring(0, domainStr.Length - 1));
                //ViewData["outrate"] = outrate;
                ViewData["inrate"] = inrate;
            }
            //if (users != null)
            //{
            //    foreach (ClientModels item in users)
            //    {
            //        usrStr.Append("'");
            //        usrStr.Append(item.name);
            //        usrStr.Append("',");
            //    }
            //}
            //ViewData["client"] = usrStr.ToString().Substring(0, usrStr.ToString().Length - 1);
            return View();
        }

        public ActionResult OutTrafficSpan()
        {
            //List<ClientModels> users = GetUsersList();
            //StringBuilder usrStr = new StringBuilder();
            //if (users != null)
            //{
            //    foreach (ClientModels item in users)
            //    {
            //        usrStr.Append("'");
            //        usrStr.Append(item.name);
            //        usrStr.Append("',");
            //    }
            //}
            //ViewData["client"] = usrStr.ToString().Substring(0, usrStr.ToString().Length - 1);
            List<TrafficModels> listData = GetSpanData();
            if (listData != null)
            {
                string domainStr = "";
                string inrate = "";
                string outrate = "";
                foreach (TrafficModels item in listData)
                {
                    domainStr += "'";
                    domainStr += item.domain;
                    domainStr += "',";

                    inrate += item.in_value.ToString("F2");
                    inrate += ",";

                    outrate += item.out_value.ToString("F2");
                    outrate += ",";
                }
                ViewData["client"] = MvcHtmlString.Create(domainStr.Substring(0, domainStr.Length - 1));
                ViewData["outrate"] = outrate;
                //ViewData["inrate"] = inrate;
            }
            return View();
        }

        public ActionResult ClientList()
        {
            //List<ClientModels> model = new List<ClientModels>();
            List<ClientModels> clientList = GetUsersList();
            if (clientList != null)
            {
                return View(clientList);
            }
            return View();
        }

        public ActionResult FileList(string id)
        {
            if (id == null || id.Length <= 0)
            {
                return View();
            }

            List<ServerListModels> model = GetServerList(id);

            return View(model);
        }

        public List<ServerListModels> GetServerList(string id)
        {
            List<ServerListModels> list = new List<ServerListModels>();

            string sql = "SELECT * FROM `server_list` where `type` = 'node' and `ip` not in(SELECT `serverip` FROM `node_file` where filemd5id ='" + id + "' );";
            DataSet ds = MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, sql);
            if (ds.Tables[0].Rows.Count > 0)
            {
                
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ServerListModels model = new ServerListModels();
                    model.ip = ds.Tables[0].Rows[i]["ip"].ToString();
                    model.desc = ds.Tables[0].Rows[i]["desc"].ToString();

                    list.Add(model);
                }
            }

            return list;
        }

        public ActionResult TrafficRpt(string user)
        {
            ViewData["user"] = user;
            string IpPort = GetIpPortByUser(user.Trim());
            string timeSpan = GetDateTable();
            ViewData["area"] = null;
            ViewData["TimeSpan"] = null;
            ViewData["server"] = null;
            if (!string.IsNullOrEmpty(IpPort))
            {
                ViewData["server"] = IpPort;
                string[] IpArr = IpPort.Split(',');
                string IpStr = "";
                for (int m = 0; m < IpArr.Length; m++)
                {
                    string[] s = IpArr[m].Split(':');
                    if (m == 0)
                    {
                        IpStr = "'" + s[0] + "'";
                    }
                    else
                    {
                        IpStr += ",'";
                        IpStr += s[0] + "'";
                    }
                }
                string area = GetAreaByIp(IpStr);
                ViewData["area"] = area;
            }
            if (!string.IsNullOrEmpty(timeSpan))
            {
                ViewData["TimeSpan"] = timeSpan;
            }
            return View();
        }

        //峰值统计
        [HttpGet]
        public ActionResult TopRpt(string user)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return RedirectToAction("LogTimeOut", "Home");
            }
            else
            {
                ViewData["user"] = user.Trim();
                string timeSpan = GetDateTable();
                if (!string.IsNullOrEmpty(timeSpan))
                {
                    ViewData["TimeSpan"] = timeSpan;
                }
                return View();
            }
        }

        //Ajax method

        //获取所有流量总和
        [HttpPost, ActionName("GetTotalStream")]
        public string GetTotalStream(string user, string start, string end)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    DateTime _start = DateTime.Parse(start.Trim());
                    DateTime _end = DateTime.Parse(end.Trim());
                    TimeSpan span = _end - _start;
                    string conStr = GetConnByUser(user.Trim());
                    if (span.TotalDays >= 0 && !string.IsNullOrEmpty(conStr))
                    {
                        Double totalNum = 0;
                        Double totalStream = 0;
                        Double totalIp = 0;
                        if (span.TotalDays > 0)  //超过一天
                        {
                            for (int i = 0; i <= span.TotalDays; i++)
                            {
                                if (TableIsExist(conStr, _start.AddDays(i)))
                                {
                                    //string conStr = ConfigurationManager.ConnectionStrings["ConnStr"] + "Database=" + db;
                                    //MySqlConnection con = new MySqlConnection(conStr);
                                    string sql = "select count(`ip`), sum(`cnt`), sum(`sent`) from `" + _start.AddDays(i).ToString("yyyy-MM-dd") + "`  where `ip` !=`serverip`";
                                    DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
                                    if (ds.Tables[0].Rows.Count > 0)
                                    {
                                        totalIp += string.IsNullOrEmpty(ds.Tables[0].Rows[0][0].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][0].ToString());
                                        totalNum += string.IsNullOrEmpty(ds.Tables[0].Rows[0][1].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][1].ToString());
                                        totalStream += string.IsNullOrEmpty(ds.Tables[0].Rows[0][2].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][2].ToString()) / 1048576;
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                        else       //查询一天
                        {
                            if (TableIsExist(conStr, _start))
                            {
                                //string conStr = ConfigurationManager.ConnectionStrings["ConnStr"] + "Database=" + db;
                                //MySqlConnection con = new MySqlConnection(conStr);
                                string sql = "select count(`ip`), sum(`cnt`), sum(`sent`) from `" + _start.ToString("yyyy-MM-dd") + "`  where `ip` !=`serverip`";
                                DataSet ds = MySqlHelper.ExecuteDataset(conStr, sql);
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    totalIp = string.IsNullOrEmpty(ds.Tables[0].Rows[0][0].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][0].ToString());
                                    totalNum = string.IsNullOrEmpty(ds.Tables[0].Rows[0][1].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][1].ToString());
                                    totalStream = string.IsNullOrEmpty(ds.Tables[0].Rows[0][2].ToString()) ? 0 : Double.Parse(ds.Tables[0].Rows[0][2].ToString()) / 1048576;
                                }
                            }
                        }
                        return totalIp.ToString() + "|" + totalNum.ToString() + "|" + totalStream.ToString("F4");
                    }
                    return "Error!";
                }
                catch
                {
                    return "Error";
                }
            }
        }

        private string GetConnByUser(string user)
        {
            try
            {
                string conStr = "";
                string strSql = "select `ip` from `server_list` where `type` = 'cdn_file_stats'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string consql = "select `value` from `server_info` where `serverip` = '" + Ds.Tables[0].Rows[0][0].ToString().Trim() + "'";
                    DataSet endDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, consql);
                    strSql = "";
                    strSql = "SELECT `stats` FROM `user` where `user`='" + user.Trim() + "'";
                    DataSet conDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql);
                    conStr = MySqlConn.ReplaceConn(endDs.Tables[0].Rows[0][0].ToString()) + "Database=" + conDs.Tables[0].Rows[0][0].ToString() + ";charset=gbk";
                    return conStr;
                }
            }
            catch (Exception ex)
            { 
            }
            return "";
        }

        //获取峰值统计数据
        [HttpPost, ActionName("GetTopRpt")]
        public string GetTopRpt(string user, string start, string span, int bfb)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "TimeOut";
            }
            else
            {
                List<TrafficModels> TopList = new List<TrafficModels>();
                DateTime _start = DateTime.Parse(start.Trim());
                string _span = span.Trim();
                string IpPortStr = GetIpPortByUser(user.Trim());
                if (!string.IsNullOrEmpty(IpPortStr))
                {
                    string[] IpArr = IpPortStr.Split(',');
                    string portStr = "";
                    string[] sarr = IpArr[0].Split(':');
                    portStr = sarr[1];
                    List<TrafficModels> Data = new List<TrafficModels>();
                    GetFileRptData DoGetData = new GetFileRptData();
                    if (span == "一天")
                    {
                        Data = DoGetData.GetTopRpt(_start, 0, "全部", portStr);
                    }
                    if (span == "一周")
                    {
                        Data = DoGetData.GetTopRpt(_start, 7, "全部", portStr);
                    }
                    if (span == "一月")
                    {
                        Data = DoGetData.GetTopRpt(_start, 30, "全部", portStr);
                    }
                    List<TrafficModels> inList = new List<TrafficModels>();
                    List<TrafficModels> outList = new List<TrafficModels>();
                    if (Data != null)
                    {
                        Data.Sort(new TrafficInComparer());
                        foreach (TrafficModels item in Data)
                        {
                            item.out_value = item.out_value * 1.2;
                            item.in_value = item.in_value * 1.2;

                            inList.Add(item);
                        }
                        Data.Sort(new TrafficOutComparer());
                        foreach (TrafficModels item in Data)
                        {
                            item.out_value = item.out_value * 1.2;
                            item.in_value = item.in_value * 1.2;

                            outList.Add(item);
                        }
                        //int start_in_num = Convert.ToInt16(inList.Count * ((bfb - 1) / 100.0));
                        //int end_in_num = Convert.ToInt16(inList.Count * ((bfb + 1) / 100.0));
                        //int start_out_num = Convert.ToInt16(outList.Count * ((bfb - 1) / 100.0));
                        //int end_out_num = Convert.ToInt16(outList.Count * ((bfb + 1) / 100.0));

                        int start_in_num = Convert.ToInt16(inList.Count * ((99 - bfb) / 100.0));
                        int end_in_num = Convert.ToInt16(inList.Count * ((101 - bfb) / 100.0));
                        int start_out_num = Convert.ToInt16(outList.Count * ((99 - bfb) / 100.0));
                        int end_out_num = Convert.ToInt16(outList.Count * ((101 - bfb) / 100.0));

                        int getX = Convert.ToInt16(outList.Count * ((100 - bfb) / 100.0));

                        List<TrafficModels> rslt_inList = new List<TrafficModels>();
                        List<TrafficModels> rslt_outList = new List<TrafficModels>();
                        for (int z = start_in_num; z < end_in_num; z++)
                        {
                            double s = z / Convert.ToDouble(inList.Count) * 100.0;
                            inList[z].bfb = s.ToString("F2") + "%";

                            if (z == getX)
                            {
                                outList[z].bfb = bfb.ToString() + "%";
                                rslt_outList.Add(outList[z]);
                            }
                            // rslt_inList.Add(inList[z]);
                        }
                        for (int x = start_out_num; x < end_out_num; x++)
                        {
                            double s = x / Convert.ToDouble(outList.Count) * 100.0;
                            outList[x].bfb = s.ToString("F2") + "%";

                            if (x == getX)
                            {
                                outList[x].bfb = bfb.ToString() + "%";
                                rslt_outList.Add(outList[x]);
                            }
                            //rslt_outList.Add(outList[x]);
                        }
                        //string ss = GetTopJson(rslt_outList) + "|" + GetTopJson(rslt_inList);
                        return GetTopJson(rslt_outList) + "|" + GetTopJson(rslt_inList);
                    }
                }
                return "[]|[]";
            }
        }
        public class TrafficOutComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.out_value.CompareTo(x.out_value));
            }
        }
        public class TrafficInComparer : IComparer<TrafficModels>
        {
            //实现按流量降序
            public int Compare(TrafficModels x, TrafficModels y)
            {
                return (y.in_value.CompareTo(x.in_value));
            }
        }

        //获取chart数据
        [HttpPost, ActionName("GetChartDataByServer")]
        public string GetChartDataByServer(string server, string day, int span)
        {
            if (HttpContext.Session["admin"] == null)
            {
                RedirectToAction("LogTimeOut", "Home");
            }
            string ipStr = "";
            string portStr = "";
            if (server.IndexOf('|') > 0)
            {
                string[] list = server.Trim().Split('|');
                for (int i = 0; i < list.Length - 1; i++)
                {
                    string[] s = list[i].Split(':');
                    if (i == 0)
                    {
                        ipStr = "'" + s[0] + "'";
                        portStr = s[1];
                    }
                    else
                    {
                        ipStr += ",'" + s[0] + "'";
                        //portStr += "," + s[1];
                    }
                }
            }
            else
            {
                string IpPortStr = GetIpPortByUser(server.Trim());
                string[] IpArr = IpPortStr.Split(',');
                string[] sarr = IpArr[0].Split(':');
                portStr = sarr[1];
                ipStr = "全部";
            }
            GetFileRptData getData = new GetFileRptData();
            List<TrafficModels> result = getData.GetRptDataList(DateTime.Parse(day), span, ipStr, portStr);
            return GetChartJson(result);
            //return "查询条件为空！";
        }

        [HttpPost, ActionName("GetUserIpPort")]
        public string GetUserIpPort(string user)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                if (!string.IsNullOrEmpty(user))
                {
                    List<IpPortModels> list = GetIpPortByNameList(user.Trim());
                    if (list != null)
                    {
                        return GetJson(list);
                    }
                    return "查询结果为空！";
                }
                return "查询条件为空！";
            }
        }

        //获取服务器列表
        [HttpPost, ActionName("GetServerList")]
        public string GetServerList()
        {
            if (HttpContext.Session["adminType"].ToString() == "user")
            {
                return "";
            }
            else
            {
                string result = DoGetServerList();
                return result;
            }
        }

        //添加服务器
        [HttpPost, ActionName("AddServer")]
        public string AddServer(string ip, int port, string nettype, string zone, string desc)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("insert into `server_list`(`ip`,`port`,`nettype`,`zone`,`type`,`desc`) values('" + ip.Trim() + "'," + port + ",'" + nettype.Trim() + "','" + zone.Trim() + "','node','" + desc.Trim() + "')");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //编辑服务器
        [HttpPost, ActionName("EditServer")]
        public string EditServer(int id, string ip, int port, string nettype, string zone, string desc)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("update `server_list` set `ip`='" + ip.Trim() + "',`port`=" + port + ",`nettype`='" + nettype.Trim() + "',`zone`='" + zone.Trim() + "',`desc`='" + desc.Trim() + "' where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //删除服务器
        [HttpPost, ActionName("DeleteServer")]
        public string DeleteServer(int id)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("delete from `server_list` where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //添加用户服务器
        [HttpPost, ActionName("AddClientServer")]
        public string AddClientServer(string user, string ip, int port)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("insert into `user_nginx`(`user`,`ip`,`port`) values('" + user.Trim() + "','" + ip.Trim() + "'," + port + ")");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //编辑用户服务器
        [HttpPost, ActionName("EditClientServer")]
        public string EditClientServer(int id, string ip, int port)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("update `user_nginx` set `ip`='" + ip.Trim() + "',`port`=" + port + " where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //删除用户服务器
        [HttpPost, ActionName("DeleClientServer")]
        public string DeleClientServer(int id)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "LogTimeOut";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("delete from `user_nginx` where `id`=" + id + "");
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "true";
                }
                catch
                {
                    return "error";
                }
                return "false";
            }
        }

        //修改用户备注信息
        [HttpPost, ActionName("SaveClientInfo")]
        public string SaveClientInfo(int id, string desc,string mydesc)
        {
            if (HttpContext.Session["admin"] == null)
            {
                return "登录超时，请重新登录！";
            }
            else
            {
                try
                {
                    MySqlConnection conn = new MySqlConnection(Core.MySqlConn.FILE_MYSQL_SERVER);
                    StringBuilder strSql = new StringBuilder();
                    conn.Open();
                    strSql.Append("update `user` set `desc`='" + desc.Trim() + "', `mydesc`='" + mydesc.Trim() + "' where `id`=" + id);
                    MySqlCommand cmd = new MySqlCommand(strSql.ToString(), conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (1 == result)
                        return "修改成功！";
                }
                catch
                {
                    return "修改报错，请联系管理员！";
                }
                return "修改失败！";
            }
        }

        //私有方法
        private List<TrafficModels> GetSpanData()
        {
            try
            {
                string ttt = DateTime.Now.ToString("HH:mm");
                string s = ttt.Substring(ttt.Length - 1, 1);
                string start = "";
                string end = "";
                if (int.Parse(s) <= 5 && int.Parse(s) > 0)
                {
                    start = ttt.Substring(0, 4) + "0";
                    end = ttt.Substring(0, 4) + "5";
                }
                if (int.Parse(s) > 5)
                {
                    start = ttt.Substring(0, 4) + "5";
                    end = ttt.Substring(0, 3) + (int.Parse(ttt.Substring(3, 1)) + 1).ToString() + "0";
                }
                if (int.Parse(s) == 0)
                {
                    start = ttt.Substring(0, 3) + (int.Parse(ttt.Substring(3, 1)) - 1).ToString() + "5";
                    end = ttt;
                }
                StringBuilder sqlStr = new StringBuilder();
                sqlStr.Clear();
                string table = DateTime.Now.ToString("yyyy-MM-dd");
                sqlStr.Append("SELECT * FROM `" + table + "` where `time`>= '" + start + "' and `time`<= '" + end + "' order by `port`");
                MySqlConnection myStatsCn = new MySqlConnection(Core.MySqlConn.GetFileStatsConn());
                myStatsCn.Close();
                DataSet Ds3 = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(myStatsCn, sqlStr.ToString());
                myStatsCn.Close();
                if (Ds3.Tables[0].Rows.Count > 0)
                {
                    List<TrafficModels> Data = new List<TrafficModels>();
                    string tmp_port = "";
                    foreach (DataRow row in Ds3.Tables[0].Rows)
                    {
                        if (row["port"].ToString() != tmp_port)
                        {
                            TrafficModels item = new TrafficModels();
                            item.domain = GetDomainByPort(row["port"].ToString());
                            item.in_value = double.Parse(row["inrate"].ToString()) / 1024 / 1024 * 8;
                            item.out_value = double.Parse(row["outrate"].ToString()) / 1024 / 1024 * 8;
                            Data.Add(item);
                        }
                        else
                        {
                            Data[Data.Count - 1].in_value += double.Parse(row["inrate"].ToString()) / 1024 / 1024 * 8;
                            Data[Data.Count - 1].out_value += double.Parse(row["outrate"].ToString()) / 1024 / 1024 * 8;
                        }
                        tmp_port = row["port"].ToString();
                    }
                    return Data;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        //通过端口号得到域名
        private string GetDomainByPort(string port)
        {
            string sql = "select `user` from `user_nginx` where `port` = '" + port + "'";
            DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, sql);
            if (Ds.Tables[0].Rows.Count > 0)
            {
                return Ds.Tables[0].Rows[0][0].ToString();
            }
            return null;
        }

        //通过用户获取流量
        private List<TrafficModels> GetSpanByUser(UserModels user)
        {
            try
            {
                string ttt = DateTime.Now.ToString("HH:mm");
                string s = ttt.Substring(ttt.Length - 1, 1);
                string start = "";
                string end = "";
                if (int.Parse(s) <= 5 && int.Parse(s) > 0)
                {
                    start = ttt.Substring(0, 4) + "0";
                    end = ttt.Substring(0, 4) + "5";
                }
                if (int.Parse(s) > 5)
                {
                    start = ttt.Substring(0, 4) + "5";
                    end = ttt.Substring(0, 3) + (int.Parse(ttt.Substring(3, 1)) + 1).ToString() + "0";
                }
                if (int.Parse(s) == 0)
                {
                    start = ttt.Substring(0, 3) + (int.Parse(ttt.Substring(3, 1)) - 1).ToString() + "5";
                    end = ttt;
                }
                StringBuilder sqlStr = new StringBuilder();
                sqlStr.Clear();
                string table = DateTime.Now.ToString("yyyy-MM-dd");
                sqlStr.Append("SELECT * FROM `" + table + "` where `time`>= '" + start + "' and `time`<= '" + end + "' order by `port`");
                MySqlConnection myStatsCn = new MySqlConnection(Core.MySqlConn.GetFileStatsConn());
                DataSet Ds3 = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(myStatsCn, sqlStr.ToString());
                myStatsCn.Close();
                if (Ds3.Tables[0].Rows.Count > 0)
                {
                    List<TrafficModels> Data = new List<TrafficModels>();
                    string tmp_port = "";
                    foreach (DataRow row in Ds3.Tables[0].Rows)
                    {
                        if (row["port"].ToString() != tmp_port)
                        {
                            TrafficModels item = new TrafficModels();
                            //item.domain = GetDomainByPort(row["port"].ToString());
                            item.in_value = double.Parse(row["inrate"].ToString()) / 1024 / 1024 * 8;
                            item.out_value = double.Parse(row["outrate"].ToString()) / 1024 / 1024 * 8;
                            Data.Add(item);
                        }
                        else
                        {
                            Data[Data.Count - 1].in_value += double.Parse(row["inrate"].ToString()) / 1024 / 1024 * 8;
                            Data[Data.Count - 1].out_value += double.Parse(row["outrate"].ToString()) / 1024 / 1024 * 8;
                        }
                        tmp_port = row["port"].ToString();
                    }
                    return Data;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        //获取用户列表
        private List<ClientModels> GetUsersList()
        {
            try
            {
                List<ClientModels> Data = new List<ClientModels>();
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT * FROM `user`"); // where `status`='true'
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientModels item = new ClientModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["user"].ToString();
                        item.password = dr["pass"].ToString();
                        item.nginxport = int.Parse(dr["nginxport"].ToString());
                        item.stats = dr["stats"].ToString();
                        item.status = dr["status"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.mydesc = dr["mydesc"].ToString();
                        Data.Add(item);
                    }
                    return Data;
                }
            }
            catch { }
            return null;
        }

        //返回泛型类型
        private List<IpPortModels> GetIpPortByNameList(string user)
        {
            if (!String.IsNullOrEmpty(user))
            {
                try
                {
                    StringBuilder strSql = new StringBuilder();
                    List<UserModels> Data = new List<UserModels>();
                    strSql.Append("SELECT `id`,`ip`,`port` FROM `user_nginx` where `user`='" + user + "'");
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql.ToString());
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        List<IpPortModels> result = new List<IpPortModels>();
                        for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                        {
                            IpPortModels item = new IpPortModels();
                            item.id = int.Parse(Ds.Tables[0].Rows[i]["id"].ToString());
                            item.ip = Ds.Tables[0].Rows[i]["ip"].ToString();
                            item.port = int.Parse(Ds.Tables[0].Rows[i]["port"].ToString());
                            result.Add(item);
                        }
                        return result;
                    }
                }
                catch
                {
                    return null;
                }
            }
            return null;
        }

        //根据用户名获取ip地址和端口号
        private string GetIpPortByUser(string user)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `ip`,`port` FROM `user_nginx` where `user`='" + user + "'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                            result += ":";
                            result += Ds.Tables[0].Rows[i]["port"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                            result += ":";
                            result += Ds.Tables[0].Rows[i]["port"].ToString();
                        }
                    }
                    return result;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            return null;
        }

        //查询所有的服务器信息
        private string DoGetServerList()
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `id`,`ip`,`port`,`nettype`,`zone`,`desc` FROM `server_list` where `type`='node'");
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    StringBuilder json = new StringBuilder();
                    json.Clear();
                    json.Append("[");
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i != Ds.Tables[0].Rows.Count - 1)
                        {
                            json.Append("{ \"id\": \"" + Ds.Tables[0].Rows[i]["id"].ToString() + "\",");
                            json.Append("\"ip\": \"" + Ds.Tables[0].Rows[i]["ip"].ToString() + "\",");
                            json.Append("\"port\": \"" + Ds.Tables[0].Rows[i]["port"].ToString() + "\",");
                            json.Append("\"nettype\": \"" + Ds.Tables[0].Rows[i]["nettype"].ToString() + "\",");
                            json.Append("\"zone\": \"" + Ds.Tables[0].Rows[i]["zone"].ToString() + "\",");
                            json.Append("\"desc\": \"" + Ds.Tables[0].Rows[i]["desc"].ToString() + "\" },");
                        }
                        else
                        {
                            json.Append("{ \"id\": \"" + Ds.Tables[0].Rows[i]["id"].ToString() + "\",");
                            json.Append("\"ip\": \"" + Ds.Tables[0].Rows[i]["ip"].ToString() + "\",");
                            json.Append("\"port\": \"" + Ds.Tables[0].Rows[i]["port"].ToString() + "\",");
                            json.Append("\"nettype\": \"" + Ds.Tables[0].Rows[i]["nettype"].ToString() + "\",");
                            json.Append("\"zone\": \"" + Ds.Tables[0].Rows[i]["zone"].ToString() + "\",");
                            json.Append("\"desc\": \"" + Ds.Tables[0].Rows[i]["desc"].ToString() + "\" }");
                        }
                    }
                    json.Append("]");
                    return json.ToString();
                }
                return "";
            }
            catch
            {
                return null;
            }
        }

        //根据用户的所有ip得到所拥有的（区域|ip）
        private string GetAreaByIp(string ip)
        {
            try
            {
                StringBuilder strSql = new StringBuilder();
                strSql.Append("SELECT `zone`,`ip` FROM `server_list` where `ip` in(" + ip + ") Order by `zone`");  // Group by `zone`
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql.ToString());
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i]["zone"].ToString();
                            result += "|";
                            result += Ds.Tables[0].Rows[i]["ip"].ToString();
                        }
                    }
                    return result;
                }
                return "";
            }
            catch
            {
                return null;
            }
        }

        //得到数据库里存在的天的表   cdn_server_stats库
        private string GetDateTable()
        {
            try
            {
                string strSql = "SHOW TABLES";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetFileStatsConn(), strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string result = "";
                    for (int i = 0; i < Ds.Tables[0].Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                        else
                        {
                            result += ",";
                            result += Ds.Tables[0].Rows[i][0].ToString();
                        }
                    }
                    return result;
                }
            }
            catch
            {
                return "Error";
            }
            return "Null";
        }

        //根据用户名和日期判断数据库是否存在该表
        private bool TableIsExist(string conn, DateTime date)
        {
            try
            {
                string mySql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet myDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn.Trim(), mySql);
                if (myDs.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

        //转换成json格式字符串
        private string GetJson(List<IpPortModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                StringBuilder json = new StringBuilder();
                json.Append("[");
                for (int i = 0; i < t.Count; i++)
                {
                    if (i != t.Count - 1)
                    {
                        json.Append("{ \"id\": \"" + t[i].id + "\",");
                        json.Append("\"ip\": \"" + t[i].ip + "\",");
                        json.Append("\"port\": \"" + t[i].port + "\"},");
                    }
                    else
                    {
                        json.Append("{ \"id\": \"" + t[i].id + "\",");
                        json.Append("\"ip\": \"" + t[i].ip + "\",");
                        json.Append("\"port\": \"" + t[i].port + "\" }");
                    }
                }
                json.Append("]");
                return json.ToString();
            }
            catch
            {
                return "";
            }
        }

        //图表专用
        private string GetChartJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                TrafficModels maxOutObj = new TrafficModels();
                TrafficModels maxInObj = new TrafficModels();
                string out_json = "";
                string in_json = "";
                foreach (TrafficModels model in t)
                {
                    if (model != t[t.Count - 1])
                    {
                        out_json += model.out_value + ",";
                        in_json += model.in_value + ",";
                    }
                    else
                    {
                        out_json += model.out_value;
                        in_json += model.in_value;
                    }
                    if (maxOutObj.out_value < model.out_value)
                    {
                        maxOutObj.out_value = model.out_value;
                        maxOutObj.time = model.time;
                    }
                    if (maxInObj.in_value < model.in_value)
                    {
                        maxInObj.in_value = model.in_value;
                        maxInObj.time = model.time;
                    }
                }
                string ret_json = maxInObj.time + "," + maxInObj.in_value + "#[" + in_json + "]" + "|" + maxOutObj.time + "," + maxOutObj.out_value + "#[" + out_json + "]";
                return ret_json;
                //return GetChartJson(result["in"]) + "|" + GetChartJson(result["out"]);
            }
            catch
            {
                return "";
            }
        }

        //峰值统计转换成json格式字符串
        private string GetTopJson(List<TrafficModels> t)
        {
            if (t == null)
            {
                return "";
            }
            try
            {
                StringBuilder json = new StringBuilder();
                json.Append("[");
                for (int i = 0; i < t.Count; i++)
                {
                    if (t[i].out_value > 0 || t[i].in_value > 0)
                    {
                        if (i != t.Count - 1)
                        {
                            json.Append("{ id: \"" + t[i].bfb + "\",");
                            json.Append("out_stream: \"" + t[i].out_value + "\",");
                            json.Append("in_stream: \"" + t[i].in_value + "\",");
                            json.Append("datetime: \"" + t[i].time + "\" },");
                        }
                        else
                        {
                            json.Append("{ id: \"" + t[i].bfb + "\",");
                            json.Append("out_stream: \"" + t[i].out_value + "\",");
                            json.Append("in_stream: \"" + t[i].in_value + "\",");
                            json.Append("datetime: \"" + t[i].time + "\" }");
                        }
                    }
                }
                json.Append("]");
                return json.ToString();
            }
            catch
            {
                return "";
            }
        }

    }
}
