﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using CDN_Web_Mgr.Models;
using System.Text;
using MySql.Data.MySqlClient;

namespace CDN_Web_Mgr.Core
{
    public class GetAllTraffic
    {
        public List<TrafficModels> GetRptDataList(DateTime date, int daySpan, string ip)
        {
            List<TrafficModels> trafficList = new List<TrafficModels>();
            if (daySpan == 0)
            {
                trafficList = DoGetMonthRptData(date, ip, 5);    //一天间隔5分钟
            }
            if (daySpan == 7)
            {
                for (int i = 0; i < 7; i++)
                {
                    if (TableIsExist(date.AddDays(i)))
                    {
                        List<TrafficModels> itemData = new List<TrafficModels>();
                        itemData = DoGetMonthRptData(date.AddDays(i), ip, 30);  //一星期间隔30分钟
                        if (itemData.Count == 48)
                        {
                            foreach (TrafficModels item in itemData)
                            {
                                trafficList.Add(item);
                            }
                        }
                        else
                        {
                            for (int k = 0; k < 48; k++)
                            {
                                TrafficModels model = new TrafficModels();
                                model.out_value = 0;
                                model.in_value = 0;
                                model.time = date.AddDays(i).AddMinutes(k * 30).ToString("HH:mm");
                                trafficList.Add(model);
                            }
                        }
                    }
                    else
                    {
                        for (int k = 0; k < 48; k++)
                        {
                            TrafficModels model = new TrafficModels();
                            model.out_value = 0;
                            model.in_value = 0;
                            model.time = date.AddDays(i).AddMinutes(k * 30).ToString("HH:mm");
                            trafficList.Add(model);
                        }
                    }
                    //continue;
                }
                return trafficList;
                //returnData.Add("in", inList);
            }
            if (daySpan == 30)
            {
                int num = (date.AddMonths(1) - date).Days;
                for (int i = 0; i < num; i++)
                {
                    if (TableIsExist(date.AddDays(i)))
                    {
                        List<TrafficModels> itemData = new List<TrafficModels>();
                        itemData = DoGetMonthRptData(date.AddDays(i), ip, 120);  //一个月间隔120分钟
                        if (itemData.Count == 12)
                        {
                            foreach (TrafficModels item in itemData)
                            {
                                trafficList.Add(item);
                            }
                        }
                        else
                        {
                            for (int k = 0; k < 12; k++)
                            {
                                TrafficModels model = new TrafficModels();
                                model.out_value = 0;
                                model.in_value = 0;
                                model.time = date.AddDays(i).AddMinutes(k * 120).ToString("HH:mm");
                                trafficList.Add(model);
                            }
                        }

                    }
                    else
                    {
                        for (int k = 0; k < 12; k++)
                        {
                            TrafficModels model = new TrafficModels();
                            model.out_value = 0;
                            model.in_value = 0;
                            model.time = date.AddDays(i).AddMinutes(k * 120).ToString("HH:mm");
                            trafficList.Add(model);
                        }
                    }
                    //continue;
                }
                return trafficList;
                //returnData.Add("in", inList);
            }
            return trafficList;
        }

        //获取数据
        private List<TrafficModels> DoGetMonthRptData(DateTime date, string ip, int getnum) //时间、ip
        {
            MySqlConnection myStatsCn = new MySqlConnection(Core.MySqlConn.MYSQL_ALLTRAFFIC);
            try
            {
                if (!string.IsNullOrEmpty(ip))
                {
                    string table = date.ToString("yyyy-MM-dd");
                    StringBuilder sqlStr = new StringBuilder();
                    if (ip == "全部")
                    {
                        sqlStr.Append("SELECT `outrate`,`inrate`,`time` FROM `" + table + "`");
                    }
                    else
                    {
                        sqlStr.Append("SELECT `outrate`,`inrate`,`time` FROM `" + table + "` WHERE ip in(" + ip + ")");
                    }
                    myStatsCn.Open();
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(myStatsCn, sqlStr.ToString());
                    myStatsCn.Close();
                    List<TrafficModels> traffic_obj = new List<TrafficModels>();
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        //DateTime start = date.Add(TimeSpan.Parse(srcDs.Tables[0].Rows[0]["time"].ToString()));
                        DateTime end = date.AddDays(1);
                        int num = (int)(end - date).TotalMinutes / getnum;
                        int temp_time;
                        //初始化集合
                        for (int k = 0; k < num; k++)
                        {
                            TrafficModels model = new TrafficModels();
                            model.in_value = 0;
                            model.out_value = 0;
                            model.time = date.AddMinutes(k * getnum).ToString("HH:mm");
                            traffic_obj.Add(model);
                        }
                        foreach (DataRow dr in Ds.Tables[0].Rows)
                        {
                            temp_time = (int)TimeSpan.Parse(dr["time"].ToString()).TotalMinutes;
                            int startNum = (int)temp_time / getnum;
                            for (int itNum = startNum; itNum < traffic_obj.Count; itNum++)
                            {
                                if (startNum > 0)//不从第一个开始
                                {
                                    if (temp_time <= (int)TimeSpan.Parse(traffic_obj[itNum].time).TotalMinutes && temp_time > (int)TimeSpan.Parse(traffic_obj[itNum - 1].time).TotalMinutes)
                                    {
                                        traffic_obj[itNum].out_value += double.Parse(dr["outrate"].ToString());
                                        traffic_obj[itNum].in_value += double.Parse(dr["inrate"].ToString());
                                    }
                                }
                                else //从第一个开始
                                {
                                    if (itNum == 0) //第一个
                                    {
                                        if (temp_time <= (int)TimeSpan.Parse(traffic_obj[1].time).TotalMinutes)
                                        {
                                            traffic_obj[0].out_value += double.Parse(dr["outrate"].ToString());
                                            traffic_obj[0].in_value += double.Parse(dr["inrate"].ToString());
                                        }
                                    }
                                    else
                                    {
                                        if (temp_time <= (int)TimeSpan.Parse(traffic_obj[itNum].time).TotalMinutes && temp_time > (int)TimeSpan.Parse(traffic_obj[itNum - 1].time).TotalMinutes)
                                        {
                                            traffic_obj[itNum].out_value += double.Parse(dr["outrate"].ToString());
                                            traffic_obj[itNum].in_value += double.Parse(dr["inrate"].ToString());
                                        }
                                    }
                                }
                            }
                        }
                        foreach (TrafficModels item in traffic_obj)
                        {
                            if (item.in_value != 0)
                            {
                                item.in_value = double.Parse((item.in_value / 1024 / 1024 * 8 / (getnum / 5)).ToString("F4"));
                            }
                            if (item.out_value != 0)
                            {
                                item.out_value = double.Parse((item.out_value / 1024 / 1024 * 8 / (getnum / 5)).ToString("F4"));
                            }
                            item.time = date.ToString("yyyy-MM-dd") + " " + item.time;
                        }
                    }
                    return traffic_obj;
                }
            }
            catch
            {
                if (myStatsCn != null) myStatsCn.Close();
            }
            myStatsCn.Close();
            return null;
        }

        //根据日期判断数据库是否存在该表
        public bool TableIsExist(DateTime date)
        {
            try
            {
                string strSql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_ALLTRAFFIC, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }

    }
}