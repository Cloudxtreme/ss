﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace CDN_Web_Mgr.Core
{
    public class MySqlConn
    {
        private static string _MYSQL_SERVER = String.Empty;
        private static string _MYSQL_SERVER_STATUS = String.Empty;
        private static string _MYSQL_SERVER_FILE = String.Empty;
        private static string _MYSQL_LOGIN = String.Empty;
        private static string _MYSQL_ALLTRAFFIC = String.Empty;
        private static string _MYSQL_SERVER_HIT = String.Empty;

        /// <summary>
        /// cdn_squid数据库连接串
        /// </summary>
        public static string HIT_MYSQL_SERVER
        {
            get
            {
                String statuConn = GetStatsConn();
                return statuConn.Replace("cdn_portrate_stats", "cdn_squid");
            }
        }

        /// <summary>
        /// cdn_iprate_stats数据库连接串
        /// </summary>
        public static string MYSQL_ALLTRAFFIC
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_ALLTRAFFIC))
                {
                    if (ConfigurationManager.ConnectionStrings["MySql_AllTraffic"] == null)
                    {
                        throw new Exception("the config node 'MySql_AllTraffic' is required in web.config");
                    }

                    lock (_MYSQL_ALLTRAFFIC)
                    {
                        _MYSQL_ALLTRAFFIC = ConfigurationManager.ConnectionStrings["MySql_AllTraffic"].ConnectionString;
                    }
                }
                return _MYSQL_ALLTRAFFIC;
            }
        }

        /// <summary>
        /// ibss_new数据库连接串
        /// </summary>
        public static string MYSQL_LOGIN
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_LOGIN))
                {
                    if (ConfigurationManager.ConnectionStrings["MySql_Login"] == null)
                    {
                        throw new Exception("the config node 'MySql_Login' is required in web.config");
                    }

                    lock (_MYSQL_LOGIN)
                    {
                        _MYSQL_LOGIN = ConfigurationManager.ConnectionStrings["MySql_Login"].ConnectionString;
                    }
                }
                return _MYSQL_LOGIN;
            }
        }

        /// <summary>
        /// cdn_web数据库连接串
        /// </summary>
        public static string MYSQL_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_SERVER))
                {
                    if (ConfigurationManager.ConnectionStrings["MySql_Server"] == null)
                    {
                        throw new Exception("the config node 'MySql_Server' is required in web.config");
                    }

                    lock (_MYSQL_SERVER)
                    {
                        _MYSQL_SERVER = ConfigurationManager.ConnectionStrings["MySql_Server"].ConnectionString;
                    }
                }
                return _MYSQL_SERVER;
            }
        }

        /// <summary>
        /// cdn_file数据库连接串
        /// </summary>
        public static string FILE_MYSQL_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_SERVER_FILE))
                {
                    if (ConfigurationManager.ConnectionStrings["File_MySql_Server"] == null)
                    {
                        throw new Exception("the config node 'File_MySql_Server' is required in web.config");
                    }

                    lock (_MYSQL_SERVER_FILE)
                    {
                        _MYSQL_SERVER_FILE = ConfigurationManager.ConnectionStrings["File_MySql_Server"].ConnectionString;
                    }
                }
                return _MYSQL_SERVER_FILE;
            }
        }

        //获取流量查询连接字符串
        public static string GetFileStatsConn()
        {
            try
            {
                string strSql = "select `ip` from `server_list` where `type` = 'cdn_file_stats'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string sql = "select `value` from `server_info` where `serverip` = '" + Ds.Tables[0].Rows[0][0].ToString().Trim() + "'";
                    DataSet endDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.FILE_MYSQL_SERVER, sql);
                    string s = ReplaceConn(endDs.Tables[0].Rows[0][0].ToString()) + "Database=cdn_portrate_stats;charset=gbk";
                    return s;
                }
            }
            catch
            {
                return "";
            }
            return "";
        }

        //获取流量查询连接字符串
        public static string GetStatsConn()
        {
            try
            {
                string strSql = "select `ip` from `server_list` where `type` = 'cdn_web_stats'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    string sql = "select `value` from `server_info` where `serverip` = '" + Ds.Tables[0].Rows[0][0].ToString().Trim() + "'";
                    DataSet endDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.MYSQL_SERVER, sql);
                    string s = ReplaceConn(endDs.Tables[0].Rows[0][0].ToString()) + "Database=cdn_portrate_stats;charset=gbk";
                    return s;
                }
            }
            catch
            {
                return "";
            }
            return "";
        }
        //修改连接字符串
        public static string ReplaceConn(string or_con)
        {
            //ip=121.9.13.245;port=3306;user=cdn;pass=cdncdncdn
            //User Id=root;Host=192.168.22.199;Database=cdn_web;password=111111;charset=gbk
            string[] connArr = or_con.Split(';');
            if (connArr.Length >= 4)
            {
                connArr[0] = connArr[0].Replace("ip", "Host");
                connArr[2] = connArr[2].Replace("user", "User Id");
                connArr[3] = connArr[3].Replace("pass", "password");
                return connArr[0] + ";" + connArr[2] + ";" + connArr[3] + ";";
            }
            else
            {
                return "";
            }
        }

    }
}