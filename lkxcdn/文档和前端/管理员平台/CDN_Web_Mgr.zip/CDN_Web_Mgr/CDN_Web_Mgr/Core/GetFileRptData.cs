﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using CDN_Web_Mgr.Models;
using System.Text;
using MySql.Data.MySqlClient;

namespace CDN_Web_Mgr.Core
{
    public class GetFileRptData
    {
        public List<TrafficModels> GetRptDataList(DateTime date, int daySpan, string ip, string port)
        {
            List<TrafficModels> returnData = new List<TrafficModels>();
            if (daySpan == 0)
            {
                returnData = DoGetDayRptData(date, ip, port);    //一天
                if (returnData.Count > 0)
                {
                    foreach (TrafficModels item in returnData)
                    {
                        if (item.in_value != 0)
                        {
                            item.in_value = double.Parse((item.in_value / 1024 / 1024 * 8).ToString("F4"));
                        }
                        if (item.out_value != 0)
                        {
                            item.out_value = double.Parse((item.out_value / 1024 / 1024 * 8).ToString("F4"));
                        }
                        item.time = date.ToString("yyyy-MM-dd ") + item.time;
                    }
                }
                return returnData;
            }
            if (daySpan == 7)  //一星期
            {
                for (int i = 0; i < 7; i++)
                {
                    if (TableIsExist(date.AddDays(i)))
                    {
                        List<TrafficModels> itemData = new List<TrafficModels>();
                        itemData = DoGetDayRptData(date.AddDays(i), ip, port);
                        if (itemData.Count == 288)
                        {
                            List<TrafficModels> weekData = new List<TrafficModels>();
                            for (int n = 0; n < 48; n++)
                            {
                                TrafficModels t = new TrafficModels();
                                t.time = date.AddDays(i).AddMinutes(n * 30).ToString("HH:mm");
                                weekData.Add(t);
                            }
                            TrafficModels obj = new TrafficModels();
                            for (int j = 0; j < weekData.Count; j++)
                            {
                                List<TrafficModels> temp_list = itemData.FindAll(
                                    delegate(TrafficModels p)
                                    {
                                        return TimeSpan.Parse(DateTime.Parse(p.time).ToString("HH:mm")) < TimeSpan.Parse(weekData[j].time).Add(new TimeSpan(0, 30, 0)) &&
                                            TimeSpan.Parse(DateTime.Parse(p.time).ToString("HH:mm")) >= TimeSpan.Parse(weekData[j].time);
                                    });
                                if (temp_list != null && temp_list.Count > 0)
                                {
                                    TrafficModels d = GetMaxObj(temp_list, "out");
                                    if (d.in_value != 0)
                                    {
                                        d.in_value = double.Parse((d.in_value / 1024 / 1024 * 8).ToString("F4"));
                                    }
                                    if (d.out_value != 0)
                                    {
                                        d.out_value = double.Parse((d.out_value / 1024 / 1024 * 8).ToString("F4"));
                                    }
                                    d.time = date.AddDays(i).ToString("yyyy-MM-dd ") + d.time;
                                    returnData.Add(d);
                                }
                                else
                                {
                                    weekData[j].time = date.AddDays(i).ToString("yyyy-MM-dd ") + weekData[j].time;
                                    returnData.Add(weekData[j]);
                                }
                            }
                        }
                        else
                        {
                            for (int k = 0; k < 48; k++)
                            {
                                TrafficModels model = new TrafficModels();
                                model.out_value = 0;
                                model.in_value = 0;
                                model.time = date.AddDays(i).AddMinutes(k * 30).ToString("yyyy-MM-dd HH:mm");
                                returnData.Add(model);
                            }
                        }
                    }
                    else
                    {
                        for (int k = 0; k < 48; k++)
                        {
                            TrafficModels model = new TrafficModels();
                            model.out_value = 0;
                            model.in_value = 0;
                            model.time = date.AddDays(i).AddMinutes(k * 30).ToString("yyyy-MM-dd HH:mm");
                            returnData.Add(model);
                        }
                    }
                }
                return returnData;
            }
            if (daySpan == 30)  //一星期
            {
                int num = (date.AddMonths(1) - date).Days;
                for (int i = 0; i < num; i++)
                {
                    if (TableIsExist(date.AddDays(i)))
                    {
                        List<TrafficModels> itemData = new List<TrafficModels>();
                        itemData = DoGetDayRptData(date.AddDays(i), ip, port);
                        if (itemData.Count == 288)
                        {
                            List<TrafficModels> monthData = new List<TrafficModels>();
                            for (int n = 0; n < 12; n++)
                            {
                                TrafficModels t = new TrafficModels();
                                t.time = date.AddDays(i).AddMinutes(n * 120).ToString("HH:mm");
                                monthData.Add(t);
                            }
                            TrafficModels obj = new TrafficModels();
                            for (int j = 0; j < monthData.Count; j++)
                            {
                                List<TrafficModels> temp_list = itemData.FindAll(
                                    delegate(TrafficModels p)
                                    {
                                        return TimeSpan.Parse(DateTime.Parse(p.time).ToString("HH:mm")) < TimeSpan.Parse(monthData[j].time).Add(new TimeSpan(0, 120, 0)) &&
                                            TimeSpan.Parse(DateTime.Parse(p.time).ToString("HH:mm")) >= TimeSpan.Parse(monthData[j].time);
                                    });
                                if (temp_list != null && temp_list.Count > 0)
                                {
                                    TrafficModels d = GetMaxObj(temp_list, "out");
                                    if (d.in_value != 0)
                                    {
                                        d.in_value = double.Parse((d.in_value / 1024 / 1024 * 8).ToString("F4"));
                                    }
                                    if (d.out_value != 0)
                                    {
                                        d.out_value = double.Parse((d.out_value / 1024 / 1024 * 8).ToString("F4"));
                                    }
                                    d.time = date.AddDays(i).ToString("yyyy-MM-dd ") + d.time;
                                    returnData.Add(d);
                                }
                                else
                                {
                                    monthData[j].time = date.AddDays(i).ToString("yyyy-MM-dd ") + monthData[j].time;
                                    returnData.Add(monthData[j]);
                                }
                            }
                        }
                        //如果该天不存在数据
                        else
                        {
                            for (int k = 0; k < 12; k++)
                            {
                                TrafficModels model = new TrafficModels();
                                model.in_value = 0;
                                model.out_value = 0;
                                model.time = date.AddDays(i).AddMinutes(k * 120).ToString("yyyy-MM-dd HH:mm");
                                returnData.Add(model);
                            }
                        }
                    }
                    //数据库里没有这天的表
                    else
                    {
                        for (int k = 0; k < 12; k++)
                        {
                            TrafficModels model = new TrafficModels();
                            model.in_value = 0;
                            model.out_value = 0;
                            model.time = date.AddDays(i).AddMinutes(k * 120).ToString("yyyy-MM-dd HH:mm");
                            returnData.Add(model);
                        }
                    }
                }
                return returnData;
            }
            return null;
        }

        //获取峰值,把为0的屏蔽掉
        public List<TrafficModels> GetTopRpt(DateTime date, int daySpan, string ip, string port)
        {
            List<TrafficModels> returnData = new List<TrafficModels>();
            if (daySpan == 0)
            {
                List<TrafficModels> list = DoGetDayRptData(date, ip, port);    //一天
                if (list.Count > 0)
                {
                    List<TrafficModels> temp_list = list.FindAll(
                        delegate(TrafficModels p)
                        {
                            return p.in_value > 0 || p.out_value > 0;
                        });
                    if (temp_list.Count > 0)
                    {
                        foreach (TrafficModels t in temp_list)
                        {
                            t.in_value = double.Parse((t.in_value / 1024 / 1024 * 8).ToString("F4"));
                            t.out_value = double.Parse((t.out_value / 1024 / 1024 * 8).ToString("F4"));
                            t.time = date.ToString("yyyy-MM-dd ") + t.time;
                            returnData.Add(t);
                        }
                    }
                }
                return returnData;
            }
            if (daySpan == 7)  //一星期
            {
                for (int i = 0; i < 7; i++)
                {
                    if (TableIsExist(date.AddDays(i)))
                    {
                        List<TrafficModels> itemData = DoGetDayRptData(date.AddDays(i), ip, port);
                        if (itemData.Count > 0)
                        {
                            List<TrafficModels> temp_list = itemData.FindAll(
                                delegate(TrafficModels p)
                                {
                                    return p.in_value > 0 || p.out_value > 0;
                                });
                            if (temp_list.Count > 0)
                            {
                                foreach (TrafficModels t in temp_list)
                                {
                                    t.in_value = double.Parse((t.in_value / 1024 / 1024 * 8).ToString("F4"));
                                    t.out_value = double.Parse((t.out_value / 1024 / 1024 * 8).ToString("F4"));
                                    t.time = date.AddDays(i).ToString("yyyy-MM-dd ") + t.time;
                                    returnData.Add(t);
                                }
                            }
                        }
                    }
                }
                return returnData;
            }
            if (daySpan == 30)  //一星期
            {
                int num = (date.AddMonths(1) - date).Days;
                for (int i = 0; i < num; i++)
                {
                    if (TableIsExist(date.AddDays(i)))
                    {
                        List<TrafficModels> itemData = DoGetDayRptData(date.AddDays(i), ip, port);
                        if (itemData.Count > 0)
                        {
                            List<TrafficModels> temp_list = itemData.FindAll(
                                delegate(TrafficModels p)
                                {
                                    return p.in_value > 0 || p.out_value > 0;
                                });
                            if (temp_list.Count > 0)
                            {
                                foreach (TrafficModels t in temp_list)
                                {
                                    t.in_value = double.Parse((t.in_value / 1024 / 1024 * 8).ToString("F4"));
                                    t.out_value = double.Parse((t.out_value / 1024 / 1024 * 8).ToString("F4"));
                                    t.time = date.AddDays(i).ToString("yyyy-MM-dd ") + t.time;
                                    returnData.Add(t);
                                }
                            }
                        }
                    }
                }
                return returnData;
            }
            return null;
        }

        private List<TrafficModels> DoGetDayRptData(DateTime date, string ip, string port) //时间、ip
        {
            MySqlConnection myStatsCn = new MySqlConnection(Core.MySqlConn.GetStatsConn());
            try
            {
                if (!string.IsNullOrEmpty(ip))
                {
                    string table = date.ToString("yyyy-MM-dd");
                    StringBuilder sqlStr = new StringBuilder();
                    if (ip == "全部")
                    {
                        sqlStr.Append("SELECT `outrate`,`inrate`,`time` FROM `" + table + "` WHERE `port`in(" + port + ")");
                    }
                    else
                    {
                        sqlStr.Append("SELECT `outrate`,`inrate`,`time` FROM `" + table + "` WHERE `port`in(" + port + ") and ip in(" + ip + ")");
                    }
                    DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetFileStatsConn(), sqlStr.ToString());
                    myStatsCn.Close();
                    List<TrafficModels> Data = new List<TrafficModels>();
                    if (Ds.Tables[0].Rows.Count > 0)
                    {
                        DateTime end = date.AddDays(1);
                        int num = (int)(end - date).TotalMinutes / 5;
                        int temp_time;
                        for (int k = 0; k < num; k++)
                        {
                            TrafficModels model = new TrafficModels();
                            model.in_value = 0;
                            model.out_value = 0;
                            model.time = date.AddMinutes(k * 5).ToString("HH:mm");
                            Data.Add(model);
                        }
                        foreach (DataRow dr in Ds.Tables[0].Rows)
                        {
                            temp_time = (int)TimeSpan.Parse(dr["time"].ToString()).TotalMinutes;
                            int startNum = (int)temp_time / 5;
                            for (int itNum = startNum; itNum < Data.Count; itNum++)
                            {
                                if (startNum > 0)//不从第一个开始
                                {
                                    if (temp_time <= (int)TimeSpan.Parse(Data[itNum].time).TotalMinutes && temp_time > (int)TimeSpan.Parse(Data[itNum - 1].time).TotalMinutes)
                                    {
                                        Data[itNum].out_value += double.Parse(dr["outrate"].ToString());
                                        Data[itNum].in_value += double.Parse(dr["inrate"].ToString());
                                    }
                                }
                                else //从第一个开始
                                {
                                    if (itNum == 0) //第一个
                                    {
                                        if (temp_time <= (int)TimeSpan.Parse(Data[1].time).TotalMinutes)
                                        {
                                            Data[0].out_value += double.Parse(dr["outrate"].ToString());
                                            Data[0].in_value += double.Parse(dr["inrate"].ToString());
                                        }
                                    }
                                    else
                                    {
                                        if (temp_time <= (int)TimeSpan.Parse(Data[itNum].time).TotalMinutes && temp_time > (int)TimeSpan.Parse(Data[itNum - 1].time).TotalMinutes)
                                        {
                                            Data[itNum].out_value += double.Parse(dr["outrate"].ToString());
                                            Data[itNum].in_value += double.Parse(dr["inrate"].ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return Data;
                }
            }
            catch
            {
                if (myStatsCn != null) myStatsCn.Close();
            }
            return null;
        }

        private TrafficModels GetMaxObj(List<TrafficModels> list, string type)
        {

            TrafficModels ret = new TrafficModels();
            ret = list[0];
            if (type == "out")
            {
                foreach (TrafficModels item in list)
                {
                    if (item.out_value > ret.out_value)
                    {
                        ret = item;
                    }
                }
                return ret;
            }
            else
            {
                foreach (TrafficModels item in list)
                {
                    if (item.in_value > ret.in_value)
                    {
                        ret = item;
                    }
                }
                return ret;
            }
        }

        //根据日期判断数据库是否存在该表
        public bool TableIsExist(DateTime date)
        {
            try
            {
                string strSql = "SHOW TABLES like '" + date.ToString("yyyy-MM-dd") + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(Core.MySqlConn.GetFileStatsConn(), strSql);
                if (Ds.Tables[0].Rows[0][0] != null)
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
            return false;
        }
    }
}