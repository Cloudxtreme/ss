﻿using System.Web;
using System.IO;
using System.Text;
using PPPOE_Client.Models;
using PPPOE_Client.Core;
using System;

namespace PPPOE_Client
{
    /// <summary>
    /// OpratelogHandler 的摘要说明
    /// </summary>
    public class OpratelogHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            //StreamReader steamRd = new StreamReader(HttpContext.Current.Request.InputStream);
            //string strPostData = steamRd.ReadToEnd();
            //strPostData = HttpUtility.UrlDecode(strPostData, Encoding.GetEncoding("utf-8"));
            ClientSysInfoModels model = new ClientSysInfoModels();
            model.action = HttpContext.Current.Request.Params["action"].Trim().Length > 0 ? HttpContext.Current.Request.Params["action"].Trim() : "";
            model.coordinate = HttpContext.Current.Request.Params["coordinate"].Trim().Length > 0 ? HttpContext.Current.Request.Params["coordinate"].Trim() : "";
            model.href = HttpContext.Current.Request.Params["href"].Trim().Length > 0 ? HttpContext.Current.Request.Params["href"].Trim() : "";
            double s = double.Parse(HttpContext.Current.Request.Params["time"].Trim()); //豪秒数
            model.time = HttpContext.Current.Request.Params["time"].Trim().Length > 0 ? ConvertDateTime.ConvertIntToDateTime(s/1000) : DateTime.Now;
            model.color = HttpContext.Current.Request.Params["color"].Trim().Length > 0 ? HttpContext.Current.Request.Params["color"].Trim() : "";
            model.cookieEnable = HttpContext.Current.Request.Params["cookie"].Trim().Length > 0 ? HttpContext.Current.Request.Params["cookie"].Trim() : "";
            model.explore = HttpContext.Current.Request.Params["explore"].Trim().Length > 0 ? HttpContext.Current.Request.Params["explore"].Trim() : "";
            model.javaEnable = HttpContext.Current.Request.Params["java"].Trim().Length > 0 ? HttpContext.Current.Request.Params["java"].Trim() : "";
            model.platform = HttpContext.Current.Request.Params["platform"].Trim().Length > 0 ? HttpContext.Current.Request.Params["platform"].Trim() : "";
            model.userAgent = HttpContext.Current.Request.Params["agent"].Trim().Length > 0 ? HttpContext.Current.Request.Params["agent"].Trim() : "";
            model.screen = HttpContext.Current.Request.Params["screen"].Trim().Length > 0 ? HttpContext.Current.Request.Params["screen"].Trim() : "";

            UserActionLog(model);

            context.Response.ContentType = "text/plain";
            context.Response.Write("Hello World");
        }

        private void UserActionLog(ClientSysInfoModels model)
        { 

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}