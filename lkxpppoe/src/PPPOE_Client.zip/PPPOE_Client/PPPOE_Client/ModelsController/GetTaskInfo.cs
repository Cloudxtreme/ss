﻿using System.Collections.Generic;
using PPPOE_Client.Models;
using System.Data;
using MySql.Data.MySqlClient;
using PPPOE_Client.Core;
using System;

namespace PPPOE_Client.ModelsController
{
    public class GetTaskInfo
    {
        public static List<TaskModels> GetTaskList()
        {
            try
            {
               // string sql = "select * from `client` where `statu` != 'true' and `statu` != 'false' and `statu` != 'stop'";
                string sql = "select * from `client` where `statu` != 'true' and `statu` != 'false' and `statu` != 'stop'";

                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<TaskModels> ret = new List<TaskModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        TaskModels item = new TaskModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["user"].ToString();
                        if (String.IsNullOrEmpty(dr["httpInfo"].ToString()))
                        {
                            item.statu = "处理中...";
                        }
                        else
                        {
                            item.statu = "处理失败！";
                        }
                        item.type = GetTaskStatu(dr["statu"].ToString().Trim());
                        item.error = dr["httpInfo"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        private static string GetTaskStatu(string statu)
        {
            switch(statu)
            {
                default: 
                    return "类型不明确！";
                case "add":
                    return "添加用户";
                case "chgpwd":
                    return "修改密码";
                case "dele":
                    return "删除用户";
                case "chgmeal":
                    return "修改套餐";
                case "chgdate":
                    return "修改期限";
            }
        }

    }
}