﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Data;
using PPPOE_Client.Models;
using PPPOE_Client.Core;

namespace PPPOE_Client.ModelsController
{
    public class GetMealInfo
    {
        //查询某个套餐的限制信息
        public static string GetMealRole(int id, int roleSpeed, int roleTraffic, int roleTime)
        {
            string result = "";
            string sql_speed = "select * from `roleSpeed` where `id`='" + roleSpeed + "' and statu='true'";
            DataSet Ds_speed = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_speed);
            if (Ds_speed.Tables[0].Rows.Count > 0)
            {
                result += "速度限制："+ Ds_speed.Tables[0].Rows[0]["limit"].ToString() + "M";
            }
            string sql_time = "select * from `roleTime` where `id`='" + roleTime + "' and statu='true'";
            DataSet Ds_time = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_time);
            if (Ds_time.Tables[0].Rows.Count > 0)
            {
                result += "<br />每月时间限制：" + Ds_speed.Tables[0].Rows[0]["limit"].ToString() + "小时";
            }
            string sql_traffic = "select * from `roleTraffic` where `id`='" + roleTraffic + "' and statu='true'";
            DataSet Ds_traffic = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_traffic);
            if (Ds_traffic.Tables[0].Rows.Count > 0)
            {
                result += "<br />每月流量限制：" + Ds_speed.Tables[0].Rows[0]["limit"].ToString() + "G";
            }

            return result;
        }

        //获取所有的套餐
        public static List<MealModels> GetMealList()
        {
            try
            {
                string sql = "select * from `mealinfo` where `statu`='true' order by `id`";
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<MealModels> ret = new List<MealModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        MealModels item = new MealModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["name"].ToString();

                        string sql_speed = "select `id` from `roleSpeed` where `id`='" + int.Parse(dr["roleSpeed"].ToString()) + "' and statu='true'";
                        DataSet Ds_speed = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_speed);
                        if (Ds_speed.Tables[0].Rows.Count > 0)
                        {
                            item.roleSpeed = int.Parse(Ds_speed.Tables[0].Rows[0][0].ToString());
                        }
                        string sql_time = "select `id` from `roleTime` where `id`='" + int.Parse(dr["roleTime"].ToString()) + "' and statu='true'";
                        DataSet Ds_time = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_time);
                        if (Ds_time.Tables[0].Rows.Count > 0)
                        {
                            item.roleTime = int.Parse(Ds_time.Tables[0].Rows[0][0].ToString());
                        }
                        string sql_traffic = "select `id` from `roleTraffic` where `id`='" + int.Parse(dr["roleTraffic"].ToString()) + "' and statu='true'";
                        DataSet Ds_traffic = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_traffic);
                        if (Ds_traffic.Tables[0].Rows.Count > 0)
                        {
                            item.roleTraffic = int.Parse(Ds_traffic.Tables[0].Rows[0][0].ToString());
                        }
                        item.limitMonth = int.Parse(dr["roleMonth"].ToString());
                        item.addMonth = int.Parse(dr["addMonth"].ToString());
                        item.price = dr["price"].ToString();
                        item.content = dr["content"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.statu = dr["statu"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //删除多个套餐，只做修改statu属性，保留原始数据
        public static int DeleMeal(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `mealinfo` set `statu`='false' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //编辑一个套餐，返回修改响应数
        public static MealModels EditOneMeal(MealModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    MealModels item = new MealModels();
                    item.id = model.id <= 0 ? 0 : model.id;
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.price = String.IsNullOrEmpty(model.price) ? "" : model.price.Trim();
                    item.content = String.IsNullOrEmpty(model.content) ? "" : model.content.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "update `mealinfo` set `name`='" + item.name + "',`price`='" + item.price + "',`content`='" + item.content + "',`desc`='" + item.desc + "' where id='" + item.id + "'";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        return item;
                    }
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        //添加一个套餐，返回套餐ID
        public static MealModels AddOneMeal(MealModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    MealModels item = new MealModels();
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.limitSpeed = String.IsNullOrEmpty(model.limitSpeed) ? "1" : model.limitSpeed; //默认1M
                    item.limitMonth = model.limitMonth == 0 ? 1 : model.limitMonth; //默认1个月
                    item.addMonth = model.addMonth; //默认0个月
                    item.limitTraffic = String.IsNullOrEmpty(model.limitTraffic) ? "0" : model.limitTraffic;
                    item.limitTime = String.IsNullOrEmpty(model.limitTime) ? "" : model.limitTime.Trim(); //限制时间
                    item.price = String.IsNullOrEmpty(model.price) ? "" : model.price.Trim();
                    item.content = String.IsNullOrEmpty(model.content) ? "" : model.content.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();

                    int TimeId = 0;
                    int SpeedId = 0;
                    int TrafficId = 0;
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();

                    //添加时间限制
                    if (!String.IsNullOrEmpty(item.limitTime)) //限制时间了
                    {
                        //先查询是否已经存在
                        string sql_time = "select `id` from `roleTime` where `limit`='" + item.limitTime + "' and statu='true'";
                        DataSet Ds_time = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_time);
                        if (Ds_time.Tables[0].Rows.Count > 0)
                        {
                            int.TryParse(Ds_time.Tables[0].Rows[0][0].ToString(), out TimeId);
                        }
                        else
                        {
                            sql_time = "insert into `roleTime`(`limit`,`statu`)values('" + item.limitTime + "','true')";
                            MySqlCommand cmd_time = new MySqlCommand(sql_time, conn);
                            int time_rlt = cmd_time.ExecuteNonQuery();
                            cmd_time.Dispose();
                            if (time_rlt == 1)
                            {
                                sql_time = "select `id` from `roleTime` where `limit`='" + item.limitTime + "' and statu='true'";
                                DataSet myDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_time);
                                if (myDs.Tables[0].Rows.Count > 0)
                                {
                                    int.TryParse(myDs.Tables[0].Rows[0][0].ToString(), out TimeId);
                                    item.roleTime = TimeId;
                                }
                            }
                        }
                    }

                    //添加速度限制
                    string sql_speed = "select `id` from `roleSpeed` where `limit`='" + item.limitSpeed + "' and statu='true'";
                    DataSet Ds_speed = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_speed);
                    if (Ds_speed.Tables[0].Rows.Count > 0)
                    {
                        int.TryParse(Ds_speed.Tables[0].Rows[0][0].ToString(), out SpeedId);
                    }
                    else
                    {
                        sql_speed = "insert into `roleSpeed`(`limit`,`statu`)values('" + item.limitSpeed + "','true')";
                        MySqlCommand cmd_speed = new MySqlCommand(sql_speed, conn);
                        int speed_rlt = cmd_speed.ExecuteNonQuery();
                        cmd_speed.Dispose();
                        if (speed_rlt == 1)
                        {
                            sql_speed = "select `id` from `roleSpeed` where `limit`='" + item.limitSpeed + "' and statu='true'";
                            DataSet myDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_speed);
                            if (myDs.Tables[0].Rows.Count > 0)
                            {
                                int.TryParse(myDs.Tables[0].Rows[0][0].ToString(), out SpeedId);
                                item.roleSpeed = SpeedId;
                            }
                        }

                    }

                    //添加流量限制
                    if (item.limitTraffic != "0")
                    {
                        string sql_traffic = "select `id` from `roleTraffic` where `limit`='" + item.limitTraffic + "' and statu='true'";
                        DataSet Ds_traffic = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_traffic);
                        if (Ds_traffic.Tables[0].Rows.Count > 0)
                        {
                            int.TryParse(Ds_traffic.Tables[0].Rows[0][0].ToString(), out TrafficId);
                        }
                        else
                        {
                            sql_traffic = "insert into `roleTraffic`(`limit`,`statu`)values('" + item.limitTraffic + "','true')";
                            MySqlCommand cmd_traffic = new MySqlCommand(sql_traffic, conn);
                            int traffic_rlt = cmd_traffic.ExecuteNonQuery();
                            cmd_traffic.Dispose();
                            if (traffic_rlt == 1)
                            {
                                sql_traffic = "select `id` from `roleTraffic` where `limit`='" + item.limitTraffic + "' and statu='true'";
                                DataSet myDs = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql_traffic);
                                if (myDs.Tables[0].Rows.Count > 0)
                                {
                                    int.TryParse(myDs.Tables[0].Rows[0][0].ToString(), out TrafficId);
                                    item.roleTraffic = TrafficId;
                                }
                            }
                        }
                    }

                    //添加一个套餐
                    string sql = "insert into `mealinfo`(`name`,`price`,`content`,`roleSpeed`,`roleMonth`,`addMonth`,`roleTraffic`,`roleTime`,`desc`,`statu`)values('"
                        + item.name + "','" + item.price + "','" + item.content + "','" + SpeedId + "','" + item.limitMonth + "','" + item.addMonth + "','" + TrafficId + "','" + TimeId + "','" + item.desc + "','true')";
                    
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        sql = "select `id` from `mealinfo` where `name`='" + item.name + "' and `content`='" + item.content + "' and statu='true'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            int s;
                            if (int.TryParse(Ds.Tables[0].Rows[0][0].ToString(), out s))
                                item.id = s;
                        }
                    }
                    return item;
                }
            }
            catch
            {
                return null;
            }
        }
    }
}