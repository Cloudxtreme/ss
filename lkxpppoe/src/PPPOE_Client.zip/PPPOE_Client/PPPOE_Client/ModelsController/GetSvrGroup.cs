﻿using System.Collections.Generic;
using PPPOE_Client.Models;
using MySql.Data.MySqlClient;
using System.Data;
using PPPOE_Client.Core;
using System;

namespace PPPOE_Client.ModelsController
{
    public class GetSvrGroup
    {
        //设置代理的服务器覆盖单元
        public static string BindAgentSvr(string aId, string idStr)
        {
            try
            {
                string sql = "";
                MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                sql = "delete from `agentRadius` where aId = '" + aId + "'";
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                
                if (string.IsNullOrEmpty(idStr))
                {
                    return "设置成功！";
                }
                else
                {
                    string[] arr = idStr.Split(',');
                    if (arr.Length > 0)
                    {
                        conn.Open();
                        foreach (string id in arr)
                        {
                            sql = "insert into `agentRadius`(`rId`,`aId`,`statu`)values('" + id + "','" + aId + "','true')";
                            MySqlCommand cmd_item = new MySqlCommand(sql, conn);
                            cmd_item.ExecuteNonQuery();
                            cmd_item.Dispose();
                        }
                        conn.Close();
                        return "设置成功！";
                    }
                    return "设置条件不足！";
                }
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        //获取所有的用户角色
        public static List<SvrGroupModels> GetSvrGroupList()
        {
            try
            {
                string sql = "select * from `radiusInfo` order by `id`";
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<SvrGroupModels> ret = new List<SvrGroupModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        SvrGroupModels item = new SvrGroupModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["name"].ToString();
                        item.serverip = dr["serverip"].ToString();
                        item.dbname = dr["dbname"].ToString();
                        item.username = dr["username"].ToString();
                        item.password = dr["password"].ToString();
                        item.desc = dr["desc"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //通过代理商编号查找服务器组，一个代理商对应多个服务器组
        public static List<SvrGroupModels> GetSvrGroupByAgent(int aId)
        {
            try
            {
                string sql = "select * from `radiusInfo` where `id` in(select `rId` from `agentRadius` where `aId` = '" + aId + "')";
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<SvrGroupModels> ret = new List<SvrGroupModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        SvrGroupModels item = new SvrGroupModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["name"].ToString();
                        //item.serverip = dr["serverip"].ToString();
                        //item.dbname = dr["dbname"].ToString();
                        //item.username = dr["username"].ToString();
                        //item.password = dr["password"].ToString();
                        item.desc = dr["desc"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //编辑一个单元，返回执行结果
        public static int EditSvrGroup(SvrGroupModels model)
        {
            try
            {
                if (model == null)
                {
                    return -1;
                }
                else
                {
                    SvrGroupModels item = new SvrGroupModels();
                    item.id = model.id <= 0 ? 0 : model.id;
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.serverip = String.IsNullOrEmpty(model.serverip) ? "" : model.serverip.Trim();
                    item.dbname = String.IsNullOrEmpty(model.dbname) ? "" : model.dbname.Trim();
                    item.username = String.IsNullOrEmpty(model.username) ? "" : model.username.Trim();
                    item.password = String.IsNullOrEmpty(model.password) ? "" : model.password.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "update `radiusInfo` set `name`='" + item.name + "',`serverip`='" + item.serverip + "',`dbname`='" + item.dbname + "',`username`='" + item.username + "',`password`='" + item.password + "',`desc`='" + item.desc + "' where id='" + item.id + "'";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return -1;
            }
        }

        //添加一个用户，返回用户实体
        public static int AddOneSvrGroup(SvrGroupModels model)
        {
            try
            {
                if (model == null)
                {
                    return -1;
                }
                else
                {
                    SvrGroupModels item = new SvrGroupModels();
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.serverip = String.IsNullOrEmpty(model.serverip) ? "" : model.serverip.Trim();
                    item.dbname = String.IsNullOrEmpty(model.dbname) ? "" : model.dbname.Trim();
                    item.username = String.IsNullOrEmpty(model.username) ? "" : model.username.Trim();
                    item.password = String.IsNullOrEmpty(model.password) ? "" : model.password.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "insert into `radiusInfo`(`name`,`serverip`,`dbname`,`username`,`password`,`desc`)values('"
                        + item.name + "','" + item.serverip + "','" + item.dbname + "','" + item.username + "','" + item.password + "','" + item.desc + "')";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        sql = "select `id` from `radiusInfo` where `name`='" + model.name + "' and `serverip`='" + model.serverip + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                        }
                    }
                    return 0;
                }
            }
            catch
            {
                return -1;
            }
        }

    }
}