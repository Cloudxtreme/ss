﻿using System;
using System.Collections.Generic;
using PPPOE_Client.Models;
using System.Data;
using MySql.Data.MySqlClient;
using PPPOE_Client.Core;

namespace PPPOE_Client.ModelsController
{
    public static class GetAgentInfo
    {
        public static List<AgentModels> GetAgentList(int page)
        {
            try
            {
                string sql = "";
                if (page == 0)
                {
                    sql = "select * from `agentInfo` where `statu`='true' order by `id`";
                }
                else
                {
                    sql = "select * from `agentInfo` where `statu`='true' order by `id` LIMIT 20 OFFSET " + (page - 1) * 20;
                }
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<AgentModels> ret = new List<AgentModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        AgentModels item = new AgentModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.user = dr["user"].ToString();
                        item.pwd = dr["pwd"].ToString();
                        item.realname = dr["realname"].ToString();
                        item.phoneNum = dr["phoneNum"].ToString();
                        item.codeNum = dr["codeNum"].ToString();
                        item.address = dr["address"].ToString();
                        item.email = dr["email"].ToString();
                        item.qq = dr["qq"].ToString();
                        item.desc = dr["desc"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //修改代理密码
        public static int ChangePwd(int id, string pwd)
        {
            try
            {
                string sql = "update `agentInfo` set `pwd`='" + pwd + "' where `id`='" + id + "'";
                MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                int rslt = cmd.ExecuteNonQuery();
                cmd.Dispose();
                conn.Close();
                return rslt;
            }
            catch
            {
                return -1;
            }
        }

        //获取在线用户数量
        public static int GetAgentTotalNum()
        {
            try
            {
                string sql = "select Count(*) from `agentInfo` where `statu`='true'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
            }
            catch
            {
            }
            return 0;
        }

        //删除一个代理，只做修改statu属性，保留原始数据
        public static int DeleAgent(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `agentInfo` set `statu`='false' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //编辑代理，返回实体
        public static AgentModels EditOneAgent(AgentModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    AgentModels item = new AgentModels();
                    item.id = model.id <= 0 ? 0 : model.id;
                    item.user = String.IsNullOrEmpty(model.user) ? "" : model.user.Trim();
                    //item.radius = String.IsNullOrEmpty(model.radius) ? "0" : model.radius.Trim();
                    item.realname = String.IsNullOrEmpty(model.realname) ? "" : model.realname.Trim();
                    item.phoneNum = String.IsNullOrEmpty(model.phoneNum) ? "" : model.phoneNum.Trim();
                    item.codeNum = String.IsNullOrEmpty(model.codeNum) ? "" : model.codeNum.Trim();
                    item.address = String.IsNullOrEmpty(model.address) ? "" : model.address.Trim();
                    item.email = String.IsNullOrEmpty(model.email) ? "" : model.email.Trim();
                    item.qq = String.IsNullOrEmpty(model.qq) ? "" : model.qq.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "update `agentInfo` set `user`='" + item.user + "',`realname`='" + item.realname + "',`address`='" 
                        + item.address + "',`phoneNum`='" + item.phoneNum + "',`codeNum`='" + item.codeNum
                        + "',`email`='" + item.email + "',`qq`='" + item.qq + "',`desc`='" + item.desc + "' where `id`='" + item.id + "'";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();

                    //string sql_sel = "select `id` from `agentRadius` where `aId`='" + item.id + "'";
                    //DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql_sel);
                    //if (Ds.Tables[0].Rows.Count > 0)
                    //{
                    //    string sql_radius = "update `agentRadius` set `rId`='" + item.user + "' where `aId`='" + item.id + "'";
                    //    MySqlCommand cmd_radius = new MySqlCommand(sql_radius, conn);
                    //    cmd_radius.ExecuteNonQuery();
                    //    cmd_radius.Dispose();
                    //}
                    //else
                    //{
                    //    string sql_insert = "insert into `agentRadius`(`aId`,`rId`,`statu`)values('" + item.id + "','" + item.radius + "','true')";
                    //    MySqlCommand cmd_insert = new MySqlCommand(sql_insert, conn);
                    //    cmd_insert.ExecuteNonQuery();
                    //    cmd_insert.Dispose();
                    //}

                    conn.Close();

                    if (result == 1)
                    {
                        return item;
                    }
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        //添加一个代理，返回代理ID
        public static int AddOneAgent(AgentModels model)
        {
            try
            {
                if (model == null)
                {
                    return -1;
                }
                else
                {
                    AgentModels item = new AgentModels();
                    item.user = String.IsNullOrEmpty(model.user) ? "" : model.user.Trim();
                    item.radius = String.IsNullOrEmpty(model.radius) ? "0" : model.radius.Trim();
                    item.pwd = String.IsNullOrEmpty(model.pwd) ? "" : model.pwd.Trim();
                    item.realname = String.IsNullOrEmpty(model.realname) ? "" : model.realname.Trim();
                    item.phoneNum = String.IsNullOrEmpty(model.phoneNum) ? "" : model.phoneNum.Trim();
                    item.codeNum = String.IsNullOrEmpty(model.codeNum) ? "" : model.codeNum.Trim();
                    item.address = String.IsNullOrEmpty(model.address) ? "" : model.address.Trim();
                    item.email = String.IsNullOrEmpty(model.email) ? "" : model.email.Trim();
                    item.qq = String.IsNullOrEmpty(model.qq) ? "" : model.qq.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "insert into `agentInfo`(`user`,`pwd`,`realname`,`address`,`phoneNum`,`codeNum`,`email`,`qq`,`desc`,`statu`,`addtime`)values('"
                        + item.user + "','" + item.pwd + "','" + item.realname + "','" + item.address + "','" + item.phoneNum + "','"
                        + item.codeNum + "','" + item.email + "','" + item.qq + "','" + item.desc + "','true','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        sql = "select `id` from `agentInfo` where `user`='" + model.user + "' and `pwd`='" + model.pwd + "' and statu='true'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            int s;
                            if (int.TryParse(Ds.Tables[0].Rows[0][0].ToString(), out s))
                            {
                                //string sql_item = "insert into `agentRadius`(`aId`,`rId`,`statu`)values('" + s + "','" + item.radius + "','true')";
                                //conn.Open();
                                //MySqlCommand cmd_item = new MySqlCommand(sql_item, conn);
                                //cmd_item.ExecuteNonQuery();
                                //cmd_item.Dispose();
                                //conn.Close();

                                return s;
                            }
                        }
                    }
                    return 0;
                }
            }
            catch
            {
                return -1;
            }
        }

        //通过ID号返回代理名称
        public static string GetNameById(int id)
        {
            try
            {
                string result = "";
                string sql = "select `realname` from `agentInfo` where `id`='" + id + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    result = Ds.Tables[0].Rows[0][0].ToString();
                }
                return result;
            }
            catch
            {
            }
            return null;
        }

    }
}