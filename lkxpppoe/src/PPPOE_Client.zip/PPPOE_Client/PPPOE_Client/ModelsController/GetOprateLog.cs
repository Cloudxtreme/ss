﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPPOE_Client.Models;
using MySql.Data.MySqlClient;
using System.Data;
using PPPOE_Client.Core;

namespace PPPOE_Client.ModelsController
{
    public class GetOprateLog
    {
        //获取所有的操作日志
        public static List<OpratelogModels> GetOpratelogList(int page)
        {
            try
            {
                string sql = "select * from `log_operate` order by `id` desc LIMIT 20 OFFSET " + (page - 1) * 20;
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<OpratelogModels> ret = new List<OpratelogModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        OpratelogModels item = new OpratelogModels();
                        item.optman = dr["optman"].ToString();
                        item.optmanlevel = dr["optmanlevel"].ToString();
                        item.optobject = dr["optobject"].ToString();
                        item.opttype = dr["opttype"].ToString();
                        item.optobjtype = dr["optobjtype"].ToString();
                        item.opttime = dr["opttime"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        public static int GetOpratelogListCount()
        {
            try
            {
                string sql = "select * from `log_operate` order by `id`";
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    int count = Ds.Tables[0].Rows.Count;
                    
                    return count;
                }
            }
            catch
            {
            }
            return 0;
        }

        //添加一条日志记录
        public static void AddOneOpratelog(OpratelogModels model)
        {
            try
            {
                if (model != null)
                {
                    OpratelogModels item = new OpratelogModels();
                    item.optman = String.IsNullOrEmpty(model.optman) ? "" : model.optman.Trim();
                    item.optmanlevel = String.IsNullOrEmpty(model.optmanlevel) ? "" : model.optmanlevel.Trim();
                    item.optobject = String.IsNullOrEmpty(model.optobject) ? "" : model.optobject.Trim();
                    item.opttime = String.IsNullOrEmpty(model.opttime) ? "" : model.opttime.Trim();
                    item.opttype = String.IsNullOrEmpty(model.opttype) ? "" : model.opttype.Trim();
                    item.optobjtype = String.IsNullOrEmpty(model.optobjtype) ? "" : model.optobjtype.Trim();
                    string sql = "insert into `log_operate`(`optman`,`optmanlevel`,`optobject`,`optobjtype`,`opttime`,`opttype`)values('"
                        + item.optman + "','" + item.optmanlevel + "','" + item.optobject + "','" + item.optobjtype + "','" + item.opttime + "','" + item.opttype + "')";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                }
            }
            catch
            {
            }
        }

    }
}