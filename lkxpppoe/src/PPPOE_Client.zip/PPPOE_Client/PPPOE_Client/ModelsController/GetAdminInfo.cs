﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using PPPOE_Client.Core;
using PPPOE_Client.Models;
using System.Data;

namespace PPPOE_Client.ModelsController
{
    public class GetAdminInfo
    {
        //获取所有的用户角色
        public static List<AdminModels> GetLevelList()
        {
            try
            {
                string sql = "select * from `levelInfo` order by `id`";
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<AdminModels> ret = new List<AdminModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        AdminModels item = new AdminModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.level = dr["name"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //获取所有的用户
        public static List<AdminModels> GetAdminList()
        {
            try
            {
                string sql = "select a.*,b.name as levelname from `adminInfo` a left join `levelInfo` b on a.level = b.id where a.`statu`='true'";
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<AdminModels> ret = new List<AdminModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        AdminModels item = new AdminModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["name"].ToString();
                        //item.pass = dr["pass"].ToString();
                        item.level = dr["levelname"].ToString();
                        item.levelId = int.Parse(Ds.Tables[0].Rows[0]["level"].ToString());
                        item.desc = dr["desc"].ToString();
                        item.statu = dr["statu"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //删除一个用户，只做修改statu属性，保留原始数据
        public static int DeleAdmin(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `adminInfo` set `statu`='false' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //编辑一个用户，返回该用户实体
        public static AdminModels EditOneAdmin(AdminModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    AdminModels item = new AdminModels();
                    item.id = model.id <= 0 ? 0 : model.id;
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.level = String.IsNullOrEmpty(model.level) ? "" : model.level.Trim();
                    item.levelId = model.levelId;
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "update `adminInfo` set `name`='" + item.name + "',`level`='" + item.level + "',`desc`='" + item.desc + "' where id='" + item.id + "'";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        sql = "select a.*,b.name as levelname from `adminInfo` a left join `levelInfo` b on a.level = b.id where a.`statu`='true' and a.id='" + item.id + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            AdminModels ret = new AdminModels();
                            ret.id = int.Parse(Ds.Tables[0].Rows[0]["id"].ToString());
                            ret.name = Ds.Tables[0].Rows[0]["name"].ToString();
                            //ret.pass = Ds.Tables[0].Rows[0]["pass"].ToString();
                            ret.level = Ds.Tables[0].Rows[0]["levelname"].ToString();
                            ret.levelId = int.Parse(Ds.Tables[0].Rows[0]["level"].ToString());
                            ret.desc = Ds.Tables[0].Rows[0]["desc"].ToString();
                            ret.statu = Ds.Tables[0].Rows[0]["statu"].ToString();
                            return ret;
                        }
                    }
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        //添加一个用户，返回用户实体
        public static AdminModels AddOneAdmin(AdminModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    AdminModels item = new AdminModels();
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.pass = String.IsNullOrEmpty(model.pass) ? "" : model.pass.Trim();
                    item.level = String.IsNullOrEmpty(model.level) ? "" : model.level.Trim();
                    item.levelId = model.levelId;
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "insert into `adminInfo`(`name`,`pass`,`level`,`desc`,`statu`)values('"
                        + item.name + "','" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(item.pass.Trim(), "MD5").ToLower() + "','" + item.level + "','" + item.desc + "','true')";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        sql = "select a.*,b.name as levelname from `adminInfo` a left join `levelInfo` b on a.level = b.id where a.`statu`='true' and a.name='" + item.name + "' and a.pass='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(item.pass.Trim(), "MD5").ToLower() + "' and a.level='" + item.levelId + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            AdminModels ret = new AdminModels();
                            ret.id = int.Parse(Ds.Tables[0].Rows[0]["id"].ToString());
                            ret.name = Ds.Tables[0].Rows[0]["name"].ToString();
                            //ret.pass = Ds.Tables[0].Rows[0]["pass"].ToString();
                            ret.level = Ds.Tables[0].Rows[0]["levelname"].ToString();
                            ret.levelId = int.Parse(Ds.Tables[0].Rows[0]["level"].ToString());
                            ret.desc = Ds.Tables[0].Rows[0]["desc"].ToString();
                            ret.statu = Ds.Tables[0].Rows[0]["statu"].ToString();
                            return ret;
                        }
                    }
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

    }
}