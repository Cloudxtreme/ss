﻿using System.Collections.Generic;
using PPPOE_Client.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System;
using PPPOE_Client.Core;

namespace PPPOE_Client.ModelsController
{
    public static class GetGroupInfo
    {
        //获取所有的区域
        public static List<GroupModels> GetGroupList(int page)
        {
            try
            {
                string sql = "";
                if (page == 0)
                {
                    sql = "select * from `groupInfo` where `statu`='true' order by `id`";
                }
                else
                {
                    sql = "select * from `groupInfo` where `statu`='true' order by `id` LIMIT 20 OFFSET " + (page - 1) * 20;
                }
                DataSet Ds = MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<GroupModels> ret = new List<GroupModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        GroupModels item = new GroupModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.name = dr["name"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.statu = dr["statu"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //删除一个区域，只做修改statu属性，保留原始数据
        public static int DeleGroup(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `groupInfo` set `statu`='false' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //编辑一个区域，返回修改响应数
        public static GroupModels EditOneGroup(GroupModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    GroupModels item = new GroupModels();
                    item.id = model.id <= 0 ? 0 : model.id;
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "update `groupInfo` set `name`='" + item.name + "',`desc`='" + item.desc + "' where id='" + item.id + "'";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        return item;
                    }
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        //添加一个区域，返回区域ID
        public static int AddOneGroup(GroupModels model)
        {
            try
            {
                if (model == null)
                {
                    return -1;
                }
                else
                {
                    GroupModels item = new GroupModels();
                    item.name = String.IsNullOrEmpty(model.name) ? "" : model.name.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();
                    string sql = "insert into `groupInfo`(`name`,`desc`,`statu`)values('"
                        + item.name + "','" + item.desc + "','true')";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (result == 1)
                    {
                        sql = "select `id` from `groupInfo` where `name`='" + item.name + "' and `desc`='" + item.desc + "' and statu='true'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            int s;
                            if (int.TryParse(Ds.Tables[0].Rows[0][0].ToString(), out s))
                                return s;
                        }
                    }
                    return 0;
                }
            }
            catch
            {
                return -1;
            }
        }

        //通过ID号返回区域名称
        public static string GetNameById(int id)
        {
            try
            {
                string result = "";
                string sql = "select `name` from `groupInfo` where `id`='" + id + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    result = Ds.Tables[0].Rows[0][0].ToString();
                }
                return result;
            }
            catch
            {
            }
            return null;
        }

    }
}