﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPPOE_Client.Models;
using System.Data;
using MySql.Data.MySqlClient;
using PPPOE_Client.Core;
using System.Web.Mvc;

namespace PPPOE_Client.ModelsController
{
    public static class GetClientInfo
    {
        public static List<ClientModels> GetClientList(int group, int agent, int page,string ser)
        {
            try
            {
                string sql = "";
                if (ser.Length > 0)
                {
                    ser = "%" + ser + "%";
                }
                else
                {
                    ser = "%";
                }
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c  left join `clientInfo` i on c.`id` = i.`cId` where c.`agentId`='" + agent + "' and (c.`statu`!='false' and c.`statu`!='stop' and c.`user` like '" + ser + "'  ) order by c.`user` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                    else
                    {
                        sql = "select * from `client` c   left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and  (c.`statu`!='false' and c.`statu`!='stop' and c.`user` like '" + ser + "'  ) and c.`agentId`='" + agent + "' order by c.`user` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c  left join `clientInfo` i on c.`id` = i.`cId` where (c.`statu`!='false' and c.`statu`!='stop' and c.`user` like '" + ser + "'  ) order by c.`user` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                    else
                    {
                        sql = "select * from `client` c  left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and (c.`statu`!='false' and c.`statu`!='stop' and c.`user` like '" + ser + "'  ) order by c.`user` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ClientModels> ret = new List<ClientModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientModels item = new ClientModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.user = dr["user"].ToString();
                        //item.pwd = dr["pwd"].ToString();
                        item.group = dr["groupId"].ToString();
                        //item.inpoint = dr["inpointId"].ToString();
                        item.inpoint = GetInPointInfo.GetNameById(int.Parse(dr["inpointId"].ToString()));
                        item.agent = dr["agentId"].ToString();
                        item.realname = dr["realname"].ToString();
                        item.phoneNum = dr["phoneNum"].ToString();
                        item.codeNum = dr["codeNum"].ToString();
                        item.address = dr["address"].ToString();
                        item.email = dr["email"].ToString();
                        item.qq = dr["qq"].ToString();
                        item.gfqPort = dr["gfqPort"].ToString();
                        item.Mac = dr["Mac"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.statu = dr["statu"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        public static ClientModels GetClient(int clientid)
        {
            try
            {
                string sql = "";

                //sql = "select * from `client` c  where `id`='" + clientid + "' left join `clientInfo` i on c.`id` = i.`cId` where  c.`statu`!='false'";
                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId`   where c.`id`='" + clientid + "'  and (c.`statu`!='false' and c.`statu` !='stop')";

                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);

                ClientModels item = new ClientModels();
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    item.id = int.Parse(Ds.Tables[0].Rows[0]["id"].ToString());
                    item.user = Ds.Tables[0].Rows[0]["user"].ToString();
                    item.radius = Ds.Tables[0].Rows[0]["radiusId"].ToString();
                    //item.pwd = dr["pwd"].ToString();
                    item.group = Ds.Tables[0].Rows[0]["groupId"].ToString();

                    item.inpoint = GetInPointInfo.GetNameById(int.Parse(Ds.Tables[0].Rows[0]["groupId"].ToString()));

                    item.agent = Ds.Tables[0].Rows[0]["agentId"].ToString();
                    item.realname = Ds.Tables[0].Rows[0]["realname"].ToString();
                    item.phoneNum = Ds.Tables[0].Rows[0]["phoneNum"].ToString();
                    item.cardType = Ds.Tables[0].Rows[0]["cardType"].ToString();
                    item.codeNum = Ds.Tables[0].Rows[0]["codeNum"].ToString();
                    item.address = Ds.Tables[0].Rows[0]["address"].ToString();
                    item.email = Ds.Tables[0].Rows[0]["email"].ToString();
                    item.qq = Ds.Tables[0].Rows[0]["qq"].ToString();
                    item.gfqPort = Ds.Tables[0].Rows[0]["gfqPort"].ToString();
                    item.Mac = Ds.Tables[0].Rows[0]["Mac"].ToString();
                    item.desc = Ds.Tables[0].Rows[0]["desc"].ToString();
                    item.statu = Ds.Tables[0].Rows[0]["statu"].ToString();
                }
                return item;
            }
            catch
            {
            }
            return null;
        }

        //获取过期用户
        public static List<ClientModels> GetTimeoutClientList(int group, int agent, int page)
        {
            try
            {
                string sql = "";
                sql = "select `cId` from `roleDate` where `enddate`< '" + DateTime.Now.ToString("yyyy-MM-dd") + "'";
                DataSet Ds_ID = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds_ID.Tables[0].Rows.Count > 0)
                {
                    string idStr = "";
                    foreach (DataRow row in Ds_ID.Tables[0].Rows)
                    {
                        idStr += row["cId"].ToString() + ",";
                    }
                    if (idStr.Length > 1)
                    {
                        idStr = idStr.Substring(0, idStr.Length - 1);
                        if (agent != 0)
                        {
                            if (group == 0)
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`agentId`='" + agent + "' and c.`statu`='true' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                            else
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`='true' and c.`agentId`='" + agent + "' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                        }
                        else
                        {
                            if (group == 0)
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`statu`='true' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                            else
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`='true' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                        }
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            List<ClientModels> ret = new List<ClientModels>();
                            foreach (DataRow dr in Ds.Tables[0].Rows)
                            {
                                ClientModels item = new ClientModels();
                                item.id = int.Parse(dr["id"].ToString());
                                item.user = dr["user"].ToString();
                                //item.pwd = dr["pwd"].ToString();
                                item.group = dr["groupId"].ToString();
                                item.agent = dr["agentId"].ToString();
                                item.realname = dr["realname"].ToString();
                                item.phoneNum = dr["phoneNum"].ToString();
                                item.codeNum = dr["codeNum"].ToString();
                                item.address = dr["address"].ToString();
                                item.email = dr["email"].ToString();
                                item.qq = dr["qq"].ToString();
                                item.desc = dr["desc"].ToString();
                                item.statu = dr["statu"].ToString();
                                ret.Add(item);
                            }
                            return ret;
                        }
                    }
                }
            }
            catch
            {
            }
            return null;
        }

        //获取即将过期用户
        public static List<ClientModels> GetWillTimeoutClientList(int group, int agent, int page)
        {
            try
            {
                string sql = "";
                sql = "select `cId` from `roleDate` where `enddate`>= '" + DateTime.Now.ToString("yyyy-MM-dd") + "' and `enddate`<= '" + DateTime.Now.AddMonths(1).ToString("yyyy-MM-dd") + "' ";
                DataSet Ds_ID = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds_ID.Tables[0].Rows.Count > 0)
                {
                    string idStr = "";
                    foreach (DataRow row in Ds_ID.Tables[0].Rows)
                    {
                        idStr += row["cId"].ToString() + ",";
                    }
                    if (idStr.Length > 1)
                    {
                        idStr = idStr.Substring(0, idStr.Length - 1);
                        if (agent != 0)
                        {
                            if (group == 0)
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`agentId`='" + agent + "' and c.`statu`='true' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                            else
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`='true' and c.`agentId`='" + agent + "' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                        }
                        else
                        {
                            if (group == 0)
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`statu`='true' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                            else
                            {
                                sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`='true' and c.`id` in(" + idStr + ") LIMIT 20 OFFSET " + (page - 1) * 20;
                            }
                        }
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            List<ClientModels> ret = new List<ClientModels>();
                            foreach (DataRow dr in Ds.Tables[0].Rows)
                            {
                                ClientModels item = new ClientModels();
                                item.id = int.Parse(dr["id"].ToString());
                                item.user = dr["user"].ToString();
                                //item.pwd = dr["pwd"].ToString();
                                item.group = dr["groupId"].ToString();
                                item.agent = dr["agentId"].ToString();
                                item.realname = dr["realname"].ToString();
                                item.phoneNum = dr["phoneNum"].ToString();
                                item.codeNum = dr["codeNum"].ToString();
                                item.address = dr["address"].ToString();
                                item.email = dr["email"].ToString();
                                item.qq = dr["qq"].ToString();
                                item.desc = dr["desc"].ToString();
                                item.statu = dr["statu"].ToString();
                                ret.Add(item);
                            }
                            return ret;
                        }
                    }
                }
            }
            catch
            {
            }
            return null;
        }

        //获取禁用用户
        public static List<ClientModels> GetForbidClientList(int group, int agent, int page)
        {
            try
            {
                string sql = "";
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`agentId`='" + agent + "' and c.`statu`='stop' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`='stop' and c.`agentId`='" + agent + "' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`statu`='stop' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`='stop' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ClientModels> ret = new List<ClientModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientModels item = new ClientModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.user = dr["user"].ToString();
                        //item.pwd = dr["pwd"].ToString();
                        item.group = dr["groupId"].ToString();
                        item.agent = dr["agentId"].ToString();
                        item.realname = dr["realname"].ToString();
                        item.phoneNum = dr["phoneNum"].ToString();
                        item.codeNum = dr["codeNum"].ToString();
                        item.address = dr["address"].ToString();
                        item.email = dr["email"].ToString();
                        item.qq = dr["qq"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.statu = dr["statu"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //获取过期用户
        public static List<ReportModels> GetReport(int group, DateTime begin,DateTime end, int page)
        {
            try
            {
                string sql = "";
                //sql = "select `cId` from `roleDate` where `Recdate` bewteen '" + begin + "' and  '" + end + "' ";
              //  sql = "select * from(select * from `roleDate` where `Recdate` bewteen '" + begin + "' and  '" + end + "') r left join (select * from `client`  where `groupId`='" + group + "' and `statu`='true' ) d   on r.cid=d.id";
                //string b = begin.ToString("yyyy-MM-dd HH:mm:ss");
                //string en = end.ToString("yyyy-MM-dd HH:mm:ss");

                string b = begin.ToString("yyyy-MM-dd");
                string en = end.ToString("yyyy-MM-dd");

                sql = "select * from((select * from `roleDate` where ( `Recdate` between cast('" + b + "'  as date) and cast( '" + en + "' as date) )  and (FristMoney+ UseMoney+ModelMoney+ChangeMoney+MobilMoney+OtherMoney!=0) ) r inner join (select * from `client`) d  on r.cid=d.id) order by cast(r.`Recdate` as date) desc";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ReportModels> ret = new List<ReportModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ReportModels item = new ReportModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.user = dr["user"].ToString();
                        //item.pwd = dr["pwd"].ToString();
                        item.group = dr["groupId"].ToString();
                        item.ChangeMoney = dr["ChangeMoney"].ToString();
                        item.FristMoney = dr["FristMoney"].ToString();
                        item.MobilMoney = dr["MobilMoney"].ToString();
                        item.ModelMoney = dr["ModelMoney"].ToString();
                        item.OtherMoney = dr["OtherMoney"].ToString();
                        item.DLMoney = dr["DLMoney"].ToString();
                        item.Recdate = dr["Recdate"].ToString();
                        item.UseMoney = dr["UseMoney"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }

            }
            catch
            {
            }
            return null;
        }

        //获取在线用户列表
        public static List<ClientModels> GetOnlineList(int group, int agent, int page,string ser)
        {
            try
            {
                string sql = "";
                if (ser.Length > 0)
                {
                    ser = "%" + ser + "%";
                }
                else
                {
                    ser = "%";
                }
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`agentId`='" + agent + "' and c.`user` like '" + ser + "' and `online`='on' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`user` like '" + ser + "' and `online`='on' and c.`agentId`='" + agent + "' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where `online`='on' and c.`user` like '" + ser + "' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`user` like '" + ser + "' and `online`='on' order by c.`id` LIMIT 20 OFFSET " + (page - 1) * 20;
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ClientModels> ret = new List<ClientModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientModels item = new ClientModels();
                        item.id = int.Parse(dr["id"].ToString());
                        item.user = dr["user"].ToString();
                        //item.pwd = dr["pwd"].ToString();
                        item.group = dr["groupId"].ToString();
                        item.agent = dr["agentId"].ToString();
                        item.radius = dr["radiusId"].ToString();
                        item.realname = dr["realname"].ToString();
                        item.phoneNum = dr["phoneNum"].ToString();
                        item.codeNum = dr["codeNum"].ToString();
                        item.address = dr["address"].ToString();
                        item.email = dr["email"].ToString();
                        item.qq = dr["qq"].ToString();
                        item.desc = dr["desc"].ToString();
                        item.statu = dr["statu"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //绑定一个用户套餐
        public static string BindClientMeal(int cId, int mId, string start,string recDate ,string desc,string price,string frist,string model,string dl ,string other,string addMonth)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                int result = 0;

                string sql_update = "update `client` set `statu`='chgdate',`httpInfo`='' where `id`='" + cId + "'";
                conn.Open();
                MySqlCommand cmd_update = new MySqlCommand(sql_update, conn);
                cmd_update.ExecuteNonQuery();
                cmd_update.Dispose();
                conn.Close();
                //查找结束时间
                string sql_meal = "select * from `mealinfo` where `id`='" + mId + "'";
                DataSet Ds_meal = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql_meal);

                //添加日期限制
                string sql_date = "select `id` from `roleDate` where `cId`='" + cId + "'";
                DataSet Ds_date = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql_date);

                if (Ds_meal.Tables[0].Rows.Count > 0)
                {
                    string end = DateTime.Parse(start).AddMonths(int.Parse(Ds_meal.Tables[0].Rows[0]["roleMonth"].ToString()) + int.Parse(Ds_meal.Tables[0].Rows[0]["addMonth"].ToString()) +int.Parse(addMonth)).ToString("yyyy-MM-dd");
                    if (Ds_date.Tables[0].Rows.Count > 0)//更新
                    {
                        string sql_up = "update `roleDate` set `startdate`='" + start + "',`Recdate`='" + recDate + "',`enddate`='" + end + "',`MonthCount`='" + addMonth + "',`FristMoney`='" + frist + "',`UseMoney`='" + price + "',`ModelMoney`='" + model + "',`DLMoney`='" + dl + "',`OtherMoney`='" + other + "',`desc`='" + desc + "' where `cId`='" + cId + "'";
                        conn.Open();
                        MySqlCommand cmd_up = new MySqlCommand(sql_up, conn);
                        result = cmd_up.ExecuteNonQuery();
                        cmd_up.Dispose();
                        conn.Close();
                    }
                    else //插入
                    {
                        sql_date = "insert into `roleDate`(`cId`,`startdate`,`enddate`,`Indate`,`MonthCount`,`Recdate`,`FristMoney`,`UseMoney`,`ModelMoney`,`DLMoney`,`OtherMoney`,`desc`)values('" + cId + "','" + start + "','" + end + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + addMonth + "','" + recDate + "','" + frist + "','" + price + "','" + model + "','" + dl + "','" + other + "','" + desc + "')";
                        conn.Open();
                        MySqlCommand cmd_date = new MySqlCommand(sql_date, conn);
                        result = cmd_date.ExecuteNonQuery();
                        cmd_date.Dispose();
                        conn.Close();
                    }
                }
                //投入队列
                string sql = "select * from `client` where `id`='" + cId + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    System.Net.WebClient clinet = new System.Net.WebClient();
                    string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_dat&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"\",\"radiusid\":\"" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + "\",\"mealid\":\"\"}";
                    System.IO.Stream stream = clinet.OpenRead(url);
                    System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                    reader.ReadToEnd();
                    clinet.Dispose();

                    OpratelogModels logModel = new OpratelogModels();

                    logModel.opttype = "修改";
                    logModel.optobjtype = "客户资料";
                    logModel.opttime = DateTime.Now.ToString();
                    if (HttpContext.Current.Session["name"].ToString() != null)
                    {
                        logModel.optman = HttpContext.Current.Session["name"].ToString();
                        logModel.optobject = HttpContext.Current.Session["name"].ToString() + "修改了账号：" + Ds.Tables[0].Rows[0]["user"].ToString() + "套餐信息";
                    }
                    GetOprateLog.AddOneOpratelog(logModel);
                }

                if (result == 1)
                {
                    sql = "update `client` set `mealid`='" + mId + "' where id='" + cId + "'";
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    int s = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    if (s == 1)
                    {
                        //投入队列
                        System.Net.WebClient clinet2 = new System.Net.WebClient();
                        string url2 = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_lim&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"\",\"radiusid\":\"" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + "\",\"mealid\":\"" + mId + "\"}";
                        System.IO.Stream stream2 = clinet2.OpenRead(url2);
                        System.IO.StreamReader reader2 = new System.IO.StreamReader(stream2, System.Text.Encoding.GetEncoding("UTF-8"));
                        reader2.ReadToEnd();
                        clinet2.Dispose();

                        return GetClientMeal(cId);
                    }
                }
                return "绑定失败";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        //绑定一个用户套餐
        public static string addReport(string user, int cId,  string recDate, string desc, string price, string frist, string model, string dl, string other)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);


                string sql_date = "insert into `roleDate`(`cId`,`Indate`,`Recdate`,`FristMoney`,`UseMoney`,`ModelMoney`,`DLMoney`,`OtherMoney`,`desc`)values('" + cId + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + recDate + "','" + frist + "','" + price + "','" + model + "','" + dl + "','" + other + "','" + desc + "')";
                conn.Open();
                MySqlCommand cmd_date = new MySqlCommand(sql_date, conn);
                cmd_date.ExecuteNonQuery();
                cmd_date.Dispose();
                conn.Close();


                OpratelogModels logModel = new OpratelogModels();

                logModel.opttype = "修改";
                logModel.optobjtype = "客户资料";
                logModel.opttime = DateTime.Now.ToString();
                if (HttpContext.Current.Session["name"].ToString() != null)
                {
                    logModel.optman = HttpContext.Current.Session["name"].ToString();
                    logModel.optobject = HttpContext.Current.Session["name"].ToString() + "修改了账号：" + user + "费用信息";
                }
                GetOprateLog.AddOneOpratelog(logModel);

                return "新增成功";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        //获取用户套餐信息
        public static string GetClientMeal(int cid)
        {
            try
            {
                string result = "";
                string sql = "select * from `client` c right join `mealinfo` r on c.`mealid` = r.`id` where c.`id`='" + cid + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    result += "【"+Ds.Tables[0].Rows[0]["name"].ToString()+"】";
                }
                sql = "select * from `roleDate` where `cId`='" + cid + "'";
                DataSet Ds_date = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds_date.Tables[0].Rows.Count > 0)
                {
                    double useM = 0;
                    double fristM = 0;
                    double modM = 0;
                    double dlM = 0;
                    double otherM = 0;

                    for (int i = 0; i < Ds_date.Tables[0].Rows.Count; i++)
                    {
                        useM += Convert.ToDouble(Ds_date.Tables[0].Rows[i]["UseMoney"].ToString());
                        fristM += Convert.ToDouble(Ds_date.Tables[0].Rows[i]["FristMoney"].ToString());
                        modM += Convert.ToDouble(Ds_date.Tables[0].Rows[i]["ModelMoney"].ToString());
                        dlM += Convert.ToDouble(Ds_date.Tables[0].Rows[i]["DLMoney"].ToString());
                        otherM += Convert.ToDouble(Ds_date.Tables[0].Rows[i]["OtherMoney"].ToString());
                    }

                    result += "<br />开通时间：" + Ds_date.Tables[0].Rows[0]["startdate"].ToString();
                    result += "<br />结束时间：" + Ds_date.Tables[0].Rows[0]["enddate"].ToString();
                    result += "<br />赠送月份：" + Ds_date.Tables[0].Rows[0]["MonthCount"].ToString();
                    //result += "<br />套餐费用：" + Ds_date.Tables[0].Rows[0]["UseMoney"].ToString();
                    //result += "<br />初装费：" + Ds_date.Tables[0].Rows[0]["FristMoney"].ToString();
                    //result += "<br />光猫押金：" + Ds_date.Tables[0].Rows[0]["ModelMoney"].ToString();
                    //result += "<br />代理直结：" + Ds_date.Tables[0].Rows[0]["DLMoney"].ToString();
                    //result += "<br />其他费用：" + Ds_date.Tables[0].Rows[0]["OtherMoney"].ToString();
                    result += "<br />套餐费用：" + useM.ToString();
                    result += "<br />初装费：" + fristM.ToString();
                    result += "<br />光猫押金：" + modM.ToString();
                    result += "<br />代理直结：" + dlM.ToString();
                    result += "<br />其他费用：" + otherM.ToString();
                    result += "<br />备注：" + Ds_date.Tables[0].Rows[0]["desc"].ToString();
                }
                else
                {
                    result += "尚未开通";
                }
                return result;
            }
            catch
            {
            }
            return null;
        }

        //导出用户Excel表
        public static List<ClientExcelModels> GetExcelList(int group, int agent)
        {
            try
            {
                string sql = "";
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`agentId`='" + agent + "' and c.`statu`!='false' order by c.`id`";
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`!='false' and c.`agentId`='" + agent + "' order by c.`id`";
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`statu`!='false' order by c.`id`";
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where c.`groupId`='" + group + "' and c.`statu`!='false' order by c.`id`";
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ClientExcelModels> ret = new List<ClientExcelModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientExcelModels item = new ClientExcelModels();
                        item.用户名 = dr["user"].ToString();
                        item.真实名字 = dr["realname"].ToString();
                        item.所属代理 = GetAgentInfo.GetNameById(int.Parse(dr["agentId"].ToString()));
                        item.所在区域 = GetGroupInfo.GetNameById(int.Parse(dr["groupId"].ToString()));
                        item.联系电话 = dr["phoneNum"].ToString();
                        item.证件号码 = dr["codeNum"].ToString();
                        item.联系地址 = dr["address"].ToString();
                        item.电子邮箱 = dr["email"].ToString();
                        item.常用QQ = dr["qq"].ToString();
                        item.备注信息 = dr["desc"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //导出过期用户Excel表
        public static List<ClientExcelModels> GetFalseClientExcel(int group, int agent)
        {
            try
            {
                string sql = "";
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where i.`agentId`='" + agent + "' and `statu`='false' order by c.`id`";
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where i.`groupId`='" + group + "' and `statu`='false' and i.`agentId`='" + agent + "' order by c.`id`";
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where `statu`='false' order by c.`id`";
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where i.`groupId`='" + group + "' and `statu`='false' order by c.`id`";
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ClientExcelModels> ret = new List<ClientExcelModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientExcelModels item = new ClientExcelModels();
                        item.用户名 = dr["user"].ToString();
                        item.真实名字 = dr["realname"].ToString();
                        item.所属代理 = GetAgentInfo.GetNameById(int.Parse(dr["agentId"].ToString()));
                        item.所在区域 = GetGroupInfo.GetNameById(int.Parse(dr["groupId"].ToString()));
                        item.联系电话 = dr["phoneNum"].ToString();
                        item.证件号码 = dr["codeNum"].ToString();
                        item.联系地址 = dr["address"].ToString();
                        item.电子邮箱 = dr["email"].ToString();
                        item.常用QQ = dr["qq"].ToString();
                        item.备注信息 = dr["desc"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        //导出在线Excel表
        public static List<ClientExcelModels> GetOnlineExcel(int group, int agent)
        {
            try
            {
                string sql = "";
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where i.`agentId`='" + agent + "' and `online`='on' order by c.`id`";
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where i.`groupId`='" + group + "' and `online`='on' and i.`agentId`='" + agent + "' order by c.`id`";
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where `online`='on' order by c.`id`";
                    }
                    else
                    {
                        sql = "select * from `client` c left join `clientInfo` i on c.`id` = i.`cId` where i.`groupId`='" + group + "' and `online`='on' order by c.`id`";
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    List<ClientExcelModels> ret = new List<ClientExcelModels>();
                    foreach (DataRow dr in Ds.Tables[0].Rows)
                    {
                        ClientExcelModels item = new ClientExcelModels();
                        item.用户名 = dr["user"].ToString();
                        item.真实名字 = dr["realname"].ToString();
                        item.所在区域 = dr["groupId"].ToString();
                        item.所属代理 = GetAgentInfo.GetNameById(int.Parse(dr["agentId"].ToString()));
                        item.所在区域 = GetGroupInfo.GetNameById(int.Parse(dr["groupId"].ToString()));
                        item.证件号码 = dr["codeNum"].ToString();
                        item.联系地址 = dr["address"].ToString();
                        item.电子邮箱 = dr["email"].ToString();
                        item.常用QQ = dr["qq"].ToString();
                        item.备注信息 = dr["desc"].ToString();
                        ret.Add(item);
                    }
                    return ret;
                }
            }
            catch
            {
            }
            return null;
        }

        public static int ChangePwd(int id, string pwd)
        {
            try
            {
                string sql = "update `client` set `pwd`='" + pwd + "',`statu`='chgpwd',`httpInfo`='' where `id`='" + id + "'";
                MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                int rslt = cmd.ExecuteNonQuery();
                cmd.Dispose();

                sql = "select * from `client` where `id`='" + id + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    //投入队列
                    System.Net.WebClient clinet = new System.Net.WebClient();
                    string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_pwd&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"" + pwd + "\",\"radiusid\":\"" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + "\",\"mealid\":\"\"}";
                    System.IO.Stream stream = clinet.OpenRead(url);
                    System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                    string result = reader.ReadToEnd();
                    clinet.Dispose();

                    OpratelogModels logModel = new OpratelogModels();

                    logModel.opttype = "修改";
                    logModel.optobjtype = "客户资料";
                    logModel.opttime = DateTime.Now.ToString();
                    if (HttpContext.Current.Session["name"].ToString() != null)
                    {
                        logModel.optman = HttpContext.Current.Session["name"].ToString();
                        logModel.optobject = HttpContext.Current.Session["name"].ToString() + "修改了账号：" + Ds.Tables[0].Rows[0]["user"].ToString() + "密码";
                    }
                    GetOprateLog.AddOneOpratelog(logModel);
                }

                conn.Close();
                return rslt;
            }
            catch
            {
                return -1;
            }
        }

        //编辑一个用户，返回用户对象
        public static ClientModels EditOneClient(ClientModels model)
        {
            try
            {
                if (model == null)
                {
                    return null;
                }
                else
                {
                    ClientModels item = new ClientModels();
                    item.id = model.id <= 0 ? 0 : model.id;
                    //item.user = String.IsNullOrEmpty(model.user) ? "" : model.user.Trim(); //用户名不能改了
                    //item.pwd = String.IsNullOrEmpty(model.pwd) ? "" : model.pwd.Trim();
                    item.group = String.IsNullOrEmpty(model.group) ? "" : model.group.Trim();
                    item.agent = String.IsNullOrEmpty(model.agent) ? "" : model.agent.Trim();
                    item.radius = String.IsNullOrEmpty(model.radius) ? "" : model.radius.Trim();
                    item.inpoint = String.IsNullOrEmpty(model.inpoint) ? "0" : model.inpoint.Trim();
                    item.realname = String.IsNullOrEmpty(model.realname) ? "" : model.realname.Trim();
                    item.phoneNum = String.IsNullOrEmpty(model.phoneNum) ? "" : model.phoneNum.Trim();
                    item.codeNum = String.IsNullOrEmpty(model.codeNum) ? "" : model.codeNum.Trim();
                    item.address = String.IsNullOrEmpty(model.address) ? "" : model.address.Trim();
                    item.email = String.IsNullOrEmpty(model.email) ? "" : model.email.Trim();
                    item.qq = String.IsNullOrEmpty(model.qq) ? "" : model.qq.Trim();
                    item.gfqPort = String.IsNullOrEmpty(model.gfqPort) ? "" : model.gfqPort.Trim();
                    item.Mac = String.IsNullOrEmpty(model.Mac) ? "" : model.Mac.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();

                    string sql_info = "update `clientInfo` set `realname`='" + item.realname + "',`address`='" + item.address 
                        + "',`phoneNum`='" + item.phoneNum + "',`codeNum`='" + item.codeNum + "',`email`='" + item.email
                        + "',`qq`='" + item.qq + "',`gfqPort`='" + item.gfqPort + "',`Mac`='" + item.Mac + "',`desc`='" + item.desc + "' where cId='" + item.id + "'";
                    string sql_main = "update `client` set `groupId`='" + item.group
                        + "',`agentId`='" + item.agent + "',`radiusId`='" + item.radius + "',`inpointId`='" + item.inpoint + "' where id='" + item.id + "'";

                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();

                    MySqlCommand cmd_info = new MySqlCommand(sql_info, conn);
                    int rslt_info = cmd_info.ExecuteNonQuery();

                    MySqlCommand cmd_main = new MySqlCommand(sql_main, conn);
                    int rslt_main = cmd_main.ExecuteNonQuery();

                    cmd_info.Dispose();
                    cmd_main.Dispose();
                    conn.Close();

                    OpratelogModels logModel = new OpratelogModels();

                    logModel.opttype = "修改";
                    logModel.optobjtype = "客户资料";
                    logModel.opttime = DateTime.Now.ToString();
                    if (HttpContext.Current.Session["name"].ToString() != null)
                    {
                        logModel.optman = HttpContext.Current.Session["name"].ToString();
                        logModel.optobject = HttpContext.Current.Session["name"].ToString() + "修改了账号：" + model.user.Trim() + "基本信息";
                    }
                    GetOprateLog.AddOneOpratelog(logModel);

                    if (rslt_info == 1 && rslt_main == 1)
                    {
                        return item;
                    }
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        //删除一个用户，只做修改statu属性，保留原始数据
        public static int DeleClient(string[] idArr)
        { 
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `client` set `statu`='dele',`httpInfo`='' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();

                        sql = "select * from `client` where id='" + id + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            System.Net.WebClient clinet = new System.Net.WebClient();
                            string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_del&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"\",\"radiusid\":" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + ",\"mealid\":\"\"}";
                            System.IO.Stream stream = clinet.OpenRead(url);
                            System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                            string resultStr = reader.ReadToEnd();
                            clinet.Dispose();

                            OpratelogModels logModel = new OpratelogModels();

                            logModel.opttype = "删除";
                            logModel.optobjtype = "客户资料";
                            logModel.opttime = DateTime.Now.ToString();
                            if (HttpContext.Current.Session["name"].ToString() != null)
                            {
                                logModel.optman = HttpContext.Current.Session["name"].ToString();
                                logModel.optobject = HttpContext.Current.Session["name"].ToString() + "删除了账号：" + Ds.Tables[0].Rows[0]["user"].ToString();
                            }
                            GetOprateLog.AddOneOpratelog(logModel);
                        }                      
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //禁用一个用户，只做修改statu属性，保留原始数据
        public static int StopClient(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `client` set `statu`='waitStop',`httpInfo`='' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();

                        sql = "select * from `client` where id='" + id + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            System.Net.WebClient clinet = new System.Net.WebClient();
                            string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_for&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"\",\"radiusid\":" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + ",\"mealid\":\"\"}";
                            System.IO.Stream stream = clinet.OpenRead(url);
                            System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                            string resultStr = reader.ReadToEnd();
                            clinet.Dispose();

                            OpratelogModels logModel = new OpratelogModels();

                            logModel.opttype = "修改";
                            logModel.optobjtype = "客户资料";
                            logModel.opttime = DateTime.Now.ToString();
                            if (HttpContext.Current.Session["name"].ToString() != null)
                            {
                                logModel.optman = HttpContext.Current.Session["name"].ToString();
                                logModel.optobject = HttpContext.Current.Session["name"].ToString() + "禁用了账号：" + Ds.Tables[0].Rows[0]["user"].ToString();
                            }
                            GetOprateLog.AddOneOpratelog(logModel);
                        }
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //启用用户
        public static int ReupClient(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `client` set `statu`='WillRecover',`httpInfo`='' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();

                        sql = "select * from `client` where id='" + id + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            System.Net.WebClient clinet = new System.Net.WebClient();
                            string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_rec&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"\",\"radiusid\":" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + ",\"mealid\":\"\"}";
                            System.IO.Stream stream = clinet.OpenRead(url);
                            System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                            string resultStr = reader.ReadToEnd();
                            clinet.Dispose();

                            OpratelogModels logModel = new OpratelogModels();

                            logModel.opttype = "修改";
                            logModel.optobjtype = "客户资料";
                            logModel.opttime = DateTime.Now.ToString();
                            if (HttpContext.Current.Session["name"].ToString() != null)
                            {
                                logModel.optman = HttpContext.Current.Session["name"].ToString();
                                logModel.optobject = HttpContext.Current.Session["name"].ToString() + "启用了账号：" + Ds.Tables[0].Rows[0]["user"].ToString();
                            }
                            GetOprateLog.AddOneOpratelog(logModel);
                        }
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }

        //重置用户
        public static int ResetClient(string[] idArr)
        {
            try
            {
                if (idArr == null)
                {
                    return 0;
                }
                else
                {
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    int result = 0;
                    conn.Open();
                    foreach (string id in idArr)
                    {
                        string sql = "update `client` set `statu`='reset',`httpInfo`='' where id='" + id + "'";
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        result += cmd.ExecuteNonQuery();
                        cmd.Dispose();

                        sql = "select * from `client` where id='" + id + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            System.Net.WebClient clinet = new System.Net.WebClient();
                            string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_for&opt=put&data={\"username\":\"" + Ds.Tables[0].Rows[0]["user"].ToString() + "\",\"password\":\"\",\"radiusid\":" + Ds.Tables[0].Rows[0]["radiusId"].ToString() + ",\"mealid\":\"\"}";
                            System.IO.Stream stream = clinet.OpenRead(url);
                            System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                            string resultStr = reader.ReadToEnd();
                            clinet.Dispose();

                            OpratelogModels logModel = new OpratelogModels();

                            logModel.opttype = "修改";
                            logModel.optobjtype = "客户资料";
                            logModel.opttime = DateTime.Now.ToString();
                            if (HttpContext.Current.Session["name"].ToString() != null)
                            {
                                logModel.optman = HttpContext.Current.Session["name"].ToString();
                                logModel.optobject = HttpContext.Current.Session["name"].ToString() + "禁用了账号：" + Ds.Tables[0].Rows[0]["user"].ToString();
                            }
                            GetOprateLog.AddOneOpratelog(logModel);
                        }
                    }
                    conn.Close();
                    return result;
                }
            }
            catch
            {
                return 0;
            }
        }
        
        //添加一个用户，返回用户ID
        public static int AddOneClient(ClientModels model)
        {
            try
            {
                if (model == null)
                {
                    return -1;
                }
                else
                {
                    ClientModels item = new ClientModels();
                    item.user = String.IsNullOrEmpty(model.user) ? "" : model.user.Trim();
                    item.pwd = String.IsNullOrEmpty(model.pwd) ? "" : model.pwd.Trim();
                    item.group = String.IsNullOrEmpty(model.group) ? "0" : model.group.Trim();
                    item.agent = String.IsNullOrEmpty(model.agent) ? "0" : model.agent.Trim();
                    item.radius = String.IsNullOrEmpty(model.radius) ? "0" : model.radius.Trim();
                    item.inpoint = String.IsNullOrEmpty(model.inpoint) ? "0" : model.inpoint.Trim();
                    item.meal = String.IsNullOrEmpty(model.meal) ? "0" : model.meal.Trim();
                    item.realname = String.IsNullOrEmpty(model.realname) ? "" : model.realname.Trim();
                    item.phoneNum = String.IsNullOrEmpty(model.phoneNum) ? "" : model.phoneNum.Trim();
                    item.cardType = String.IsNullOrEmpty(model.cardType) ? "" : model.cardType.Trim();
                    item.codeNum = String.IsNullOrEmpty(model.codeNum) ? "" : model.codeNum.Trim();
                    item.address = String.IsNullOrEmpty(model.address) ? "" : model.address.Trim();
                    item.email = String.IsNullOrEmpty(model.email) ? "" : model.email.Trim();
                    item.qq = String.IsNullOrEmpty(model.qq) ? "" : model.qq.Trim();
                    item.gfqPort = String.IsNullOrEmpty(model.gfqPort) ? "" : model.gfqPort.Trim();
                    item.Mac = String.IsNullOrEmpty(model.Mac) ? "" : model.Mac.Trim();
                    item.desc = String.IsNullOrEmpty(model.desc) ? "" : model.desc.Trim();


                    string sql_main = "insert into `client`(`user`,`pwd`,`groupId`,`agentId`,`radiusId`,`inpointId`,`mealid`,`statu`)values('"
                        + item.user + "','" + item.pwd + "','" + item.group + "','" + item.agent + "','" + item.radius + "','"+item.inpoint+"','" + item.meal + "','add')";
                    MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                    conn.Open();
                    MySqlCommand cmd_main = new MySqlCommand(sql_main, conn);
                    int rslt_main = cmd_main.ExecuteNonQuery();
                    cmd_main.Dispose();
                    conn.Close();
                    
                    if (rslt_main == 1 )
                    {
                        string sql = "select `id` from `client` where `user`='" + model.user + "'";
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            string sql_info = "insert into `clientInfo`(`cId`,`realname`,`address`,`phoneNum`,`cardType`,`codeNum`,`email`,`qq`,`gfqPort`,`Mac`,`desc`,`addtime`)values('"
                            + int.Parse(Ds.Tables[0].Rows[0][0].ToString()) + "','" + item.realname + "','" + item.address + "','" + item.phoneNum + "','"+item.cardType+"','" + item.codeNum + "','" + item.email + "','"
                            + item.qq + "','"+item.gfqPort+"','"+item.Mac+"','" + item.desc + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "')";
                            conn.Open();
                            MySqlCommand cmd_info = new MySqlCommand(sql_info, conn);
                            int rslt_info = cmd_info.ExecuteNonQuery();
                            cmd_info.Dispose();
                            conn.Close();

                            if (rslt_info == 1)
                            {
                                System.Net.WebClient clinet = new System.Net.WebClient();
                                string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_add&opt=put&data={\"username\":\"" + item.user + "\",\"password\":\"" + item.pwd + "\",\"radiusid\":\"" + item.radius + "\",\"mealid\":\"" + item.meal + "\"}";
                                System.IO.Stream stream = clinet.OpenRead(url);
                                System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                                string result = reader.ReadToEnd();
                                clinet.Dispose();
                                if (!string.IsNullOrEmpty(result))
                                {
                                    if (result == "HTTPSQS_PUT_OK")
                                    {
                                        OpratelogModels logModel = new OpratelogModels();

                                        logModel.opttype = "添加";
                                        logModel.optobjtype = "客户资料";
                                        logModel.opttime = DateTime.Now.ToString();
                                        if (HttpContext.Current.Session["name"].ToString() != null)
                                        {
                                            logModel.optman = HttpContext.Current.Session["name"].ToString();
                                            logModel.optobject = HttpContext.Current.Session["name"].ToString() + "添加了账号：" + model.user.Trim();
                                        }
                                        GetOprateLog.AddOneOpratelog(logModel);

                                        return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                                    }
                                    return 0;
                                }
                            }
                        }
                    }

                    

                    return 0;
                }
            }
            catch
            {
                return -1;
            }
        }

        //获取用户数量
        public static int GetClientTotalNum(int group, int agent,string ser)
        {
            try
            {
                string sql = "";
                if (ser.Length > 0)
                {
                    ser = "%" + ser + "%";
                }
                else
                {
                    ser = "%";
                }
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select Count(*) from `client` where `agentId`='" + agent + "' and `statu`!='false' and `user` like '" + ser + "'";
                    }
                    else
                    {
                        sql = "select Count(*) from `client` where `groupId`='" + group + "' and `statu`!='false' and `agentId`='" + agent + "' and `user` like '" + ser + "'";
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select Count(*) from `client` where `statu`!='false' and `user` like '" + ser + "'";
                    }
                    else
                    {
                        sql = "select Count(*) from `client` where `groupId`='" + group + "' and `statu`!='false' and `user` like '" + ser + "'";
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
            }
            catch
            {
            }
            return 0;
        }

        //获取过期用户数量
        public static int GetTimeoutTotalNum(int group, int agent)
        {
            try
            {
                string sql = "";
                sql = "select `cId` from `roleDate` where `enddate`< '" + DateTime.Now.ToString("yyyy-MM-dd") + "'";
                DataSet Ds_ID = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds_ID.Tables[0].Rows.Count > 0)
                {
                    string idStr = "";
                    foreach (DataRow row in Ds_ID.Tables[0].Rows)
                    {
                        idStr += row["cId"].ToString() + ",";
                    }
                    if (idStr.Length > 1)
                    {
                        idStr = idStr.Substring(0, idStr.Length - 1);
                        if (agent != 0)
                        {
                            if (group == 0)
                            {
                                sql = "select Count(*) from `client` where `agentId`='" + agent + "' and `statu`='true' and `id` in(" + idStr + ")";
                            }
                            else
                            {
                                sql = "select Count(*) from `client` where `groupId`='" + group + "' and `statu`='true' and `agentId`='" + agent + "' and `id` in(" + idStr + ")";
                            }
                        }
                        else
                        {
                            if (group == 0)
                            {
                                sql = "select Count(*) from `client` where `statu`='true' and `id` in(" + idStr + ")";
                            }
                            else
                            {
                                sql = "select Count(*) from `client` where `groupId`='" + group + "' and `statu`='true' and `id` in(" + idStr + ")";
                            }
                        }
                        DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                        if (Ds.Tables[0].Rows.Count > 0)
                        {
                            return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                        }
                    }
                }
            }
            catch
            {
            }
            return 0;
        }

        //获取禁用用户数量
        public static int GetForbidTotalNum(int group, int agent)
        {
            try
            {
                string sql = "";
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select Count(*) from `client` where `agentId`='" + agent + "' and `statu`='stop'";
                    }
                    else
                    {
                        sql = "select Count(*) from `client` where `groupId`='" + group + "' and `statu`='stop' and `agentId`='" + agent + "'";
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select Count(*) from `client` where `statu`='stop'";
                    }
                    else
                    {
                        sql = "select Count(*) from `client` where `groupId`='" + group + "' and `statu`='stop'";
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
            }
            catch
            {
            }
            return 0;
        }

        //获取在线用户数量
        public static int GetOnlineTotalNum(int group, int agent,string ser)
        {
            try
            {
                string sql = "";
                if (ser.Length > 0)
                {
                    ser = "%" + ser + "%";
                }
                else
                {
                    ser = "%";
                }
                if (agent != 0)
                {
                    if (group == 0)
                    {
                        sql = "select Count(*) from `client` where `agentId`='" + agent + "' and `online`='on' and `user` like '" + ser + "'";
                    }
                    else
                    {
                        sql = "select Count(*) from `client` where `groupId`='" + group + "' and `online`='on' and `agentId`='" + agent + "' and `user` like '" + ser + "'";
                    }
                }
                else
                {
                    if (group == 0)
                    {
                        sql = "select Count(*) from `client` where `online`='on' and `user` like '" + ser + "'";
                    }
                    else
                    {
                        sql = "select Count(*) from `client` where `groupId`='" + group + "' and `online`='on' and `user` like '" + ser + "'";
                    }
                }
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
            }
            catch
            {
            }
            return 0;
        }

        //检查用户名唯一性
        public static int CheckUserName(string name)
        {
            try
            {
                string sql = "select Count(*) from `client` where `user`='" + name.Trim() + "' and (`statu` = 'true' or `statu` = 'stop') ; ";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
                return 0;
            }
            catch
            {
                return -1;
            }
        }

        //获取用户名id
        public static int GetUserID(string name)
        {
            try
            {
                string sql = "select `id` from `client` where `user`='" + name.Trim() + "' and (`statu` = 'true' or `statu` = 'stop') ; ";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    return int.Parse(Ds.Tables[0].Rows[0][0].ToString());
                }
                return 0;
            }
            catch
            {
                return -1;
            }
        }
    }
}