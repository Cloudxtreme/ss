﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class SvrGroupModels
    {
        public int id { get; set; }

        public string name { get; set; }

        public string serverip { get; set; }

        public string dbname{ get; set; }

        public string username { get; set; }

        public string password { get; set; }

        public string desc { get; set; }
    }
}