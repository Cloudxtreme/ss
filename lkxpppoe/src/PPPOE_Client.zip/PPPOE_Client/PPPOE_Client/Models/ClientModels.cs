﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class ClientModels
    {
        public int id { get; set; }

        public string user { get; set; }

        public string pwd { get; set; }

        public string realname { get; set; }

        public string group { get; set; }  //所属区域

        public string agent { get; set; }  //所属代理

        public string radius { get; set; }  //所属PPOE单元

        public string inpoint { get; set; }  //所属区域

        public string meal { get; set; }  //绑定套餐
         
        public string address { get; set; }

        public string phoneNum { get; set; }

        public string cardType { get; set; }

        public string codeNum { get; set; }

        public string email { get; set; }

        public string qq { get; set; }

        public string gfqPort { get; set; }

        public string Mac { get; set; }

        public string desc { get; set; }

        public string addtime { get; set; }

        public string statu { get; set; }
    }

    public class ClientRoleModels
    {
        public int id { get; set; }

        public int cId { get; set; }

        public string type { get; set; }

        public string value { get; set; }
    }

    public class ClientExcelModels
    {
        public string 用户名 { get; set; }

        public string 真实名字 { get; set; }

        public string 所在区域 { get; set; }  //所属区域

        public string 所属代理 { get; set; }  //所属代理

        public string 联系地址 { get; set; }

        public string 联系电话 { get; set; }

        public string 证件号码 { get; set; }

        public string 电子邮箱 { get; set; }

        public string 常用QQ { get; set; }

        public string 备注信息 { get; set; }

        public string 添加时间 { get; set; }
    }
}