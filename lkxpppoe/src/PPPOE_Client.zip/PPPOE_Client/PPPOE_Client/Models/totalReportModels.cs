﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class totalReportModels
    {
        public decimal FristMoney { get; set; }

        public decimal UseMoney { get; set; }

        public decimal ModelMoney { get; set; }

        public decimal ChangeMoney { get; set; }

        public decimal MobilMoney { get; set; }

        public decimal DlMoney { get; set; }

        public decimal OtherMoney { get; set; }

        public decimal TotalMoney { get; set; }
    }
}