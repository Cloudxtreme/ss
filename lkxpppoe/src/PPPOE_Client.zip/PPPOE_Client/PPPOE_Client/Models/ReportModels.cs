﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class ReportModels
    {
        public int id { get; set; }

        public string user { get; set; }

       // public string realname { get; set; }

        public string group { get; set; }  //所属区域

        public string Recdate { get; set; }

        public string FristMoney { get; set; }

        public string UseMoney { get; set; }

        public string ModelMoney { get; set; }

        public string ChangeMoney { get; set; }

        public string MobilMoney { get; set; }

        public string DLMoney { get; set; }

        public string OtherMoney { get; set; }

    }
}