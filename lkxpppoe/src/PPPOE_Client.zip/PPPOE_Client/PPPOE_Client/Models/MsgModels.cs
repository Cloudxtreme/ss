﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class MsgModels
    {
        public int id { get; set; }

        public string msg { get; set; }
    }
}