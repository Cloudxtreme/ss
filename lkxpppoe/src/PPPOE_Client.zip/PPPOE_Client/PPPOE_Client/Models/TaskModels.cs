﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class TaskModels
    {
        public int id { get; set; }  //编号

        public string name { get; set; }  //用户名

        public string type { get; set; }  //任务类型

        public string statu { get; set; }  //当前状态

        public string error { get; set; }  //执行失败则为对应的原因或者相关信息
    }
}