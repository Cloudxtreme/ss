﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class OpratelogModels
    {
        public int id { get; set; }

        public string optman { get; set; } //操作人

        public string optmanlevel { get; set; } //操作人身份级别

        public string optobject { get; set; }  //操作对象

        public string opttype { get; set; } //操作类型\

        public string optobjtype { get; set; } //操作对象类型

        public string opttime { get; set; } //操作时间
    }
}