﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class ClientSysInfoModels
    {
        public string action { get; set; } //执行操作

        public DateTime time { get; set; } //操作时间

        public string explore { get; set; }   //浏览器名称、版本号

        public string platform { get; set; }   //操作系统

        public string cookieEnable { get; set; }   //是否启用cookie

        public string userAgent { get; set; }   //用户代理

        public string javaEnable { get; set; }   //是否启用Java

        public string color { get; set; }   //浏览器颜色

        public string href { get; set; }  //当前位置

        public string screen { get; set; } //屏幕大小

        public string coordinate { get; set; } //鼠标位置
    }
}