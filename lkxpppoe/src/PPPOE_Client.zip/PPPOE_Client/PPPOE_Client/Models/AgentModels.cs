﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class AgentModels
    {
        public int id { get; set; }

        public string user { get; set; }

        public string radius { get; set; }

        public string pwd { get; set; }

        public string realname { get; set; }

        public string address { get; set; }

        public string phoneNum { get; set; }

        public string codeNum { get; set; }

        public string email { get; set; }

        public string qq { get; set; }

        public string desc { get; set; }

        public string addtime { get; set; }

        public string statu { get; set; }

    }
}