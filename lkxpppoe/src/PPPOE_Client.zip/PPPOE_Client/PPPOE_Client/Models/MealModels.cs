﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPOE_Client.Models
{
    public class MealModels
    {
        public int id { get; set; }

        public string name { get; set; }

        public int roleSpeed { get; set; }

        public int roleTraffic { get; set; }

        public int roleTime { get; set; }

        public int roleDate { get; set; }

        public string limitSpeed { get; set; }

        public string limitTraffic { get; set; }

        public string limitTime { get; set; }

        public int limitMonth { get; set; }

        public int addMonth { get; set; }

        public string price { get; set; }

        public string content { get; set; }

        public string desc { get; set; }

        public string statu { get; set; }
    }
}