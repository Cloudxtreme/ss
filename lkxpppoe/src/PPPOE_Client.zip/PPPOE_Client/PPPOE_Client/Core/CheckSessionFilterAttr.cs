﻿using System;
using System.Web;
using System.Web.Routing;
using System.Web.Mvc;

namespace PPPOE_Client.Core
{
    public class CheckSessionFilterAttr : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpContext httpcontext = HttpContext.Current;
            if (httpcontext.Session != null)
            {
                if (httpcontext.Session.IsNewSession)
                {
                    Logon(filterContext);
                }
                else
                {
                    try
                    {
                        String session = httpcontext.Session["name"].ToString();
                        if (string.IsNullOrEmpty(session))
                        {
                            Logon(filterContext);
                        }
                    }
                    catch
                    {
                        Logon(filterContext);
                    }
                }
            }
            base.OnActionExecuting(filterContext);
        }
        private void Logon(ActionExecutingContext filterContext)
        {
            RouteValueDictionary dictionary = new RouteValueDictionary
                (new
                {
                    controller = "Home",
                    action = "LogTimeOut",
                    returnUrl = filterContext.HttpContext.Request.RawUrl
                });
            filterContext.Result = new RedirectToRouteResult(dictionary);
        }
    }
}