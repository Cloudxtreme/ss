﻿using System;
using System.Configuration;

namespace PPPOE_Client.Core
{
    public class MySqlConn
    {
        private static string _MYSQL_SERVER = String.Empty;

        /// <summary>
        /// pppCenter数据库连接串
        /// </summary>
        public static string MYSQL_SERVER
        {
            get
            {
                if (String.IsNullOrEmpty(_MYSQL_SERVER))
                {
                    if (ConfigurationManager.ConnectionStrings["conn_center"] == null)
                    {
                        throw new Exception("the config node 'conn_center' is required in web.config");
                    }

                    lock (_MYSQL_SERVER)
                    {
                        _MYSQL_SERVER = ConfigurationManager.ConnectionStrings["conn_center"].ConnectionString;
                    }
                }
                return _MYSQL_SERVER;
            }
        }

    }
}