﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using PPPOE_Client.Models;
using PPPOE_Client.ModelsController;
using PPPOE_Client.Core;
using System.Data;
using MySql.Data.MySqlClient;
using System.Web;
using System.Web.UI;

namespace PPPOE_Client.Controllers
{
    public class ClientController : Controller
    {
        //
        // GET: /Client/
        [CheckSessionFilterAttr]
        public ActionResult Index()
        {
            return View();
        }

        [CheckSessionFilterAttr]
        public ActionResult ClientList(int groupId = 0, int agentId = 0, int page = 1,string ser="")
        {
            List<ClientModels> model = GetClientInfo.GetClientList(groupId, agentId, page,ser);
            List<GroupModels> group = GetGroupInfo.GetGroupList(0); //0为获取全部列表
            List<InPointModels> inpoint = GetInPointInfo.GetInPointList(0); //0为获取全部列表
            List<AgentModels> agent = GetAgentInfo.GetAgentList(0);
            List<MealModels> meal = GetMealInfo.GetMealList();
            ViewBag.totalNum = GetClientInfo.GetClientTotalNum(groupId, agentId,ser);
            ViewData["AgentList"] = agent;
            ViewData["GroupList"] = group;
            ViewData["InpointList"] = inpoint;
            ViewData["MealList"] = meal;
            if (agent != null && agent.Count > 0)
            {
                List<SvrGroupModels> svrgroup = GetSvrGroup.GetSvrGroupByAgent(agent[0].id);
                ViewData["SvrGroup"] = svrgroup;
            }
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult FalseClient(int groupId = 0, int agentId = 0, int page = 1)
        {
            List<ClientModels> model = GetClientInfo.GetTimeoutClientList(groupId, agentId, page);
            List<GroupModels> group = GetGroupInfo.GetGroupList(0); //0为获取全部列表
            List<AgentModels> agent = GetAgentInfo.GetAgentList(0);
            List<MealModels> meal = GetMealInfo.GetMealList();
            ViewBag.totalNum = GetClientInfo.GetTimeoutTotalNum(groupId, agentId);
            ViewData["AgentList"] = agent;
            ViewData["GroupList"] = group;
            ViewData["MealList"] = meal;
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult WillClient(int groupId = 0, int agentId = 0, int page = 1)
        {
            List<ClientModels> model = GetClientInfo.GetWillTimeoutClientList(groupId, agentId, page);
            List<GroupModels> group = GetGroupInfo.GetGroupList(0); //0为获取全部列表
            List<AgentModels> agent = GetAgentInfo.GetAgentList(0);
            List<MealModels> meal = GetMealInfo.GetMealList();
            ViewBag.totalNum = GetClientInfo.GetTimeoutTotalNum(groupId, agentId);
            ViewData["AgentList"] = agent;
            ViewData["GroupList"] = group;
            ViewData["MealList"] = meal;
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult ForbidClient(int groupId = 0, int agentId = 0, int page = 1)
        {
            List<ClientModels> model = GetClientInfo.GetForbidClientList(groupId, agentId, page);
            List<GroupModels> group = GetGroupInfo.GetGroupList(0); //0为获取全部列表
            List<AgentModels> agent = GetAgentInfo.GetAgentList(0);
            List<MealModels> meal = GetMealInfo.GetMealList();
            ViewBag.totalNum = GetClientInfo.GetForbidTotalNum(groupId, agentId);
            ViewData["AgentList"] = agent;
            ViewData["GroupList"] = group;
            ViewData["MealList"] = meal;
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult OnlineList(int groupId = 0, int agentId = 0, int page = 1,string ser="")
        {
            List<ClientModels> model = GetClientInfo.GetOnlineList(groupId, agentId, page,ser);
            List<GroupModels> group = GetGroupInfo.GetGroupList(0); //0为获取全部列表
            List<AgentModels> agent = GetAgentInfo.GetAgentList(0);
            List<MealModels> meal = GetMealInfo.GetMealList();
            ViewBag.totalNum = GetClientInfo.GetOnlineTotalNum(groupId, agentId,ser);
            ViewData["AgentList"] = agent;
            ViewData["GroupList"] = group;
            ViewData["MealList"] = meal;
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult GroupList(int page = 1)
        {
            List<GroupModels> model = GetGroupInfo.GetGroupList(page);
            ViewBag.totalNum = 0;
            if (model != null)
            {
                ViewBag.totalNum = model.Count;
            }
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult InPoint(int page = 1)
        {
            List<InPointModels> model = GetInPointInfo.GetInPointList(page);
            ViewBag.totalNum = 0;
            if (model != null)
            {
                ViewBag.totalNum = model.Count;
            }
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult AgentList(int page = 1)
        {
            List<AgentModels> model = GetAgentInfo.GetAgentList(page);
            ViewBag.totalNum = GetAgentInfo.GetAgentTotalNum();
            List<SvrGroupModels> svrgroup = GetSvrGroup.GetSvrGroupList();
            ViewData["SvrGroup"] = svrgroup;
            return View(model);
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //断开在线用户
        public ActionResult KillConn(string user, string radius)
        {
            OpratelogModels logModel = new OpratelogModels();
            MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);

            string sql_update = "update `client` set `statu`='kill' where `user`='" + user + "' and `radiusId`='" + radius + "'";
            conn.Open();
            MySqlCommand cmd_update = new MySqlCommand(sql_update, conn);
            cmd_update.ExecuteNonQuery();
            cmd_update.Dispose();
            conn.Close();

            System.Net.WebClient clinet = new System.Net.WebClient();
            string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_kil&opt=put&data={\"username\":\"" + user + "\",\"password\": \"\",\"radiusid\":\"" + radius + "\",\"mealid\":\"\"}";
            System.IO.Stream stream = clinet.OpenRead(url);
            System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
            string result = reader.ReadToEnd();
            clinet.Dispose();
            MsgModels msg = new MsgModels();
            if (!string.IsNullOrEmpty(result))
            {
                if (result == "HTTPSQS_PUT_OK")
                {
                    msg.id = 3;
                    msg.msg = "操作成功，请稍后...";

                    logModel.opttype = "断开";
                    logModel.optobjtype = "账号状态";
                    logModel.opttime = DateTime.Now.ToString();
                    if (HttpContext.Session["name"].ToString() != null)
                    {
                        logModel.optman = HttpContext.Session["name"].ToString();
                        logModel.optobject = HttpContext.Session["name"].ToString() + "断开了账号：" + user + "在线状态";
                    }
                    GetOprateLog.AddOneOpratelog(logModel);

                    return Json(msg);
                }
            }

            string newsql = "update `client` set `statu`='true' where `user`='" + user + "' and `radiusId`='" + radius + "'";
            conn.Open();
            MySqlCommand newupdate = new MySqlCommand(sql_update, conn);
            newupdate.ExecuteNonQuery();
            newupdate.Dispose();
            conn.Close();

            logModel.opttype = "断开";
            logModel.optobjtype = "账号状态";
            logModel.opttime = DateTime.Now.ToString();
            if (HttpContext.Session["name"].ToString() != null)
            {
                logModel.optman = HttpContext.Session["name"].ToString();
                logModel.optobject = HttpContext.Session["name"].ToString() + "尝试断开账号：" + user + "状态失败";
            }
            GetOprateLog.AddOneOpratelog(logModel);

            msg.id = 1;
            msg.msg = "断开失败，请稍后再试！";
            return Json(msg);
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //绑定代理的radius
        public ActionResult SetAgentSvr(string aId, string idStr)
        {
            try
            {
                MsgModels msg = new MsgModels();
                msg.id = 3;
                msg.msg = GetSvrGroup.BindAgentSvr(aId, idStr);
                return Json(msg);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //获取代理的radius绑定
        public ActionResult GetAgentSvr(int aId)
        {
            List<SvrGroupModels> svrgroup = GetSvrGroup.GetSvrGroupByAgent(aId);
            MsgModels msg = new MsgModels();
            if (svrgroup != null && svrgroup.Count > 0)
            {
                msg.id = 3;
                for (int i = 0; i < svrgroup.Count; i++)
                {
                    msg.msg += svrgroup[i].id + ",";
                }
                msg.msg = msg.msg.Substring(0, msg.msg.Length - 1);
                return Json(msg);
            }
            msg.id = 1;
            msg.msg = "该代理下还没有绑定服务器单元！";
            return Json(msg);
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //绑定代理的radius
        public ActionResult GetSvrgroupByAgent(int aId)
        {
            List<SvrGroupModels> svrgroup = GetSvrGroup.GetSvrGroupByAgent(aId);
            MsgModels msg = new MsgModels();
            if (svrgroup != null && svrgroup.Count > 0)
            {
                msg.id = 3;
                for (int i = 0; i < svrgroup.Count; i++)
                {
                    msg.msg = "<option value='" + svrgroup[i].id + "'>" + svrgroup[i].name + "</option>";
                }
                return Json(msg);
            }
            msg.id = 1;
            msg.msg = "没有获取到该代理下的服务器组信息！";
            return Json(msg);
        }

        [HttpPost]  //绑定用户套餐
        public ActionResult BindClientMeal(int cId, int mId, string start,string recDate ,string desc,string price,string frist,string model,string dl,string other,string addMonth)
        {
            try
            {
                MsgModels msg = new MsgModels();
                msg.id = 3;
                msg.msg = GetClientInfo.BindClientMeal(cId, mId, start,recDate, desc,price,frist,model,dl,other,addMonth);
                return Json(msg);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        public ActionResult addReport(string user, string recDate, string desc, string price, string frist, string model, string dl, string other)
        {
            try
            {
                MsgModels msg = new MsgModels();
                int userid = GetClientInfo.GetUserID(user);

                if (userid == 0)
                {
                    msg.id = 2;
                    msg.msg = "用户名不存在";
                    return Json(msg);
                }

                
                msg.id = 3;
                msg.msg = GetClientInfo.addReport(user,userid, recDate, desc, price, frist, model, dl, other);
                return Json(msg);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //获取用户套餐信息
        public ActionResult GetClientMeal(string id)
        { 
            try
            {
                int idStr = 0;
                int.TryParse(id.Trim(),out idStr);
                MsgModels msg = new MsgModels();
                if (idStr > 0)
                {
                    msg.id = 3;
                    string meal = GetClientInfo.GetClientMeal(idStr);
                    if (!String.IsNullOrEmpty(meal))
                    {
                        msg.msg = meal;
                        return Json(msg);
                    }
                    msg.msg = "暂无绑定";
                    return Json(msg);
                }
                msg.id = 1;
                msg.msg = "查询条件为空";
                return Json(msg);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpGet]  //导出过期用户
        public ActionResult FalseClientExcel(int groupId = 0, int agentId = 0)
        {
            List<ClientExcelModels> model = GetClientInfo.GetFalseClientExcel(groupId, agentId);
            if (model != null && model.Count > 0)
            {
                return new ExcelResult<ClientExcelModels>(model);
            }
            else
            {
                return RedirectToAction("FalseClient", "Client", new { result = "empty" });
            }
        }

        [CheckSessionFilterAttr]
        [HttpGet]  //导出在线用户
        public ActionResult OnlineExcel(int groupId = 0, int agentId = 0)
        {
            List<ClientExcelModels> model = GetClientInfo.GetOnlineExcel(groupId, agentId);
            if (model != null && model.Count > 0)
            {
                return new ExcelResult<ClientExcelModels>(model);
            }
            else
            {
                return RedirectToAction("OnlineList", "Client", new { result = "empty" });
            }
        }

        [CheckSessionFilterAttr]
        [HttpGet]  //导出用户
        public ActionResult ClientExcel(int groupId = 0, int agentId = 0)
        {
            List<ClientExcelModels> model = GetClientInfo.GetExcelList(groupId, agentId);
            if (model != null && model.Count > 0)
            {
                return new ExcelResult<ClientExcelModels>(model);
            }
            else
            {
                return RedirectToAction("ClientList", "Client", new { result = "empty" });
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //删除用户
        public ActionResult DeleClient(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetClientInfo.DeleClient(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    { 
                        ret.id = 3;
                        ret.msg = "删除成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功删除" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //禁用用户
        public ActionResult StopClient(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetClientInfo.StopClient(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    {
                        ret.id = 3;
                        ret.msg = "禁用成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功禁用" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //启用用户
        public ActionResult ReupClient(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetClientInfo.ReupClient(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    {
                        ret.id = 3;
                        ret.msg = "启用成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功启用" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        public ActionResult ClientReset(string userid,string user, string radiusid)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(MySqlConn.MYSQL_SERVER);
                MsgModels ret = new MsgModels();

                string sql = "update `client` set `statu`='reset',`httpInfo`='' where id='" + userid + "'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                cmd.Dispose();

                sql = "select * from `client` where id='" + userid + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(conn, sql);
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    System.Net.WebClient clinet = new System.Net.WebClient();
                    // string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_res&opt=put&data={\"username\":\"" + user + "\",\"radiusid\":\"" + radiusid + "\"}";
                    string url = "http://mid.pppoe.rightgo.net:12001?name=pppoe_mgr_user_res&opt=put&data={\"username\":\"" + user + "\",\"password\":\"\",\"radiusid\":\"" + radiusid + "\",\"mealid\":\"\"}";
                    System.IO.Stream stream = clinet.OpenRead(url);
                    System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
                    string result = reader.ReadToEnd();
                    clinet.Dispose();

                    if (!string.IsNullOrEmpty(result))
                    {
                        ret.id = 1;
                        ret.msg = "重置成功！";
                    }

                    OpratelogModels logModel = new OpratelogModels();

                    logModel.opttype = "修改";
                    logModel.optobjtype = "客户资料";
                    logModel.opttime = DateTime.Now.ToString();
                    if (Session["name"].ToString() != null)
                    {
                        logModel.optman = Session["name"].ToString();
                        logModel.optobject = HttpContext.Session["name"].ToString() + "重置了账号：" + Ds.Tables[0].Rows[0]["user"].ToString();
                    }
                    GetOprateLog.AddOneOpratelog(logModel);
                    conn.Close();

                }

                return Json(ret);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //修改用户密码
        public ActionResult ChgClientPwd(string id, string newpwd)
        {
            MsgModels msg = new MsgModels();
            try
            {
                string sql = "select * from `client` where `id`='" + id + "' ";//and `pwd` = '" + oldpwd + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                msg.id = 3;
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    int rslt = GetClientInfo.ChangePwd(int.Parse(id), newpwd);
                    if(rslt == 1)
                    {
                        msg.msg = "修改成功！";
                        return Json(msg);
                    }
                }
                msg.msg = "原始密码错误！";
                return Json(msg);
            }
            catch
            {
                msg.id = 2;
                msg.msg = "修改报错！";
                return Json(msg);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //修改用户密码
        public ActionResult ChgAgentPwd(string id, string newpwd)
        {
            MsgModels msg = new MsgModels();
            try
            {
                string sql = "select `id` from `agentInfo` where `id`='" + id + "'";
                DataSet Ds = MySql.Data.MySqlClient.MySqlHelper.ExecuteDataset(MySqlConn.MYSQL_SERVER, sql);
                msg.id = 3;
                if (Ds.Tables[0].Rows.Count > 0)
                {
                    int rslt = GetAgentInfo.ChangePwd(int.Parse(id), newpwd);
                    if (rslt == 1)
                    {
                        msg.msg = "修改成功！";
                        return Json(msg);
                    }
                }
                msg.msg = "原始密码错误！";
                return Json(msg);
            }
            catch
            {
                msg.id = 2;
                msg.msg = "修改报错！";
                return Json(msg);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑用户
        public ActionResult EditClient(ClientModels client)
        {
            try
            {
                ClientModels item = new ClientModels();
                if (ModelState.IsValid)
                {
                    item = GetClientInfo.EditOneClient(client);
                    return Json(item);
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "修改失败！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加用户
        public ActionResult AddClient(ClientModels client)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (GetClientInfo.CheckUserName(client.user) == 0)
                    {
                        client.id = GetClientInfo.AddOneClient(client);
                        return Json(client);
                    }
                    MsgModels msg = new MsgModels();
                    msg.id = 2;
                    msg.msg = "该用户已经存在！";
                    return Json(msg);
                }
                return null;
            }
            catch(Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加用户
        public ActionResult mulAddClient(int user1, int user2, string pwd, string group, string agent, string radius,string mealid)
        {
            try
            {
                //int count = Convert.ToInt32(user2) - Convert.ToInt32(user1);
                int count = user2 - user1;
                if (count > 0&&count<=100)
                {
                    ClientModels client = new ClientModels();
                    client.pwd = pwd;
                    client.group = group;
                    client.agent = agent;
                    client.radius = radius;
                    client.meal = mealid;
                    for (int i = 0; i <= count; i++)
                    {
                        client.user = "GQ" + (user1 + i).ToString();
                        if (GetClientInfo.CheckUserName(client.user) == 0)
                        {
                            client.id = GetClientInfo.AddOneClient(client);
                            //return Json(client);
                        }
                        else
                        {
                            MsgModels msg = new MsgModels();
                            msg.id = 2;
                            msg.msg = "该用户已经存在！";
                            return Json(msg);
                        }

                    }
                    return Json(client);
                }
                if (count > 100)
                {
                    MsgModels msg = new MsgModels();
                    msg.id = 2;
                    msg.msg = "一次最多只能添加100个用户！";
                    return Json(msg);
                }
               

                //if (ModelState.IsValid)
                //{
                //    if (GetClientInfo.CheckUserName(client.user) == 0)
                //    {
                //        client.id = GetClientInfo.AddOneClient(client);
                //        return Json(client);
                //    }
                    
                //}
                return null;
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //删除代理
        public ActionResult DeleAgent(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetAgentInfo.DeleAgent(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    {
                        ret.id = 3;
                        ret.msg = "删除成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功删除" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑代理
        public ActionResult EditAgent(AgentModels model)
        {
            try
            {
                AgentModels item = new AgentModels();
                if (ModelState.IsValid)
                {
                    item = GetAgentInfo.EditOneAgent(model);
                    return Json(item);
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "修改失败！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [HttpPost]  //添加代理
        public ActionResult AddAgent(AgentModels model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.id = GetAgentInfo.AddOneAgent(model);
                }
                return Json(model);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //删除用户
        public ActionResult DeleGroup(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetGroupInfo.DeleGroup(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    {
                        ret.id = 3;
                        ret.msg = "删除成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功删除" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //删除用户
        public ActionResult DeleInPoint(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetInPointInfo.DeleInPoint(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    {
                        ret.id = 3;
                        ret.msg = "删除成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功删除" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑区域
        public ActionResult EditGroup(GroupModels model)
        {
            try
            {
                GroupModels item = new GroupModels();
                if (ModelState.IsValid)
                {
                    item = GetGroupInfo.EditOneGroup(model);
                }
                return Json(item);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑区域
        public ActionResult EditInPoint(InPointModels model)
        {
            try
            {
                InPointModels item = new InPointModels();
                if (ModelState.IsValid)
                {
                    item = GetInPointInfo.EditOneInPoint(model);
                }
                return Json(item);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加区域
        public ActionResult AddGroup(GroupModels model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.id = GetGroupInfo.AddOneGroup(model);
                }
                return Json(model);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加区域
        public ActionResult AddInPoint(InPointModels model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.id = GetInPointInfo.AddOneInPoint(model);
                }
                return Json(model);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        public ActionResult ClientInfo(string id)
        {
            int idStr = 0;
            int.TryParse(id.Trim(), out idStr);
            ClientModels model = GetClientInfo.GetClient(idStr);
            List<GroupModels> group = GetGroupInfo.GetGroupList(0); //0为获取全部列表
            List<AgentModels> agent = GetAgentInfo.GetAgentList(0);
            List<MealModels> meal = GetMealInfo.GetMealList();
            List<InPointModels> inpoint = GetInPointInfo.GetInPointList(0); //0为获取全部列表
            //ViewBag.totalNum = GetClientInfo.GetClientTotalNum(groupId, agentId);
            string strMeal = GetClientInfo.GetClientMeal(idStr);
         //   MvcHtmlString strMeal = (MvcHtmlString)GetClientInfo.GetClientMeal(idStr);
            ViewData["id"] = idStr;
            ViewData["strMeal"] = strMeal;
            ViewData["AgentList"] = agent;
            ViewData["GroupList"] = group;
            ViewData["MealList"] = meal;
            ViewData["InpointList"] = inpoint;
            if (agent != null && agent.Count > 0)
            {
                List<SvrGroupModels> svrgroup = GetSvrGroup.GetSvrGroupByAgent(agent[0].id);
                ViewData["SvrGroup"] = svrgroup;
            }
            
            //判断账号状态
            System.Net.WebClient clinet = new System.Net.WebClient();
            string url = "http://mid.pppoe.rightgo.net/pppoe/pppoe.php?action=usercheck&username=" + model.user;
            System.IO.Stream stream = clinet.OpenRead(url);
            System.IO.StreamReader reader = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("UTF-8"));
            string result = reader.ReadToEnd();
            clinet.Dispose();
            string status = "";

            if (!string.IsNullOrEmpty(result))
            {
                switch (result)
                {
                    case "OK":
                        status = "正常使用中";
                        break;
                    case "ARGUMENT_ERROR":
                        status = "参数错误;请联系管理员处理";
                        break;
                    case "RADIUS_NOT_EXIST":
                        status = "用户所在单位不存在（没有这个radius）";
                        break;
                    case "USER_NOT_EXIST":
                        status = "用户在radius数据库不存在";
                        break;
                    case "USER_FORBIDDEN":
                        status = "用户被禁用了（删除）";
                        break;
                    case "USER_USEUP":
                        status = "用户未开通或套餐已用完";
                        break;
                    case "USER_EXCEED":
                        status = "用户时间、流量统计超出限制值";
                        break;
                    default:
                        break;
                }
            }
            ViewData["status"] = status;

            return View(model);

           // return View();
        }


      


        //public ActionResult Report(DateTime begin, DateTime end,int groupId=0, int page = 1)
        public ActionResult Report(string begin = "", string end = "", int groupId = 0, int page = 1)
        {
            // List<ClientModels> model = GetClientInfo.GetClient(idStr);
            DateTime dtBegin;
            DateTime dtEnd;
            if (begin.Trim().Length <= 0 || end.Trim().Length <= 0)
            {
                dtBegin = DateTime.Now.AddDays(-1);
                dtEnd = DateTime.Now.AddDays(1);
            }
            else
            {
                //dtBegin = Convert.ToDateTime(begin).ToUniversalTime().AddDays(-1);
                //dtEnd = Convert.ToDateTime(end).AddDays(1);

                dtBegin = Convert.ToDateTime(begin);
                dtEnd = Convert.ToDateTime(end).AddDays(1);
            }

            List<ReportModels> model = GetClientInfo.GetReport(groupId, dtBegin, dtEnd, page);

            decimal fristMoney = 0;
            decimal useMoney = 0;
            decimal modelMoney = 0;
            decimal changeMoney = 0;
            decimal mobilMoney = 0;
            decimal dlMoney = 0;
            decimal otherMoney = 0;
            decimal totalMoney = 0;

            decimal ufristMoney = 0;
            decimal uuseMoney = 0;
            decimal umodelMoney = 0;
            decimal uchangeMoney = 0;
            decimal umobilMoney = 0;
            decimal udlMoney = 0;
            decimal uotherMoney = 0;

            if (model != null)
            {
                foreach (ReportModels rm in model)
                {
                    if (decimal.TryParse(rm.FristMoney, out ufristMoney))
                    {
                        fristMoney += Convert.ToDecimal(rm.FristMoney);
                    }
                    if (decimal.TryParse(rm.UseMoney, out uuseMoney))
                    {
                        useMoney += Convert.ToDecimal(rm.UseMoney);
                    }
                    if (decimal.TryParse(rm.ModelMoney, out umodelMoney))
                    {
                        modelMoney += Convert.ToDecimal(rm.ModelMoney);
                    }
                    if (decimal.TryParse(rm.ChangeMoney, out uchangeMoney))
                    {
                        changeMoney += Convert.ToDecimal(rm.ChangeMoney);
                    }
                    if (decimal.TryParse(rm.MobilMoney, out umobilMoney))
                    {
                        mobilMoney += Convert.ToDecimal(rm.MobilMoney);
                    }
                    if (decimal.TryParse(rm.DLMoney, out udlMoney))
                    {
                        dlMoney += Convert.ToDecimal(rm.DLMoney);
                    }
                    if (decimal.TryParse(rm.OtherMoney, out uotherMoney))
                    {
                        otherMoney += Convert.ToDecimal(rm.OtherMoney);
                    }
                }

               // totalMoney = fristMoney + useMoney + mobilMoney + changeMoney + mobilMoney + otherMoney;
                totalMoney = fristMoney + useMoney + mobilMoney + changeMoney + otherMoney + modelMoney + dlMoney;
            }
            totalReportModels totalReportMod = new totalReportModels();
            totalReportMod.FristMoney = fristMoney;
            totalReportMod.UseMoney = useMoney;
            totalReportMod.ModelMoney = modelMoney;
            totalReportMod.ChangeMoney = changeMoney;
            totalReportMod.MobilMoney = mobilMoney;
            totalReportMod.DlMoney = dlMoney;
            totalReportMod.OtherMoney = otherMoney;
            totalReportMod.TotalMoney = totalMoney;
            ViewData["totalReportMod"] = totalReportMod;

            ViewBag.totalNum = 0;
            if (model != null)
            {
                ViewBag.totalNum = model.Count;
            }
            return View(model);
        }

    }
}
