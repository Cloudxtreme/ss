﻿using System.Web;
using System.Web.Mvc;
using PPPOE_Client.Core;
using System.Text.RegularExpressions;
using System.Text;
using MySql.Data.MySqlClient;
using System;

namespace PPPOE_Client.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Default/
        public ActionResult GetValidateCode()
        {
            ValidateCode vCode = new ValidateCode();
            string code = vCode.CreateValidateCode(5);
            Session["ValidateCode"] = code;
            byte[] bytes = vCode.CreateValidateGraphic(code);
            return File(bytes, @"image/jpeg");
        }

        public ActionResult Login()
        {
            if (HttpContext.Session["user"] != null)
            {
                HttpContext.Session["user"] = null;    //用户名
                HttpContext.Session["pwd"] = null;
                //Session["ValidateCode"] = null;
            }
            Cookie Cookie = new Cookie();
            ViewData["name"] = "";
            ViewData["pwd"] = "";
            string name = Cookie.getCookie("pppoeAdminName");//取值
            string pwd = Cookie.getCookie("pppoeAdminPwd");
            if (!string.IsNullOrEmpty(name))
            {
                ViewData["name"] = name;
            }
            if (!string.IsNullOrEmpty(pwd))
            {
                ViewData["pwd"] = pwd;
            }
            return View();
        }

        public ActionResult LogTimeOut()
        {
            return View();
        }

        //Ajax Mothed
        public string CheckLogin(string user, string pwd, string code, string type, string cookie)
        {
            try
            {
                string pat = @"[()|""'~`!@#$%^&*?/,.{}<>;:\\]";
                Regex r = new Regex(pat);
                if (r.IsMatch(user) | r.IsMatch(pwd) | r.IsMatch(code))
                {
                    //SQL注入
                    return "请不要尝试注入我们的系统，您的行为我们已经记录！";
                }
                else
                {
                    Cookie Cookie = new Cookie();
                    if (cookie.Trim() == "记住我")
                    {
                        Cookie.setCookie("pppoeAdminName", user, 1);
                        Cookie.setCookie("pppoeAdminPwd", pwd, 1);
                    }
                    else
                    {
                        Cookie.delCookie("pppoeAdminName");
                        Cookie.delCookie("pppoeAdminPwd");
                    }
                    StringBuilder strSql = new StringBuilder();
                    if (type == "管理员")
                    {
                        strSql.Append("SELECT Count(`name`),`name` FROM `adminInfo` where `name`='" + user.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower() + "' and `level`='1' and statu='true'");
                      //  strSql.Append("SELECT Count(`name`),`name` FROM `adminInfo` where `name`='" + user.Trim() + "'");
                    }
                    else
                    {
                        if (code != Session["ValidateCode"].ToString())
                        {
                            return "验证码输入错误！";
                        }
                        strSql.Append("SELECT Count(`name`),`name` FROM `adminInfo` where `user`='" + user.Trim() + "' and `pass`='" + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pwd.Trim(), "MD5").ToLower() + "' and status='true'");
                    }
                    MySqlDataReader sdr = MySql.Data.MySqlClient.MySqlHelper.ExecuteReader(Core.MySqlConn.MYSQL_SERVER, strSql.ToString());
                    if (sdr.Read())
                    {
                        if (int.Parse(sdr["Count(`name`)"].ToString()) == 1)
                        {
                            HttpContext.Session["name"] = sdr["name"].ToString();    //用户名
                            //HttpContext.Session["pwd"] = pwd.Trim().ToLower();
                            return "true";
                        }
                    }
                }
                return "验证失败！";
            }
            catch
            {

               // return e.ToString();
                return "验证报错！";
            }
        }

    }
}
