﻿using System.Collections.Generic;
using System.Web.Mvc;
using PPPOE_Client.Models;
using PPPOE_Client.ModelsController;
using System;
using PPPOE_Client.Core;

namespace PPPOE_Client.Controllers
{
    public class SysMgrController : Controller
    {
        //
        // GET: /SysMgr/
        [CheckSessionFilterAttr]
        public ActionResult Index()
        {
            return View();
        }

        [CheckSessionFilterAttr]
        public ActionResult AdminList()  //用户管理
        {
            List<AdminModels> model = GetAdminInfo.GetAdminList();
           // ViewData["LevelList"] = GetAdminInfo.GetLevelList();
            //去除超级管理员
            List<AdminModels> vdList = GetAdminInfo.GetLevelList();
            vdList.RemoveAt(0);
            ViewData["LevelList"] = vdList;

            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult PppoeList()  //PPOE单元管理
        {
            List<SvrGroupModels> model = GetSvrGroup.GetSvrGroupList();
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult MealList()  //套餐管理
        {
            List<MealModels> model = GetMealInfo.GetMealList();
            return View(model);
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑服务器单元
        public ActionResult EditSvrGroup(SvrGroupModels model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int i = GetSvrGroup.EditSvrGroup(model);
                    if (i == 1)
                    {
                        return Json(model);
                    }
                }
                MsgModels err = new MsgModels();
                err.id = 2;
                err.msg = "修改失败！";
                return Json(err);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加服务器单元
        public ActionResult AddSvrGroup(SvrGroupModels model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.id = GetSvrGroup.AddOneSvrGroup(model);
                    return Json(model);
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "添加对象无效！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //查看套餐限制信息
        public ActionResult GetMealRole(int id, int roleSpeed, int roleTraffic, int roleTime)
        {
            try
            {
                MsgModels msg = new MsgModels();
                string result = GetMealInfo.GetMealRole(id, roleSpeed, roleTraffic, roleTime);
                if (!String.IsNullOrEmpty(result))
                {
                    msg.id = 3;
                    msg.msg = result;
                }
                else
                {
                    msg.id = 2;
                    msg.msg = "暂无限制信息！";
                }
                return Json(msg);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //删除套餐
        public ActionResult DeleMeal(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetMealInfo.DeleMeal(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    {
                        ret.id = 3;
                        ret.msg = "删除成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功删除" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑套餐
        public ActionResult EditMeal(MealModels model)
        {
            try
            {
                MealModels item = new MealModels();
                if (ModelState.IsValid)
                {
                    item = GetMealInfo.EditOneMeal(model);
                    return Json(item);
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "修改失败！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加套餐
        public ActionResult AddMeal(MealModels model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    MealModels item = GetMealInfo.AddOneMeal(model);
                    if (item != null)
                    {
                        return Json(item);
                    }
                }
                MsgModels err = new MsgModels();
                err.id = 2;
                err.msg = "添加失败！";
                return Json(err);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //删除用户
        public ActionResult DeleAdmin(string id)
        {
            try
            {
                string idStr = id.Trim();
                if (!String.IsNullOrEmpty(idStr))
                {
                    string[] idArr = idStr.Split(',');
                    int count = idArr.Length;
                    int result = GetAdminInfo.DeleAdmin(idArr);
                    MsgModels ret = new MsgModels();
                    if (result == idArr.Length)
                    { 
                        ret.id = 3;
                        ret.msg = "删除成功！";
                        return Json(ret);
                    }
                    else
                    {
                        ret.id = 4;
                        ret.msg = "总共" + count + "条,成功删除" + result + "条记录！";
                        return Json(ret);
                    }
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "条件为空！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //编辑用户
        public ActionResult EditAdmin(AdminModels model)
        {
            try
            {
                AdminModels item = new AdminModels();
                if (ModelState.IsValid)
                {
                    item = GetAdminInfo.EditOneAdmin(model);
                    return Json(item);
                }
                else
                {
                    MsgModels err = new MsgModels();
                    err.id = 2;
                    err.msg = "修改失败！";
                    return Json(err);
                }
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

        [CheckSessionFilterAttr]
        [HttpPost]  //添加用户
        public ActionResult AddAdmin(AdminModels model)
        {
            try
            {
                AdminModels item = new AdminModels();
                if (ModelState.IsValid)
                {
                    item = GetAdminInfo.AddOneAdmin(model);
                }
                return Json(item);
            }
            catch (Exception ex)
            {
                MsgModels err = new MsgModels();
                err.id = 1;
                err.msg = ex.Message;
                return Json(err);
            }
        }

    }
}
