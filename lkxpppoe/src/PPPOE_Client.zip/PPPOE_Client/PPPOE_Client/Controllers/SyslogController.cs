﻿using System.Collections.Generic;
using System.Web.Mvc;
using PPPOE_Client.Models;
using PPPOE_Client.ModelsController;
using PPPOE_Client.Core;

namespace PPPOE_Client.Controllers
{
    public class SyslogController : Controller
    {
        //
        // GET: /Syslog/
        [CheckSessionFilterAttr]
        public ActionResult Index()
        {
            return View();
        }

        [CheckSessionFilterAttr]
        public ActionResult TaskList()
        {
            List<TaskModels> model = GetTaskInfo.GetTaskList();
            if (model != null)
            {
                ViewBag.totalNum = model.Count;
            }
            else
            {
                ViewBag.totalNum = 0;
            }
            return View(model);
        }

        [CheckSessionFilterAttr]
        public ActionResult GongdanList()
        {
            return View();
        }

        [CheckSessionFilterAttr]
        public ActionResult OprateList(int page = 1)
        {
            List<OpratelogModels> model = GetOprateLog.GetOpratelogList(page);
            if (model != null)
            {
                ViewBag.totalNum = GetOprateLog.GetOpratelogListCount();
            }
            else
            {
                ViewBag.totalNum = 0;
            }
            return View(model);
        }

    }
}
