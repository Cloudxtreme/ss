﻿var chart;
$(document).ready(function () {

    var colors = Highcharts.getOptions().colors,
		categories = ['内存', 'CPU', '硬盘', '带宽'],
		name = '已使用百分比',
		data = [55.11, 2.63, 35.94, 65.15];

    function setChart(name, categories, data, color) {
        chart.xAxis[0].setCategories(categories);
        chart.series[0].remove();
        chart.addSeries({
            name: name,
            data: data,
            color: colors
        });
    }

    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            type: 'column'
        },
        title: {
            text: '【丽日豪庭】服务器性能'
        },
        xAxis: {
            categories: categories
        },
        plotOptions: {
            column: {
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    color: colors[0],
                    style: {
                        fontWeight: 'bold'
                    },
                    formatter: function () {
                        return this.y + '%';
                    }
                }
            }
        },
        tooltip: {
            formatter: function () {
                var point = this.point,
					s = this.x + ':<b>' + this.y + '% 已使用</b><br/>';
                return s;
            }
        },
        series: [{
            name: name,
            data: data,
            color: colors
        }],
        exporting: {
            enabled: false
        }
    });
});