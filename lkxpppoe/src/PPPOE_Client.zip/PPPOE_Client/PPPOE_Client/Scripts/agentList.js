﻿$(function () {
    $('#agent-add').dialog({
        autoOpen: false,
        width: 380,
        height: 400,
        modal: true,
        buttons: {
            "保存": SubContent,
            "取消": function () {
                $(this).dialog("close");
                EditReset();
            }
        }
    });
    $('#agent-set-svr').dialog({
        autoOpen: false,
        width: 300,
        height: 250,
        modal: true,
        buttons: {
            "保存": SaveSvrgroup,
            "取消": function () {
                $(this).dialog("close");
            }
        }
    });
    $('#agent-pwd').dialog({
        autoOpen: false,
        width: 350,
        height: 210,
        modal: true,
        buttons: {
            "保存": ChgPwd,
            "取消": function () {
                $('#chg_id').val("");
                $('#chg_user').val("");
               // $('#old_pwd').val("");
                $('#new_pwd').val("");
                $('#new_pwd_confirm').val("");
                $(this).dialog("close");
            }
        }
    });
    //弹出添加用户对话框
    $('#btn_agent_add').click(function () {
        ShowAddForm();
    });
    $('#btn_agent_edit').click(function () {
        ShowEditForm();
    });
    $('#btn_agent_dele').click(function () {
        DeleAgent();
    });
});

//修改代理密码
function ShowChgPwd(evt) {
    $('#chg_id').val("");
    $('#chg_user').val("");
    $('#old_pwd').val("");
    $('#new_pwd').val("");
    $('#new_pwd_confirm').val("");
    var id = $.trim($(evt).parent().parent().children("td").get(1).innerHTML);
    var user = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
    if (id.length <= 0 || typeof id == "undefined") {
        ShowMsg("请至少选择一个代理！");
        return false;
    }
    $('#chg_id').val(id);
    $('#chg_user').val(user);
    $('#agent-pwd').dialog('open');
}

function ChgPwd() {
    var id = $('#chg_id').val();
    //var user = $('#chg_user').val();
   // var old_pwd = $('#old_pwd').val();
    var new_pwd = $('#new_pwd').val();
    var new_pwd_confirm = $('#new_pwd_confirm').val();
    if (id.length <= 0 || typeof id == "undefined" || new_pwd.length <= 0 || new_pwd_confirm.length <= 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    if (new_pwd != new_pwd_confirm) {
        ShowMsg("密码输入不一致！");
        return false;
    }
    $.ajax({
        url: '/Client/ChgAgentPwd',
        dataType: 'json',
        data: { id: id,  newpwd: new_pwd },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            ShowMsg(data.id + "." + data.msg);
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#agent-pwd').dialog('close');
}

//绑定代理的服务器单元
function SaveSvrgroup() {
    var idStr = "";
    var aId = $("#set_id").val();
    $("#svrgroup_tb tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            idStr += $(this).attr("id") + ",";
        }
    });
    if (aId.length <= 0) {
        ShowMsg("获取对象失败！");
        return false;
    }
    $.ajax({
        url: '/Client/SetAgentSvr',
        dataType: 'json',
        data: { aId: aId, idStr: idStr.substring(0, idStr.length - 1) },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            ShowMsg(data.id + "." + data.msg);
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function GetAgentSvr(evt) {
    var id = $.trim($(evt).parent().parent().children("td").get(1).innerHTML);
    var name = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
    if (id.length <= 0 || typeof id == "undefined") {
        ShowMsg("请至少选择一个代理！");
        return false;
    }
    $("#svrgroup_tb tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            $(this).attr("checked", false);
        }
    });
    $("#set_id").val(id);
    $("#set_user").html(name);
    $.ajax({
        url: '/Client/GetAgentSvr',
        dataType: 'json',
        data: { aId: id },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 3) {
                var arr = data.msg.split(',');
                for (i = 0; i < arr.length; i++) {
                    $("#" + arr[i]).attr("checked", true);
                }
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#agent-set-svr').dialog('open');
}

function DeleAgent() {
    var idArr = [];
    var nameArr = [];
    $("#agent_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            idArr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = idArr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要删除客户【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/Client/DeleAgent',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#agent_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function SubContent() {
    var type = $.trim($("#add_id").val());
    if (String(type).length == 0) {
        AddAgent();
    }
    else {
        EditAgent();
    }
}

function ShowEditForm() {
    var id, user, realname, phone, addr, code, email, qq, desc, groupId;
    var count = 0;
    EditReset();
    $("#agent_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            id = $.trim($(this).parent().parent().children("td").get(1).innerHTML);
            user = $.trim($(this).parent().parent().children("td").get(2).innerHTML);
            realname = $.trim($(this).parent().parent().children("td").get(3).innerHTML);
            phone = $.trim($(this).parent().parent().children("td").get(4).innerHTML);
            addr = $.trim($(this).parent().parent().children("td").get(5).innerHTML);
            code = $.trim($(this).parent().parent().children("td").get(6).innerHTML);
            email = $.trim($(this).parent().parent().children("td").get(7).innerHTML);
            qq = $.trim($(this).parent().parent().children("td").get(8).innerHTML);
            desc = $.trim($(this).parent().parent().children("td").get(9).innerHTML);
            count++;
        }
    });
    if (count > 1) {
        ShowMsg("一次只能编辑一个代理商");
        return false;
    }
    if (String(user).length == 0 || typeof user == "undefined") {  //或者这种形式if(obj === undefined)
        ShowMsg("请至少选择一个代理商！");
        return false;
    }
    $("#add_id").val(id);
    $("#add_user").val(user);
    $("#add_pwd").hide();
    $("#add_pwd_confirm").hide();
    $("#add_realname").val(realname);
    $("#add_addr").val(addr);
    $("#add_phone").val(phone);
    $("#add_codenum").val(code);
    $("#add_email").val(email);
    $("#add_qq").val(qq);
    $("#add_desc").val(desc);
    $('#agent-add').dialog('open');
    return false;
}

function EditAgent() {
    var edit_id, edit_user, edit_radius, edit_realname, edit_addr, edit_phone, edit_code, edit_email, edit_qq, edit_desc;
    edit_id = $("#add_id").val();
    edit_user = $("#add_user").val();
    //edit_radius = $("#add_radius").val();
    edit_realname = $("#add_realname").val();
    edit_addr = $("#add_addr").val();
    edit_phone = $("#add_phone").val();
    edit_code = $("#add_codenum").val();
    edit_email = $("#add_email").val();
    edit_qq = $("#add_qq").val();
    edit_desc = $("#add_desc").val();
    if (String(edit_user).length == 0 || String(edit_realname).length == 0 || String(edit_phone).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/EditAgent',
        dataType: 'json',
        data: { id: edit_id, user: edit_user, realname: edit_realname, address: edit_addr, phoneNum: edit_phone, codeNum: edit_code, email: edit_email, qq: edit_qq, desc: edit_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#agent_list tr").find(":checkbox").each(function (i) {
                    if ($.trim(String($(this).parent().parent().children("td").get(1).innerHTML)) == data.id) {
                        $(this).parent().parent().children("td").get(2).innerHTML = data.user;
                        $(this).parent().parent().children("td").get(3).innerHTML = data.realname;
                        $(this).parent().parent().children("td").get(4).innerHTML = data.phoneNum;
                        $(this).parent().parent().children("td").get(5).innerHTML = data.address;
                        $(this).parent().parent().children("td").get(6).innerHTML = data.codeNum;
                        $(this).parent().parent().children("td").get(7).innerHTML = data.email;
                        $(this).parent().parent().children("td").get(8).innerHTML = data.qq;
                        $(this).parent().parent().children("td").get(9).innerHTML = data.desc;
                    }
                });
            } catch (ex) {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#agent-add').dialog("close");
}

function ShowAddForm() {
    EditReset();
    $('#agent-add').dialog('open');
    return false;
}

function AddAgent() {
    var add_user = $("#add_user").val();
    //var add_radius = $("#add_radius").val();
    var add_pwd = $("#add_pwd").val();
    var add_pwd_confirm = $("#add_pwd_confirm").val();
    var add_realname = $("#add_realname").val();
    var add_address = $("#add_addr").val();
    var add_phoneNum = $("#add_phone").val();
    var add_codeNum = $("#add_codenum").val();
    var add_email = $("#add_email").val();
    var add_qq = $("#add_qq").val();
    var add_desc = $("#add_desc").val();
    if (add_pwd != add_pwd_confirm) {
        ShowMsg("密码输入不一致！");
        return false;
    }
    if (String(add_user).length == 0 || String(add_realname).length == 0 || String(add_phoneNum).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/AddAgent',
        dataType: 'json',
        data: { user: add_user, pwd: add_pwd, realname: add_realname, address: add_address, phoneNum: add_phoneNum, codeNum: add_codeNum, email: add_email, qq: add_qq, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#agentInfoTemp").render(data).appendTo("#agent_list");
            } catch (ex) {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#agent-add').dialog("close");
}

function checkAll(evt) {
    $("#agent_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked)
    });
}

function changePage() {
    var sel_page = $("#pageNum").val();
    window.location = "../Client/AgentList?page=" + sel_page;
}

//清空重置
function EditReset() {
    $("#add_user").val("");
    $("#add_realname").val("");
    $("#add_addr").val("");
    $("#add_phone").val("");
    $("#add_codenum").val("");
    $("#add_email").val("");
    $("#add_qq").val("");
    $("#add_desc").val("");
}