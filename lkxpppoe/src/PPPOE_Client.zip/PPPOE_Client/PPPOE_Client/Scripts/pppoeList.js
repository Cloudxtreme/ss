﻿$(function () {
    $('#svrgroup-add').dialog({
        autoOpen: false,
        width: 380,
        height: 300,
        modal: true,
        buttons: {
            "保存": SubContent,
            "取消": function () {
                $(this).dialog("close");
                EditReset();
            }
        }
    });
    //弹出添加用户对话框
    $('#btn_svrgroup_add').click(function () {
        ShowAddForm();
    });
    $('#btn_svrgroup_edit').click(function () {
        ShowEditForm();
    });
});

function SubContent() {
    var type = $.trim($("#add_id").val());
    if (String(type).length == 0) {
        AddSvrGroup();
    }
    else {
        EditSvrGroup();
    }
}

function EditSvrGroup() {
    var edit_id = $("#add_id").val();
    var edit_name = $("#add_name").val();
    var edit_ip = $("#add_ip").val();
    var edit_db = $("#add_dbname").val();
    var edit_user = $("#add_user").val();
    var edit_pwd = $("#add_pass").val();
    var add_desc = $("#add_desc").val();
    if (String(edit_name).length == 0 || String(edit_ip).length == 0 || String(edit_db).length == 0 || String(edit_user).length == 0 || String(edit_pwd).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/EditSvrGroup',
        dataType: 'json',
        data: { id: edit_id, name: edit_name, serverip: edit_ip, dbname: edit_db, username: edit_user, password: edit_pwd, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            //更新列表数据
            try {
                $("#pppoe_list tr").find(":checkbox").each(function (i) {
                    if ($.trim(String($(this).parent().parent().children("td").get(1).innerHTML)) == data.id) {
                        $(this).parent().parent().children("td").get(2).innerHTML = data.name;
                        $(this).parent().parent().children("td").get(3).innerHTML = data.serverip;
                        $(this).parent().parent().children("td").get(4).innerHTML = data.dbname;
                        $(this).parent().parent().children("td").get(5).innerHTML = data.username;
                        $(this).parent().parent().children("td").get(6).innerHTML = data.password;
                        $(this).parent().parent().children("td").get(7).innerHTML = String(data.desc);
                    }
                });
            } catch (ex) {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#svrgroup-add").dialog("close");
}

function AddSvrGroup() {
    var add_name = $("#add_name").val();
    var add_ip = $("#add_ip").val();
    var add_dbname = $("#add_dbname").val();
    var add_user = $("#add_user").val();
    var add_pass = $("#add_pass").val();
    var add_desc = $("#add_desc").val();
    if (add_name.length <= 0 || add_ip.length <= 0 || add_dbname.length <= 0 || add_user.length <= 0 || add_pass.length <= 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/AddSvrGroup',
        dataType: 'json',
        data: { name: add_name, serverip: add_ip, dbname: add_dbname, username: add_user, password: add_pass, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#svrgroupInfoTemp").render(data).appendTo("#pppoe_list");
            } catch (ex) {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#svrgroup-add').dialog('close');
}

//清空重置
function EditReset() {
    $("#add_id").val("");
    $("#add_name").val("");
    $("#add_ip").val("");
    $("#add_dbname").val("");
    $("#add_user").val("");
    $("#add_pass").val("");
    $("#add_desc").val("");
}

function ShowEditForm() {
    var id, name, serverip, dbname, dbuser, dbpwd, desc;
    var count = 0;
    EditReset();
    $("#pppoe_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            id = $.trim($(this).parent().parent().children("td").get(1).innerHTML);
            name = $.trim($(this).parent().parent().children("td").get(2).innerHTML);
            serverip = $.trim($(this).parent().parent().children("td").get(3).innerHTML);
            dbname = $.trim($(this).parent().parent().children("td").get(4).innerHTML);
            dbuser = $.trim($(this).parent().parent().children("td").get(5).innerHTML);
            dbpwd = $.trim($(this).parent().parent().children("td").get(6).innerHTML);
            desc = $.trim($(this).parent().parent().children("td").get(7).innerHTML);
            count++;
        }
    });
    if (count > 1) {
        ShowMsg("一次只能编辑一个单元！");
        return false;
    }
    if (String(name).length == 0 || typeof name == "undefined") {  //或者这种形式if(obj === undefined)
        ShowMsg("请至少选择一个单元！");
        return false;
    }
    $("#add_id").val(id);
    $("#add_name").val(name);
    $("#add_ip").val(serverip);
    $("#add_dbname").val(dbname);
    $("#add_user").val(dbuser);
    $("#add_pass").val(dbpwd);
    $("#add_desc").val(desc);
    $('#svrgroup-add').dialog('open');
    return false;
}

function ShowAddForm() {
    EditReset();
    $('#svrgroup-add').dialog('open');
    return false;
}