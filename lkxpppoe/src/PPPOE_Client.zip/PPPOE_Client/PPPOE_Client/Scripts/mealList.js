﻿$(function () {
    $('#meal-add').dialog({
        autoOpen: false,
        width: 450,
        height: 420,
        modal: true,
        buttons: {
            "保存": SubContent,
            "取消": function () {
                $(this).dialog("close");
                EditReset();
            }
        }
    });
    //弹出添加用户对话框
    $('#btn_meal_add').click(function () {
        ShowAddForm();
    });
    $('#btn_meal_edit').click(function () {
        ShowEditForm();
    });
    $('#btn_meal_dele').click(function () {
        DeleMeal();
    });
});

function DeleMeal() {
    var idArr = [];
    var nameArr = [];
    $("#meal_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            idArr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = idArr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个套餐！");
        return false;
    }
    ShowMsg("确定要删除套餐【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/SysMgr/DeleMeal',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#meal_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function SubContent() {
    var type = $.trim($("#add_id").val());
    if (String(type).length == 0) {
        AddMeal();
    }
    else {
        EditMeal();
    }
}

function ShowEditForm() {
    var id, name, price, content, desc;
    var count = 0;
    EditReset();
    $("#meal_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            id = $.trim($(this).parent().parent().children("td").get(1).innerHTML);
            name = $.trim($(this).parent().parent().children("td").get(2).innerHTML);
            price = $.trim($(this).parent().parent().children("td").get(3).innerHTML);
            content = $.trim($(this).parent().parent().children("td").get(4).innerHTML);
            desc = $.trim($(this).parent().parent().children("td").get(5).innerHTML);
            count++;
        }
    });
    if (count > 1) {
        ShowMsg("一次只能编辑一个套餐！");
        return false;
    }
    if (String(name).length == 0 || typeof name == "undefined") {  //或者这种形式if(obj === undefined)
        ShowMsg("请至少选择一个套餐！");
        return false;
    }
    $("#add_id").val(id);
    $("#add_name").val(name);
    $("#add_price").val(price);
    $("#add_content").val(content);
    $("#add_desc").val(desc);
    $('#meal-add').dialog('open');
    return false;
}

function EditMeal() {
    var edit_id = $("#add_id").val();
    var edit_name = $("#add_name").val();
    var edit_price = $("#add_price").val();
    var edit_content = $("#add_content").val();
    var edit_desc = $("#add_desc").val();
    if (String(edit_name).length == 0 || String(edit_price).length == 0 || String(edit_content).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/EditMeal',
        dataType: 'json',
        data: { id: edit_id, name: edit_name, price: edit_price, content: edit_content, desc: edit_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#meal_list tr").find(":checkbox").each(function (i) {
                    if ($.trim(String($(this).parent().parent().children("td").get(1).innerHTML)) == data.id) {
                        $(this).parent().parent().children("td").get(2).innerHTML = data.name;
                        $(this).parent().parent().children("td").get(3).innerHTML = data.price;
                        $(this).parent().parent().children("td").get(4).innerHTML = data.content;
                        $(this).parent().parent().children("td").get(5).innerHTML = data.desc;
                    }
                });
            } catch (ex) {
                ajaxTips(ex.Message);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#meal-add").dialog("close");
}

function ShowAddForm() {
    EditReset();
    $('#meal-add').dialog('open');
    return false;
}

function AddMeal() {
    var add_name = $("#add_meal_name").val();
    var add_speed = $("#add_meal_speed").val();
    var add_month = $("#add_meal_month").val();
    var add_addmonth = $("#add_meal_addmonth").val();
    var add_time = $("#add_meal_time").val();
    var add_traffic = $("#add_meal_traffic").val();
    var add_price = $("#add_meal_price").val();
    var add_content = $("#add_meal_content").val();
    var add_desc = $("#add_meal_desc").val();
    if (String(add_name).length == 0 || Number(add_price) == "undefined" || Number(add_month) == "undefined" || Number(add_addmonth) == "undefined" || String(add_content).length == 0 || Number(add_speed) == "undefined") {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/AddMeal',
        dataType: 'json',
        data: { name: add_name, limitSpeed: add_speed, limitTraffic: add_traffic, limitTime: add_time, limitMonth: add_month, addMonth: add_addmonth, price: add_price, content: add_content, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try{
                $("#mealInfoTemp").render(data).appendTo("#meal_list");
            }catch(ex){
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#meal-add").dialog("close");
}

function MealInfo(cId, roleSpeed, roleTraffic, roleTime) {
    if (Number(cId) == "undefined" || Number(roleSpeed) == "undefined" || Number(roleTraffic) == "undefined" || Number(roleTime) == "undefined") {
        ShowMsg("条件不足！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/GetMealRole',
        dataType: 'json',
        data: { id: cId, roleSpeed: roleSpeed, roleTraffic: roleTraffic, roleTime: roleTime},
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if(data.id == 3) {
                ShowMsg(data.msg);
            } else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    ShowMsg(roleSpeed + cId + roleTraffic + roleTime);
}

function checkAll(evt) {
    $("#meal_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked);
    });
}

//清空重置
function EditReset() {
    $("#add_meal_id").val("");
    $("#add_meal_name").val("");
    $("#add_meal_speed").val("");
    $("#add_meal_month").val("");
    $("#add_meal_addmonth").val("");
    $("#add_meal_time").val("");
    $("#add_meal_traffic").val("");
    $("#add_meal_price").val("");
    $("#add_meal_content").val("");
    $("#add_meal_desc").val("");
}