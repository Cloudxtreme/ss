﻿//日志上报logClass  long qqNo, String ip, String action,String ScreenWH,String coordinate,String content
function logSubmit(event) {
    var action = $(this).attr("name");
    var explore = navigator.appName + ';' + navigator.appVersion; //浏览器名称、版本号
    var platform = navigator.platform;  //操作系统
    var cookieEnable = navigator.cookieEnabled;  //是否启用cookie
    var userAgent = navigator.userAgent; //用户代理
    var javaEnable = navigator.javaEnabled(); //是否启用Java
    var screenWH = screen.width + "*" + screen.height;  //屏幕大小
    var color = window.screen.colorDepth; //浏览器颜色
    var strHref = window.location.href;
    var mouseXY = event.pageX + "*" + event.pageY; //鼠标位置
    var myDate = new Date();   //时间
    $.post("../OpratelogHandler.ashx", {
        action: action,
        time: myDate.getTime(),
        explore: explore,
        platform: platform,
        cookie: cookieEnable,
        agent: userAgent,
        java: javaEnable,
        href: strHref,
        color: color,
        screen: screenWH,
        coordinate: mouseXY,
        X_Content_Type: "json"
    });
}

$(function () {
    $("#valiCode").bind("click", function () {
        this.src = "../Home/GetValidateCode?time=" + (new Date()).getTime();
    });
    $('#mylogin').live("click", login);
});

function reset() {
    $('#txt_user').val("");
    $('#txt_pwd').val("");
    $('#txt_code').val("");
}

function login() {
    var loginn = rtrim(ltrim(document.getElementById('txt_user').value));
    var loginp = rtrim(ltrim(document.getElementById('txt_pwd').value));
    var loginc = rtrim(ltrim(document.getElementById('txt_code').value));
    var logint = $('#user_level').find('option:selected').text();
    var cookie = $('#user_cookie').val();
    if (loginn == "") {
        document.getElementById('msg').innerHTML = "请输入用户名！";
        document.all('txt_user').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginp == "") {
        document.getElementById('msg').innerHTML = "请输入密码！";
        document.all('txt_pwd').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginp.length < 3) {
        document.getElementById('msg').innerHTML = "密码不能小于3位！";
        document.all('txt_pwd').focus();
        return false;
    }
    else {
        $("#msg").html("");
    }
    if (loginc == "" || loginc.length != 5) {
        document.getElementById('msg').innerHTML = "请输入正确的验证码！";
        document.all('txt_code').focus();
        return false;
    }
    $("#msg").html("正在验证中，请稍候...");
    $.ajax(
    {
        url: '/Home/CheckLogin',
        data: "user=" + loginn + "&pwd=" + loginp + "&code=" + loginc + "&type=" + logint + "&cookie=" + cookie,
        type: "POST",
        //contentType: "charset=utf-8",
        dataType: "text",
        success: function (data) {
            if (data == null || data.length == 0) {
                alert("验证失败！");
                return false;
            } else {
                if (data == "true") {
                    window.location = "../SysMgr/Index";
                }
                else {
                    document.getElementById('msg').innerHTML = data;
                }
            }
        },
        error: function (data) {
            alert(data.statusText);
        }
    });
}

function ltrim(s) {
    return s.replace(/^\s*/, "");
}
//去右空格; 
function rtrim(s) {
    return s.replace(/\s*$/, "");
}