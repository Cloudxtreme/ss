﻿$(function () {
    $('#group-add').dialog({
        autoOpen: false,
        width: 380,
        height: 200,
        modal: true,
        buttons: {
            "保存": SubContent,
            "取消": function () {
                $(this).dialog("close");
                EditReset();
            }
        }
    });
    //弹出添加用户对话框
    $('#btn_group_add').click(function () {
        ShowAddForm();
    });
    $('#btn_group_edit').click(function () {
        ShowEditForm();
    });
    $('#btn_group_dele').click(function () {
        DeleGroup();
    });
});

function DeleGroup() {
    var idArr = [];
    var nameArr = [];
    $("#group_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            idArr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = idArr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要删除客户【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/Client/DeleGroup',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#group_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function SubContent() {
    var type = $.trim($("#add_id").val());
    if (String(type).length == 0) {
        AddGroup();
    }
    else {
        EditGroup();
    }
}

function ShowEditForm() {
    var id, name, desc;
    var count = 0;
    EditReset();
    $("#group_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            id = $.trim($(this).parent().parent().children("td").get(1).innerHTML);
            name = $.trim($(this).parent().parent().children("td").get(2).innerHTML);
            desc = $.trim($(this).parent().parent().children("td").get(3).innerHTML);
            count++;
        }
    });
    if (count > 1) {
        ShowMsg("一次只能编辑一个区域！");
        return false;
    }
    if (String(name).length == 0 || typeof name == "undefined") {  //或者这种形式if(obj === undefined)
        ShowMsg("请至少选择一个区域！");
        return false;
    }
    $("#add_id").val(id);
    $("#add_name").val(name);
    $("#add_desc").val(desc);
    $('#group-add').dialog('open');
    return false;
}

function EditGroup() {
    var edit_id = $("#add_id").val();
    var edit_name = $("#add_name").val();
    var edit_desc = $("#add_desc").val();
    if (String(edit_name).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/EditGroup',
        dataType: 'json',
        data: { id: edit_id, name: edit_name, desc: edit_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#group_list tr").find(":checkbox").each(function (i) {
                    if ($.trim(String($(this).parent().parent().children("td").get(1).innerHTML)) == data.id) {
                        $(this).parent().parent().children("td").get(2).innerHTML = data.name;
                        $(this).parent().parent().children("td").get(3).innerHTML = data.desc;
                    }
                });
            } catch (ex) {
                ajaxTips(ex.Message);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#group-add").dialog("close");
}

function ShowAddForm() {
    EditReset();
    $('#group-add').dialog('open');
    return false;
}

function AddGroup() {
    var add_name = $("#add_name").val();
    var add_desc = $("#add_desc").val();
    if (String(add_name).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/AddGroup',
        dataType: 'json',
        data: { name: add_name, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#groupInfoTemp").render(data).appendTo("#group_list");
            } catch (ex) {
                ajaxTips(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#group-add').dialog("close");
}

function checkAll(evt) {
    $("#group_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked)
    });
}

//清空重置
function EditReset() {
    $("#add_id").val("");
    $("#add_name").val("");
    $("#add_desc").val("");
}