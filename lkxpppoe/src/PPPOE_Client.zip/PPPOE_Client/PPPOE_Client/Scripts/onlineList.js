﻿$(function () {
    //断开所选用户
    $('#btn_sum_kill').click(function () {
        KillSumConn();
    });
    //导出用户
    $('#btn_online_excel').click(function () {
        ExcelOnline();
    });
    var strHref = window.location.href;
    if (strHref.length > 0) {
        $('#search_group').val(strHref.getQuery("groupId"));
        $('#search_agent').val(strHref.getQuery("agentId"));
        $('#pageNum').val(strHref.getQuery("page"));
        if (strHref.getQuery("result") == "empty") {
            ShowMsg("数据为空，导出失败！");
            var sel_group = strHref.getQuery("groupId") == null ? 0 : strHref.getQuery("groupId");
            var sel_agent = strHref.getQuery("agentId") == null ? 0 : strHref.getQuery("agentId");
            var sel_page = strHref.getQuery("page") == null ? 1 : strHref.getQuery("page");
            window.location = "../Client/OnlineList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
        }
    }
});

//断开在线用户
function KillOneConn(evt) {
    var radius = $.trim($(evt).parent().parent().children("td").get(12).innerHTML);
    var user = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
    if (user.length <= 0 || typeof user == "undefined" || radius.length <= 0) {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要断开客户【" + user + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/Client/KillConn',
                dataType: 'json',
                data: { user: user, radius: radius },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {
                        $(evt).parent().parent().remove();
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
    });
}

function OnlineInfo(evt) {
    var id = $.trim($(evt).parent().parent().children("td").get(1).innerHTML);
    var user = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
}

function ExcelOnline() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    window.location = "../Client/OnlineExcel?groupId=" + sel_group + "&agentId=" + sel_agent;
}

function changePage() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/OnlineList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function selectAgent() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/OnlineList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function selectGroup() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/OnlineList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function server() {
    var ser = $("#searchInput").val();
    if (ser == "请输入账号搜索") {
        ser = "";
    }
    $("#saveSearch").val(ser);
    window.location = "../Client/OnlineList?ser=" + ser;
}

function checkAll(evt) {
    $("#online_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked); //$(this).removeAttr("checked"); 
    });
}