﻿$(function () {
    $('#addReport').dialog({
        autoOpen: false,
        width: 420,
        height: 450,
        modal: true,
        buttons: {
            "保存": addReport,
            "取消": function () {
                $(this).dialog("close");
            }
        }
    });
})

function add() {
    $('#addReport').dialog('open');
}

function addReport() {
    var user = $("#client_user").val();
    var recDate = $('#add_recDate').val();
    var desc = $('#meal_desc').val();
    var price = $('#client_meal_price').val();
    var frist = $('#client_meal_frist').val();
    var model = $('#client_meal_model').val();
    var dl = $('#client_meal_dl').val();
    var other = $('#client_meal_other').val();
//    if (typeof Number(mId) == 'undefined' || typeof Number(cId) == 'undefined') {
//        ShowMsg("条件非法！");
//        return false;
//    }
    if (String(recDate).length < 10) {
        ShowMsg("收费日期是必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/addReport',
        dataType: 'json',
        data: { user:user, recDate: recDate, desc: desc, price: price, frist: frist, model: model, dl: dl, other: other },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 3) {  //成功
                ShowMsg(data.msg);
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}


function selectReport() {
    var start = $("#date_start").val();
    var end = $("#date_end").val();
    $("#_start").val(start);
    $("#_end").val(end);
    var sel_page = $("#pageNum").val();
    window.location = "../Client/Report?begin=" + start + "&end=" + end + "&page=" + sel_page;
}
//导出excel
function toExcel() {
    //先声明Excel插件、Excel工作簿等对像
    var jXls, myWorkbook, myWorksheet;

    try {
        //插件初始化失败时作出提示
        jXls = new ActiveXObject('Excel.Application');
    } catch (e) {
        alert("无法启动Excel!\n\n如果您确信您的电脑中已经安装了Excel，" + "那么请调整IE的安全级别。\n\n具体操作：\n\n" + "工具 → Internet选项 → 安全 → 自定义级别 → 对没有标记为安全的ActiveX进行初始化和脚本运行 → 启用");
        return false;
    }

    //不显示警告 
    jXls.DisplayAlerts = false;

    //创建AX对象excel
    myWorkbook = jXls.Workbooks.Add();
    //myWorkbook.Worksheets(3).Delete();//删除第3个标签页(可不做)
    //myWorkbook.Worksheets(2).Delete();//删除第2个标签页(可不做)

    //获取DOM对像
    var curTb = document.getElementById("group_list");

    //获取当前活动的工作薄(即第一个)
    myWorksheet = myWorkbook.ActiveSheet;

    //设置工作薄名称
    myWorksheet.name = "收费明细";

    //获取BODY文本范围
    var sel = document.body.createTextRange();

    //将文本范围移动至DIV处
    sel.moveToElementText(curTb);

    //选中Range
   // sel.select();

    //清空剪贴板
    window.clipboardData.setData('text', '');

    //将文本范围的内容拷贝至剪贴板
    sel.execCommand("Copy");

    //将内容粘贴至工作簿
    myWorksheet.Paste();

    //打开工作簿
    jXls.Visible = true;

    //清空剪贴板
    window.clipboardData.setData('text', '');
    jXls = null; //释放对像
    myWorkbook = null; //释放对像
    myWorksheet = null; //释放对像
}

function changePage() {
//    var start = $("#_strat").val();
//    var end = $("#_end").val();

    var Request = new Object(); Request = GetRequest();
    var start, end;
    start = Request['begin']; 
    end = Request['end']; 

    var sel_page = $("#pageNum").val();
    window.location = "../Client/Report?begin=" + start + "&end=" + end + "&page=" + sel_page;
}

function GetRequest() {

    var url = location.search; //获取url中"?"符后的字串

    var theRequest = new Object();

    if (url.indexOf("?") != -1) {

        var str = url.substr(1);

        strs = str.split("&");

        for (var i = 0; i < strs.length; i++) {

            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);

        }

    }

    return theRequest;

}

