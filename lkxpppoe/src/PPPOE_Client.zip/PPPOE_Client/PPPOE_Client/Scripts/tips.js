﻿$.fn.extend({
    tips: function(options){
        var o = {
            delay: 200,
            tgClass: '',
            //eventType: 'click',
            margin: {l: 0, r: 0, b: 0, t: 0},
            offset: false
        };
        $.extend(o,options);
        
        var re = $(o.relation),
            reMaxWidth = o.reMaxWidth,
            margin = o.margin,
            aTimer = null,
            self = this;
        
        
        var show = function(){
        	clearTimeout(aTimer);
        	var offset = self.offset(), l, t;
        	switch(o.position){
	            case 'r':
	                
	                l = offset.left + self.outerWidth() + margin.l;
	                t = offset.top + margin.t;
	                
	            break;
	            
	            case 'l':
	                
	                l = offset.left - re.outerWidth() + margin.l;
	                t = offset.top + margin.t;
	            
	            break;
	            
	            case 'b':
	                
	                l = offset.left + margin.l;
	                t = offset.top + self.outerHeight() + margin.t;
	            
	            break;
	            
	            default: break;
	        }
	        
	        re.css({'left': l, 'top': t}).show();
        };
    	var hide = function(){
        	aTimer = setTimeout(function(){
                self.removeClass(o.tgClass);
                re.hide();
            },o.delay);
        };
    	
        if(o.eventType){
        	this.live(o.eventType,show);
        }
        
        this.live('mouseleave',hide);
        re.hover(
            function(){
                clearTimeout(aTimer);
                $(this).show();
            },
            function(){
                clearTimeout(aTimer);
                
                aTimer = setTimeout(function(){
                    self.removeClass(o.tgClass);
                    re.hide();
                },o.delay);
            }
        );

    }
});