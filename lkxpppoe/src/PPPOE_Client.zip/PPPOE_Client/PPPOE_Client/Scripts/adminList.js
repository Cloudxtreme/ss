﻿$(function () {
    $('#admin-add').dialog({
        autoOpen: false,
        width: 380,
        height: 240,
        modal: true,
        buttons: {
            "保存": SubContent,
            "取消": function () {
                $(this).dialog("close");
                EditReset();
            }
        }
    });
    //弹出添加用户对话框
    $('#btn_admin_add').click(function () {
        ShowAddForm();
    });
    $('#btn_admin_edit').click(function () {
        ShowEditForm();
    });
    $('#btn_admin_dele').click(function () {
        DeleAdmin();
    });
});

function DeleAdmin() {
    var idArr = [];
    var nameArr = [];
    $("#admin_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            idArr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = idArr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要删除用户【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/SysMgr/DeleAdmin',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#admin_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function SubContent() {
    var type = $.trim($("#add_id").val());
    if (String(type).length == 0) {
        AddAdmin();
    }
    else {
        EditAdmin();
    }
}

function ShowEditForm() {
    var id, name, levelId, desc;
    var count = 0;
    EditReset();
    $("#admin_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            id = $.trim($(this).parent().parent().children("td").get(1).innerHTML);
            name = $.trim($(this).parent().parent().children("td").get(2).innerHTML);
            desc = $.trim($(this).parent().parent().children("td").get(4).innerHTML);
            levelId = $.trim($(this).parent().parent().children("td").get(5).innerHTML);
            count++;
        }
    });
    if (count > 1) {
        ShowMsg("一次只能编辑一个用户！");
        return false;
    }
    if (String(name).length == 0 || typeof name == "undefined") {  //或者这种形式if(obj === undefined)
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    $("#add_id").val(id);
    $("#add_name").val(name);
    $("#add_level").val(levelId);
    $("#add_desc").val(desc);
    $('#admin-add').dialog('open');
    return false;
}

function EditAdmin() {
    var edit_id = $("#add_id").val();
    var edit_name = $("#add_name").val();
    var edit_level = $("#add_level").val();
    var edit_desc = $("#add_desc").val();
    if (String(edit_name).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/EditAdmin',
        dataType: 'json',
        data: { id: edit_id, name: edit_name, levelId: edit_level, level: edit_level,desc: edit_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#admin_list tr").find(":checkbox").each(function (i) {
                    if ($.trim(String($(this).parent().parent().children("td").get(1).innerHTML)) == data.id) {
                        $(this).parent().parent().children("td").get(2).innerHTML = data.name;
                        $(this).parent().parent().children("td").get(3).innerHTML = data.level;
                        $(this).parent().parent().children("td").get(4).innerHTML = data.desc;
                        $(this).parent().parent().children("td").get(5).innerHTML = data.levelId;
                    }
                });
            } catch (ex) {
                ajaxTips(ex.Message);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#admin-add").dialog("close");
}

function ShowAddForm() {
    EditReset();
    $('#admin-add').dialog('open');
    return false;
}

function AddAdmin() {
    var add_name = $("#add_name").val();
    var add_level = $("#add_level").val();
    var add_pass = $("#add_pass").val();
    var add_desc = $("#add_desc").val();
    if (String(add_name).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/SysMgr/AddAdmin',
        dataType: 'json',
        data: { name: add_name, pass: add_pass, level: add_level, levelId: add_level, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#adminInfoTemp").render(data).appendTo("#admin_list");
            } catch (ex) {
                ajaxTips(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#admin-add").dialog("close");
}

function checkAll(evt) {
    $("#admin_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked)
    });
}

//清空重置
function EditReset() {
    $("#add_id").val("");
    $("#add_name").val("");
    $("#add_pass").val("");
    $("#add_level").get(0).selectedIndex = 0; 
    $("#add_desc").val("");
}