﻿$(function () {
    //导出用户
    $('#btn_false_excel').click(function () {
        ExcelFalseClient();
    });
    var strHref = window.location.href;
    if (strHref.length > 0) {
        $('#search_group').val(strHref.getQuery("groupId"));
        $('#search_agent').val(strHref.getQuery("agentId"));
        $('#pageNum').val(strHref.getQuery("page"));
        if (strHref.getQuery("result") == "empty") {
            ShowMsg("数据为空，导出失败！");
            var sel_group = strHref.getQuery("groupId") == null ? 0 : strHref.getQuery("groupId");
            var sel_agent = strHref.getQuery("agentId") == null ? 0 : strHref.getQuery("agentId");
            var sel_page = strHref.getQuery("page") == null ? 1 : strHref.getQuery("page");
            window.location = "../Client/FalseClient?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
        }
    }
});

function ExcelFalseClient() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    window.location = "../Client/FalseClientExcel?groupId=" + sel_group + "&agentId=" + sel_agent;
}

function changePage() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/FalseClient?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function selectAgent() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/FalseClient?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function selectGroup() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/FalseClient?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function checkAll(evt) {
    $("#false_client_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked); //$(this).removeAttr("checked"); 
    });
}