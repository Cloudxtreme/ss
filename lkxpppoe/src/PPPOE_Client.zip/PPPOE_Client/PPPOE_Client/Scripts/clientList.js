﻿$(function () {
    $('#client-add').dialog({
        autoOpen: false,
        width: 420,
        height: 450,
        modal: true,
        buttons: {
            "保存": SubContent,
            "取消": function () {
                $(this).dialog("close");
            }
        }
    });
    $('#client-mulAdd').dialog({
        autoOpen: false,
        width: 420,
        height: 288,
        modal: true,
        buttons: {
            "保存": MulAddClient,
            "取消": function () {
                $(this).dialog("close");
            }
        }
    });
    $('#client-meal').dialog({
        autoOpen: false,
        width: 510,
        height: 620,
        modal: true,
        buttons: {
            "保存": SaveMeal,
            "取消": function () {
                $('#client_meal_id').val("");
                $(this).dialog("close");
            }
        }
    });
    $('#client-pwd').dialog({
        autoOpen: false,
        width: 350,
        height: 210,
        modal: true,
        buttons: {
            "保存": ChgPwd,
            "取消": function () {
                $('#chg_id').val("");
                $('#chg_user').val("");
              //  $('#old_pwd').val("");
                $('#new_pwd').val("");
                $('#new_pwd_confirm').val("");
                $(this).dialog("close");
            }
        }
    });
    //弹出添加用户对话框
    $('#btn_client_add').click(function () {
        ShowAddForm();
    });
    //弹出批量添加用户对话框
    $('#btn_client_mulAdd').click(function () {
        ShowMulAddForm();
    });
    //编辑选中的用户
    $('#btn_client_edit').click(function () {
        ShowEditForm();
    });
    //删除所选用户
    $('#btn_client_dele').click(function () {
        DeleClient();
    });
    //禁用所选用户
    $('#btn_client_stop').click(function () {
        StopClient();
    });
    //导出用户
    $('#btn_client_excel').click(function () {
        ExcelClient();
    });
    //重置按钮
    $('#btn_Reset').click(function () {
        ClientReset();
    });
    var strHref = window.location.href;
    if (strHref.length > 0) {
        $('#search_group').val(strHref.getQuery("groupId"));
        $('#search_agent').val(strHref.getQuery("agentId"));
        $('#pageNum').val(strHref.getQuery("page"));
        if (strHref.getQuery("result") == "empty") {
            ShowMsg("数据为空，导出失败！");
            var sel_group = strHref.getQuery("groupId") == null ? 0 : strHref.getQuery("groupId");
            var sel_agent = strHref.getQuery("agentId") == null ? 0 : strHref.getQuery("agentId");
            var sel_page = strHref.getQuery("page") == null ? 1 : strHref.getQuery("page");
            window.location = "../Client/ClientList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
        }
    }
    //$("#pwd_chg").button();
});

function ChgAgent() {
    var agent = $("#add_agent").val();
    if (String(agent).length == 0) {
        return false;
    }
    $("#add_radius").empty();
    $.ajax({
        url: '/Client/GetSvrgroupByAgent',
        dataType: 'json',
        data: { aId: Number(agent) },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 3) {
                $(data.msg).appendTo("#add_radius");
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function ChgMulAgent() {
    var agent = $("#mulAdd_agent").val();
    if (String(agent).length == 0) {
        return false;
    }
    $("#mulAdd_radius").empty();
    $.ajax({
        url: '/Client/GetSvrgroupByAgent',
        dataType: 'json',
        data: { aId: Number(agent) },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 3) {
                $(data.msg).appendTo("#mulAdd_radius");
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function ShowChgPwd(evt) {
    $('#chg_id').val("");
    $('#chg_user').val("");
    $('#old_pwd').val("");
    $('#new_pwd').val("");
    $('#new_pwd_confirm').val("");
    var id = $.trim($(evt).parent().parent().children("td").get(1).innerHTML);
    var user = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
    if (id.length <= 0 || typeof id == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    $('#chg_id').val(id);
    $('#chg_user').val(user);
    $('#client-pwd').dialog('open');
}

function ChgPwd() {
    var id = $('#chg_id').val();
    //var user = $('#chg_user').val();
   // var old_pwd = $('#old_pwd').val();
    var new_pwd = $('#new_pwd').val();
    var new_pwd_confirm = $('#new_pwd_confirm').val();
    if (id.length <= 0 || typeof id == "undefined" || new_pwd.length <= 0 || new_pwd_confirm.length <= 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    if (new_pwd != new_pwd_confirm) {
        ShowMsg("密码输入不一致！");
        return false;
    }
    $.ajax({
        url: '/Client/ChgClientPwd',
        dataType: 'json',
        data: { id: id, newpwd: new_pwd },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            ShowMsg(data.id + "." + data.msg);
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $('#client-pwd').dialog('close');
}

function ClientSetMeal(evt) {
    $('#client_meal_id').val("");
    $("#meal_type").get(0).selectedIndex = 0;
    $('#add_date_start').val("");
    $('#meal_desc').val(""); 
    var id = $.trim($(evt).parent().parent().children("td").get(1).innerHTML);
    var user = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
    if (id.length <= 0 || typeof id == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    $.ajax({
        url: '/Client/GetClientMeal',
        dataType: 'json',
        data: { id: id },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 3) {
                $('#client_meal_id').val(id);
                $('#client_meal_user').val(user);
                $('#client_meal_name').html(data.msg);
                $('#client-meal').dialog('open');
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function SaveMeal() {
    //var type = $('#role_type').find('option:selected').text();
    var mId = $('#meal_type').val();
    var cId = $('#client_meal_id').val();
    var start_date = $('#add_date_start').val();
    var recDate = $('#add_recDate').val();
    var desc = $('#meal_desc').val();
    var price = $('#client_meal_price').val();
    var frist = $('#client_meal_frist').val();
    var model = $('#client_meal_model').val();
    var dl = $('#client_meal_dl').val();
    var other = $('#client_meal_other').val();
    var addMonth = $('#add_month').val();
    if (typeof Number(mId) == 'undefined' || typeof Number(cId) == 'undefined') {
        ShowMsg("条件非法！");
        return false;
    }
    if (String(start_date).length < 10 || String(recDate).length < 10) {
        ShowMsg("生效日期或收费日期是必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/BindClientMeal',
        dataType: 'json',
        data: { cId: cId, mId: mId, start: start_date,recDate:recDate ,desc: desc, price: price, frist: frist, model: model, dl:dl,other: other, addMonth: addMonth },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 3) {  //绑定成功
                $('#client_meal_name').html(data.msg);
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function ExcelClient() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    window.location = "../Client/ClientExcel?groupId=" + sel_group + "&agentId=" + sel_agent;
}

function DeleClient() {
    var arr = [];
    var nameArr = [];
    $("#client_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            arr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = arr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要删除客户【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/Client/DeleClient',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#client_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function StopClient() {
    var arr = [];
    var nameArr = [];
    $("#client_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            arr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = arr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要禁用客户【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/Client/StopClient',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#client_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function ClientReset() {
    var userid = $("#add_id").val();
    var radiusid = $("#radiusid").val();
    var username = $("#client_meal_user").val();

      $.ajax({
        url: '/Client/ClientReset',
        dataType: 'json',
        data: { userid:userid,user:username,radiusid:radiusid  },
        type: 'POST',
        beforeSend: ajaxTips("数据重置中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            if (data.id == 1) {  //重置成功
                ShowMsg("重置成功");
            }    
            },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}


function client_reup() {
    var arr = [];
    var nameArr = [];
    $("#client_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            arr.push($.trim($(this).parent().parent().children("td").get(1).innerHTML));
            nameArr.push($.trim($(this).parent().parent().children("td").get(2).innerHTML));
        }
    });
    var result = arr.join(',');
    var nameStr = nameArr.join(',');
    if (result.length <= 0 || typeof result == "undefined") {
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    ShowMsg("确定要启用客户【" + nameStr + "】吗？", function (yes) {
        if (yes) {
            $.ajax({
                url: '/Client/ReupClient',
                dataType: 'json',
                data: { id: result },
                type: 'POST',
                beforeSend: ajaxTips("数据加载中..."),
                complete: ajaxTips("操作成功返回！"),
                success: function (data) {
                    ShowMsg(data.id + "." + data.msg);
                    if (data.id == 3) {  //全部删除成功
                        $("#client_list tr").find(":checkbox").each(function (i) {
                            if ($(this).attr("checked")) {
                                $(this).parent().parent().remove();
                            }
                        });
                    }
                },
                error: function (data) {
                    ajaxTips(data.statusText);
                }
            });
        }
        return false;
    });
}

function SubContent() {
    var type = $.trim($("#add_id").val());
    if(String(type).length == 0){
        AddClient();
    }
    else{
        EditClient();
    }
}

function ShowEditForm() {
    var id, name, realname, phone, addr, code, email, qq, desc, groupId, agentId, gfqPort, mac;
    var count = 0;
    $("#client_list tr").find(":checkbox").each(function (i) {
        if ($(this).attr("checked")) {
            id = $.trim($(this).parent().parent().children("td").get(1).innerHTML);
            name = $.trim($(this).parent().parent().children("td").get(2).innerHTML);
            realname = $.trim($(this).parent().parent().children("td").get(3).innerHTML);
            phone = $.trim($(this).parent().parent().children("td").get(4).innerHTML);
            inpoint = $.trim($(this).parent().parent().children("td").get(5).innerHTML);
            addr = $.trim($(this).parent().parent().children("td").get(6).innerHTML);
            code = $.trim($(this).parent().parent().children("td").get(7).innerHTML);
            email = $.trim($(this).parent().parent().children("td").get(8).innerHTML);
            qq = $.trim($(this).parent().parent().children("td").get(9).innerHTML);
            desc = $.trim($(this).parent().parent().children("td").get(10).innerHTML);
            groupId = $.trim($(this).parent().parent().children("td").get(11).innerHTML);
            agentId = $.trim($(this).parent().parent().children("td").get(12).innerHTML);
            radiusId = $.trim($(this).parent().parent().children("td").get(13).innerHTML);
            gfqPort = $.trim($(this).parent().parent().children("td").get(14).innerHTML);
            mac = $.trim($(this).parent().parent().children("td").get(15).innerHTML);
            count++;
        }
    });
    if (count > 1) {
        ShowMsg("一次只能编辑一个用户！");
        return false;
    }
    if (String(name).length == 0 || typeof name == "undefined") {  //或者这种形式if(obj === undefined)
        ShowMsg("请至少选择一个用户！");
        return false;
    }
    EditReset();
    $("#add_id").val(id);
    $("#add_user").val(name);
    $("#add_user").attr("readonly", true);
    $("#pwd_chg").attr("disabled", false);
    $("#add_pwd").hide();
    $("#add_pwd_confirm").hide();
    $("#add_meal").hide();
    $("#add_group").val(groupId);
    $("#add_agent").val(agentId);
    //$("#add_group").get(0).value = groupId;  //这种写法也是可以的
    $("#add_realname").val(realname);
    $("#add_addr").val(addr);
    $("#add_phone").val(phone);
    $("#add_inpoint").val(inpoint);
    $("#add_codenum").val(code);
    $("#add_email").val(email);
    $("#add_qq").val(qq);
    $("#add_desc").val(desc);
    $("#add_gfqPort").val(gfqPort);
    $("#add_Mac").val(mac);
    $.ajax({
        url: '/Client/GetSvrgroupByAgent',
        dataType: 'json',
        data: { aId: Number(agentId) },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            $("#add_radius").empty();
            if (data.id == 3) {
                $(data.msg).appendTo("#add_radius");
                $("#add_radius").val(radiusId);
            }
            else {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    //$('#client-add').attr("title", "编辑用户");
    //$('#client-add').dialog.title = '编辑用户';
    $('#client-add').dialog('open');
    return false;
}

function EditClient() {
    var add_id = $("#add_id").val();
    var add_user = $("#add_user").val();
    var add_group = $("#add_group").val(); //直接获取选中的value值
    var add_agent = $("#add_agent").val();
    var add_radius = $("#add_radius").val();
    var add_inpoint = $("#add_inpoint").val();
    var add_realname = $("#add_realname").val();
    var add_address = $("#add_addr").val();
    var add_phoneNum = $("#add_phone").val();
    var add_codeNum = $("#add_codenum").val();
    var add_email = $("#add_email").val();
    var add_qq = $("#add_qq").val();
    var add_gfqPort = $("#add_gfqPort").val();
    var add_Mac = $("#add_Mac").val();
    var add_desc = $("#add_desc").val();
    if (String(add_user).length == 0 || String(add_realname).length == 0 || String(add_phoneNum).length == 0 || String(add_radius).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/EditClient',
        dataType: 'json',
        data: { id: add_id, user: add_user, group: add_group, agent: add_agent, radius: add_radius, inpoint: add_inpoint, realname: add_realname, address: add_address, phoneNum: add_phoneNum, codeNum: add_codeNum, email: add_email, qq: add_qq, gfqPort: add_gfqPort, Mac: add_Mac, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            //更新列表数据
            try {
                $("#client_list tr").find(":checkbox").each(function (i) {
                    if ($.trim(String($(this).parent().parent().children("td").get(1).innerHTML)) == data.id) {
                        $(this).parent().parent().children("td").get(2).innerHTML = data.user;
                        $(this).parent().parent().children("td").get(3).innerHTML = data.realname;
                        $(this).parent().parent().children("td").get(4).innerHTML = data.phoneNum;
                        $(this).parent().parent().children("td").get(5).innerHTML = data.inpoint;
                        $(this).parent().parent().children("td").get(6).innerHTML = data.address;
                        $(this).parent().parent().children("td").get(7).innerHTML = data.codeNum;
                        $(this).parent().parent().children("td").get(8).innerHTML = data.email;
                        $(this).parent().parent().children("td").get(9).innerHTML = data.qq;
                        $(this).parent().parent().children("td").get(10).innerHTML = data.desc;
                        $(this).parent().parent().children("td").get(11).innerHTML = data.group;
                        $(this).parent().parent().children("td").get(12).innerHTML = data.agent;
                        $(this).parent().parent().children("td").get(13).innerHTML = data.radius;
                    }
                });
            } catch (ex) {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
    $("#client-add").dialog("close");
}

function doEditClient() {
    var add_id = $("#add_id").val();
    var add_user = $("#add_user").val();
    var add_group = $("#add_group").val(); //直接获取选中的value值
    var add_agent = $("#add_agent").val();
    var add_radius = $("#add_radius").val();
    var add_inpoint = $("#add_inpoint").val();
    var add_realname = $("#add_realname").val();
    var add_address = $("#add_addr").val();
    var add_phoneNum = $("#add_phone").val();
    var add_codeNum = $("#add_codenum").val();
    var add_email = $("#add_email").val();
    var add_qq = $("#add_qq").val();
    var add_gfqPort = $("#add_gfqPort").val();
    var add_Mac = $("#add_Mac").val();
    var add_desc = $("#add_desc").val();
    if (String(add_user).length == 0 || String(add_realname).length == 0 || String(add_phoneNum).length == 0 || String(add_radius).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/EditClient',
        dataType: 'json',
        data: { id: add_id, user: add_user, group: add_group, agent: add_agent, radius: add_radius, inpoint: add_inpoint, realname: add_realname, address: add_address, phoneNum: add_phoneNum, codeNum: add_codeNum, email: add_email, qq: add_qq, gfqPort: add_gfqPort, Mac: add_Mac, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            //更新列表数据
            //$('#client_meal_name').html(data.msg);
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function ShowAddForm() {
    EditReset();
    $("#pwd_chg").attr("disabled", "");
    $("#add_pwd").show();
    $("#add_pwd_confirm").show();
    $('#client-add').dialog('open');
    return false;
}

function ShowMulAddForm() {
    EditReset();
    $("#pwd_chg").attr("disabled", "");
    $("#mulAdd_pwd").show();
    $("#mulAdd_pwd_confirm").show();
    $('#client-mulAdd').dialog('open');
    return false;
}

function AddClient() {
    var add_user = $("#add_user").val();
    var add_group = $("#add_group").val();
    var add_agent = $("#add_agent").val();
    var add_radius = $("#add_radius").val();
    var add_meal = $("#add_meal").val();
    var add_pwd = $("#add_pwd").val();
    var add_pwd_confirm = $("#add_pwd_confirm").val();
    var add_realname = $("#add_realname").val();
    var add_address = $("#add_addr").val();
    var add_inpoint = $("#add_inpoint").val();
    var add_phoneNum = $("#add_phone").val();
    var add_cardtype = $("#add_cardtype").val();
    var add_codeNum = $("#add_codenum").val();
    var add_email = $("#add_email").val();
    var add_qq = $("#add_qq").val();
    var add_gfqPort = $("#add_gfqPort").val();
    var add_Mac = $("#add_Mac").val();
    var add_desc = $("#add_desc").val();
    if (add_pwd != add_pwd_confirm) {
        ShowMsg("密码输入不一致！");
        return false;
    }
    if (String(add_user).length == 0 || String(add_pwd).length == 0 || String(add_realname).length == 0 || String(add_phoneNum).length == 0 || String(add_radius).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    $.ajax({
        url: '/Client/AddClient',
        dataType: 'json',
        data: { user: add_user, pwd: add_pwd, group: add_group, agent: add_agent, radius: add_radius, inpoint: add_inpoint, meal: add_meal, realname: add_realname, address: add_address, phoneNum: add_phoneNum, cardType: add_cardtype, codeNum: add_codeNum, email: add_email, qq: add_qq, gfqPort: add_gfqPort, Mac: add_Mac, desc: add_desc },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try{
                $("#clientInfoTemp").render(data).appendTo("#client_list");
                $("#client-add").dialog("close");
                EditReset();
            }catch(ex){
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function MulAddClient() {
    var add_user1 = $("#mulAdd_user1").val();
    var add_user2 = $("#mulAdd_user2").val();
    var add_group = $("#mulAdd_group").val();
    var add_agent = $("#mulAdd_agent").val();
    var add_radius = $("#mulAdd_radius").val();
    var add_mealid = $("#mul_add_meal").val();
    var add_pwd = $("#mulAdd_pwd").val();
    var add_pwd_confirm = $("#mulAdd_pwd_confirm").val();
    if (add_pwd != add_pwd_confirm) {
        ShowMsg("密码输入不一致！");
        return false;
    }
    if (String(add_user1).length == 0 || String(add_user2).length == 0 || String(add_pwd).length == 0 || String(add_radius).length == 0) {
        ShowMsg("带星号的为必填项！");
        return false;
    }
    if (!((/^(\+|-)?\d+$/.test(add_user2)) || add_user2 < 0) || !((/^(\+|-)?\d+$/.test(add_user1)) || add_user1 < 0)) {
        ShowMsg("账号输入格式错误！");
        return false;
    }
    $.ajax({
        //url: '/Client/mulAddClient',
        url: '/Client/mulAddClient',
        dataType: 'json',
        data: { user1: add_user1, user2: add_user2, pwd: add_pwd, group: add_group, agent: add_agent, radius: add_radius, mealid: add_mealid },
        type: 'POST',
        beforeSend: ajaxTips("数据加载中..."),
        complete: ajaxTips("操作成功返回！"),
        success: function (data) {
            try {
                $("#clientInfoTemp").render(data).appendTo("#client_list");
                $("#client-mulAdd").dialog("close");
                EditReset();
            } catch (ex) {
                ShowMsg(data.id + "." + data.msg);
            }
        },
        error: function (data) {
            ajaxTips(data.statusText);
        }
    });
}

function InfoDetail(evt) {
    var name = $.trim($(evt).parent().parent().children("td").get(2).innerHTML);
    var codeNum = $.trim($(evt).parent().parent().children("td").get(6).innerHTML);
    var email = $.trim($(evt).parent().parent().children("td").get(7).innerHTML);
    var qq = $.trim($(evt).parent().parent().children("td").get(8).innerHTML);
    ShowMsg("用户名：" + name + "<br />证件号码：" + codeNum + "<br />电子邮箱：" + email + "<br />常用QQ：" + qq);
}

function checkAll(evt) {
    $("#client_list tr").find(":checkbox").each(function (i) {
        $(this).attr("checked", evt.checked); //$(this).removeAttr("checked"); 
    });
}

//清空重置
function EditReset() {
    $("#add_id").val("");
    $("#add_user").val("");
    $("#add_user").attr("readonly", false);
    $("#add_group").get(0).selectedIndex = 0; //设置为第一个选项
    $("#add_agent").get(0).selectedIndex = 0;
    $("#add_pwd").val("");
    $("#add_pwd_confirm").val("");
    $("#add_realname").val("");
    $("#add_addr").val("");
    $("#add_phone").val("");
    $("#add_codenum").val("");
    $("#add_email").val("");
    $("#add_qq").val("");
    $("#add_desc").val("");
}

function changePage() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/ClientList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function fchangePage() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/ForbidClient?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function selectAgent() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/ClientList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function selectGroup() {
    var sel_group = $("#search_group").val();
    var sel_agent = $("#search_agent").val();
    var sel_page = $("#pageNum").val();
    window.location = "../Client/ClientList?groupId=" + sel_group + "&agentId=" + sel_agent + "&page=" + sel_page;
}

function server() {
    var ser = $("#searchInput").val();
    if (ser == "请输入账号搜索") {
        ser = "";
    }
    window.location = "../Client/ClientList?ser=" + ser;
}

//循环取表格某一列数据
//    var arr = [];
//    $("#client_list tr td:nth-child(2)").each(function (key, value) {
//        arr.push($(this).html());
//    });
//var result = arr.join(',');