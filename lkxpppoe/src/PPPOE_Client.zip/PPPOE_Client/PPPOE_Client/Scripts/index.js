﻿
function test() {
    ajaxTips("数据加载中...");
}